import {
    registerUser,
    loginUser
} from "./auth.js";

import {
    sendEmailVerification,
    browserLocalPersistence,
    browserSessionPersistence,
    setPersistence,
    signOut
} from "https://www.gstatic.com/firebasejs/12.19.0/firebase-auth.js";

import {
    doc,
    getDoc,
    getDocs,
    setDoc,
    addDoc,
    updateDoc,
    deleteDoc,
    collection,
    query,
    where,
    onSnapshot,
    serverTimestamp,
    arrayUnion,
    arrayRemove,
    orderBy,
    limit
} from "https://www.gstatic.com/firebasejs/12.19.0/firebase-firestore.js";

import {
    db,
    auth
} from "./firebase.js";

import {
    getMessaging,
    getToken,
    onMessage,
    deleteToken,
    isSupported
} from "https://www.gstatic.com/firebasejs/12.19.0/firebase-messaging.js";

import { app } from "./firebase.js";


console.log("Enclave avviato correttamente.");


// =========================
// FUNZIONI SCHERMATE
// =========================

const startupScreen =
    document.getElementById("startupScreen");

const registerScreen =
    document.getElementById("registerScreen");

const loginScreen =
    document.getElementById("loginScreen");

const homeScreen =
    document.getElementById("homeScreen");

const verificationOverlay =
    document.getElementById("verificationOverlay");

const verificationEmail =
    document.getElementById("verificationEmail");

const verificationMessage =
    document.getElementById("verificationMessage");

const verificationSpinner =
    document.getElementById("verificationSpinner");

const userEnclaveId =
    document.getElementById("userEnclaveId");

const userNickname =
    document.getElementById("userNickname");

const profileNickname =
    document.getElementById("profileNickname");

const profileEnclaveId =
    document.getElementById("profileEnclaveId");

const profileInitial =
    document.getElementById("profileInitial");

const resendVerificationButton =
    document.getElementById("resendVerificationButton");

const chatEmptyState =
    document.getElementById("chatEmptyState");

const activeChat =
    document.getElementById("activeChat");

const chatUserAvatar =
    document.getElementById("chatUserAvatar");

const chatUserNickname =
    document.getElementById("chatUserNickname");

const chatUserId =
    document.getElementById("chatUserId");

const chatUserInfo =
    document.querySelector(".chat-user-info");

const chatBackButton =
    document.getElementById("chatBackButton");

const startVoiceCallButton =
    document.getElementById("startVoiceCallButton");

let activeVoiceCall = null;
let unsubscribeIncomingCalls = null; // listener globale delle chat dell'utente
let incomingVoiceCallListeners = new Map();
let incomingCallIndicators = new Map();
let incomingVoiceCallUserUid = null;
let unsubscribeCallCandidates = [];
let voiceCallModal = null;
// Evita che una chiamata appena chiusa riappaia mentre il telefono si risveglia.
let silencedIncomingCallIds = new Map();
// Invalida un accesso al microfono ancora in corso se la chiamata viene chiusa.
let voiceCallSession = 0;

const homeMain =
    document.querySelector(".home-main");

const chatArea =
    document.querySelector(".chat-area");

const chatSidebar =
    document.querySelector(".chat-sidebar");

const chatMessages =
    document.getElementById("chatMessages");

// Indicatore del giorno attivo nella cronologia della chat.
let activeChatDayIndicator = null;

function formatChatDayLabel(date) {
    if (!(date instanceof Date) || Number.isNaN(date.getTime())) return "";

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    const messageDay = new Date(date);
    messageDay.setHours(0, 0, 0, 0);

    if (messageDay.getTime() === today.getTime()) return "Oggi";
    if (messageDay.getTime() === yesterday.getTime()) return "Ieri";

    return messageDay.toLocaleDateString("it-IT", {
        day: "numeric",
        month: "short",
        year: "numeric"
    }).replace(/\./g, "");
}

function updateChatDayIndicator() {
    if (!activeChatDayIndicator || !chatMessages) return;

    const messageElements = Array.from(
        chatMessages.querySelectorAll(":scope > .message")
    );

    if (!messageElements.length) {
        activeChatDayIndicator.textContent = "";
        activeChatDayIndicator.classList.add("hidden");
        return;
    }

    const containerTop = chatMessages.getBoundingClientRect().top;
    const visibleThreshold = containerTop + 48;
    let currentMessage = messageElements.find(element =>
        element.getBoundingClientRect().bottom >= visibleThreshold
    );

    if (!currentMessage) currentMessage = messageElements[messageElements.length - 1];

    const timestamp = currentMessage?._enclaveMessage?.createdAt;
    const messageDate = timestamp?.toDate?.() || (timestamp instanceof Date ? timestamp : null);
    const label = formatChatDayLabel(messageDate);

    activeChatDayIndicator.textContent = label;
    activeChatDayIndicator.classList.toggle("hidden", !label);
}

if (chatMessages) {
    chatMessages.addEventListener("scroll", updateChatDayIndicator, { passive: true });
}

const messageInput =
    document.getElementById("messageInput");

const sendMessageButton =
    document.getElementById("sendMessageButton");

const messageAttachButton =
    document.getElementById("messageAttachButton");

const messageAttachMenu =
    document.getElementById("messageAttachMenu");

const chatInputArea =
    document.querySelector(".chat-input-area");

const ENCLAVE_STORAGE_WORKER_URL =
    "https://enclave-storage.gpvyw7wnf8.workers.dev";

const activeMediaObjectUrls = new Set();
const protectedMediaObjectUrlCache = new Map();
const MAX_CACHED_MEDIA_OBJECT_URLS = 40;

const mediaFileInput = document.createElement("input");
mediaFileInput.type = "file";
mediaFileInput.accept = "image/jpeg,image/png,image/webp,image/gif,image/avif";
mediaFileInput.hidden = true;
mediaFileInput.setAttribute("aria-label", "Seleziona un'immagine");
document.body.appendChild(mediaFileInput);

const chatSearch =
    document.getElementById("chatSearch");

const searchResults =
    document.getElementById("searchResults");

const newGroupButton =
    document.getElementById("newGroupButton");

const notificationsOverlay =
    document.getElementById("notificationsOverlay");

const activateNotificationsButton =
    document.getElementById("activateNotificationsButton");

const skipNotificationsButton =
    document.getElementById("skipNotificationsButton");

const notificationsPopupMessage =
    document.getElementById("notificationsPopupMessage");



let currentChatUserUid = null;

let currentChatId = null;
// Indica se il documento Firestore della chat aperta esiste già.
let currentChatDocumentExists = false;

// Tema globale personale: un unico colore per le bolle in tutte le chat e i gruppi.
let currentUserChatTheme = "#111111";
let themeSaveQueue = Promise.resolve();

// Sfondo globale personale: viene salvato nel profilo Firestore, non in Storage.
let currentUserChatWallpaper = "";
let wallpaperSaveQueue = Promise.resolve();

// Per aggiungere uno sfondo: inserisci qui un elemento e carica il file indicato in /images.
// Usa un ID stabile (es. wallpaper2) e un nome file con estensione (es. wallpaper2.jpg).
const ENCLAVE_WALLPAPERS = [
    { id: "wallpaper1", name: "Ethereal Horizon", category: "realistici", src: "./images/wallpaper1.jpg" },
    { id: "wallpaper2", name: "Noir Atmosphere", category: "realistici", src: "./images/wallpaper2.jpg" },
    { id: "wallpaper3", name: "Crimson Galaxy", category: "realistici", src: "./images/wallpaper3.jpg" },
    { id: "wallpaper4", name: "Cyber Pastel", category: "realistici", src: "./images/wallpaper4.jpg" },
    { id: "wallpaper5", name: "Midnight Electric", category: "realistici", src: "./images/wallpaper5.jpg" },
    { id: "wallpaper6", name: "Emerald Nebula", category: "realistici", src: "./images/wallpaper6.jpg" },
    { id: "wallpaper7", name: "Amber Cosmos", category: "realistici", src: "./images/wallpaper7.jpg" },
    { id: "wallpaper8", name: "Nero", category: "monocolore", src: "./images/wallpaper_mono5.jpg" },
    { id: "wallpaper9", name: "Bordeaux", category: "monocolore", src: "./images/wallpaper_mono3.jpg" },
    { id: "wallpaper10", name: "Marrone", category: "monocolore", src: "./images/wallpaper_mono4.jpg" },
    { id: "wallpaper11", name: "Azzurro", category: "monocolore", src: "./images/wallpaper_mono2.jpg" },
    { id: "wallpaper12", name: "Rosa", category: "monocolore", src: "./images/wallpaper_mono1.jpg" },

];

const ENCLAVE_CHAT_THEMES = [
    { name: "Rosso", color: "#D9303E" },
    { name: "Arancione", color: "#E87522" },
    { name: "Giallo oro", color: "#C79613" },
    { name: "Verde", color: "#268B4A" },
    { name: "Blu", color: "#2878D0" },
    { name: "Tiffany", color: "#0ABAB5" },
    { name: "Viola", color: "#8059C9" },
    { name: "Rosa", color: "#D65391" },
    { name: "Marrone", color: "#986747" },
    { name: "Nero", color: "#111111" }
];

let unsubscribeMessages = null;

// Evita che il caricamento asincrono di una vecchia chat sovrascriva quella appena aperta.
let messagesLoadVersion = 0;

let unsubscribeChats = null;

let conversationsRenderVersion = 0;

// Cache breve dei profili pubblici: evita di rileggere da Firestore gli stessi
// nickname a ogni aggiornamento della lista chat. Scade automaticamente e viene
// invalidata subito quando l'utente cambia il proprio nickname.
const publicUserSnapshotCache = new Map();
const PUBLIC_USER_CACHE_TTL_MS = 30_000;

async function getCachedPublicUserSnapshot(uid) {
    const now = Date.now();
    const cached = publicUserSnapshotCache.get(uid);

    if (cached && cached.expiresAt > now) {
        return cached.promise;
    }

    const promise = getDoc(doc(db, "publicUsers", uid)).catch((error) => {
        publicUserSnapshotCache.delete(uid);
        throw error;
    });

    publicUserSnapshotCache.set(uid, {
        promise,
        expiresAt: now + PUBLIC_USER_CACHE_TTL_MS
    });

    return promise;
}

function invalidatePublicUserSnapshot(uid) {
    publicUserSnapshotCache.delete(uid);
}

let unsubscribeReadStates = [];

let unreadMessageListeners = new Map();

let unreadTrackingStartUid = null;

let unreadTrackingStartPromise = null;


// =========================
// NOTIFICHE PUSH
// =========================

const ENCLAVE_VAPID_KEY =
    "BGbi6huAaDx6taFFgwQ0ipz5VDpJ1r0ia1rFGXR3GZrEEb0jiNeBpikMbkwALoTIRKCoo-29nU9Dq6NwO3cPUZc";

let foregroundMessageListenerRegistered = false;
let userNotificationsEnabled = null;
let notificationsPreferenceLoaded = false;

// Rimuove le notifiche Enclave già presenti nel centro notifiche.
async function clearEnclaveNotifications() {
    if (!("serviceWorker" in navigator)) return;
    try {
        const registrations = await navigator.serviceWorker.getRegistrations();
        for (const registration of registrations) {
            if (!registration.scope.includes("/Enclave/")) continue;
            const notifications = await registration.getNotifications();
            notifications.forEach(notification => notification.close());
        }
    } catch (error) {
        console.warn("Pulizia notifiche Enclave non riuscita:", error);
    }
}

function clearNotificationsWhenEnclaveIsOpened() {
    if (document.visibilityState === "visible") void clearEnclaveNotifications();
}
document.addEventListener("visibilitychange", clearNotificationsWhenEnclaveIsOpened);
window.addEventListener("focus", clearNotificationsWhenEnclaveIsOpened);
window.addEventListener("pageshow", clearNotificationsWhenEnclaveIsOpened);


const ENCLAVE_NOTIFICATION_WORKER_URL =
    "https://enclave-notification.gpvyw7wnf8.workers.dev/";

// Token FCM di questo dispositivo, tenuto in memoria per poterlo rimuovere al logout.
let currentFcmToken = null;

// Invia una richiesta al Worker delle notifiche.
// - ritenta in caso di errore di rete o risposta 429/502/503/504 (tipico con
//   passaggi wifi <-> dati mobili o rete debole);
// - la prima richiesta usa keepalive, così non viene annullata se l'utente
//   blocca il telefono o cambia app subito dopo aver premuto Invia.
async function postToNotificationWorker(payload) {
    const delaysMs = [0, 1000, 3000];
    let lastError = null;

    for (let attempt = 0; attempt < delaysMs.length; attempt++) {
        if (delaysMs[attempt]) {
            await new Promise(resolve => setTimeout(resolve, delaysMs[attempt]));
        }

        try {
            const user = auth.currentUser;
            if (!user) return null;

            const idToken = await user.getIdToken();
            const response = await fetch(ENCLAVE_NOTIFICATION_WORKER_URL, {
                method: "POST",
                keepalive: attempt === 0,
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${idToken}`
                },
                body: JSON.stringify(payload)
            });

            if ([429, 502, 503, 504].includes(response.status)) {
                lastError = new Error(`Worker notifiche: risposta ${response.status}`);
                continue;
            }

            const result = await response.json().catch(() => ({}));
            return { ok: response.ok, status: response.status, result };
        } catch (error) {
            lastError = error;
        }
    }

    throw lastError || new Error("Notifica non inviata.");
}

// Rimuove da Firestore (e invalida) il token di QUESTO dispositivo.
// Va chiamata prima del logout: altrimenti il telefono continua a ricevere
// le notifiche dell'account appena chiuso.
async function removeThisDeviceFcmToken() {
    const user = auth.currentUser;

    if (user && currentFcmToken) {
        try {
            await updateDoc(doc(db, "users", user.uid), {
                fcmTokens: arrayRemove(currentFcmToken),
                updatedAt: serverTimestamp()
            });
        } catch (error) {
            console.warn("Rimozione token FCM dal profilo non riuscita:", error);
        }
    }

    try {
        if (await isSupported()) {
            await deleteToken(getMessaging(app));
        }
    } catch (error) {
        console.warn("Invalidazione token FCM non riuscita:", error);
    }

    currentFcmToken = null;
}

async function enableEnclaveNotifications(requestPermission = true) {
    try {
        const currentUser = auth.currentUser;

        if (!currentUser || !currentUser.emailVerified) {
            return false;
        }

        if (
            !("Notification" in window) ||
            !("serviceWorker" in navigator)
        ) {
            if (requestPermission) {
                alert("Questo browser non supporta le notifiche push.");
            }
            return false;
        }

        if (!(await isSupported())) {
            if (requestPermission) {
                alert("Le notifiche push non sono supportate su questo dispositivo.");
            }
            return false;
        }

        let permission = Notification.permission;

        if (permission === "default" && requestPermission) {
            permission = await Notification.requestPermission();
        }

        if (permission !== "granted") {
            if (requestPermission) {
                alert("Permesso per le notifiche non concesso.");
            }
            return false;
        }

        // Registra il Service Worker e aspetta che sia attivo.
        await navigator.serviceWorker.register(
            "/Enclave/firebase-messaging-sw.js",
            { scope: "/Enclave/" }
        );

        const serviceWorkerRegistration =
            await navigator.serviceWorker.ready;

        // All'apertura di Enclave elimina le vecchie notifiche rimaste nel centro notifiche.
        await clearEnclaveNotifications();

        const messaging = getMessaging(app);

        // Mostra una notifica anche quando Enclave è aperto e la pagina è in primo
        // piano. Quando la pagina è in background/chiusa, ci pensa il service worker.
        // Il listener viene registrato una sola volta per evitare notifiche duplicate.
        if (!foregroundMessageListenerRegistered) {
            onMessage(messaging, async (payload) => {
                // Enclave è già visibile: evitiamo notifiche di sistema mentre si usa l'app.
                if (document.visibilityState === "visible" && document.hasFocus()) return;
                if (userNotificationsEnabled === false) return;
                try {
                    const title =
                        payload.notification?.title ||
                        payload.data?.title ||
                        "Nuovo messaggio su Enclave";

                    const body =
                        payload.notification?.body ||
                        payload.data?.body ||
                        "Hai ricevuto un nuovo messaggio.";

                    const registration = await navigator.serviceWorker.ready;
                    await registration.showNotification(title, {
                        body,
                        icon: "/Enclave/images/Enclave_icon_192.png",
                        badge: "/Enclave/images/Enclave_badge.png",
                        tag: payload.data?.messageId || undefined,
                        data: payload.data || {}
                    });
                } catch (error) {
                    console.error("Impossibile mostrare la notifica in primo piano:", error);
                }
            });

            foregroundMessageListenerRegistered = true;
        }

        const token = await getToken(messaging, {
            vapidKey: ENCLAVE_VAPID_KEY,
            serviceWorkerRegistration
        });

        if (!token) {
            throw new Error("Token FCM non generato.");
        }

        currentFcmToken = token;

        // Salva il token nel profilo dell'utente autenticato.
        await updateDoc(
            doc(db, "users", currentUser.uid),
            {
                fcmTokens: arrayUnion(token),
                notificationsEnabled: true,
                updatedAt: serverTimestamp()
            }
        );
        userNotificationsEnabled = true;
        notificationsPreferenceLoaded = true;
        updateNotificationsSwitchUI();

        console.log("TOKEN FCM SALVATO CORRETTAMENTE");
        console.log("UID:", currentUser.uid);

        if (requestPermission) {
            alert("Notifiche abilitate su questo dispositivo!");
        }

        return true;

    } catch (error) {
        console.error(
            "Errore durante la registrazione delle notifiche:",
            error
        );

        if (requestPermission) {
            alert(
                "Non siamo riusciti ad attivare le notifiche. " +
                "Controlla la console."
            );
        }

        return false;
    }
}



// =========================
// POPUP INIZIALE NOTIFICHE
// =========================

const NOTIFICATIONS_PROMPT_KEY =
    "enclaveNotificationsPromptChoice";


function maybeShowNotificationsPrompt() {
    if (!auth.currentUser?.emailVerified || !notificationsPreferenceLoaded) return;

    // La scelta salvata nel profilo vale su tutti i dispositivi.
    if (userNotificationsEnabled === false) return;

    if (typeof Notification === "undefined") {
        localStorage.setItem(NOTIFICATIONS_PROMPT_KEY, "done");
        return;
    }

    if (Notification.permission === "granted") {
        localStorage.setItem(NOTIFICATIONS_PROMPT_KEY, "done");
        // Se l'utente non ha disattivato le notifiche, registra il token sul dispositivo.
        enableEnclaveNotifications(false).catch(error => {
            console.error("Registrazione automatica FCM fallita:", error);
        });
        return;
    }

    if (Notification.permission === "denied") {
        localStorage.setItem(NOTIFICATIONS_PROMPT_KEY, "done");
        return;
    }

    // Il popup iniziale viene mostrato solo finché l'utente non ha già scelto.
    if (localStorage.getItem(NOTIFICATIONS_PROMPT_KEY)) return;
    notificationsOverlay?.classList.remove("hidden");
}

function closeNotificationsPrompt() {
    localStorage.setItem(NOTIFICATIONS_PROMPT_KEY, "done");
    notificationsOverlay?.classList.add("hidden");
}

async function disableEnclaveNotifications() {
    const user = auth.currentUser;
    if (!user) throw new Error("Devi accedere per modificare le notifiche.");

    userNotificationsEnabled = false;
    notificationsPreferenceLoaded = true;
    updateNotificationsSwitchUI();

    // Svuotare i token impedisce al sistema di inviare push a questo account.
    // La preferenza viene salvata sul profilo, quindi il popup non riappare agli accessi successivi.
    await updateDoc(doc(db, "users", user.uid), {
        notificationsEnabled: false,
        fcmTokens: [],
        updatedAt: serverTimestamp()
    });
}

skipNotificationsButton?.addEventListener("click", async () => {
    closeNotificationsPrompt();
    try {
        await disableEnclaveNotifications();
    } catch (error) {
        console.error("Impossibile salvare la scelta notifiche:", error);
    }
});

activateNotificationsButton?.addEventListener("click", async () => {
    if (activateNotificationsButton.disabled) return;

    activateNotificationsButton.disabled = true;
    skipNotificationsButton.disabled = true;
    notificationsPopupMessage.textContent = "Stiamo attivando le notifiche...";

    try {
        const enabled = await enableEnclaveNotifications();
        if (!enabled) {
            notificationsPopupMessage.textContent =
                "Attivazione non riuscita. Riprova dalle impostazioni di Enclave o del dispositivo.";
            return;
        }

        if (typeof Notification !== "undefined" && Notification.permission === "granted") {
            notificationsPopupMessage.textContent = "Permesso ottenuto su questo dispositivo.";
        }
        closeNotificationsPrompt();
    } catch (error) {
        console.error("Errore notifiche:", error);
        notificationsPopupMessage.textContent = "Non siamo riusciti ad attivarle. Riprova più tardi.";
    } finally {
        activateNotificationsButton.disabled = false;
        skipNotificationsButton.disabled = false;
    }
});

// =========================
// RISPOSTA A UN MESSAGGIO
// =========================

let replyTarget = null;


// =========================
// CAMBIO SCHERMATE
// =========================

function hideStartupScreen() {
    startupScreen?.classList.add("hidden");
}

function showRegister() {

    hideStartupScreen();
    registerScreen.classList.remove("hidden");

    loginScreen.classList.add("hidden");

    homeScreen.classList.add("hidden");

}


function showLogin() {

    hideStartupScreen();
    registerScreen.classList.add("hidden");

    loginScreen.classList.remove("hidden");

    homeScreen.classList.add("hidden");

}


function showHome() {

    hideStartupScreen();
    registerScreen.classList.add("hidden");

    loginScreen.classList.add("hidden");

    homeScreen.classList.remove("hidden");

}


// =========================
// PROFILO UTENTE
// =========================

async function loadUserProfile(user) {

    const userDocument =
        await getDoc(
            doc(db, "users", user.uid)
        );

    console.log("PROFILO DA CARICARE:", {
    uidRichiesto: user.uid,
    uidAutenticato: auth.currentUser?.uid,
    stessoUtente: user.uid === auth.currentUser?.uid
});


    if (!userDocument.exists()) {

        console.error(
            "Profilo utente non trovato."
        );

        return;
    }


    const userData =
        userDocument.data();

    userNotificationsEnabled = userData.notificationsEnabled === true
        ? true
        : userData.notificationsEnabled === false
            ? false
            : null;
    notificationsPreferenceLoaded = true;
    updateNotificationsSwitchUI();

    currentUserChatTheme = ENCLAVE_CHAT_THEMES.some(theme => theme.color.toLowerCase() === String(userData.chatBubbleTheme || "#111111").toLowerCase())
        ? ENCLAVE_CHAT_THEMES.find(theme => theme.color.toLowerCase() === String(userData.chatBubbleTheme || "#111111").toLowerCase()).color
        : "#111111";

    currentUserChatWallpaper = ENCLAVE_WALLPAPERS.some(wallpaper => wallpaper.id === userData.chatWallpaper)
        ? userData.chatWallpaper
        : "";

    applyConversationTheme();
    applyConversationWallpaper();

    const nickname =
        userData.nickname;

    const enclaveId =
        userData.enclaveId;


    userNickname.textContent =
        nickname;

    userEnclaveId.textContent =
        enclaveId;


    profileNickname.textContent =
        nickname;

    profileEnclaveId.textContent =
        enclaveId;


    profileInitial.textContent =
        nickname.charAt(0).toUpperCase();

    maybeShowNotificationsPrompt();

}


// =========================
// MODIFICA NICKNAME PERSONALE
// =========================

let ownProfileNicknameOverlay = null;

function createOwnProfileNicknamePanel() {
    if (ownProfileNicknameOverlay) return ownProfileNicknameOverlay;

    const overlay = document.createElement("div");
    overlay.className = "group-info-overlay hidden";
    overlay.id = "ownProfileNicknameOverlay";

    const panel = document.createElement("div");
    panel.className = "group-info-panel";

    const header = document.createElement("div");
    header.className = "group-info-header";

    const title = document.createElement("h2");
    title.className = "group-info-title";
    title.textContent = "Modifica nickname";

    const closeButton = document.createElement("button");
    closeButton.type = "button";
    closeButton.className = "group-info-close";
    closeButton.textContent = "×";
    closeButton.setAttribute("aria-label", "Chiudi");

    header.append(title, closeButton);

    const content = document.createElement("div");
    content.className = "own-profile-nickname-content";

    const label = document.createElement("label");
    label.htmlFor = "ownProfileNicknameInput";
    label.textContent = "Il tuo nickname";

    const input = document.createElement("input");
    input.id = "ownProfileNicknameInput";
    input.className = "contact-nickname-input";
    input.type = "text";
    input.maxLength = 40;
    input.autocomplete = "nickname";
    input.placeholder = "Inserisci il nickname";

    const note = document.createElement("p");
    note.className = "own-profile-nickname-note";
    note.textContent = "Il tuo EnclaveID e i soprannomi personalizzati scelti dai tuoi contatti non cambieranno.";

    const actions = document.createElement("div");
    actions.className = "contact-nickname-actions";

    const cancelButton = document.createElement("button");
    cancelButton.type = "button";
    cancelButton.className = "contact-nickname-cancel";
    cancelButton.textContent = "Annulla";

    const saveButton = document.createElement("button");
    saveButton.type = "button";
    saveButton.className = "contact-nickname-save";
    saveButton.textContent = "Salva";

    const status = document.createElement("p");
    status.className = "own-profile-nickname-status";
    status.setAttribute("role", "status");

    actions.append(cancelButton, saveButton);
    content.append(label, input, note, actions, status);
    panel.append(header, content);
    overlay.appendChild(panel);
    document.body.appendChild(overlay);

    const close = () => overlay.classList.add("hidden");
    closeButton.addEventListener("click", close);
    cancelButton.addEventListener("click", close);
    overlay.addEventListener("click", event => {
        if (event.target === overlay) close();
    });

    const save = async () => {
        const user = auth.currentUser;
        const nickname = input.value.trim();

        if (!user) {
            status.textContent = "Devi effettuare nuovamente l'accesso.";
            return;
        }
        if (!nickname) {
            status.textContent = "Il nickname non può essere vuoto.";
            input.focus();
            return;
        }
        if (nickname.length > 40) {
            status.textContent = "Il nickname può contenere al massimo 40 caratteri.";
            input.focus();
            return;
        }

        saveButton.disabled = true;
        cancelButton.disabled = true;
        status.textContent = "Salvataggio…";

        try {
            // Il nickname originale è conservato sia nel profilo privato
            // sia nel profilo pubblico letto dagli altri utenti.
            await Promise.all([
                updateDoc(doc(db, "users", user.uid), {
                    nickname,
                    updatedAt: serverTimestamp()
                }),
                updateDoc(doc(db, "publicUsers", user.uid), {
                    nickname,
                    updatedAt: serverTimestamp()
                })
            ]);

            invalidatePublicUserSnapshot(user.uid);

            userNickname.textContent = nickname;
            profileNickname.textContent = nickname;
            profileInitial.textContent = nickname.charAt(0).toUpperCase();

            // Aggiorna gli eventuali riferimenti al proprio nickname nella UI.
            const headerNickname = document.querySelector(".user-nickname");
            if (headerNickname) headerNickname.textContent = nickname;

            status.textContent = "Nickname aggiornato.";
            window.setTimeout(() => overlay.classList.add("hidden"), 350);
        } catch (error) {
            console.error("Errore modifica nickname personale:", error);
            status.textContent = error.message || "Impossibile salvare il nickname. Riprova.";
        } finally {
            saveButton.disabled = false;
            cancelButton.disabled = false;
        }
    };

    saveButton.addEventListener("click", save);
    input.addEventListener("keydown", event => {
        if (event.key === "Enter") {
            event.preventDefault();
            save();
        }
        if (event.key === "Escape") close();
    });

    ownProfileNicknameOverlay = overlay;
    return overlay;
}

function lightenThemeColor(hex, amount = 0.78) {
    if (hex.toLowerCase() === "#111111") return "#e9e9e9";
    const value = hex.replace("#", "");
    const channels = [0, 2, 4].map(index => parseInt(value.slice(index, index + 2), 16));
    const lightened = channels.map(channel => Math.round(channel + (255 - channel) * amount));
    return "#" + lightened.map(channel => channel.toString(16).padStart(2, "0")).join("");
}

function applyConversationTheme() {
    const validTheme = ENCLAVE_CHAT_THEMES.find(theme => theme.color.toLowerCase() === String(currentUserChatTheme || "#111111").toLowerCase());
    const ownColor = validTheme ? validTheme.color : "#111111";
    const otherColor = lightenThemeColor(ownColor);

    // EnclaveAI riprende automaticamente il colore scelto per le bolle.
    // Il tema nero usa un accento argento, mantenendo l'interfaccia scura.
    const aiAccent = ownColor.toLowerCase() === "#111111" ? "#9ba6b8" : ownColor;
    const aiChannels = [0, 2, 4].map(index => parseInt(aiAccent.slice(1).slice(index, index + 2), 16));
    const aiAccentRgb = aiChannels.join(", ");
    const aiAccentLight = lightenThemeColor(aiAccent, 0.42);
    const aiAccentDark = "#" + aiChannels.map(channel => Math.round(channel * 0.48).toString(16).padStart(2, "0")).join("");

    document.documentElement.style.setProperty("--enclave-ai-accent", aiAccent);
    document.documentElement.style.setProperty("--enclave-ai-accent-light", aiAccentLight);
    document.documentElement.style.setProperty("--enclave-ai-accent-dark", aiAccentDark);
    document.documentElement.style.setProperty("--enclave-ai-accent-rgb", aiAccentRgb);

    // Le variabili globali aggiornano sia le bolle dei messaggi sia i due pulsanti
    // dell'area di scrittura, in tutte le chat private e nei gruppi.
    document.documentElement.style.setProperty("--enclave-own-bubble", ownColor);
    document.documentElement.style.setProperty("--enclave-other-bubble", otherColor);
    if (chatMessages) {
        chatMessages.style.setProperty("--enclave-own-bubble", ownColor);
        chatMessages.style.setProperty("--enclave-other-bubble", otherColor);
    }

    const settingsOverlay = document.getElementById("enclaveSettingsOverlay");
    if (settingsOverlay && !settingsOverlay.classList.contains("hidden")) {
        settingsOverlay.querySelectorAll(".settings-theme-swatch").forEach(button => {
            const selected = button.dataset.themeColor.toLowerCase() === ownColor.toLowerCase();
            button.setAttribute("aria-pressed", String(selected));
            const check = button.querySelector(".settings-theme-swatch-check");
            if (check) check.textContent = selected ? "✓" : "";
        });
    }
}

function applyConversationWallpaper() {
    if (!chatMessages) return;

    const wallpaper = ENCLAVE_WALLPAPERS.find(item => item.id === currentUserChatWallpaper);
    if (!wallpaper) {
        chatMessages.style.backgroundImage = "";
        chatMessages.style.backgroundSize = "";
        chatMessages.style.backgroundPosition = "";
        chatMessages.style.backgroundRepeat = "";
        chatMessages.style.backgroundAttachment = "";
    } else {
        const imageUrl = new URL(wallpaper.src, document.baseURI).href;
        chatMessages.style.backgroundImage = `linear-gradient(rgba(255, 255, 255, 0.12), rgba(255, 255, 255, 0.12)), url("${imageUrl}")`;
        chatMessages.style.backgroundSize = "cover";
        chatMessages.style.backgroundPosition = "center";
        chatMessages.style.backgroundRepeat = "no-repeat";
        chatMessages.style.backgroundAttachment = "scroll";
    }

    const overlay = document.getElementById("enclaveSettingsOverlay");
    if (overlay && !overlay.classList.contains("hidden")) {
        overlay.querySelectorAll(".settings-wallpaper-choice").forEach(button => {
            const selected = button.dataset.wallpaperId === currentUserChatWallpaper;
            button.setAttribute("aria-pressed", String(selected));
            button.classList.toggle("is-selected", selected);
            const check = button.querySelector(".settings-wallpaper-check");
            if (check) check.textContent = selected ? "✓" : "";
        });
    }
}

function updateNotificationsSwitchUI() {
    const switchButton = document.querySelector("#enclaveSettingsOverlay .notification-switch");
    if (!switchButton) return;
    const permissionGranted = typeof Notification !== "undefined" && Notification.permission === "granted";
    const isEnabled = userNotificationsEnabled !== false && permissionGranted;
    switchButton.setAttribute("aria-checked", String(isEnabled));
    switchButton.classList.toggle("is-on", isEnabled);
    switchButton.title = isEnabled ? "Disattiva notifiche" : "Attiva notifiche";
}

const REMEMBER_CONNECTED_KEY = "enclaveRememberConnected";

function isRememberConnectedEnabled() {
    return localStorage.getItem(REMEMBER_CONNECTED_KEY) === "true";
}

function updateRememberConnectedSwitchUI() {
    const switchButton = document.querySelector("#enclaveSettingsOverlay .remember-connected-switch");
    if (!switchButton) return;
    const isEnabled = isRememberConnectedEnabled();
    switchButton.setAttribute("aria-checked", String(isEnabled));
    switchButton.classList.toggle("is-on", isEnabled);
    switchButton.title = isEnabled ? "Disattiva Rimani connesso" : "Attiva Rimani connesso";
}

const MICROPHONE_READY_KEY = "enclaveMicrophoneReady";
let microphonePermissionState = "unknown";

function isMicrophoneReadyEnabled() {
    return localStorage.getItem(MICROPHONE_READY_KEY) === "true";
}

function updateMicrophoneSwitchUI() {
    const switchButton = document.querySelector("#enclaveSettingsOverlay .microphone-ready-switch");
    if (!switchButton) return;
    const isEnabled = isMicrophoneReadyEnabled() && microphonePermissionState === "granted";
    switchButton.setAttribute("aria-checked", String(isEnabled));
    switchButton.classList.toggle("is-on", isEnabled);
    switchButton.title = isEnabled ? "Disattiva accesso al microfono" : "Attiva accesso al microfono";
}

async function refreshMicrophonePermissionState() {
    if (!navigator.permissions?.query) return;
    try {
        const status = await navigator.permissions.query({ name: "microphone" });
        microphonePermissionState = status.state || "unknown";
        status.onchange = () => {
            microphonePermissionState = status.state || "unknown";
            if (microphonePermissionState !== "granted") {
                localStorage.setItem(MICROPHONE_READY_KEY, "false");
            }
            updateMicrophoneSwitchUI();
        };
    } catch (error) {
        console.warn("Stato microfono non disponibile:", error);
    }
}

function saveChatWallpaper(wallpaperId) {
    const user = auth.currentUser;
    const status = document.querySelector("#enclaveSettingsOverlay .settings-wallpaper-status");
    if (!user) {
        if (status) status.textContent = "Accedi per salvare lo sfondo.";
        return;
    }

    if (wallpaperId && !ENCLAVE_WALLPAPERS.some(wallpaper => wallpaper.id === wallpaperId)) return;

    currentUserChatWallpaper = wallpaperId;
    applyConversationWallpaper();
    if (status) status.textContent = "Sfondo applicato. Salvataggio…";

    wallpaperSaveQueue = wallpaperSaveQueue.then(async () => {
        await updateDoc(doc(db, "users", user.uid), {
            chatWallpaper: wallpaperId,
            updatedAt: serverTimestamp()
        });
        if (auth.currentUser?.uid === user.uid && currentUserChatWallpaper === wallpaperId && status) {
            status.textContent = wallpaperId
                ? "Sfondo salvato sul tuo account e sincronizzato sui tuoi dispositivi."
                : "Sfondo predefinito ripristinato e salvato sul tuo account.";
        }
    }).catch(error => {
        console.error("Errore salvataggio sfondo chat:", error);
        if (auth.currentUser?.uid === user.uid && currentUserChatWallpaper === wallpaperId && status) {
            status.textContent = "Lo sfondo è applicato qui, ma non è stato possibile salvarlo. Controlla la connessione.";
        }
    });
}

function createEnclaveSettingsPanel() {
    let overlay = document.getElementById("enclaveSettingsOverlay");
    if (overlay) return overlay;

    overlay = document.createElement("div");
    overlay.id = "enclaveSettingsOverlay";
    overlay.className = "group-info-overlay hidden";

    const panel = document.createElement("div");
    panel.className = "group-info-panel enclave-settings-panel";

    const header = document.createElement("div");
    header.className = "group-info-header";
    const title = document.createElement("h2");
    title.className = "group-info-title";
    title.textContent = "Impostazioni";
    const closeButton = document.createElement("button");
    closeButton.type = "button";
    closeButton.className = "group-info-close";
    closeButton.textContent = "×";
    closeButton.setAttribute("aria-label", "Chiudi impostazioni");
    header.append(title, closeButton);

    const content = document.createElement("div");
    content.className = "settings-content";

    const nicknameButton = document.createElement("button");
    nicknameButton.type = "button";
    nicknameButton.className = "settings-option";
    nicknameButton.innerHTML = '<span class="settings-option-icon">✎</span><span class="settings-option-text"><span class="settings-option-title">Nickname</span><span class="settings-option-description">Modifica il nome visualizzato sul tuo profilo</span></span><span aria-hidden="true">›</span>';

    const themeButton = document.createElement("button");
    themeButton.type = "button";
    themeButton.className = "settings-option";
    themeButton.dataset.themeOption = "true";
    themeButton.setAttribute("aria-expanded", "false");
    themeButton.innerHTML = '<span class="settings-option-icon">◉</span><span class="settings-option-text"><span class="settings-option-title">Colore delle bolle</span><span class="settings-option-description">Scegli il colore delle bolle in tutte le chat e i gruppi</span></span><span class="settings-theme-chevron" aria-hidden="true">›</span>';

    const themeSection = document.createElement("div");
    themeSection.className = "settings-theme-section hidden";
    const themeHeading = document.createElement("p");
    themeHeading.className = "settings-theme-heading";
    themeHeading.textContent = "Scegli un colore";
    const grid = document.createElement("div");
    grid.className = "settings-theme-grid";

    ENCLAVE_CHAT_THEMES.forEach(theme => {
        const swatch = document.createElement("button");
        swatch.type = "button";
        swatch.className = "settings-theme-swatch";
        swatch.style.backgroundColor = theme.color;
        swatch.dataset.themeColor = theme.color;
        swatch.title = theme.name;
        swatch.setAttribute("aria-label", theme.name);
        swatch.setAttribute("aria-pressed", "false");
        const check = document.createElement("span");
        check.className = "settings-theme-swatch-check";
        swatch.appendChild(check);
        swatch.addEventListener("click", () => {
            const user = auth.currentUser;
            if (!user) {
                status.textContent = "Accedi per salvare il tema.";
                return;
            }

            // Applica subito il colore a tutte le bolle; salva una sola preferenza globale sul profilo.
            currentUserChatTheme = theme.color;
            applyConversationTheme();
            status.textContent = "Colore applicato ovunque. Salvataggio…";
            themeSaveQueue = themeSaveQueue.then(async () => {
                await updateDoc(doc(db, "users", user.uid), {
                    chatBubbleTheme: theme.color,
                    updatedAt: serverTimestamp()
                });
                if (auth.currentUser?.uid === user.uid && currentUserChatTheme === theme.color) {
                    status.textContent = "Tema globale salvato per tutte le chat e i gruppi.";
                }
            }).catch(error => {
                console.error("Errore salvataggio tema globale:", error);
                if (auth.currentUser?.uid === user.uid && currentUserChatTheme === theme.color) {
                    status.textContent = "Il colore è applicato ovunque, ma non è stato possibile salvarlo. Controlla la connessione.";
                }
            });
        });
        grid.appendChild(swatch);
    });

    const status = document.createElement("p");
    status.className = "settings-theme-status";
    status.setAttribute("role", "status");
    status.textContent = "La scelta vale per tutte le chat private e i gruppi.";

    themeSection.append(themeHeading, grid, status);

    const wallpaperButton = document.createElement("button");
    wallpaperButton.type = "button";
    wallpaperButton.className = "settings-option";
    wallpaperButton.dataset.wallpaperOption = "true";
    wallpaperButton.setAttribute("aria-expanded", "false");
    wallpaperButton.innerHTML = '<span class="settings-option-icon" aria-hidden="true">▧</span><span class="settings-option-text"><span class="settings-option-title">Sfondo</span><span class="settings-option-description">Scegli lo sfondo per tutte le conversazioni</span></span><span class="settings-wallpaper-chevron" aria-hidden="true">›</span>';

    const wallpaperSection = document.createElement("div");
    wallpaperSection.className = "settings-wallpaper-section hidden";

    const wallpaperEmpty = document.createElement("p");
    wallpaperEmpty.className = "settings-wallpaper-empty hidden";
    wallpaperEmpty.textContent = "Non ci sono ancora immagini disponibili in questa categoria. Aggiungi i file nella cartella images e registrali nell'elenco ENCLAVE_WALLPAPERS in js/script.js.";

    const defaultHeading = document.createElement("p");
    defaultHeading.className = "settings-theme-heading settings-wallpaper-category-title";
    defaultHeading.textContent = "Predefinito";
    const defaultGrid = document.createElement("div");
    defaultGrid.className = "settings-wallpaper-grid";
    const defaultWallpaperButton = document.createElement("button");
    defaultWallpaperButton.type = "button";
    defaultWallpaperButton.className = "settings-wallpaper-choice settings-wallpaper-default";
    defaultWallpaperButton.dataset.wallpaperId = "";
    defaultWallpaperButton.setAttribute("aria-pressed", "false");
    defaultWallpaperButton.innerHTML = '<span class="settings-wallpaper-default-preview" aria-hidden="true">Aa</span><span class="settings-wallpaper-label">Predefinito</span><span class="settings-wallpaper-check" aria-hidden="true"></span>';
    defaultWallpaperButton.addEventListener("click", () => saveChatWallpaper(""));
    defaultGrid.appendChild(defaultWallpaperButton);
    wallpaperSection.append(defaultHeading, defaultGrid);

    const wallpaperCategories = [
        { id: "monocolore", title: "Monocolore" },
        { id: "realistici", title: "Realistici" }
    ];

    wallpaperCategories.forEach(category => {
        const heading = document.createElement("p");
        heading.className = "settings-theme-heading settings-wallpaper-category-title";
        heading.textContent = category.title;
        const grid = document.createElement("div");
        grid.className = "settings-wallpaper-grid";
        grid.dataset.wallpaperCategory = category.id;
        const categoryWallpapers = ENCLAVE_WALLPAPERS.filter(item => (item.category || "realistici") === category.id);

        categoryWallpapers.forEach(wallpaper => {
            const choice = document.createElement("button");
            choice.type = "button";
            choice.className = "settings-wallpaper-choice";
            choice.dataset.wallpaperId = wallpaper.id;
            choice.setAttribute("aria-label", wallpaper.name);
            choice.setAttribute("aria-pressed", "false");
            const image = document.createElement("img");
            image.className = "settings-wallpaper-preview";
            image.src = new URL(wallpaper.src, document.baseURI).href;
            image.alt = "Anteprima " + wallpaper.name;
            image.loading = "lazy";
            image.addEventListener("error", () => {
                choice.remove();
                const hasChoices = grid.querySelectorAll(".settings-wallpaper-choice").length > 0;
                heading.classList.toggle("hidden", !hasChoices);
                grid.classList.toggle("hidden", !hasChoices);
            }, { once: true });
            const label = document.createElement("span");
            label.className = "settings-wallpaper-label";
            label.textContent = wallpaper.name;
            const check = document.createElement("span");
            check.className = "settings-wallpaper-check";
            check.setAttribute("aria-hidden", "true");
            choice.append(image, label, check);
            choice.addEventListener("click", () => saveChatWallpaper(wallpaper.id));
            grid.appendChild(choice);
        });
        const hasChoices = categoryWallpapers.length > 0;
        heading.classList.toggle("hidden", !hasChoices);
        grid.classList.toggle("hidden", !hasChoices);
        wallpaperSection.append(heading, grid);
    });

    wallpaperSection.appendChild(wallpaperEmpty);
    const wallpaperStatus = document.createElement("p");
    wallpaperStatus.className = "settings-wallpaper-status";
    wallpaperStatus.setAttribute("role", "status");
    wallpaperStatus.textContent = "La scelta vale per tutte le chat private e i gruppi.";
    wallpaperSection.appendChild(wallpaperStatus);

    const tabs = document.createElement("div");
    tabs.className = "settings-tabs";
    tabs.setAttribute("role", "tablist");

    const normalTab = document.createElement("button");
    normalTab.type = "button";
    normalTab.className = "settings-tab-button is-active";
    normalTab.dataset.settingsTab = "normal";
    normalTab.setAttribute("role", "tab");
    normalTab.setAttribute("aria-selected", "true");
    normalTab.textContent = "Generali";

    const advancedTab = document.createElement("button");
    advancedTab.type = "button";
    advancedTab.className = "settings-tab-button";
    advancedTab.dataset.settingsTab = "advanced";
    advancedTab.setAttribute("role", "tab");
    advancedTab.setAttribute("aria-selected", "false");
    advancedTab.textContent = "Avanzate";
    tabs.append(normalTab, advancedTab);

    const normalSection = document.createElement("div");
    normalSection.className = "settings-tab-panel";
    normalSection.setAttribute("role", "tabpanel");

    const advancedSection = document.createElement("div");
    advancedSection.className = "settings-tab-panel hidden";
    advancedSection.setAttribute("role", "tabpanel");

    const notificationsOption = document.createElement("div");
    notificationsOption.className = "settings-option notifications-settings-option";
    notificationsOption.innerHTML = '<span class="settings-option-icon" aria-hidden="true">🔔</span><span class="settings-option-text"><span class="settings-option-title">Notifiche</span><span class="settings-option-description">Attiva o disattiva le notifiche di Enclave</span></span>';
    const notificationsSwitch = document.createElement("button");
    notificationsSwitch.type = "button";
    notificationsSwitch.className = "notification-switch";
    notificationsSwitch.setAttribute("role", "switch");
    notificationsSwitch.setAttribute("aria-label", "Attiva o disattiva le notifiche");
    notificationsSwitch.setAttribute("aria-checked", "false");
    notificationsSwitch.innerHTML = '<span class="notification-switch-knob"></span>';
    notificationsOption.appendChild(notificationsSwitch);

    const notificationsStatus = document.createElement("p");
    notificationsStatus.className = "settings-notifications-status";
    notificationsStatus.setAttribute("role", "status");
    notificationsStatus.textContent = "";

    const rememberOption = document.createElement("div");
    rememberOption.className = "settings-option notifications-settings-option";
    rememberOption.innerHTML = '<span class="settings-option-icon" aria-hidden="true">🔐</span><span class="settings-option-text"><span class="settings-option-title">Rimani connesso</span><span class="settings-option-description">Mantieni l’accesso su questo dispositivo quando riapri Enclave</span></span>';
    const rememberSwitch = document.createElement("button");
    rememberSwitch.type = "button";
    rememberSwitch.className = "notification-switch remember-connected-switch";
    rememberSwitch.setAttribute("role", "switch");
    rememberSwitch.setAttribute("aria-label", "Rimani connesso su questo dispositivo");
    rememberSwitch.setAttribute("aria-checked", "false");
    rememberSwitch.innerHTML = '<span class="notification-switch-knob"></span>';
    rememberOption.appendChild(rememberSwitch);

    const rememberStatus = document.createElement("p");
    rememberStatus.className = "settings-notifications-status remember-connected-status";
    rememberStatus.setAttribute("role", "status");
    rememberStatus.textContent = "La preferenza vale solo per questo dispositivo. Se premi Esci, dovrai accedere di nuovo.";

    normalSection.append(nicknameButton, themeButton, themeSection, wallpaperButton, wallpaperSection);
    const microphoneOption = document.createElement("div");
    microphoneOption.className = "settings-option notifications-settings-option";
    microphoneOption.innerHTML = '<span class="settings-option-icon" aria-hidden="true">🎙</span><span class="settings-option-text"><span class="settings-option-title">Microfono</span><span class="settings-option-description">Se attivo, le chiamate usano il microfono senza richiederlo ogni volta</span></span>';
    const microphoneSwitch = document.createElement("button");
    microphoneSwitch.type = "button";
    microphoneSwitch.className = "notification-switch microphone-ready-switch";
    microphoneSwitch.setAttribute("role", "switch");
    microphoneSwitch.setAttribute("aria-label", "Attiva o disattiva l’accesso al microfono per le chiamate");
    microphoneSwitch.setAttribute("aria-checked", "false");
    microphoneSwitch.innerHTML = '<span class="notification-switch-knob"></span>';
    microphoneOption.appendChild(microphoneSwitch);

    advancedSection.append(
        notificationsOption,
        notificationsStatus,
        microphoneOption,
        rememberOption,
        rememberStatus
    );
    content.append(tabs, normalSection, advancedSection);
    panel.append(header, content);
    overlay.appendChild(panel);
    document.body.appendChild(overlay);

    const close = () => overlay.classList.add("hidden");
    closeButton.addEventListener("click", close);
    overlay.addEventListener("click", event => {
        if (event.target === overlay) close();
    });

    nicknameButton.addEventListener("click", () => {
        close();
        const nicknameOverlay = createOwnProfileNicknamePanel();
        const input = nicknameOverlay.querySelector("#ownProfileNicknameInput");
        const nicknameStatus = nicknameOverlay.querySelector(".own-profile-nickname-status");
        input.value = profileNickname.textContent.trim() === "—" ? "" : profileNickname.textContent.trim();
        nicknameStatus.textContent = "";
        nicknameOverlay.classList.remove("hidden");
        window.setTimeout(() => {
            input.focus();
            input.select();
        }, 50);
    });

    themeButton.addEventListener("click", () => {
        const willOpen = themeSection.classList.contains("hidden");
        themeSection.classList.toggle("hidden", !willOpen);
        themeButton.setAttribute("aria-expanded", String(willOpen));
        const chevron = themeButton.querySelector(".settings-theme-chevron");
        if (chevron) chevron.textContent = willOpen ? "⌄" : "›";
        if (willOpen) {
            applyConversationTheme();
            status.textContent = "La scelta vale per tutte le chat private e i gruppi.";
        }
    });

    wallpaperButton.addEventListener("click", () => {
        const willOpen = wallpaperSection.classList.contains("hidden");
        wallpaperSection.classList.toggle("hidden", !willOpen);
        wallpaperButton.setAttribute("aria-expanded", String(willOpen));
        const chevron = wallpaperButton.querySelector(".settings-wallpaper-chevron");
        if (chevron) chevron.textContent = willOpen ? "⌄" : "›";
        if (willOpen) applyConversationWallpaper();
    });

    const activateSettingsTab = tabName => {
        const showAdvanced = tabName === "advanced";
        normalSection.classList.toggle("hidden", showAdvanced);
        advancedSection.classList.toggle("hidden", !showAdvanced);
        normalTab.classList.toggle("is-active", !showAdvanced);
        advancedTab.classList.toggle("is-active", showAdvanced);
        normalTab.setAttribute("aria-selected", String(!showAdvanced));
        advancedTab.setAttribute("aria-selected", String(showAdvanced));
        if (showAdvanced) {
            updateNotificationsSwitchUI();
            updateRememberConnectedSwitchUI();
            void refreshMicrophonePermissionState().finally(updateMicrophoneSwitchUI);
        }
    };
    normalTab.addEventListener("click", () => activateSettingsTab("normal"));
    advancedTab.addEventListener("click", () => activateSettingsTab("advanced"));

    // Scorrimento orizzontale sulla barra delle schede: funziona con touch, trackpad e mouse.
    let settingsSwipeStartX = null;
    let settingsSwipePointerId = null;
    tabs.addEventListener("pointerdown", event => {
        if (event.pointerType === "mouse" && event.button !== 0) return;
        settingsSwipeStartX = event.clientX;
        settingsSwipePointerId = event.pointerId;
    });
    tabs.addEventListener("pointerup", event => {
        if (settingsSwipeStartX === null || event.pointerId !== settingsSwipePointerId) return;
        const deltaX = event.clientX - settingsSwipeStartX;
        settingsSwipeStartX = null;
        settingsSwipePointerId = null;
        if (Math.abs(deltaX) < 35) return;
        const advancedIsActive = advancedTab.classList.contains("is-active");
        if (deltaX < 0 && !advancedIsActive) activateSettingsTab("advanced");
        if (deltaX > 0 && advancedIsActive) activateSettingsTab("normal");
    });
    const resetSettingsSwipe = () => {
        settingsSwipeStartX = null;
        settingsSwipePointerId = null;
    };
    tabs.addEventListener("pointercancel", resetSettingsSwipe);
    tabs.addEventListener("lostpointercapture", resetSettingsSwipe);

    microphoneSwitch.addEventListener("click", async () => {
        microphoneSwitch.disabled = true;
        try {
            const turningOn = microphoneSwitch.getAttribute("aria-checked") !== "true";
            if (!turningOn) {
                localStorage.setItem(MICROPHONE_READY_KEY, "false");
                return;
            }

            if (!navigator.mediaDevices?.getUserMedia) {
                localStorage.setItem(MICROPHONE_READY_KEY, "false");
                return;
            }

            const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
            stream.getTracks().forEach(track => track.stop());
            microphonePermissionState = "granted";
            localStorage.setItem(MICROPHONE_READY_KEY, "true");
        } catch (error) {
            console.error("Errore attivazione microfono:", error);
            localStorage.setItem(MICROPHONE_READY_KEY, "false");
            microphonePermissionState = error?.name === "NotAllowedError" ? "denied" : microphonePermissionState;
        } finally {
            microphoneSwitch.disabled = false;
            updateMicrophoneSwitchUI();
        }
    });

    rememberSwitch.addEventListener("click", async () => {
        rememberSwitch.disabled = true;
        rememberStatus.textContent = "Salvataggio…";
        try {
            const currentlyEnabled = isRememberConnectedEnabled();
            const nextEnabled = !currentlyEnabled;
            await setPersistence(
                auth,
                nextEnabled ? browserLocalPersistence : browserSessionPersistence
            );
            localStorage.setItem(REMEMBER_CONNECTED_KEY, String(nextEnabled));
            rememberStatus.textContent = nextEnabled
                ? "Rimani connesso attivato su questo dispositivo. Se premi Esci, la sessione verrà comunque chiusa."
                : "Rimani connesso disattivato. La sessione non verrà mantenuta dopo la chiusura del browser o dell’app.";
        } catch (error) {
            console.error("Errore aggiornamento preferenza Rimani connesso:", error);
            rememberStatus.textContent = "Impossibile salvare la preferenza. Controlla la connessione e riprova.";
        } finally {
            rememberSwitch.disabled = false;
            updateRememberConnectedSwitchUI();
        }
    });

    notificationsSwitch.addEventListener("click", async () => {
        notificationsSwitch.disabled = true;
        notificationsStatus.textContent = "Salvataggio…";
        try {
            const isEnabled = notificationsSwitch.getAttribute("aria-checked") === "true";
            if (isEnabled) {
                await disableEnclaveNotifications();
                notificationsStatus.textContent = "Notifiche disattivate per il tuo account.";
            } else {
                const enabled = await enableEnclaveNotifications(true);
                if (enabled) {
                    userNotificationsEnabled = true;
                    notificationsPreferenceLoaded = true;
                    notificationsStatus.textContent = "Notifiche attivate.";
                } else {
                    notificationsStatus.textContent = (typeof Notification !== "undefined" && Notification.permission === "denied")
                        ? "Permesso bloccato dal dispositivo. Attivalo nelle impostazioni del browser o del telefono."
                        : "Non è stato possibile attivare le notifiche. Riprova.";
                }
            }
        } catch (error) {
            console.error("Errore aggiornamento preferenza notifiche:", error);
            notificationsStatus.textContent = "Impossibile salvare la preferenza. Controlla la connessione.";
        } finally {
            notificationsSwitch.disabled = false;
            updateNotificationsSwitchUI();
        }
    });

    return overlay;
}

// =====================================================
// CHIAMATE VOCALI 1:1 — WEBRTC + FIRESTORE SIGNALING
// =====================================================

function createVoiceCallModal() {
    if (voiceCallModal) return voiceCallModal;

    const overlay = document.createElement("div");
    overlay.className = "voice-call-overlay hidden";
    overlay.id = "voiceCallOverlay";
    overlay.innerHTML = `
        <section class="voice-call-panel" role="dialog" aria-modal="true" aria-labelledby="voiceCallTitle">
            <div class="voice-call-avatar" id="voiceCallAvatar" aria-hidden="true">?</div>
            <h2 id="voiceCallTitle">Chiamata vocale</h2>
            <p id="voiceCallStatus" class="voice-call-status">Connessione in corso…</p>
            <div class="voice-call-controls">
                <button id="voiceCallMuteButton" type="button" class="voice-call-control" aria-label="Disattiva microfono" title="Microfono">🎙<span>Mute</span></button>
                <button id="voiceCallEndButton" type="button" class="voice-call-end" aria-label="Termina chiamata" title="Termina chiamata">✕<span>Chiudi</span></button>
            </div>
            <div class="voice-call-incoming-actions">
                <button id="voiceCallAcceptButton" type="button" class="voice-call-accept hidden">✓<span>Accetta</span></button>
                <button id="voiceCallDeclineButton" type="button" class="voice-call-decline hidden">✕<span>Rifiuta</span></button>
            </div>
        </section>`;
    document.body.appendChild(overlay);
    voiceCallModal = overlay;

    overlay.querySelector("#voiceCallEndButton").addEventListener("click", () => endVoiceCall("ended"));
    overlay.querySelector("#voiceCallDeclineButton").addEventListener("click", () => endVoiceCall("declined"));
    overlay.querySelector("#voiceCallMuteButton").addEventListener("click", toggleVoiceCallMute);
    overlay.querySelector("#voiceCallAcceptButton").addEventListener("click", acceptVoiceCall);
    return overlay;
}

function showVoiceCallModal(status, title = "Chiamata vocale", incoming = false) {
    const modal = createVoiceCallModal();
    const safeTitle = (title || "").trim() || "Chiamata vocale";
    const isGenericTitle = safeTitle === "Chiamata in arrivo" || safeTitle === "Chiamata vocale";
    modal.querySelector("#voiceCallTitle").textContent = safeTitle;
    modal.querySelector("#voiceCallAvatar").textContent = (isGenericTitle ? "?" : safeTitle.charAt(0)).toLocaleUpperCase("it-IT");
    modal.querySelector("#voiceCallStatus").textContent = status;
    modal.querySelector(".voice-call-controls")?.classList.toggle("hidden", incoming);
    modal.querySelector(".voice-call-incoming-actions")?.classList.toggle("hidden", !incoming);
    modal.querySelector("#voiceCallAcceptButton").classList.toggle("hidden", !incoming);
    modal.querySelector("#voiceCallDeclineButton").classList.toggle("hidden", !incoming);
    modal.querySelector("#voiceCallEndButton").classList.toggle("hidden", incoming);
    modal.querySelector("#voiceCallMuteButton").classList.toggle("hidden", incoming);
    const acceptButton = modal.querySelector("#voiceCallAcceptButton");
    if (acceptButton) acceptButton.disabled = false;
    modal.classList.remove("hidden");
}

function setVoiceCallIdentity(name) {
    const safeName = (name || "").trim();
    if (!safeName || !voiceCallModal) return;
    const title = voiceCallModal.querySelector("#voiceCallTitle");
    const avatar = voiceCallModal.querySelector("#voiceCallAvatar");
    if (title) title.textContent = safeName;
    if (avatar) avatar.textContent = safeName.charAt(0).toLocaleUpperCase("it-IT");
}

function silenceIncomingCall(callId) {
    if (!callId) return;
    silencedIncomingCallIds.set(callId, Date.now() + 20000);
}

function isIncomingCallSilenced(callId) {
    const expiresAt = silencedIncomingCallIds.get(callId);
    if (!expiresAt) return false;
    if (expiresAt <= Date.now()) {
        silencedIncomingCallIds.delete(callId);
        return false;
    }
    return true;
}

function findKnownContactName(callerUid, chatId) {
    const escapeValue = value => window.CSS?.escape ? CSS.escape(value) : String(value).replace(/["\\]/g, "\\$&");
    const readName = selector => document.querySelector(selector)?.textContent?.trim() || "";

    if (callerUid) {
        const fromContact = readName(`.conversation-item[data-contact-uid="${escapeValue(callerUid)}"] .conversation-nickname`);
        if (fromContact) return fromContact;
    }
    if (chatId) {
        const fromChat = readName(`.conversation-item[data-chat-id="${escapeValue(chatId)}"] .conversation-nickname`);
        if (fromChat) return fromChat;
    }
    if (callerUid && currentChatUserUid === callerUid) {
        const openChatName = chatUserNickname?.textContent?.trim();
        if (openChatName && openChatName !== "—") return openChatName;
    }
    return "";
}

async function resolveCallerDisplayName(callerUid, localName) {
    try {
        const callerDocument = await getCachedPublicUserSnapshot(callerUid);
        const originalNickname = callerDocument.exists()
            ? (callerDocument.data().nickname || "")
            : "";
        const resolved = await getContactNickname(callerUid, originalNickname || localName || "");
        return (resolved || localName || "").trim();
    } catch (error) {
        console.error("Impossibile caricare il nome del chiamante:", error);
        return localName || "";
    }
}

function requestMicrophoneStream(sessionToken) {
    if (!navigator.mediaDevices?.getUserMedia) {
        return Promise.reject(Object.assign(new Error("Microfono non disponibile"), { name: "NotSupportedError" }));
    }

    return new Promise((resolve, reject) => {
        let settled = false;
        const timeoutId = setTimeout(() => {
            if (settled) return;
            settled = true;
            reject(Object.assign(new Error("Il microfono non risponde. Riprova."), { name: "TimeoutError" }));
        }, 8000);

        navigator.mediaDevices.getUserMedia({ audio: true, video: false }).then(stream => {
            clearTimeout(timeoutId);
            if (settled || sessionToken !== voiceCallSession) {
                stream.getTracks().forEach(track => track.stop());
                if (!settled) {
                    settled = true;
                    reject(Object.assign(new Error("Chiamata chiusa"), { name: "AbortError" }));
                }
                return;
            }
            settled = true;
            resolve(stream);
        }).catch(error => {
            clearTimeout(timeoutId);
            if (settled) return;
            settled = true;
            reject(error);
        });
    });
}

function updateVoiceCallStatus(status) {
    const node = voiceCallModal?.querySelector("#voiceCallStatus");
    if (node) node.textContent = status;
}

function stopVoiceCallListeners() {
    unsubscribeCallCandidates.forEach(unsubscribe => {
        try { unsubscribe(); } catch (error) { console.warn("Listener ICE:", error); }
    });
    unsubscribeCallCandidates = [];
}

function getVoiceCallChatId(callRef) {
    return callRef?.parent?.parent?.id || activeVoiceCall?.chatId || currentChatId;
}

async function attachVoiceCallCandidateListener(callRef, collectionName, peerConnection) {
    const callChatId = getVoiceCallChatId(callRef);
    const candidateQuery = collection(db, "chats", callChatId, "calls", callRef.id, collectionName);
    const unsubscribe = onSnapshot(candidateQuery, snapshot => {
        snapshot.docChanges().forEach(change => {
            if (change.type !== "added") return;
            const candidate = change.doc.data()?.candidate;
            if (!candidate) return;
            const iceCandidate = new RTCIceCandidate(candidate);
            if (peerConnection.remoteDescription) {
                peerConnection.addIceCandidate(iceCandidate).catch(error => {
                    console.warn("ICE candidate non applicato:", error);
                });
            } else if (activeVoiceCall) {
                activeVoiceCall.pendingIceCandidates ||= [];
                activeVoiceCall.pendingIceCandidates.push(iceCandidate);
            }
        });
    }, error => console.error("Errore listener ICE:", error));
    unsubscribeCallCandidates.push(unsubscribe);
}

async function createVoicePeerConnection(callRef, localStream, remoteAudio) {
    const peer = new RTCPeerConnection({
        iceServers: [{ urls: "stun:stun.l.google.com:19302" }]
    });
    localStream.getTracks().forEach(track => peer.addTrack(track, localStream));
    peer.ontrack = event => {
        remoteAudio.srcObject = event.streams[0];
        remoteAudio.play().catch(() => {});
    };
    peer.onconnectionstatechange = () => {
        if (!activeVoiceCall) return;
        if (peer.connectionState === "connected") updateVoiceCallStatus("Chiamata attiva");
        if (["failed", "disconnected"].includes(peer.connectionState)) updateVoiceCallStatus("Connessione instabile. Verifica la rete.");
        if (peer.connectionState === "closed") updateVoiceCallStatus("Chiamata terminata");
    };
    peer.onicecandidate = event => {
        if (!event.candidate) return;
        const target = activeVoiceCall?.isCaller ? "callerCandidates" : "calleeCandidates";
        const callChatId = getVoiceCallChatId(callRef);
        addDoc(collection(db, "chats", callChatId, "calls", callRef.id, target), {
            candidate: event.candidate.toJSON(),
            createdAt: serverTimestamp()
        }).catch(error => console.error("Errore invio ICE:", error));
    };
    return peer;
}

async function startVoiceCall() {
    if (!currentChatId || !currentChatUserUid || currentChatUserUid === auth.currentUser?.uid) return;
    if (activeVoiceCall) return;
    if (!navigator.mediaDevices?.getUserMedia || !window.RTCPeerConnection) {
        alert("Le chiamate vocali non sono supportate da questo browser.");
        return;
    }

    try {
        const stream = await requestMicrophoneStream(voiceCallSession);
        const callRef = doc(collection(db, "chats", currentChatId, "calls"));
        const remoteAudio = document.createElement("audio");
        remoteAudio.autoplay = true;
        remoteAudio.playsInline = true;
        document.body.appendChild(remoteAudio);
        activeVoiceCall = {
            callRef,
            chatId: currentChatId,
            peerUid: currentChatUserUid,
            displayName: chatUserNickname.textContent,
            stream,
            remoteAudio,
            isCaller: true,
            peer: null
        };
        const peer = await createVoicePeerConnection(callRef, stream, remoteAudio);
        activeVoiceCall.peer = peer;
        const offer = await peer.createOffer();
        await peer.setLocalDescription(offer);
        await setDoc(callRef, {
            callerId: auth.currentUser.uid,
            calleeId: currentChatUserUid,
            status: "ringing",
            offer: { type: offer.type, sdp: offer.sdp },
            createdAt: serverTimestamp()
        });

        showVoiceCallModal("Chiamata in corso…", chatUserNickname.textContent);

        // Push al destinatario tramite il Worker già pubblicato.
        // Non blocca l'avvio della chiamata e ritenta in caso di rete instabile.
        void postToNotificationWorker({
            action: "call",
            chatId: activeVoiceCall.chatId,
            callId: callRef.id
        }).then(outcome => {
            if (outcome && !outcome.ok) {
                console.error("Notifica chiamata non inviata:", outcome.result);
            } else if (outcome) {
                console.log("Risultato notifica chiamata:", outcome.result);
            }
        }).catch(error => {
            console.error("Errore invio notifica chiamata:", error);
        });

        await attachVoiceCallCandidateListener(callRef, "calleeCandidates", peer);
        const unsubscribe = onSnapshot(callRef, async snapshot => {
            const data = snapshot.data();
            if (!data || !activeVoiceCall) return;
            if (data.answer && !peer.currentRemoteDescription) {
                await peer.setRemoteDescription(new RTCSessionDescription(data.answer));
                const pendingCandidates = activeVoiceCall?.pendingIceCandidates || [];
                for (const candidate of pendingCandidates) {
                    await peer.addIceCandidate(candidate).catch(error => console.warn("ICE in coda:", error));
                }
                if (activeVoiceCall) activeVoiceCall.pendingIceCandidates = [];
                updateVoiceCallStatus("Connessione audio…");
            }
            if (["declined", "ended", "missed"].includes(data.status)) await endVoiceCall(data.status, false);
        });
        activeVoiceCall.unsubscribeCall = unsubscribe;
    } catch (error) {
        console.error("Avvio chiamata non riuscito:", error);
        await endVoiceCall("ended", false);
        alert(error.name === "NotAllowedError" ? "Consenti l'accesso al microfono per chiamare." : "Non è stato possibile avviare la chiamata.");
    }
}

function updateIncomingCallIndicator(chatId, callerUid, isRinging) {
    if (isRinging) incomingCallIndicators.set(chatId, callerUid);
    else incomingCallIndicators.delete(chatId);

    const conversation = [...document.querySelectorAll(".conversation-item")]
        .find(item => item.dataset.chatId === chatId);
    const indicator = conversation?.querySelector(".incoming-call-indicator");
    if (indicator) {
        indicator.classList.toggle("visible", isRinging);
        indicator.setAttribute("aria-label", isRinging ? "Chiamata in arrivo" : "");
        indicator.title = isRinging ? "Chiamata in arrivo" : "";
    }
}

function stopGlobalIncomingVoiceCallListener() {
    if (unsubscribeIncomingCalls) {
        unsubscribeIncomingCalls();
        unsubscribeIncomingCalls = null;
    }
    for (const unsubscribe of incomingVoiceCallListeners.values()) {
        try { unsubscribe(); } catch (error) { console.warn("Chiusura listener chiamate:", error); }
    }
    incomingVoiceCallListeners.clear();
    incomingCallIndicators.clear();
}

async function showIncomingVoiceCall(callRef, chatId, callData) {
    if (activeVoiceCall || !auth.currentUser || isIncomingCallSilenced(callRef.id)) return;
    if (callData.calleeId !== auth.currentUser.uid || callData.status !== "ringing") return;
    if (!callData.offer) return;

    const createdAtMs = callData.createdAt?.toMillis?.();
    if (createdAtMs && Date.now() - createdAtMs > 2 * 60 * 1000) return;

    const callerUid = callData.callerId;
    const localName = findKnownContactName(callerUid, chatId);
    activeVoiceCall = {
        callRef, chatId, callerUid, peerUid: callerUid,
        isCaller: false, stream: null, peer: null, remoteAudio: null,
        offer: callData.offer, displayName: localName, accepting: false
    };

    const visibleName = localName || "Chiamata in arrivo";
    showVoiceCallModal(
        localName ? "Chiamata in arrivo da " + localName : "Chiamata in arrivo",
        visibleName,
        true
    );

    if (localName) return;

    const displayName = await resolveCallerDisplayName(callerUid, "");
    if (!activeVoiceCall || activeVoiceCall.callRef.id !== callRef.id || !displayName) return;
    activeVoiceCall.displayName = displayName;
    setVoiceCallIdentity(displayName);
    updateVoiceCallStatus("Chiamata in arrivo da " + displayName);
}

function listenForIncomingVoiceCalls() {
    const currentUser = auth.currentUser;
    if (!currentUser) return;
    if (unsubscribeIncomingCalls && incomingVoiceCallUserUid === currentUser.uid) return;

    stopGlobalIncomingVoiceCallListener();
    incomingVoiceCallUserUid = currentUser.uid;

    const chatsQuery = query(
        collection(db, "chats"),
        where("participants", "array-contains", currentUser.uid)
    );

    unsubscribeIncomingCalls = onSnapshot(chatsQuery, snapshot => {
        const activeChatIds = new Set(snapshot.docs.map(chatDocument => chatDocument.id));

        for (const [chatId, unsubscribe] of incomingVoiceCallListeners) {
            if (!activeChatIds.has(chatId)) {
                unsubscribe();
                incomingVoiceCallListeners.delete(chatId);
                updateIncomingCallIndicator(chatId, null, false);
            }
        }

        snapshot.docs.forEach(chatDocument => {
            const chatId = chatDocument.id;
            if (incomingVoiceCallListeners.has(chatId)) return;

            const callsReference = query(
                collection(db, "chats", chatId, "calls"),
                where("calleeId", "==", currentUser.uid)
            );
            const unsubscribe = onSnapshot(callsReference, callsSnapshot => {
                if (activeVoiceCall?.chatId === chatId) {
                    const activeCallSnapshot = callsSnapshot.docs.find(
                        callDocument => callDocument.id === activeVoiceCall.callRef.id
                    );
                    const activeCallStatus = activeCallSnapshot?.data()?.status;
                    if (["ended", "declined", "missed"].includes(activeCallStatus)) {
                        void endVoiceCall(activeCallStatus, false);
                    }
                }

                const ringingCalls = callsSnapshot.docs
                    .map(callDocument => ({ ref: callDocument.ref, data: callDocument.data() }))
                    .filter(call => {
                        const createdAtMs = call.data.createdAt?.toMillis?.();
                        const recentEnough = !createdAtMs || Date.now() - createdAtMs <= 2 * 60 * 1000;
                        return recentEnough &&
                            call.data.calleeId === currentUser.uid &&
                            call.data.callerId !== currentUser.uid &&
                            call.data.status === "ringing";
                    })
                    .sort((a, b) =>
                        (b.data.createdAt?.toMillis?.() || 0) -
                        (a.data.createdAt?.toMillis?.() || 0)
                    );

                const incoming = ringingCalls.find(call => !isIncomingCallSilenced(call.ref.id));
                if (!incoming) {
                    updateIncomingCallIndicator(chatId, null, false);
                    return;
                }

                updateIncomingCallIndicator(chatId, incoming.data.callerId, true);
                if (activeVoiceCall?.callRef?.id === incoming.ref.id) return;
                // Prepara la schermata anche se Enclave è in standby:
                // resta pronta quando il telefono viene riaperto, senza ricreare la chiamata.
                if (!activeVoiceCall) {
                    void showIncomingVoiceCall(incoming.ref, chatId, incoming.data);
                }
            }, error => console.error("Errore listener chiamate per chat:", chatId, error));

            incomingVoiceCallListeners.set(chatId, unsubscribe);
        });
    }, error => console.error("Errore listener globale chiamate in arrivo:", error));
}

async function acceptVoiceCall() {
    const call = activeVoiceCall;
    if (!call || call.isCaller || !call.offer || call.accepting) return;
    if (document.visibilityState === "hidden") return;

    call.accepting = true;
    const sessionToken = voiceCallSession;
    const acceptButton = voiceCallModal?.querySelector("#voiceCallAcceptButton");
    if (acceptButton) acceptButton.disabled = true;
    updateVoiceCallStatus("Connessione al microfono…");

    let stream = null;
    try {
        stream = await requestMicrophoneStream(sessionToken);
        if (sessionToken !== voiceCallSession || activeVoiceCall !== call) {
            stream.getTracks().forEach(track => track.stop());
            return;
        }

        const remoteAudio = document.createElement("audio");
        remoteAudio.autoplay = true;
        remoteAudio.playsInline = true;
        document.body.appendChild(remoteAudio);
        call.stream = stream;
        call.remoteAudio = remoteAudio;
        const peer = await createVoicePeerConnection(call.callRef, stream, remoteAudio);
        if (sessionToken !== voiceCallSession || activeVoiceCall !== call) {
            stream.getTracks().forEach(track => track.stop());
            peer.close();
            remoteAudio.remove();
            return;
        }
        call.peer = peer;
        await peer.setRemoteDescription(new RTCSessionDescription(call.offer));
        const answer = await peer.createAnswer();
        await peer.setLocalDescription(answer);
        await updateDoc(call.callRef, {
            answer: { type: answer.type, sdp: answer.sdp },
            status: "accepted"
        });
        if (sessionToken !== voiceCallSession || activeVoiceCall !== call) return;
        await attachVoiceCallCandidateListener(call.callRef, "callerCandidates", peer);
        call.unsubscribeCall = onSnapshot(call.callRef, snapshot => {
            const data = snapshot.data();
            if (activeVoiceCall === call && data && ["ended", "declined", "missed"].includes(data.status)) {
                void endVoiceCall(data.status, false);
            }
        });
        showVoiceCallModal("Connessione audio…", call.displayName || "Chiamata in arrivo");
    } catch (error) {
        console.error("Accettazione chiamata non riuscita:", error);
        if (sessionToken !== voiceCallSession || activeVoiceCall !== call) return;
        stream?.getTracks().forEach(track => track.stop());
        if (call.peer) {
            call.peer.close();
            call.peer = null;
        }
        if (call.remoteAudio) {
            call.remoteAudio.remove();
            call.remoteAudio = null;
        }
        call.stream = null;
        call.accepting = false;
        if (acceptButton) acceptButton.disabled = false;
        showVoiceCallModal(
            error?.name === "NotAllowedError"
                ? "Permesso microfono negato. Attivalo e tocca di nuovo Accetta."
                : "Microfono non disponibile. Tocca di nuovo Accetta.",
            call.displayName || "Chiamata in arrivo",
            true
        );
    }
}

function toggleVoiceCallMute() {
    const tracks = activeVoiceCall?.stream?.getAudioTracks() || [];
    if (!tracks.length) return;
    const enabled = !tracks[0].enabled;
    tracks.forEach(track => { track.enabled = enabled; });
    const button = voiceCallModal?.querySelector("#voiceCallMuteButton");
    if (button) {
        button.textContent = enabled ? "🎙" : "🔇";
        button.setAttribute("aria-label", enabled ? "Disattiva microfono" : "Attiva microfono");
    }
}

async function endVoiceCall(status = "ended", updateRemote = true) {
    const call = activeVoiceCall;
    voiceCallSession += 1;
    if (!call) {
        voiceCallModal?.classList.add("hidden");
        return;
    }
    activeVoiceCall = null;
    silenceIncomingCall(call.callRef?.id);
    if (call.chatId) updateIncomingCallIndicator(call.chatId, call.callerUid, false);
    stopVoiceCallListeners();
    if (call.unsubscribeCall) call.unsubscribeCall();
    if (call.stream) call.stream.getTracks().forEach(track => track.stop());
    if (call.peer) call.peer.close();
    if (call.remoteAudio) call.remoteAudio.remove();
    voiceCallModal?.classList.add("hidden");
    if (updateRemote && call.callRef) {
        try {
            await updateDoc(call.callRef, { status });
        } catch (error) {
            console.warn("Aggiornamento stato chiamata:", error);
            try {
                await new Promise(resolve => setTimeout(resolve, 500));
                await updateDoc(call.callRef, { status });
            } catch (retryError) {
                console.warn("Secondo aggiornamento stato chiamata non riuscito:", retryError);
            }
        }
    }
}

if (startVoiceCallButton) {
    startVoiceCallButton.addEventListener("click", startVoiceCall);
}


let mobileChatHistoryStateActive = false;

function markChatViewOpen() {
    homeMain.classList.add("chat-open");
    if (window.innerWidth <= 700) {
        homeScreen.classList.add("mobile-chat-open");
        if (!mobileChatHistoryStateActive) {
            history.pushState({ enclaveChatView: true }, "", window.location.href);
            mobileChatHistoryStateActive = true;
        }
    }
}

function returnToChatList() {
    // Il listener globale resta attivo anche quando si torna alla lista chat.
    if (activeVoiceCall) void endVoiceCall("ended");
    closeMessageMenus();
    clearReply();
    chatEmptyState.classList.remove("hidden");
    activeChat.classList.add("hidden");
    homeMain.classList.remove("chat-open");
    homeScreen.classList.remove("mobile-chat-open");
    messagesLoadVersion++;

    if (unsubscribeMessages) {
        unsubscribeMessages();
        unsubscribeMessages = null;
    }

    chatMessages.replaceChildren();
    activeChatDayIndicator = null;
    currentChatUserUid = null;
    currentChatId = null;
    currentChatDocumentExists = false;

    if (window.innerWidth <= 700) {
        chatSidebar.style.display = "flex";
        chatArea.style.display = "none";
    }
}

window.addEventListener("popstate", () => {
    if (!mobileChatHistoryStateActive) return;
    mobileChatHistoryStateActive = false;
    if (homeMain.classList.contains("chat-open")) {
        returnToChatList();
    }
});

const settingsButton = document.getElementById("settingsButton");
if (settingsButton) {
    settingsButton.addEventListener("click", () => {
        const overlay = createEnclaveSettingsPanel();
        updateNotificationsSwitchUI();
        const themeSection = overlay.querySelector(".settings-theme-section");
        const themeButton = overlay.querySelector("[data-theme-option]");
        const chevron = overlay.querySelector(".settings-theme-chevron");
        themeSection.classList.add("hidden");
        themeButton?.setAttribute("aria-expanded", "false");
        if (chevron) chevron.textContent = "›";
        overlay.querySelector(".settings-theme-status").textContent = "La scelta vale per tutte le chat private e i gruppi.";
        const wallpaperSection = overlay.querySelector(".settings-wallpaper-section");
        const wallpaperButton = overlay.querySelector("[data-wallpaper-option]");
        wallpaperSection?.classList.add("hidden");
        wallpaperButton?.setAttribute("aria-expanded", "false");
        const wallpaperChevron = overlay.querySelector(".settings-wallpaper-chevron");
        if (wallpaperChevron) wallpaperChevron.textContent = "›";
        const wallpaperStatus = overlay.querySelector(".settings-wallpaper-status");
        if (wallpaperStatus) wallpaperStatus.textContent = "La scelta vale per tutte le chat private e i gruppi.";
        // Ogni apertura parte dalla scheda Generali; Avanzate è una scheda separata in alto.
        overlay.querySelector('[data-settings-tab="normal"]')?.click();
        overlay.classList.remove("hidden");
        applyConversationTheme();
        applyConversationWallpaper();
        updateNotificationsSwitchUI();
        updateRememberConnectedSwitchUI();
    });
}


// =========================
// VERIFICA EMAIL
// =========================

function showVerification(user) {

    hideStartupScreen();
    verificationEmail.textContent =
        user.email;

    verificationMessage.textContent =
        "";

    verificationSpinner.style.display =
        "none";

    verificationOverlay.classList.remove(
        "hidden"
    );

}


async function checkEmailVerification(user) {

    verificationSpinner.style.display =
        "block";


    await user.reload();


    if (user.emailVerified) {

        verificationSpinner.style.display =
            "none";

        verificationOverlay.classList.add(
            "hidden"
        );

        showRegister();

        return;
    }


    setTimeout(() => {

        checkEmailVerification(user);

    }, 2000);

}


// =========================
// REGISTRAZIONE
// =========================

document
    .getElementById("registerButton")
    .addEventListener(
        "click",
        async () => {

            const email =
                document
                    .getElementById("registerEmail")
                    .value
                    .trim();

            const password =
                document
                    .getElementById("registerPassword")
                    .value;

            const nickname =
                document
                    .getElementById("registerNickname")
                    .value
                    .trim();

            const message =
                document.getElementById("message");


            if (!email || !password || !nickname) {

                message.textContent =
                    "Compila tutti i campi.";

                return;
            }


            message.textContent =
                "Creazione account...";


            const result =
                await registerUser(
                    email,
                    password,
                    nickname
                );


            if (result.success) {

                showVerification(
                    result.user
                );

                checkEmailVerification(
                    result.user
                );

            } else {

                message.textContent =
                    "Errore: " +
                    result.error.message;

            }

        }
    );


// =========================
// APRI LOGIN
// =========================

document
    .getElementById("loginLink")
    .addEventListener(
        "click",
        () => {

            showLogin();

        }
    );


// =========================
// LOGIN
// =========================

document
    .getElementById("loginButton")
    .addEventListener(
        "click",
        async () => {

            const email =
                document
                    .getElementById("loginEmail")
                    .value
                    .trim();

            const password =
                document
                    .getElementById("loginPassword")
                    .value;

            const message =
                document.getElementById(
                    "loginMessage"
                );


            if (!email || !password) {

                message.textContent =
                    "Inserisci email e password.";

                return;
            }


            message.textContent =
                "Accesso in corso...";


            const result =
                await loginUser(
                    email,
                    password
                );


            if (result.success) {

                showHome();

                await loadUserProfile(
                    result.user
                );

                loadConversations();
                listenForIncomingVoiceCalls();

            } else if (result.emailNotVerified) {

                message.textContent =
                    "Devi prima verificare la tua email.";

            } else {

                message.textContent =
                    "Email o password non corretti.";

                console.error(
                    result.error
                );

            }

        }
    );


// =========================
// TORNA ALLA REGISTRAZIONE
// =========================

document
    .getElementById("registerLink")
    .addEventListener(
        "click",
        () => {

            showRegister();

        }
    );


// =========================
// LOGOUT
// =========================

document
    .getElementById("logoutButton")
    .addEventListener(
        "click",
        async () => {

            if (unsubscribeMessages) {

                unsubscribeMessages();

                unsubscribeMessages = null;

            }


            if (unsubscribeChats) {

                unsubscribeChats();

                unsubscribeChats = null;

            }

            stopGlobalIncomingVoiceCallListener();
            incomingVoiceCallUserUid = null;
            if (activeVoiceCall) await endVoiceCall("ended", false);

            currentChatUserUid = null;

            currentChatId = null;
            mobileChatHistoryStateActive = false;
            homeScreen.classList.remove("mobile-chat-open");
            homeMain.classList.remove("chat-open");
            currentUserChatTheme = "#111111";
            currentUserChatWallpaper = "";
            if (chatMessages) {
                chatMessages.style.backgroundImage = "";
                chatMessages.style.backgroundSize = "";
                chatMessages.style.backgroundPosition = "";
                chatMessages.style.backgroundRepeat = "";
                chatMessages.style.backgroundAttachment = "";
            }
            document.documentElement.style.removeProperty("--enclave-own-bubble");
            document.documentElement.style.removeProperty("--enclave-other-bubble");
            if (chatMessages) {
                chatMessages.style.removeProperty("--enclave-own-bubble");
                chatMessages.style.removeProperty("--enclave-other-bubble");
            }

            clearReply();

            try {
                // Esci chiude sempre la sessione Firebase e cancella il marcatore della scheda.
                sessionStorage.removeItem("enclaveSessionAuthMarker");
                await removeThisDeviceFcmToken();
                await signOut(auth);
            } catch (error) {
                console.error("Errore durante la disconnessione:", error);
            }

            showRegister();

        }
    );


// =========================
// REINVIO EMAIL
// =========================

resendVerificationButton
    .addEventListener(
        "click",
        async () => {

            const user =
                (
                    await import("./firebase.js")
                ).auth.currentUser;


            if (!user) {
                return;
            }


            try {

                await sendEmailVerification(
                    user
                );

                verificationMessage.textContent =
                    "Email inviata nuovamente.";

            } catch (error) {

                console.error(error);

                verificationMessage.textContent =
                    "Non è stato possibile inviare l'email.";

            }

        }
    );


// =========================
// ID CONVERSAZIONE
// =========================

function createChatId(uid1, uid2) {

    return [uid1, uid2]
        .sort()
        .join("_");

}


async function markChatAsRead(chatId, lastReadAt = serverTimestamp()) {
    const currentUser = auth.currentUser;

    if (!currentUser || !chatId) {
        return;
    }

    try {
        await setDoc(
            doc(
                db,
                "users",
                currentUser.uid,
                "chatReadState",
                chatId
            ),
            {
                lastReadAt: lastReadAt
            },
            { merge: true }
        );
    } catch (error) {
        console.error(
            "Errore aggiornamento lettura chat:",
            error
        );
    }
}


// Conferma di lettura dei singoli messaggi.
// Viene eseguita solo mentre la conversazione corrispondente è aperta.
async function markMessagesAsRead(chatId, messages, userUid) {
    if (!chatId || !userUid || currentChatId !== chatId || auth.currentUser?.uid !== userUid) {
        return;
    }

    const unreadIncomingMessages = messages.filter((message) =>
        message.senderId !== userUid &&
        !(Array.isArray(message.readBy) && message.readBy.includes(userUid))
    );

    await Promise.all(unreadIncomingMessages.map(async (message) => {
        try {
            await updateDoc(
                doc(db, "chats", chatId, "messages", message.id),
                { readBy: arrayUnion(userUid) }
            );
        } catch (error) {
            // Un errore sulla conferma non deve mai bloccare il rendering della chat.
            console.error("Errore conferma lettura messaggio:", {
                code: error.code,
                message: error.message,
                chatId,
                messageId: message.id
            });
        }
    }));
}


async function getUnreadTrackingStart(userUid) {
    if (unreadTrackingStartUid !== userUid) {
        unreadTrackingStartUid = userUid;
        unreadTrackingStartPromise = null;
    }

    if (!unreadTrackingStartPromise) {
        unreadTrackingStartPromise = (async () => {
            const userRef = doc(db, "users", userUid);

            let userSnapshot = await getDoc(userRef);
            let startAt =
                userSnapshot.exists()
                    ? userSnapshot.data().unreadTrackingStartedAt
                    : null;

            if (!startAt) {
                await setDoc(
                    userRef,
                    { unreadTrackingStartedAt: serverTimestamp() },
                    { merge: true }
                );

                userSnapshot = await getDoc(userRef);
                startAt = userSnapshot.data()?.unreadTrackingStartedAt;
            }

            return startAt;
        })();
    }

    return unreadTrackingStartPromise;
}


async function updateUnreadBadge(chatId, badge, userUid) {
    try {
        const readStateRef = doc(
            db,
            "users",
            userUid,
            "chatReadState",
            chatId
        );

        let readStateSnapshot = await getDoc(readStateRef);
        let lastReadAt = readStateSnapshot.exists()
            ? readStateSnapshot.data().lastReadAt
            : null;

        if (!lastReadAt) {
            lastReadAt = await getUnreadTrackingStart(userUid);

            if (!lastReadAt) {
                badge.classList.remove("visible");
                return;
            }

            await setDoc(
                readStateRef,
                { lastReadAt },
                { merge: true }
            );
        }

        // Se la conversazione è aperta, non mostrare messaggi non letti.
        if (currentChatId === chatId) {
                badge.classList.remove("visible");

                try {
                    await markChatAsRead(chatId);
                } catch (error) {
                    console.error("Errore azzeramento badge:", error);
                }

                return;
            }

        const unreadQuery = query(
            collection(db, "chats", chatId, "messages"),
            where("createdAt", ">", lastReadAt)
        );

        const unreadSnapshot = await getDocs(unreadQuery);

        const unreadCount = unreadSnapshot.docs.filter(
            messageDocument =>
                messageDocument.data().senderId !== userUid
        ).length;

        if (unreadCount > 0) {
            badge.textContent = unreadCount > 99 ? "99+" : unreadCount;
            badge.classList.add("visible");
        } else {
            badge.classList.remove("visible");
        }
    } catch (error) {
        console.error("Errore conteggio messaggi non letti:", error);
    }
}


function clearUnreadBadge(chatId) {
    const badges = document.querySelectorAll(".unread-badge");

    badges.forEach(badge => {
        if (badge.dataset.chatId === chatId) {
            badge.classList.remove("visible");
            badge.textContent = "";
        }
    });
}



// =========================
// CHIUDI MENU MESSAGGI
// =========================

function closeMessageMenus() {

    document
        .querySelectorAll(".message-menu")
        .forEach((menu) => {

            menu.remove();

        });

}


// =========================
// NUOVO GRUPPO
// =========================

let groupCreationOverlay = null;

let selectedGroupMembers = [];

function createGroupCreationPanel() {

    if (groupCreationOverlay) {
        return groupCreationOverlay;
    }

    groupCreationOverlay =
        document.createElement("div");

    groupCreationOverlay.className =
        "group-creation-overlay hidden";


    const panel =
        document.createElement("div");

    panel.className =
        "group-creation-panel";


    const title =
        document.createElement("h2");

    title.className =
        "group-creation-title";

    title.textContent =
        "Crea gruppo";


    const groupNameInput =
        document.createElement("input");

    groupNameInput.type =
        "text";

    groupNameInput.className =
        "group-name-input";

    groupNameInput.placeholder =
        "Nome del gruppo";

    groupNameInput.id =
        "groupNameInput";


    const memberSearch =
        document.createElement("input");

    memberSearch.type =
        "text";

    memberSearch.className =
        "group-member-search";

    memberSearch.placeholder =
        "Cerca Enclave ID";

    memberSearch.id =
        "groupMemberSearch";

    memberSearch.autocomplete =
        "off";


    const membersCount =
        document.createElement("div");

    membersCount.className =
        "group-members-count";

    membersCount.id =
        "groupMembersCount";


    const searchResults =
        document.createElement("div");

    searchResults.className =
        "group-search-results";

    searchResults.id =
        "groupSearchResults";


    const selectedMembers =
        document.createElement("div");

    selectedMembers.className =
        "group-selected-members";

    selectedMembers.id =
        "groupSelectedMembers";


    const actions =
        document.createElement("div");

    actions.className =
        "group-creation-actions";


    const cancelButton =
        document.createElement("button");

    cancelButton.type =
        "button";

    cancelButton.className =
        "group-cancel-button";

    cancelButton.textContent =
        "Annulla";


    const createButton =
        document.createElement("button");

    createButton.type =
        "button";

    createButton.className =
        "group-create-button";

    createButton.textContent =
        "Crea gruppo";

    createButton.disabled =
        true;


    actions.appendChild(
        cancelButton
    );

    actions.appendChild(
        createButton
    );


    panel.appendChild(title);
    panel.appendChild(groupNameInput);
    panel.appendChild(memberSearch);
    panel.appendChild(membersCount);
    panel.appendChild(searchResults);
    panel.appendChild(selectedMembers);
    panel.appendChild(actions);


    groupCreationOverlay.appendChild(
        panel
    );


    document.body.appendChild(
        groupCreationOverlay
    );


    // =========================
    // ANNULLA
    // =========================

    cancelButton.addEventListener(
        "click",
        () => {

            closeGroupCreation();

        }
    );


    // =========================
    // CLICK FUORI
    // =========================

    // Chiudi toccando/cliccando il backdrop, senza dover entrare nel pannello.
    const closeFromBackdrop = event => {
        if (event.target === groupCreationOverlay) {
            closeGroupCreation();
        }
    };
    groupCreationOverlay.addEventListener("pointerdown", closeFromBackdrop);
    groupCreationOverlay.addEventListener("click", closeFromBackdrop);

    groupCreationOverlay.addEventListener("keydown", event => {
        if (event.key === "Escape") {
            event.preventDefault();
            closeGroupCreation();
        }
    });


    // =========================
    // NOME GRUPPO
    // =========================

    groupNameInput.addEventListener(
        "input",
        () => {

            updateGroupCreateButton();

        }
    );


    // =========================
    // RICERCA MEMBRI
    // =========================

    memberSearch.addEventListener(
        "input",
        async () => {

            const search =
                memberSearch.value
                    .trim()
                    .toUpperCase();


            searchResults.innerHTML =
                "";


            if (!search) {
                return;
            }


            if (
                selectedGroupMembers.length >=
                20
            ) {

                return;

            }


            try {

                const idDocument =
                    await getDoc(
                        doc(
                            db,
                            "enclaveIds",
                            search
                        )
                    );


                if (
                    !idDocument.exists()
                ) {

                    return;

                }


                const userUid =
                    idDocument.data().uid;


                if (
                    userUid ===
                    auth.currentUser.uid
                ) {

                    return;

                }


                const alreadySelected =
                    selectedGroupMembers.some(
                        (member) =>
                            member.uid ===
                            userUid
                    );


                if (alreadySelected) {
                    return;
                }


                const userDocument =
                    await getDoc(
                        doc(
                            db,
                            "publicUsers",
                            userUid
                        )
                    );


                if (
                    !userDocument.exists()
                ) {

                    return;

                }


                const userData =
                    userDocument.data();


                const result =
                    document.createElement(
                        "div"
                    );


                result.className =
                    "group-search-result";


                const avatar =
                    document.createElement(
                        "div"
                    );


                avatar.className =
                    "group-search-avatar";


                avatar.textContent =
                    userData.nickname
                        .charAt(0)
                        .toUpperCase();


                const info =
                    document.createElement(
                        "div"
                    );


                info.className =
                    "group-search-info";


                const nickname =
                    document.createElement(
                        "span"
                    );


                nickname.className =
                    "group-search-nickname";

                nickname.textContent =
                    userData.nickname;


                const enclaveId =
                    document.createElement(
                        "span"
                    );


                enclaveId.className =
                    "group-search-id";

                enclaveId.textContent =
                    userData.enclaveId;


                info.appendChild(
                    nickname
                );

                info.appendChild(
                    enclaveId
                );


                result.appendChild(
                    avatar
                );

                result.appendChild(
                    info
                );


                searchResults.appendChild(
                    result
                );


                result.addEventListener(
                    "click",
                    () => {

                        if (
                            selectedGroupMembers.length >=
                            19
                        ) {

                            return;

                        }


                        selectedGroupMembers.push({
                            uid:
                                userUid,

                            nickname:
                                userData.nickname,

                            enclaveId:
                                userData.enclaveId
                        });


                        memberSearch.value =
                            "";

                        searchResults.innerHTML =
                            "";


                        renderSelectedMembers();

                        updateGroupCreateButton();

                    }
                );


            } catch (error) {

                console.error(
                    "Errore ricerca membro gruppo:",
                    error
                );

            }

        }
    );


    // =========================
    // CREA GRUPPO
    // =========================

    createButton.addEventListener(
        "click",
        async () => {

            await createGroup();

        }
    );


    updateGroupMembersCount();


    return groupCreationOverlay;
}


// =========================
// CONTATORE MEMBRI
// =========================

function updateGroupMembersCount() {

    const counter =
        document.getElementById(
            "groupMembersCount"
        );


    if (!counter) {
        return;
    }


    counter.textContent =
        `${selectedGroupMembers.length + 1}/20 partecipanti`;
}


// =========================
// PULSANTE CREA
// =========================

function updateGroupCreateButton() {

    const button =
        document.querySelector(
            ".group-create-button"
        );

    const nameInput =
        document.getElementById(
            "groupNameInput"
        );


    if (!button || !nameInput) {
        return;
    }


    button.disabled =
        !nameInput.value.trim() ||
        selectedGroupMembers.length === 0;
}


// =========================
// MEMBRI SELEZIONATI
// =========================

function renderSelectedMembers() {

    const container =
        document.getElementById(
            "groupSelectedMembers"
        );


    if (!container) {
        return;
    }


    container.innerHTML =
        "";


    selectedGroupMembers.forEach(
        (member, index) => {

            const element =
                document.createElement(
                    "div"
                );


            element.className =
                "group-selected-member";


            const text =
                document.createElement(
                    "span"
                );


            text.textContent =
                `${member.nickname} · ${member.enclaveId}`;


            const removeButton =
                document.createElement(
                    "button"
                );


            removeButton.type =
                "button";

            removeButton.className =
                "group-remove-member";

            removeButton.textContent =
                "×";


            removeButton.addEventListener(
                "click",
                () => {

                    selectedGroupMembers.splice(
                        index,
                        1
                    );


                    renderSelectedMembers();

                    updateGroupMembersCount();

                    updateGroupCreateButton();

                }
            );


            element.appendChild(
                text
            );

            element.appendChild(
                removeButton
            );


            container.appendChild(
                element
            );

        }
    );


    updateGroupMembersCount();
}


// =========================
// APRI CREAZIONE GRUPPO
// =========================

function openGroupCreation() {

    const overlay =
        createGroupCreationPanel();


    selectedGroupMembers =
        [];


    const nameInput =
        document.getElementById(
            "groupNameInput"
        );

    const memberSearch =
        document.getElementById(
            "groupMemberSearch"
        );

    const results =
        document.getElementById(
            "groupSearchResults"
        );


    if (nameInput) {
        nameInput.value = "";
    }


    if (memberSearch) {
        memberSearch.value = "";
    }


    if (results) {
        results.innerHTML = "";
    }


    renderSelectedMembers();

    updateGroupMembersCount();

    updateGroupCreateButton();


    overlay.classList.remove(
        "hidden"
    );


    nameInput?.focus();

}


// =========================
// CHIUDI CREAZIONE GRUPPO
// =========================

function closeGroupCreation() {

    if (!groupCreationOverlay) {
        return;
    }


    groupCreationOverlay.classList.add(
        "hidden"
    );


    selectedGroupMembers =
        [];

}


// =========================
// SCHEDA GRUPPO
// =========================

let groupInfoOverlay = null;

let currentGroupData = null;


// =========================
// CREA SCHEDA GRUPPO
// =========================

function createGroupInfoPanel() {

    if (groupInfoOverlay) {
        return groupInfoOverlay;
    }


    groupInfoOverlay =
        document.createElement("div");

    groupInfoOverlay.className =
        "group-info-overlay hidden";


    const panel =
        document.createElement("div");

    panel.className =
        "group-info-panel";


    // =========================
    // HEADER
    // =========================

    const header =
        document.createElement("div");

    header.className =
        "group-info-header";


    const title =
        document.createElement("h2");

    title.className =
        "group-info-title";


    const closeButton =
        document.createElement("button");

    closeButton.type =
        "button";

    closeButton.className =
        "group-info-close";

    closeButton.textContent =
        "×";


    header.appendChild(title);
    header.appendChild(closeButton);


    // =========================
    // CONTATORE
    // =========================

    const count =
        document.createElement("div");

    count.className =
        "group-info-count";


    // =========================
    // MEMBRI
    // =========================

    const membersList =
        document.createElement("div");

    membersList.className =
        "group-info-members";


    // =========================
    // AGGIUNGI MEMBRO
    // =========================

    const addSection =
        document.createElement("div");

    addSection.className =
        "group-add-section";


    const addButton =
        document.createElement("button");

    addButton.type =
        "button";

    addButton.className =
        "group-add-button";

    addButton.textContent =
        "+ Aggiungi membro";


    const addArea =
        document.createElement("div");

    addArea.className =
        "group-add-area hidden";


    const addInput =
        document.createElement("input");

    addInput.type =
        "text";

    addInput.className =
        "group-add-input";

    addInput.placeholder =
        "Cerca Enclave ID";

    addInput.autocomplete =
        "off";


    const addResults =
        document.createElement("div");

    addResults.className =
        "group-add-results";


    addArea.appendChild(addInput);
    addArea.appendChild(addResults);

    addSection.appendChild(addButton);
    addSection.appendChild(addArea);


    // =========================
    // ABBANDONA
    // =========================

    const leaveSection =
        document.createElement("div");

    leaveSection.className =
        "group-leave-section";


    const leaveButton =
        document.createElement("button");

    leaveButton.type =
        "button";

    leaveButton.className =
        "group-leave-button";

    leaveButton.textContent =
        "🚪 Abbandona gruppo";


    leaveSection.appendChild(
        leaveButton
    );


    // =========================
    // ASSEMBLA
    // =========================

    panel.appendChild(header);
    panel.appendChild(count);
    panel.appendChild(membersList);
    panel.appendChild(addSection);
    panel.appendChild(leaveSection);

    groupInfoOverlay.appendChild(panel);

    document.body.appendChild(
        groupInfoOverlay
    );


    // =========================
    // CHIUDI
    // =========================

    closeButton.addEventListener(
        "click",
        () => {

            closeGroupInfo();

        }
    );


    groupInfoOverlay.addEventListener(
        "click",
        (event) => {

            if (
                event.target ===
                groupInfoOverlay
            ) {

                closeGroupInfo();

            }

        }
    );


    // =========================
    // APRI AGGIUNTA
    // =========================

    addButton.addEventListener(
        "click",
        () => {

            addArea.classList.toggle(
                "hidden"
            );

            if (
                !addArea.classList.contains(
                    "hidden"
                )
            ) {

                addInput.focus();

            }

        }
    );


    // =========================
    // RICERCA MEMBRO
    // =========================

    addInput.addEventListener(
        "input",
        async () => {

            const search =
                addInput.value
                    .trim()
                    .toUpperCase();


            addResults.innerHTML =
                "";


            if (!search) {
                return;
            }


            if (
                !currentGroupData ||
                currentGroupData.participants.length >= 20
            ) {

                return;

            }


            const currentUser =
                auth.currentUser;


            if (!currentUser) {
                return;
            }


            try {

                const idDocument =
                    await getDoc(
                        doc(
                            db,
                            "enclaveIds",
                            search
                        )
                    );


                if (
                    !idDocument.exists()
                ) {

                    return;

                }


                const userUid =
                    idDocument.data().uid;


                if (
                    currentGroupData.participants.includes(
                        userUid
                    )
                ) {

                    return;

                }


                const userDocument =
                    await getDoc(
                        doc(
                            db,
                            "publicUsers",
                            userUid
                        )
                    );


                if (
                    !userDocument.exists()
                ) {

                    return;

                }


                const userData =
                    userDocument.data();


                const result =
                    document.createElement(
                        "div"
                    );

                result.className =
                    "group-add-result";


                const avatar =
                    document.createElement(
                        "div"
                    );

                avatar.className =
                    "group-add-avatar";

                avatar.textContent =
                    userData.nickname
                        .charAt(0)
                        .toUpperCase();


                const info =
                    document.createElement(
                        "div"
                    );

                info.className =
                    "group-add-info";


                const nickname =
                    document.createElement(
                        "span"
                    );

                nickname.className =
                    "group-add-nickname";

                nickname.textContent =
                    userData.nickname;


                const enclaveId =
                    document.createElement(
                        "span"
                    );

                enclaveId.className =
                    "group-add-id";

                enclaveId.textContent =
                    userData.enclaveId;


                info.appendChild(
                    nickname
                );

                info.appendChild(
                    enclaveId
                );


                result.appendChild(
                    avatar
                );

                result.appendChild(
                    info
                );


                addResults.appendChild(
                    result
                );


                result.addEventListener(
                    "click",
                    async () => {

                        await addGroupMember(
                            userUid
                        );

                        addInput.value =
                            "";

                        addResults.innerHTML =
                            "";

                    }
                );


            } catch (error) {

                console.error(
                    "Errore ricerca membro:",
                    error
                );

            }

        }
    );


    // =========================
    // ABBANDONA
    // =========================

    leaveButton.addEventListener(
        "click",
        async () => {

            await leaveGroup();

        }
    );


    return groupInfoOverlay;
}


// =========================
// RIMUOVI MEMBRO
// =========================

async function removeGroupMember(
    userUid,
    userNickname
) {

    if (!currentGroupData) {
        return;
    }

    const currentUser =
        auth.currentUser;

    if (!currentUser) {
        return;
    }

    // Solo il proprietario può rimuovere membri
    if (
        currentGroupData.createdBy !==
        currentUser.uid
    ) {
        return;
    }

    // Il proprietario non può rimuovere sé stesso
    if (
        userUid ===
        currentGroupData.createdBy
    ) {
        return;
    }

    const confirmed =
        confirm(
            `Vuoi rimuovere ${userNickname} dal gruppo?`
        );

    if (!confirmed) {
        return;
    }

    try {

        const remainingParticipants =
            currentGroupData.participants.filter(
                uid =>
                    uid !== userUid
            );

        await updateDoc(
            doc(
                db,
                "chats",
                currentGroupData.chatId
            ),
            {
                participants:
                    remainingParticipants
            }
        );

        currentGroupData.participants =
            remainingParticipants;

        await renderGroupInfo();

        await loadConversations();

    } catch (error) {

        console.error(
            "Errore rimozione membro:",
            error
        );

        alert(
            "Impossibile rimuovere il membro."
        );
    }
}


// =========================
// APRI SCHEDA GRUPPO
// =========================

async function openGroupInfo(chatId) {

    try {

        const chatDocument =
            await getDoc(
                doc(
                    db,
                    "chats",
                    chatId
                )
            );


        if (
            !chatDocument.exists()
        ) {

            return;

        }


        const chatData =
            chatDocument.data();


        if (
            chatData.type !== "group"
        ) {

            return;

        }


        currentGroupData = {

            chatId:
                chatId,

            ...chatData

        };


        const overlay =
            createGroupInfoPanel();


        renderGroupInfo();


        overlay.classList.remove(
            "hidden"
        );


    } catch (error) {

        console.error(
            "Errore apertura gruppo:",
            error
        );

    }

}


let contactInfoOverlay = null;
let currentContactData = null;


function createContactInfoPanel() {
    if (contactInfoOverlay) {
        return contactInfoOverlay;
    }

    contactInfoOverlay = document.createElement("div");
    contactInfoOverlay.className = "group-info-overlay hidden";

    const panel = document.createElement("div");
    panel.className = "group-info-panel";

    const header = document.createElement("div");
    header.className = "group-info-header";

    const title = document.createElement("h2");
    title.className = "group-info-title";
    title.textContent = "Informazioni contatto";

    const closeButton = document.createElement("button");
    closeButton.type = "button";
    closeButton.className = "group-info-close";
    closeButton.textContent = "×";

    header.appendChild(title);
    header.appendChild(closeButton);

    const contactSection = document.createElement("div");
    contactSection.className = "group-info-members";

    const nicknameRow = document.createElement("div");
    nicknameRow.className = "contact-nickname-row";

    const nicknameLabel = document.createElement("span");
    nicknameLabel.textContent = "Soprannome";

    const nicknameValue = document.createElement("span");
    nicknameValue.className = "contact-nickname-value";

    const editButton = document.createElement("button");
    editButton.type = "button";
    editButton.className = "contact-nickname-edit";
    editButton.textContent = "✎";
    editButton.title = "Modifica soprannome";
    editButton.setAttribute("aria-label", "Modifica soprannome");

    nicknameRow.appendChild(nicknameLabel);
    nicknameRow.appendChild(nicknameValue);
    nicknameRow.appendChild(editButton);

    const originalNickname = document.createElement("div");
    originalNickname.className = "contact-original-nickname";

    contactSection.appendChild(nicknameRow);
    contactSection.appendChild(originalNickname);

    panel.appendChild(header);
    panel.appendChild(contactSection);

    contactInfoOverlay.appendChild(panel);
    document.body.appendChild(contactInfoOverlay);

    closeButton.addEventListener("click", closeContactInfo);

    contactInfoOverlay.addEventListener("click", (event) => {
        if (event.target === contactInfoOverlay) {
            closeContactInfo();
        }
    });


editButton.addEventListener("click", async () => {
    if (!currentContactData) return;

    const currentNickname = nicknameValue.textContent;

    const newNickname = prompt(
        "Inserisci il soprannome personale (lascia vuoto per ripristinare quello originale):",
        currentNickname
    );

    if (newNickname === null) return;

    try {
        await saveContactNickname(
            currentContactData.uid,
            newNickname
        );

        const cleanNickname = newNickname.trim();
        const displayedNickname =
            cleanNickname || currentContactData.originalNickname;

        nicknameValue.textContent = displayedNickname;
        chatUserNickname.textContent = displayedNickname;
        chatUserAvatar.textContent =
            displayedNickname.charAt(0).toUpperCase();

        originalNickname.textContent =
            "Nickname originale: " +
            currentContactData.originalNickname;

        // Aggiorna il nome nella lista senza ricaricare tutte le chat.
        document.querySelectorAll(".conversation-item").forEach((item) => {
            const nameElement = item.querySelector(".conversation-nickname");

            if (
                nameElement &&
                item.dataset.contactUid === currentContactData.uid
            ) {
                nameElement.textContent = displayedNickname;

                const avatar = item.querySelector(".conversation-avatar");
                if (avatar) {
                    avatar.textContent = displayedNickname.charAt(0).toUpperCase();
                }
            }
        });

    } catch (error) {
        console.error("Errore modifica soprannome:", error);
        alert(error.message || "Impossibile salvare il soprannome.");
    }
});


    return contactInfoOverlay;
}

function closeContactInfo() {
    if (contactInfoOverlay) {
        contactInfoOverlay.classList.add("hidden");
    }
}


async function openContactInfo(contactUid, originalNickname) {
    try {
        const displayedNickname = await getContactNickname(
            contactUid,
            originalNickname
        );

        currentContactData = {
            uid: contactUid,
            originalNickname: originalNickname
        };

        const overlay = createContactInfoPanel();

        overlay.querySelector(".contact-nickname-value")
            .textContent = displayedNickname;

        overlay.querySelector(".contact-original-nickname")
            .textContent = "Nickname originale: " + originalNickname;

        overlay.classList.remove("hidden");
    } catch (error) {
        console.error("Errore apertura informazioni contatto:", error);
    }
}



// =========================
// RENDER SCHEDA GRUPPO
// =========================

async function renderGroupInfo() {

    if (!currentGroupData) {
        return;
    }


    const panel =
        groupInfoOverlay.querySelector(
            ".group-info-panel"
        );


    const title =
        panel.querySelector(
            ".group-info-title"
        );


    const count =
        panel.querySelector(
            ".group-info-count"
        );


    const membersList =
        panel.querySelector(
            ".group-info-members"
        );


    const addSection =
        panel.querySelector(
            ".group-add-section"
        );


    title.textContent =
        currentGroupData.name;


    // =========================================
    // PARTECIPANTI TOTALI
    // Il proprietario è incluso
    // =========================================

    const participants =
        currentGroupData.participants || [];


    count.textContent =
        `${participants.length} partecipanti`;


    membersList.innerHTML =
        "";


    const currentUser =
        auth.currentUser;


    const isOwner =
        currentUser &&
        currentGroupData.createdBy ===
            currentUser.uid;


    addSection.style.display =
        isOwner &&
        participants.length < 20
            ? "block"
            : "none";


    // =========================================
    // CARICA TUTTI I PARTECIPANTI
    // =========================================

    const memberResults =
        await Promise.all(

            participants.map(
                async (uid) => {

                    try {

                        const userDocument =
                            await getDoc(
                                doc(
                                    db,
                                    "publicUsers",
                                    uid
                                )
                            );


                        if (
                            userDocument.exists()
                        ) {

                            return {
                                uid:
                                    uid,

                                ...userDocument.data()
                            };

                        }


                        // Fallback nel caso in cui
                        // il profilo pubblico non esista

                        return {
                            uid:
                                uid,

                            nickname:
                                uid ===
                                currentGroupData.createdBy
                                    ? "Proprietario"
                                    : "Utente",

                            enclaveId:
                                ""
                        };


                    } catch (error) {

                        console.error(
                            "Errore caricamento partecipante:",
                            uid,
                            error
                        );


                        return {
                            uid:
                                uid,

                            nickname:
                                "Utente",

                            enclaveId:
                                ""
                        };

                    }

                }
            )

        );


    // =========================================
    // CREA ELEMENTI PARTECIPANTI
    // =========================================

    memberResults.forEach(
        (userData) => {

            const member =
                document.createElement(
                    "div"
                );


            member.className =
                "group-info-member";


            const avatar =
                document.createElement(
                    "div"
                );


            avatar.className =
                "group-info-avatar";


            avatar.textContent =
                (
                    userData.nickname ||
                    "?"
                )
                    .charAt(0)
                    .toUpperCase();


            const info =
                document.createElement(
                    "div"
                );


            info.className =
                "group-info-member-data";


            const nickname =
                document.createElement(
                    "div"
                );


            nickname.className =
                "group-info-member-name";


            nickname.textContent =
                userData.nickname ||
                "Utente";


            const enclaveId =
                document.createElement(
                    "div"
                );


            enclaveId.className =
                "group-info-member-id";


            enclaveId.textContent =
                userData.enclaveId ||
                "";


            info.appendChild(
                nickname
            );


            info.appendChild(
                enclaveId
            );


            // =================================
            // PROPRIETARIO
            // =================================

            if (
                userData.uid ===
                currentGroupData.createdBy
            ) {

                const owner =
                    document.createElement(
                        "span"
                    );


                owner.className =
                    "group-owner-label";


                owner.textContent =
                    "Proprietario";


                nickname.appendChild(
                    owner
                );

            }


            if (
                isOwner &&
                userData.uid !== currentGroupData.createdBy
            ) {

                const removeButton =
                    document.createElement(
                        "button"
                    );

                removeButton.className =
                    "group-remove-member-button";

                removeButton.type =
                    "button";

                removeButton.textContent =
                    "Rimuovi";

                removeButton.addEventListener(
                    "click",
                    async (event) => {

                        event.preventDefault();
                        event.stopPropagation();

                        await removeGroupMember(
                            userData.uid,
                            userData.nickname
                        );

                    }
                );

                member.appendChild(
                    avatar
                );

                member.appendChild(
                    info
                );

                member.appendChild(
                    removeButton
                );

            } else {

                member.appendChild(
                    avatar
                );

                member.appendChild(
                    info
                );

            }


            membersList.appendChild(
                member
            );

        }
    );

}


// =========================
// CHIUDI SCHEDA GRUPPO
// =========================

function closeGroupInfo() {

    if (!groupInfoOverlay) {
        return;
    }


    groupInfoOverlay.classList.add(
        "hidden"
    );


    currentGroupData =
        null;

}


// =========================
// AGGIUNGI MEMBRO
// =========================

async function addGroupMember(userUid) {

    const currentUser =
        auth.currentUser;


    if (
        !currentUser ||
        !currentGroupData
    ) {

        return;

    }


    if (
        currentGroupData.createdBy !==
        currentUser.uid
    ) {

        return;

    }


    if (
        currentGroupData.participants.length >=
        20
    ) {

        return;

    }


    if (
        currentGroupData.participants.includes(
            userUid
        )
    ) {

        return;

    }


    try {

        await updateDoc(
            doc(
                db,
                "chats",
                currentGroupData.chatId
            ),
            {

                participants: [
                    ...currentGroupData.participants,
                    userUid
                ]

            }
        );


        currentGroupData.participants.push(
            userUid
        );


        await renderGroupInfo();


    } catch (error) {

        console.error(
            "Errore aggiunta membro:",
            error
        );

    }

}


// =========================
// ABBANDONA GRUPPO
// =========================

async function leaveGroup() {

    const currentUser =
        auth.currentUser;


    if (
        !currentUser ||
        !currentGroupData
    ) {

        return;

    }


    const confirmed =
        confirm(
            "Sei sicuro di voler abbandonare questo gruppo?"
        );


    if (!confirmed) {
        return;
    }


    try {

        const remainingParticipants =
            currentGroupData.participants.filter(
                (uid) =>
                    uid !==
                    currentUser.uid
            );


        if (
            remainingParticipants.length ===
            0
        ) {

            await deleteDoc(
                doc(
                    db,
                    "chats",
                    currentGroupData.chatId
                )
            );


        } else {

            let newOwner =
                currentGroupData.createdBy;


            if (
                currentGroupData.createdBy ===
                currentUser.uid
            ) {

                newOwner =
                    remainingParticipants[0];

            }


            await updateDoc(
                doc(
                    db,
                    "chats",
                    currentGroupData.chatId
                ),
                {

                    participants:
                        remainingParticipants,

                    createdBy:
                        newOwner

                }
            );

        }


        closeGroupInfo();


        if (
            currentChatId ===
            currentGroupData?.chatId
        ) {

            chatBackButton.click();

        }


        loadConversations();


    } catch (error) {

        console.error(
            "Errore abbandono gruppo:",
            error
        );

    }

}


// =========================
// CLICK SUL +
// =========================

newGroupButton.addEventListener(
    "click",
    () => {

        let menu =
            document.getElementById(
                "newGroupMenu"
            );


        if (!menu) {

            menu =
                document.createElement(
                    "div"
                );

            menu.id =
                "newGroupMenu";

            menu.className =
                "new-group-menu hidden";


            const groupButton =
                document.createElement(
                    "button"
                );


            groupButton.type =
                "button";

            groupButton.textContent =
                "👥  Nuovo gruppo";


            groupButton.addEventListener(
                "click",
                () => {

                    menu.classList.add(
                        "hidden"
                    );

                    openGroupCreation();

                }
            );


            menu.appendChild(groupButton);

            const aiButton = document.createElement("button");
            aiButton.type = "button";
            aiButton.className = "enclave-ai-menu-option";
            aiButton.innerHTML = '<span aria-hidden="true">✦</span><span>EnclaveAI</span><span class="enclave-ai-menu-tag">AI</span>';
            aiButton.addEventListener("click", () => {
                menu.classList.add("hidden");
                openEnclaveAI();
            });
            menu.appendChild(aiButton);

            chatSidebar.appendChild(menu);

        }


        menu.classList.toggle(
            "hidden"
        );

    }
);

// Chiude il menu rapido "Nuovo gruppo" quando si interagisce
// con qualsiasi altra parte dell'app, inclusa l'apertura di una chat.
document.addEventListener("pointerdown", event => {
    const menu = document.getElementById("newGroupMenu");

    if (!menu || menu.classList.contains("hidden")) {
        return;
    }

    if (
        menu.contains(event.target) ||
        newGroupButton.contains(event.target)
    ) {
        return;
    }

    menu.classList.add("hidden");
});

document.addEventListener("keydown", event => {
    if (event.key !== "Escape") {
        return;
    }

    document
        .getElementById("newGroupMenu")
        ?.classList.add("hidden");
});


// =========================
// CREA GRUPPO FIRESTORE
// =========================

async function createGroup() {

    const currentUser =
        auth.currentUser;


    if (!currentUser) {
        return;
    }


    const nameInput =
        document.getElementById(
            "groupNameInput"
        );


    if (!nameInput) {
        return;
    }


    const groupName =
        nameInput.value.trim();


    if (!groupName) {
        return;
    }


    if (
        selectedGroupMembers.length >
        19
    ) {

        return;

    }


    const participants = [
        currentUser.uid,
        ...selectedGroupMembers.map(
            (member) =>
                member.uid
        )
    ];


    try {

        const chatReference =
            await addDoc(
                collection(
                    db,
                    "chats"
                ),
                {

                    type:
                        "group",

                    name:
                        groupName,

                    participants:
                        participants,

                    createdBy:
                        currentUser.uid,

                    lastMessage:
                        "",

                    lastMessageAt:
                        null,

                    lastSenderId:
                        null,

                    createdAt:
                        serverTimestamp()

                }
            );


        closeGroupCreation();


        console.log(
            "GRUPPO CREATO:",
            chatReference.id
        );


    } catch (error) {

        console.error(
            "Errore creazione gruppo:",
            error
        );

    }

}


// =========================
// BARRA RISPOSTA
// =========================

function createReplyBar() {

    let replyBar =
        document.getElementById(
            "messageReplyBar"
        );


    if (replyBar) {
        return replyBar;
    }


    const chatInputArea =
        document.querySelector(
            ".chat-input-area"
        );


    if (!chatInputArea) {
        return null;
    }


    replyBar =
        document.createElement(
            "div"
        );


    replyBar.id =
        "messageReplyBar";


    replyBar.className =
        "message-reply-bar";


    const replyInfo =
        document.createElement(
            "div"
        );


    replyInfo.className =
        "message-reply-info";


    const replyTitle =
        document.createElement(
            "div"
        );


    replyTitle.className =
        "message-reply-title";


    replyTitle.textContent =
        "Rispondi a";


    const replyText =
        document.createElement(
            "div"
        );


    replyText.className =
        "message-reply-text";


    replyInfo.appendChild(
        replyTitle
    );


    replyInfo.appendChild(
        replyText
    );


    const cancelButton =
        document.createElement(
            "button"
        );


    cancelButton.type =
        "button";


    cancelButton.className =
        "message-reply-cancel";


    cancelButton.textContent =
        "×";


    cancelButton.addEventListener(
        "click",
        (event) => {

            event.preventDefault();

            event.stopPropagation();

            clearReply();

        }
    );


    replyBar.appendChild(
        replyInfo
    );


    replyBar.appendChild(
        cancelButton
    );


    chatInputArea.insertBefore(
        replyBar,
        chatInputArea.firstChild
    );


    return replyBar;

}


// =========================
// INIZIA RISPOSTA
// =========================

function startReply(message) {

    if (!message) {
        return;
    }


    replyTarget = {

        messageId:
            message.id,

        text:
            message.text || "",

        senderId:
            message.senderId || ""

    };


    const replyBar =
        createReplyBar();


    if (!replyBar) {
        return;
    }


    const replyText =
        replyBar.querySelector(
            ".message-reply-text"
        );


    if (replyText) {

        replyText.textContent =
            message.text || "";

    }


    replyBar.style.display =
        "flex";


    messageInput.focus();


    closeMessageMenus();

}


// =========================
// CANCELLA RISPOSTA
// =========================

function clearReply() {

    replyTarget = null;


    const replyBar =
        document.getElementById(
            "messageReplyBar"
        );


    if (replyBar) {

        replyBar.style.display =
            "none";

    }

}


// =========================
// AGGIORNA ULTIMO MESSAGGIO
// =========================

async function updateChatLastMessage(chatId) {

    if (!chatId) {
        return;
    }


    try {

        const messagesReference =
            collection(
                db,
                "chats",
                chatId,
                "messages"
            );


        const snapshot =
            await getDocs(
                messagesReference
            );


        const messages = [];


        snapshot.forEach(
            (messageDocument) => {

                messages.push({
                    id:
                        messageDocument.id,

                    ...messageDocument.data()
                });

            }
        );


        messages.sort(
            (a, b) => {

                const timeA =
                    a.createdAt
                        ?.toMillis?.() || 0;

                const timeB =
                    b.createdAt
                        ?.toMillis?.() || 0;

                return timeB - timeA;

            }
        );


        const chatReference =
            doc(
                db,
                "chats",
                chatId
            );


        if (messages.length === 0) {

            await updateDoc(
                chatReference,
                {
                    lastMessage: "",
                    lastMessageAt: null,
                    lastSenderId: null
                }
            );

            return;
        }


        const latestMessage =
            messages[0];


        await updateDoc(
            chatReference,
            {
                lastMessage:
                    latestMessage.text,

                lastMessageAt:
                    latestMessage.createdAt,

                lastSenderId:
                    latestMessage.senderId
            }
        );


    } catch (error) {

        console.error(
            "Errore aggiornamento ultimo messaggio:",
            error
        );

    }

}


// =========================
// ELIMINA MESSAGGIO
// =========================

async function deleteMessage(
    messageId,
    chatId
) {

    if (!messageId || !chatId) {
        return;
    }


    try {

        const messageReference =
            doc(
                db,
                "chats",
                chatId,
                "messages",
                messageId
            );


        await deleteDoc(
            messageReference
        );


        await updateChatLastMessage(
            chatId
        );


    } catch (error) {

        console.error(
            "Errore eliminazione messaggio:",
            error
        );

    }

}


// =========================
// MODIFICA MESSAGGIO
// =========================

async function editMessage(
    messageId,
    chatId,
    oldText
) {

    const newText =
        prompt(
            "Modifica messaggio:",
            oldText
        );


    if (newText === null) {
        return;
    }


    const trimmedText =
        newText.trim();


    if (!trimmedText) {
        return;
    }


    try {

        const messageReference =
            doc(
                db,
                "chats",
                chatId,
                "messages",
                messageId
            );


        await updateDoc(
            messageReference,
            {
                text:
                    trimmedText,

                edited:
                    true
            }
        );


        await updateChatLastMessage(
            chatId
        );


    } catch (error) {

        console.error(
            "Errore modifica messaggio:",
            error
        );

    }

}


// =========================
// MENU MESSAGGIO
// =========================

function openMessageMenu(
    messageElement,
    message
) {

    closeMessageMenus();


    const menu =
        document.createElement(
            "div"
        );


    menu.className =
        "message-menu";


    const isOwnMessage =
        auth.currentUser &&
        message.senderId ===
            auth.currentUser.uid;


    // =========================
    // RISPONDI
    // =========================

    const replyButton =
        document.createElement(
            "button"
        );


    replyButton.className =
        "message-menu-button";


    replyButton.type =
        "button";


    replyButton.textContent =
        "↩ Rispondi";


    replyButton.addEventListener(
        "click",
        (event) => {

            event.preventDefault();

            event.stopPropagation();

            startReply(
                message
            );

        }
    );


    menu.appendChild(
        replyButton
    );


    // =========================
    // COPIA — DISPONIBILE PER TUTTI I MESSAGGI
    // =========================

    const copyButton = document.createElement("button");
    copyButton.className = "message-menu-button";
    copyButton.type = "button";
    copyButton.textContent = "Copia";

    copyButton.addEventListener("click", async (event) => {
        event.preventDefault();
        event.stopPropagation();

        const textToCopy = String(message.text ?? "");

        try {
            if (navigator.clipboard?.writeText) {
                await navigator.clipboard.writeText(textToCopy);
            } else {
                throw new Error("Clipboard API non disponibile");
            }
        } catch (error) {
            // Fallback per browser/dispositivi che non espongono Clipboard API.
            const temporaryTextarea = document.createElement("textarea");
            temporaryTextarea.value = textToCopy;
            temporaryTextarea.setAttribute("readonly", "");
            temporaryTextarea.style.position = "fixed";
            temporaryTextarea.style.opacity = "0";
            temporaryTextarea.style.pointerEvents = "none";
            document.body.appendChild(temporaryTextarea);
            temporaryTextarea.select();
            temporaryTextarea.setSelectionRange(0, temporaryTextarea.value.length);

            let copied = false;
            try {
                copied = document.execCommand("copy");
            } finally {
                temporaryTextarea.remove();
            }

            if (!copied) {
                console.error("Copia del messaggio non riuscita:", error);
                copyButton.textContent = "Copia non riuscita";
                return;
            }
        }

        copyButton.textContent = "Copiato!";
        closeMessageMenus();
    });

    menu.appendChild(copyButton);


    // =========================
    // MODIFICA + ELIMINA
    // SOLO PER I TUOI MESSAGGI
    // =========================

    if (isOwnMessage) {

        const editButton =
            document.createElement(
                "button"
            );


        editButton.className =
            "message-menu-button";


        editButton.type =
            "button";


        editButton.textContent =
            "Modifica";


        editButton.addEventListener(
            "click",
            async (event) => {

                event.preventDefault();

                event.stopPropagation();

                closeMessageMenus();

                await editMessage(
                    message.id,
                    currentChatId,
                    message.text
                );

            }
        );


        const deleteButton =
            document.createElement(
                "button"
            );


        deleteButton.className =
            "message-menu-button";


        deleteButton.type =
            "button";


        deleteButton.textContent =
            "Elimina";


        deleteButton.addEventListener(
            "click",
            async (event) => {

                event.preventDefault();

                event.stopPropagation();

                closeMessageMenus();

                await deleteMessage(
                    message.id,
                    currentChatId
                );

            }
        );


        menu.appendChild(
            editButton
        );


        menu.appendChild(
            deleteButton
        );

    }


    // =========================
    // POSIZIONAMENTO
    // =========================

    const actionButton =
        messageElement.querySelector(
            ".message-actions"
        );


    if (!actionButton) {
        return;
    }


    document.body.appendChild(
        menu
    );


    menu.style.position =
        "fixed";

    menu.style.right =
        "auto";

    menu.style.bottom =
        "auto";


    const arrowRect =
        actionButton.getBoundingClientRect();


    const menuRect =
        menu.getBoundingClientRect();


    const gap =
        8;


    let top =
        arrowRect.top +
        (
            arrowRect.height -
            menuRect.height
        ) / 2;


    let left;


    if (isOwnMessage) {

        left =
            arrowRect.left -
            menuRect.width -
            gap;

    } else {

        left =
            arrowRect.right +
            gap;

    }


    const margin =
        8;


    if (
        left +
        menuRect.width >
        window.innerWidth -
        margin
    ) {

        left =
            window.innerWidth -
            menuRect.width -
            margin;

    }


    if (left < margin) {

        left =
            margin;

    }


    if (
        top +
        menuRect.height >
        window.innerHeight -
        margin
    ) {

        top =
            window.innerHeight -
            menuRect.height -
            margin;

    }


    if (top < margin) {

        top =
            margin;

    }


    menu.style.left =
        `${left}px`;


    menu.style.top =
        `${top}px`;

}


// =========================
// CARICAMENTO MESSAGGI
// =========================

async function loadMessages(chatId) {
    applyConversationTheme();

    const loadVersion = ++messagesLoadVersion;

    // Interrompe subito il listener precedente, senza aspettare Firestore.
    if (unsubscribeMessages) {
        unsubscribeMessages();
        unsubscribeMessages = null;
    }

    clearReply();

    // Non lasciare visibile lo storico della conversazione precedente.
    activeChatDayIndicator = null;
    chatMessages.replaceChildren();

    const loadingMessage = document.createElement("div");
    loadingMessage.className = "chat-empty-messages";
    loadingMessage.textContent = "Caricamento messaggi…";
    chatMessages.appendChild(loadingMessage);

    const chatDocument = await getDoc(
        doc(db, "chats", chatId)
    );

    // Se nel frattempo è stata aperta un'altra chat, ignora questo risultato.
    if (
        loadVersion !== messagesLoadVersion ||
        currentChatId !== chatId
    ) {
        return;
    }

    const chatData = chatDocument.exists() ? chatDocument.data() : {};
    currentChatDocumentExists = chatDocument.exists();
    const isGroupChat = chatData.type === "group";
    const chatParticipants = Array.isArray(chatData.participants)
        ? chatData.participants
        : [];

    // Cache dei nickname del gruppo: evita letture Firestore ripetute a ogni nuovo messaggio.
    const senderNicknameCache = new Map();

    const messagesReference =
        collection(
            db,
            "chats",
            chatId,
            "messages"
        );


    // Carica soltanto i tre giorni di calendario correnti:
    // oggi, ieri e il giorno precedente. I messaggi più vecchi restano
    // conservati in Firestore ma non vengono letti da questa chat.
    const messagesCutoff = new Date();
    messagesCutoff.setHours(0, 0, 0, 0);
    messagesCutoff.setDate(messagesCutoff.getDate() - 2);

    const messagesQuery =
        query(
            messagesReference,
            where("createdAt", ">=", messagesCutoff),
            orderBy("createdAt", "asc")
        );


    // Evita che callback asincrone più vecchie sovrascrivano uno snapshot più recente.
    let latestMessagesSnapshotVersion = 0;

    unsubscribeMessages =
        onSnapshot(
            messagesQuery,
            async (snapshot) => {

                if (
                    loadVersion !== messagesLoadVersion ||
                    currentChatId !== chatId
                ) {
                    return;
                }

                const snapshotVersion = ++latestMessagesSnapshotVersion;

                if (snapshot.empty) {
                    closeMessageMenus();

                    // Aggiorna lo stato di lettura in background: non bloccare la UI.
                    void markChatAsRead(chatId);

                    if (loadVersion !== messagesLoadVersion || currentChatId !== chatId) {
                        return;
                    }

                    const emptyMessage =
                        document.createElement(
                            "div"
                        );


                    emptyMessage.className =
                        "chat-empty-messages";


                    emptyMessage.textContent =
                        "Nessun messaggio negli ultimi 3 giorni";


                    chatMessages.appendChild(
                        emptyMessage
                    );


                    return;

                }


                const messages = [];


                snapshot.forEach(
                    (messageDocument) => {

                        messages.push({
                            id:
                                messageDocument.id,

                            ...messageDocument.data()
                        });

                    }
                );


                messages.sort(
                    (a, b) => {

                        const timeA =
                            a.createdAt
                                ?.toMillis?.() || 0;

                        const timeB =
                            b.createdAt
                                ?.toMillis?.() || 0;

                        return timeA - timeB;

                    }
                );

                const latestMessage = messages[messages.length - 1];

                if (latestMessage?.createdAt) {
                    // La scrittura dello stato di lettura non deve ritardare il rendering.
                    void markChatAsRead(chatId, latestMessage.createdAt);
                }

                // Se è cambiato soltanto readBy, aggiorna il bordo verde in-place.
                // Non svuotare né ricostruire la chat per una semplice conferma di lettura.
                const existingMessageElements = Array.from(
                    chatMessages.querySelectorAll(":scope > .message")
                );
                const existingById = new Map(
                    existingMessageElements.map(element => [element.dataset.messageId, element])
                );
                const sameMessagesExceptReadState =
                    existingMessageElements.length === messages.length &&
                    messages.every(message => {
                        const element = existingById.get(message.id);
                        const previousMessage = element?._enclaveMessage;
                        if (!element || !previousMessage) return false;
                        const { readBy: _previousReadBy, ...previousStableData } = previousMessage;
                        const { readBy: _nextReadBy, ...nextStableData } = message;
                        return JSON.stringify(previousStableData) === JSON.stringify(nextStableData);
                    });

                if (sameMessagesExceptReadState) {
                    const currentUser = auth.currentUser;
                    for (const message of messages) {
                        const element = existingById.get(message.id);
                        const bubble = element?.querySelector(".message-bubble");
                        if (!element || !bubble) continue;

                        const isOwnMessage = currentUser && message.senderId === currentUser.uid;
                        const recipients = chatParticipants.filter(uid => uid !== message.senderId);
                        const readBy = Array.isArray(message.readBy) ? message.readBy : [];
                        const isReadByAllRecipients = isOwnMessage && recipients.length > 0 &&
                            recipients.every(uid => readBy.includes(uid));

                        bubble.classList.toggle("message-read", Boolean(isReadByAllRecipients));
                        if (isReadByAllRecipients) bubble.title = "Letto";
                        else bubble.removeAttribute("title");
                        element._enclaveMessage = message;
                    }

                    if (currentUser && currentChatId === chatId) {
                        void markMessagesAsRead(chatId, messages, currentUser.uid);
                    }
                    return;
                }

                const senderNicknames = {};

                if (isGroupChat) {
                    const senderIds = [...new Set(
                        messages.map(message => message.senderId).filter(Boolean)
                    )];

                    await Promise.all(senderIds.map(async senderId => {
                        if (senderNicknameCache.has(senderId)) {
                            senderNicknames[senderId] = senderNicknameCache.get(senderId);
                            return;
                        }
                        try {
                            const userDocument = await getDoc(doc(db, "publicUsers", senderId));
                            const nickname = userDocument.exists()
                                ? userDocument.data().nickname || "Utente"
                                : "Utente";
                            senderNicknameCache.set(senderId, nickname);
                            senderNicknames[senderId] = nickname;
                        } catch (error) {
                            console.error("Errore recupero nickname:", error);
                            senderNicknameCache.set(senderId, "Utente");
                            senderNicknames[senderId] = "Utente";
                        }
                    }));
                }

                if (
                    loadVersion !== messagesLoadVersion ||
                    currentChatId !== chatId ||
                    snapshotVersion !== latestMessagesSnapshotVersion
                ) {
                    return;
                }

                const currentUser = auth.currentUser;

                // Costruisce il nuovo DOM fuori dallo schermo e lo applica in un unico passaggio.
                // Gli URL dei media restano in cache tra i render: evita download R2 ripetuti
                // quando Firestore aggiorna la conversazione. La cache è limitata a 40 elementi.
                closeMessageMenus();
                const renderedMessagesFragment = document.createDocumentFragment();

                const dayIndicator = document.createElement("div");
                dayIndicator.className = "chat-day-indicator";
                dayIndicator.setAttribute("aria-live", "polite");
                dayIndicator.setAttribute("aria-label", "Giorno dei messaggi visualizzati");
                activeChatDayIndicator = dayIndicator;
                renderedMessagesFragment.appendChild(dayIndicator);

                const historyBoundary = document.createElement("div");
                historyBoundary.className = "chat-history-boundary";
                historyBoundary.textContent = "Impossibile visualizzare messaggi precedenti";
                renderedMessagesFragment.appendChild(historyBoundary);

                messages.forEach(
                    (message) => {

                        const messageElement =
                            document.createElement(
                                "div"
                            );


                        const isOwnMessage =
                            currentUser &&
                            message.senderId ===
                                currentUser.uid;

                        const messageRecipients = chatParticipants.filter(
                            (participantUid) => participantUid !== message.senderId
                        );
                        const messageReadBy = Array.isArray(message.readBy)
                            ? message.readBy
                            : [];
                        const isReadByAllRecipients =
                            isOwnMessage &&
                            messageRecipients.length > 0 &&
                            messageRecipients.every((recipientUid) => messageReadBy.includes(recipientUid));


                        if (isOwnMessage) {

                            messageElement.className =
                                "message message-own";

                        } else {

                            messageElement.className =
                                "message message-other";

                        }


                        // =========================
                        // DATI DEL MESSAGGIO
                        // =========================

                        messageElement._enclaveMessage =
                            message;


                        messageElement.dataset.messageId =
                            message.id;

                        if (isGroupChat) {

                            const senderName =
                                document.createElement("div");

                            senderName.className =
                                "message-sender-name";

                            senderName.textContent =
                                message.senderId === currentUser?.uid
                                    ? senderNicknames[message.senderId] || "Tu"
                                    : senderNicknames[message.senderId] || "Utente";

                            senderName.style.fontSize = "12px";
                            senderName.style.fontWeight = "600";
                            senderName.style.marginBottom = "4px";
                            senderName.style.opacity = "0.8";

                            messageElement.appendChild(senderName);
                        }


                        // =========================
                        // BUBBLE
                        // =========================

                        const bubble =
                            document.createElement(
                                "div"
                            );


                        bubble.className =
                            "message-bubble";

                        if (isReadByAllRecipients) {
                            bubble.classList.add("message-read");
                            bubble.title = "Letto";
                        }


                        // =========================
                        // RISPOSTA QUOTATA
                        // =========================

                        if (message.replyTo) {

                            const replyQuote =
                                document.createElement(
                                    "div"
                                );


                            replyQuote.className =
                                "message-reply-quote";


                            const replyQuoteTitle =
                                document.createElement(
                                    "div"
                                );


                            replyQuoteTitle.className =
                                "message-reply-quote-title";


                            if (
                                message.replyTo.senderId ===
                                currentUser?.uid
                            ) {

                                replyQuoteTitle.textContent =
                                    "Tu";

                            } else {

                                replyQuoteTitle.textContent =
                                    chatUserNickname.textContent;

                            }


                            const replyQuoteText =
                                document.createElement(
                                    "div"
                                );


                            replyQuoteText.className =
                                "message-reply-quote-text";


                            replyQuoteText.textContent =
                                message.replyTo.text || "";


                            replyQuote.appendChild(
                                replyQuoteTitle
                            );


                            replyQuote.appendChild(
                                replyQuoteText
                            );


                            // =========================
                            // CLICK SULLA RISPOSTA
                            // =========================

                            replyQuote.addEventListener(
                                "click",
                                (event) => {

                                    event.preventDefault();

                                    event.stopPropagation();


                                    const targetMessage =
                                        Array.from(
                                            chatMessages.querySelectorAll(
                                                ".message"
                                            )
                                        ).find(
                                            (element) =>
                                                element.dataset.messageId ===
                                                message.replyTo.messageId
                                        );


                                    if (!targetMessage) {
                                        return;
                                    }


                                    targetMessage.scrollIntoView({
                                        behavior:
                                            "smooth",

                                        block:
                                            "center"
                                    });


                                    targetMessage.classList.add(
                                        "reply-highlight"
                                    );


                                    setTimeout(
                                        () => {

                                            targetMessage.classList.remove(
                                                "reply-highlight"
                                            );

                                        },
                                        1200
                                    );

                                }
                            );


                            // La citazione viene
                            // messa SOPRA alla bolla.

                            messageElement.appendChild(
                                replyQuote
                            );

                        }


                        // =========================
                        // TESTO
                        // =========================

                        const textElement =
                            document.createElement(
                                "span"
                            );


                        textElement.className =
                            "message-text";


                        textElement.textContent =
                            message.text || "";


                        // =========================
                        // CONTENUTO MULTIMEDIALE PRIVATO
                        // =========================

                        if (
                            message.media &&
                            message.media.objectKey &&
                            ["image", "audio"].includes(message.media.type)
                        ) {
                            const mediaElement = document.createElement(
                                message.media.type === "image" ? "img" : "audio"
                            );

                            if (message.media.type === "image") {
                                mediaElement.className = "message-media-image";
                                mediaElement.alt = "Immagine condivisa";
                                mediaElement.loading = "lazy";
                            } else {
                                mediaElement.className = "message-media-audio";
                                mediaElement.controls = true;
                                mediaElement.preload = "metadata";
                                mediaElement.setAttribute("aria-label", "Messaggio vocale");
                            }

                            bubble.appendChild(mediaElement);

                            void loadProtectedMediaIntoElement(
                                mediaElement,
                                chatId,
                                message.media.objectKey,
                                loadVersion
                            );
                        }


                        // =========================
                        // ORARIO
                        // =========================

                        const timeElement =
                            document.createElement(
                                "span"
                            );


                        timeElement.className =
                            "message-time";


                        if (message.createdAt) {

                            timeElement.textContent =
                                message.createdAt
                                    .toDate()
                                    .toLocaleTimeString(
                                        "it-IT",
                                        {
                                            hour:
                                                "2-digit",

                                            minute:
                                                "2-digit"
                                        }
                                    );

                        } else {

                            timeElement.textContent =
                                "";

                        }


                        // I messaggi multimediali mostrano solo il contenuto, senza
                        // le vecchie etichette "Immagine" / "Messaggio vocale".
                        if (!message.media && message.text) {
                            bubble.appendChild(textElement);
                        }


                        // =========================
                        // MODIFICATO
                        // =========================

                        if (message.edited) {

                            const editedElement =
                                document.createElement(
                                    "span"
                                );


                            editedElement.className =
                                "message-edited";


                            editedElement.textContent =
                                "modificato";


                            bubble.appendChild(
                                editedElement
                            );

                        }


                        bubble.appendChild(
                            timeElement
                        );


                        // =========================
                        // BOLLA
                        // =========================

                        messageElement.appendChild(
                            bubble
                        );


                        // =========================
                        // AZIONI
                        // TUTTI I MESSAGGI
                        // =========================

                        const actionButton =
                            document.createElement(
                                "button"
                            );


                        actionButton.className =
                            "message-actions";


                        actionButton.type =
                            "button";


                        actionButton.textContent =
                            "⌄";


                        // =========================
                        // APERTURA MENU
                        // TOUCH + CLICK
                        // =========================

                        let lastTouchTime =
                            0;


                        const openActions =
                            (event) => {

                                event.preventDefault();

                                event.stopPropagation();


                                openMessageMenu(
                                    messageElement,
                                    message
                                );

                            };


                        actionButton.addEventListener(
                            "touchend",
                            (event) => {

                                lastTouchTime =
                                    Date.now();

                                openActions(
                                    event
                                );

                            },
                            {
                                passive:
                                    false
                            }
                        );


                        actionButton.addEventListener(
                            "click",
                            (event) => {

                                if (
                                    Date.now() -
                                    lastTouchTime <
                                    600
                                ) {

                                    return;

                                }


                                openActions(
                                    event
                                );

                            }
                        );


                        messageElement.appendChild(
                            actionButton
                        );


                        // =========================
                        // TAP SU MOBILE
                        // MOSTRA FRECCETTA
                        // =========================

                        messageElement.addEventListener(
                            "click",
                            (event) => {

                                if (
                                    window.innerWidth >
                                    700
                                ) {

                                    return;

                                }


                                if (
                                    event.target.closest(
                                        ".message-actions"
                                    )
                                ) {

                                    return;

                                }


                                if (
                                    event.target.closest(
                                        ".message-menu"
                                    )
                                ) {

                                    return;

                                }


                                document
                                    .querySelectorAll(
                                        ".message-actions-visible"
                                    )
                                    .forEach(
                                        (element) => {

                                            if (
                                                element !==
                                                messageElement
                                            ) {

                                                element.classList.remove(
                                                    "message-actions-visible"
                                                );

                                            }

                                        }
                                    );


                                messageElement.classList.toggle(
                                    "message-actions-visible"
                                );

                            }
                        );


                        // =========================
                        // EVITA SELEZIONE TESTO
                        // =========================

                        messageElement.addEventListener(
                            "selectstart",
                            (event) => {

                                if (
                                    window.innerWidth <=
                                    700
                                ) {

                                    event.preventDefault();

                                }

                            }
                        );


                        // =========================
                        // EVITA MENU BROWSER
                        // =========================

                        messageElement.addEventListener(
                            "contextmenu",
                            (event) => {

                                if (
                                    window.innerWidth <=
                                    700
                                ) {

                                    event.preventDefault();

                                }

                            }
                        );


                        renderedMessagesFragment.appendChild(
                            messageElement
                        );

                    }
                );

                // Sostituzione atomica: la conversazione resta visibile fino al completamento.
                chatMessages.replaceChildren(renderedMessagesFragment);

                chatMessages.scrollTop =
                    chatMessages.scrollHeight;
                updateChatDayIndicator();

                // Le conferme sono asincrone e non impediscono il rendering.
                if (currentUser && currentChatId === chatId) {
                    void markMessagesAsRead(chatId, messages, currentUser.uid);
                }

            },
            (error) => {

                console.error(
                    "Errore caricamento messaggi:",
                    error
                );

            }
        );
    }


// =========================
// CHIUDI MENU CLICCANDO FUORI
// =========================

document.addEventListener(
    "click",
    (event) => {

        if (
            !event.target.closest(
                ".message-menu"
            ) &&
            !event.target.closest(
                ".message-actions"
            )
        ) {

            closeMessageMenus();

        }

    }
);


// =========================
// RICERCA UTENTI
// =========================

chatSearch.addEventListener(
    "input",
    async () => {

        console.log(
            "RICERCA ATTIVATA"
        );


        const search =
            chatSearch.value
                .trim()
                .toUpperCase();


        searchResults.innerHTML =
            "";


        if (!search) {
            return;
        }


        try {

            console.log(
                "RICERCA ID:",
                search
            );


            const idDocument =
                await getDoc(
                    doc(
                        db,
                        "enclaveIds",
                        search
                    )
                );


            console.log(
                "DOCUMENTO ID ESISTE:",
                idDocument.exists()
            );


            if (!idDocument.exists()) {

                const noResult =
                    document.createElement(
                        "div"
                    );


                noResult.className =
                    "search-no-result";


                noResult.textContent =
                    "Nessun utente trovato.";


                searchResults.appendChild(
                    noResult
                );


                return;

            }


            const userUid =
                idDocument.data().uid;


            const userDocument =
                await getDoc(
                    doc(
                        db,
                        "publicUsers",
                        userUid
                    )
                );


            if (!userDocument.exists()) {
                return;
            }


            const userData =
                userDocument.data();


            const nickname =
                userData.nickname;


            const enclaveId =
                userData.enclaveId;


            const result =
                document.createElement(
                    "div"
                );


            result.className =
                "search-result";


            const avatar =
                document.createElement(
                    "div"
                );


            avatar.className =
                "search-result-avatar";


            avatar.textContent =
                nickname
                    .charAt(0)
                    .toUpperCase();


            const resultInfo =
                document.createElement(
                    "div"
                );


            resultInfo.className =
                "search-result-info";


            const resultNickname =
                document.createElement(
                    "span"
                );


            resultNickname.className =
                "search-result-nickname";


            resultNickname.textContent =
                nickname;


            const resultId =
                document.createElement(
                    "span"
                );


            resultId.className =
                "search-result-id";


            resultId.textContent =
                enclaveId;


            resultInfo.appendChild(
                resultNickname
            );


            resultInfo.appendChild(
                resultId
            );


            result.appendChild(
                avatar
            );


            result.appendChild(
                resultInfo
            );


            searchResults.appendChild(
                result
            );


            result.addEventListener(
                "click",
                () => {

                    chatEmptyState.classList.add(
                        "hidden"
                    );


                    activeChat.classList.remove(
                        "hidden"
                    );


                    chatUserNickname.textContent =
                        nickname;


                    chatUserId.textContent =
                        enclaveId;


                    chatUserAvatar.textContent =
                        nickname
                            .charAt(0)
                            .toUpperCase();


                    currentChatUserUid =
                        userUid;
                    if (startVoiceCallButton) startVoiceCallButton.classList.remove("hidden");


                    currentChatId =
                        createChatId(
                            auth.currentUser.uid,
                            userUid
                        );


                    loadMessages(
                        currentChatId
                    );

                    if (startVoiceCallButton) {
                        startVoiceCallButton.disabled = false;
                        listenForIncomingVoiceCalls();
                    }


                    markChatViewOpen();


                    if (
                        window.innerWidth <= 700
                    ) {

                        chatSidebar.style.display =
                            "none";


                        chatArea.style.display =
                            "flex";


                        chatArea.style.width =
                            "100%";

                    }

                }
            );


        } catch (error) {

            console.error(
                "Errore ricerca utente:",
                error
            );

        }

    }
);


// =========================
// TORNA ALLA LISTA CHAT
// =========================

chatBackButton.addEventListener("click", () => {
    if (mobileChatHistoryStateActive) {
        // Lascia che il normale evento popstate esegua la chiusura della chat.
        history.back();
        return;
    }
    returnToChatList();
});


// =========================
// INVIO MESSAGGI
// =========================


async function sendMessage() {

    const message = messageInput.value.trim();

    if (!message) return;

    const currentUser = auth.currentUser;

    if (!currentUser) return;

    if (!currentChatUserUid && !currentChatId) return;

    if (
        currentChatUserUid &&
        currentUser.uid === currentChatUserUid
    ) {
        return;
    }

    try {

        let chatId;

        if (currentChatUserUid) {
            chatId = createChatId(
                currentUser.uid,
                currentChatUserUid
            );
        } else {
            chatId = currentChatId;
        }

        const chatReference = doc(db, "chats", chatId);
        // Se la conversazione è già aperta, loadMessages ha già caricato il documento:
        // evita una lettura di rete aggiuntiva prima di inviare ogni messaggio.
        const updateChatMetadataAfterMessage =
            currentChatId === chatId && currentChatDocumentExists;

        if (currentChatUserUid && !updateChatMetadataAfterMessage) {

            const existingChat = await getDoc(chatReference);

            if (existingChat.exists()) {

                const chatData = existingChat.data();

                if (
                    "type" in chatData ||
                    !Array.isArray(chatData.participants) ||
                    !chatData.participants.includes(currentUser.uid) ||
                    !chatData.participants.includes(currentChatUserUid)
                ) {
                    throw new Error(
                        "La chat privata non ha una struttura valida."
                    );
                }

                await updateDoc(chatReference, {
                    lastMessage: message,
                    lastMessageAt: serverTimestamp(),
                    lastSenderId: currentUser.uid
                });

            } else {

                await setDoc(chatReference, {
                    participants: [
                        currentUser.uid,
                        currentChatUserUid
                    ],
                    lastMessage: message,
                    lastMessageAt: serverTimestamp(),
                    lastSenderId: currentUser.uid
                });
                if (currentChatId === chatId) {
                    currentChatDocumentExists = true;
                }

            }

        } else if (!currentChatUserUid && !updateChatMetadataAfterMessage) {

            await updateDoc(chatReference, {
                lastMessage: message,
                lastMessageAt: serverTimestamp(),
                lastSenderId: currentUser.uid
            });

        }

        const messageData = {
            text: message,
            senderId: currentUser.uid,
            createdAt: serverTimestamp(),
            edited: false,
            readBy: [currentUser.uid]
        };

        if (replyTarget) {
            messageData.replyTo = {
                messageId: replyTarget.messageId,
                text: replyTarget.text,
                senderId: replyTarget.senderId
            };
        }

        const messageReference = await addDoc(
            collection(db, "chats", chatId, "messages"),
            messageData
        );

        // La chat è già aperta: aggiorna l'anteprima dopo aver avviato il messaggio,
        // senza mettere due richieste di rete in sequenza prima della visualizzazione.
        if (updateChatMetadataAfterMessage) {
            void updateDoc(chatReference, {
                lastMessage: message,
                lastMessageAt: serverTimestamp(),
                lastSenderId: currentUser.uid
            }).catch(error => {
                console.error("Errore aggiornamento anteprima chat:", error);
            });
        }


        messageInput.value = "";
        clearReply();

        // Notifica al destinatario tramite il Worker.
        // Il messaggio è già stato salvato in Firestore. La richiesta non blocca
        // l'interfaccia e ritenta in caso di rete instabile.
        void postToNotificationWorker({
            chatId: chatId,
            messageId: messageReference.id
        }).then(outcome => {
            if (outcome && !outcome.ok) {
                console.error("Notifica non inviata:", outcome.result);
            } else if (outcome) {
                console.log("Risultato notifiche:", outcome.result);
            }
        }).catch(error => {
            console.error("Errore collegamento notifiche:", error);
        });

        console.log("INVIO COMPLETATO ✅");

    } catch (error) {

    console.error("ERRORE INVIO MESSAGGIO:", {
        code: error.code,
        message: error.message,
        chatId: currentChatId,
        currentUserUid: auth.currentUser?.uid,
        contactUid: currentChatUserUid
    });

    alert(
        "Errore: " +
        (error.code || "sconosciuto") +
        "\n" +
        error.message
    );

}
}




// =========================
// STORAGE MULTIMEDIALE R2
// =========================

async function loadProtectedMediaIntoElement(element, chatId, objectKey, loadVersion) {
    const cacheKey = `${chatId}/${objectKey}`;
    try {
        const cachedUrl = protectedMediaObjectUrlCache.get(cacheKey);
        if (cachedUrl) {
            // Aggiorna l'ordine LRU senza richiedere nuovamente il file a R2.
            protectedMediaObjectUrlCache.delete(cacheKey);
            protectedMediaObjectUrlCache.set(cacheKey, cachedUrl);
            element.src = cachedUrl;
            return;
        }

        const currentUser = auth.currentUser;
        if (!currentUser) throw new Error("Sessione non disponibile.");

        const idToken = await currentUser.getIdToken();
        const mediaUrl = new URL(`${ENCLAVE_STORAGE_WORKER_URL}/media`);
        mediaUrl.searchParams.set("chatId", chatId);
        mediaUrl.searchParams.set("key", objectKey);

        const response = await fetch(mediaUrl.toString(), {
            method: "GET",
            headers: { "Authorization": `Bearer ${idToken}` },
            cache: "no-store"
        });

        if (!response.ok) {
            const result = await response.json().catch(() => ({}));
            throw new Error(result.error || `Download non riuscito (${response.status}).`);
        }

        const blob = await response.blob();
        const objectUrl = URL.createObjectURL(blob);

        if (
            !element.isConnected ||
            currentChatId !== chatId ||
            loadVersion !== messagesLoadVersion
        ) {
            URL.revokeObjectURL(objectUrl);
            return;
        }

        protectedMediaObjectUrlCache.set(cacheKey, objectUrl);
        activeMediaObjectUrls.add(objectUrl);
        while (protectedMediaObjectUrlCache.size > MAX_CACHED_MEDIA_OBJECT_URLS) {
            const oldestKey = protectedMediaObjectUrlCache.keys().next().value;
            const oldestUrl = protectedMediaObjectUrlCache.get(oldestKey);
            protectedMediaObjectUrlCache.delete(oldestKey);
            activeMediaObjectUrls.delete(oldestUrl);
            URL.revokeObjectURL(oldestUrl);
        }
        element.src = objectUrl;
    } catch (error) {
        console.error("Errore caricamento media Enclave:", error);
        const errorLabel = document.createElement("span");
        errorLabel.className = "message-media-error";
        errorLabel.textContent = "Contenuto non disponibile";
        element.replaceWith(errorLabel);
    }
}

async function ensureCurrentMediaChat(currentUser) {
    let chatId = currentChatId;

    if (!chatId && currentChatUserUid) {
        chatId = createChatId(currentUser.uid, currentChatUserUid);
    }

    if (!chatId) {
        throw new Error("Apri prima una conversazione.");
    }

    const chatReference = doc(db, "chats", chatId);
    const chatSnapshot = await getDoc(chatReference);

    if (!chatSnapshot.exists()) {
        if (!currentChatUserUid || currentChatUserUid === currentUser.uid) {
            throw new Error("La conversazione non è disponibile.");
        }

        await setDoc(chatReference, {
            participants: [currentUser.uid, currentChatUserUid]
        });
    } else {
        const participants = chatSnapshot.data().participants || [];
        if (!participants.includes(currentUser.uid)) {
            throw new Error("Non fai parte di questa conversazione.");
        }
    }

    if (currentChatId === chatId) {
        currentChatDocumentExists = true;
    }

    return chatId;
}

async function uploadEnclaveMedia(chatId, type, blob, durationSeconds = null) {
    const currentUser = auth.currentUser;
    if (!currentUser) throw new Error("Devi accedere a Enclave.");

    const formData = new FormData();
    const normalizedMimeType = String(blob.type || "").toLowerCase().split(";")[0].trim();
    const extension = type === "image"
        ? (normalizedMimeType === "image/png" ? "png" : normalizedMimeType === "image/webp" ? "webp" : normalizedMimeType === "image/gif" ? "gif" : normalizedMimeType === "image/avif" ? "avif" : "jpg")
        : (normalizedMimeType === "audio/mp4" || normalizedMimeType === "audio/x-m4a" ? "m4a"
            : normalizedMimeType === "audio/aac" ? "aac"
            : normalizedMimeType === "audio/ogg" ? "ogg"
            : normalizedMimeType === "audio/wav" || normalizedMimeType === "audio/x-wav" ? "wav"
            : normalizedMimeType === "audio/mpeg" ? "mp3" : "webm");

    formData.append("chatId", chatId);
    formData.append("type", type);
    if (durationSeconds !== null) {
        formData.append("durationSeconds", String(durationSeconds));
    }
    formData.append("file", blob, `enclave-${type}.${extension}`);

    const idToken = await currentUser.getIdToken();
    const response = await fetch(`${ENCLAVE_STORAGE_WORKER_URL}/upload`, {
        method: "POST",
        headers: { "Authorization": `Bearer ${idToken}` },
        body: formData
    });

    const result = await response.json().catch(() => ({}));
    if (!response.ok || !result.ok) {
        throw new Error(result.error || `Upload non riuscito (${response.status}).`);
    }

    return result;
}

async function notifyEnclaveMediaMessage(chatId, messageId) {
    try {
        const outcome = await postToNotificationWorker({ chatId, messageId });

        if (outcome && !outcome.ok) {
            console.error("Notifica allegato non inviata:", outcome.result);
        } else if (outcome) {
            console.log("Risultato notifica allegato:", outcome.result);
        }
    } catch (error) {
        console.error("Errore notifica allegato:", error);
    }
}

let mediaUploadInProgress = false;

async function sendEnclaveMediaMessage(type, blob, durationSeconds = null) {
    if (mediaUploadInProgress) return;

    const currentUser = auth.currentUser;
    if (!currentUser) {
        alert("Devi accedere a Enclave.");
        return;
    }

    if (!currentChatId && !currentChatUserUid) {
        alert("Apri prima una conversazione.");
        return;
    }

    mediaUploadInProgress = true;
    if (messageAttachButton) messageAttachButton.disabled = true;

    try {
        const chatId = await ensureCurrentMediaChat(currentUser);
        const uploaded = await uploadEnclaveMedia(
            chatId,
            type,
            blob,
            durationSeconds
        );

        const previewText = type === "image" ? "📷 Immagine" : "🎙 Messaggio vocale";
        const messageData = {
            text: "",
            senderId: currentUser.uid,
            createdAt: serverTimestamp(),
            edited: false,
            readBy: [currentUser.uid],
            media: {
                type,
                objectKey: uploaded.objectKey,
                mimeType: uploaded.mimeType,
                size: uploaded.size,
                durationSeconds: uploaded.durationSeconds
            }
        };

        const messageReference = await addDoc(
            collection(db, "chats", chatId, "messages"),
            messageData
        );

        await updateDoc(doc(db, "chats", chatId), {
            lastMessage: previewText,
            lastMessageAt: serverTimestamp(),
            lastSenderId: currentUser.uid
        });

        if (currentChatId === chatId) {
            currentChatDocumentExists = true;
        }

        clearReply();
        void notifyEnclaveMediaMessage(chatId, messageReference.id);
        console.log(`MESSAGGIO ${type.toUpperCase()} INVIATO ✅`);
    } catch (error) {
        console.error("Errore invio allegato Enclave:", error);
        alert("Impossibile inviare l'allegato:\n" + error.message);
        throw error;
    } finally {
        mediaUploadInProgress = false;
        if (messageAttachButton) messageAttachButton.disabled = false;
    }
}

mediaFileInput.addEventListener("change", async () => {
    const file = mediaFileInput.files?.[0];
    mediaFileInput.value = "";
    if (!file) return;

    const allowedTypes = [
        "image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"
    ];
    if (!allowedTypes.includes(file.type)) {
        alert("Formato immagine non supportato. Usa JPG, PNG, WebP, GIF o AVIF.");
        return;
    }
    if (file.size > 10 * 1024 * 1024) {
        alert("L'immagine supera il limite massimo di 10 MB.");
        return;
    }

    try {
        await sendEnclaveMediaMessage("image", file);
    } catch {
        // L'errore è già mostrato all'utente dalla funzione di invio.
    }
});


// =========================
// REGISTRAZIONE MESSAGGIO VOCALE (MAX 60 SECONDI)
// =========================

let voiceRecorderPanel = null;
let voiceRecorder = null;
let voiceRecorderStream = null;
let voiceRecorderChunks = [];
let voiceRecordedBlob = null;
let voicePreviewObjectUrl = null;
let voiceRecordingStartedAt = 0;
let voiceRecordingTimer = null;
let voiceRecordedDuration = 0;
let voiceRecorderCancelled = false;

function openVoiceRecorderPanel() {
    if (!chatInputArea) return;
    // Ogni nuova sessione parte pulita: dopo Annulla/Invia il flag viene
    // impostato a true per ignorare l'evento onstop della sessione precedente.
    voiceRecorderCancelled = false;
    if (voiceRecorderPanel) {
        voiceRecorderPanel.remove();
        voiceRecorderPanel = null;
    }

    const panel = document.createElement("div");
    panel.className = "voice-recording-panel";
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-label", "Registrazione messaggio vocale");

    const title = document.createElement("strong");
    title.className = "voice-recording-title";
    title.textContent = "Messaggio vocale";

    const status = document.createElement("div");
    status.className = "voice-recording-status";
    status.textContent = "Premi Registra per iniziare (massimo 60 secondi).";

    const timer = document.createElement("div");
    timer.className = "voice-recording-timer";
    timer.textContent = "00:00";

    const controls = document.createElement("div");
    controls.className = "voice-recording-controls";

    const startButton = document.createElement("button");
    startButton.type = "button";
    startButton.textContent = "● Registra";

    const stopButton = document.createElement("button");
    stopButton.type = "button";
    stopButton.textContent = "Ferma";
    stopButton.disabled = true;

    const previewButton = document.createElement("button");
    previewButton.type = "button";
    previewButton.textContent = "Anteprima";
    previewButton.disabled = true;

    const cancelButton = document.createElement("button");
    cancelButton.type = "button";
    cancelButton.textContent = "Annulla";

    const sendButton = document.createElement("button");
    sendButton.type = "button";
    sendButton.textContent = "Invia";
    sendButton.disabled = true;

    const previewHolder = document.createElement("div");
    previewHolder.className = "voice-recording-preview";

    controls.append(startButton, stopButton, previewButton, cancelButton, sendButton);
    panel.append(title, status, timer, previewHolder, controls);
    chatInputArea.appendChild(panel);
    voiceRecorderPanel = panel;

    const updateTimer = () => {
        const elapsed = Math.min(60, Math.floor((Date.now() - voiceRecordingStartedAt) / 1000));
        timer.textContent = `00:${String(elapsed).padStart(2, "0")}`;
        if (elapsed >= 60 && voiceRecorder?.state === "recording") {
            stopRecording();
        }
    };

    const stopRecording = () => {
        if (voiceRecordingTimer) {
            clearInterval(voiceRecordingTimer);
            voiceRecordingTimer = null;
        }
        if (voiceRecorder && voiceRecorder.state === "recording") {
            voiceRecorder.stop();
        }
        stopButton.disabled = true;
        startButton.disabled = true;
        status.textContent = "Elaborazione registrazione…";
    };

    const cleanupRecording = () => {
        voiceRecorderCancelled = true;
        if (voiceRecordingTimer) {
            clearInterval(voiceRecordingTimer);
            voiceRecordingTimer = null;
        }
        if (voiceRecorder && voiceRecorder.state === "recording") {
            try { voiceRecorder.stop(); } catch {}
        }
        if (voiceRecorderStream) {
            voiceRecorderStream.getTracks().forEach(track => track.stop());
        }
        voiceRecorder = null;
        voiceRecorderStream = null;
        voiceRecorderChunks = [];
        voiceRecordedBlob = null;
        voiceRecordedDuration = 0;
        if (voicePreviewObjectUrl) {
            URL.revokeObjectURL(voicePreviewObjectUrl);
            voicePreviewObjectUrl = null;
        }
        if (voiceRecorderPanel) {
            voiceRecorderPanel.remove();
            voiceRecorderPanel = null;
        }
    };

    startButton.addEventListener("click", async () => {
        if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") {
            status.textContent = "Registrazione audio non supportata da questo browser.";
            return;
        }

        startButton.disabled = true;
        status.textContent = "Richiesta accesso al microfono…";

        try {
            voiceRecorderStream = await navigator.mediaDevices.getUserMedia({ audio: true });
            // Safari/iOS registra normalmente in MP4; Chromium/Android in WebM.
            // Si sceglie un formato realmente dichiarato supportato dal browser.
            const mimeCandidates = [
                "audio/mp4",
                "audio/webm;codecs=opus",
                "audio/webm",
                "audio/ogg;codecs=opus",
                "audio/ogg"
            ];
            const selectedMime = mimeCandidates.find(type =>
                MediaRecorder.isTypeSupported?.(type)
            );

            const recorderInstance = selectedMime
                ? new MediaRecorder(voiceRecorderStream, { mimeType: selectedMime })
                : new MediaRecorder(voiceRecorderStream);
            voiceRecorder = recorderInstance;

            voiceRecorderChunks = [];
            recorderInstance.ondataavailable = event => {
                if (event.data && event.data.size > 0) {
                    voiceRecorderChunks.push(event.data);
                }
            };

            recorderInstance.onerror = event => {
                console.error("Errore MediaRecorder:", event.error);
                status.textContent = "Errore durante la registrazione.";
                stopRecording();
            };

            recorderInstance.onstop = () => {
                if (voiceRecordingTimer) {
                    clearInterval(voiceRecordingTimer);
                    voiceRecordingTimer = null;
                }
                if (voiceRecorderStream) {
                    voiceRecorderStream.getTracks().forEach(track => track.stop());
                    voiceRecorderStream = null;
                }

                if (voiceRecorderCancelled || !voiceRecorderPanel) {
                    voiceRecorder = null;
                    voiceRecorderChunks = [];
                    return;
                }

                const rawMimeType = String(
                    recorderInstance.mimeType || voiceRecorderChunks.find(chunk => chunk.type)?.type || "audio/webm"
                ).toLowerCase();
                let mimeType = rawMimeType.split(";")[0].trim();
                // Il Worker riceve il MIME canonico (senza parametri codecs),
                // mentre i byte registrati restano esattamente quelli originali.
                if (mimeType === "audio/x-m4a") mimeType = "audio/mp4";
                if (mimeType === "audio/x-wav") mimeType = "audio/wav";
                voiceRecordedBlob = new Blob(voiceRecorderChunks, { type: mimeType });
                if (voiceRecorder === recorderInstance) voiceRecorder = null;
                voiceRecordedDuration = Math.max(
                    1,
                    Math.min(60, Math.ceil((Date.now() - voiceRecordingStartedAt) / 1000))
                );

                if (voicePreviewObjectUrl) URL.revokeObjectURL(voicePreviewObjectUrl);
                voicePreviewObjectUrl = URL.createObjectURL(voiceRecordedBlob);

                const audioPreview = document.createElement("audio");
                audioPreview.controls = true;
                audioPreview.preload = "auto";
                audioPreview.loop = false;
                audioPreview.playsInline = true;
                audioPreview.src = voicePreviewObjectUrl;
                audioPreview.load();
                audioPreview.addEventListener("ended", () => {
                    previewButton.textContent = "Anteprima";
                });
                previewHolder.replaceChildren(audioPreview);

                timer.textContent = `00:${String(voiceRecordedDuration).padStart(2, "0")}`;
                status.textContent = voiceRecordedBlob.size
                    ? "Anteprima pronta. Puoi ascoltare, annullare oppure inviare."
                    : "Registrazione vuota. Riprova.";
                previewButton.disabled = !voiceRecordedBlob.size;
                sendButton.disabled = !voiceRecordedBlob.size;
                cancelButton.disabled = false;
            };

            voiceRecordingStartedAt = Date.now();
            status.textContent = "Registrazione in corso…";
            stopButton.disabled = false;
            recorderInstance.start();
            voiceRecordingTimer = setInterval(updateTimer, 250);
        } catch (error) {
            console.error("Accesso al microfono non riuscito:", error);
            status.textContent = "Impossibile accedere al microfono. Controlla i permessi del browser.";
            startButton.disabled = false;
            if (voiceRecorderStream) {
                voiceRecorderStream.getTracks().forEach(track => track.stop());
                voiceRecorderStream = null;
            }
        }
    });

    stopButton.addEventListener("click", stopRecording);

    previewButton.addEventListener("click", () => {
        const audio = previewHolder.querySelector("audio");
        if (audio) {
            if (audio.paused) {
                if (audio.ended) audio.currentTime = 0;
                void audio.play().catch(error => console.warn("Anteprima audio:", error));
                previewButton.textContent = "Pausa";
            } else {
                audio.pause();
                previewButton.textContent = "Anteprima";
            }
        }
    });

    cancelButton.addEventListener("click", cleanupRecording);

    sendButton.addEventListener("click", async () => {
        if (!voiceRecordedBlob) return;
        sendButton.disabled = true;
        cancelButton.disabled = true;
        startButton.disabled = true;
        stopButton.disabled = true;
        previewButton.disabled = true;
        status.textContent = "Caricamento del messaggio vocale…";

        const blobToSend = voiceRecordedBlob;
        const durationToSend = voiceRecordedDuration;
        try {
            await sendEnclaveMediaMessage("audio", blobToSend, durationToSend);
            cleanupRecording();
        } catch (error) {
            console.error(error);
            status.textContent = "Invio non riuscito. Puoi riprovare o annullare.";
            sendButton.disabled = false;
            cancelButton.disabled = false;
        }
    });
}


// Menu allegati: ora apre le funzioni reali di immagini e vocali.
function setMessageAttachMenuOpen(isOpen) {
    if (!messageAttachButton || !messageAttachMenu) return;

    messageAttachMenu.classList.toggle("hidden", !isOpen);
    messageAttachButton.setAttribute("aria-expanded", String(isOpen));
}

if (messageAttachButton && messageAttachMenu) {
    messageAttachButton.addEventListener("click", (event) => {
        event.stopPropagation();
        const isOpen = messageAttachButton.getAttribute("aria-expanded") === "true";
        setMessageAttachMenuOpen(!isOpen);
    });

    messageAttachMenu.addEventListener("click", (event) => {
        event.stopPropagation();

        const option = event.target.closest("[data-attach-option]");
        if (!option) return;

        const selectedOption = option.dataset.attachOption;
        setMessageAttachMenuOpen(false);

        if (selectedOption === "image") {
            mediaFileInput.click();
        } else if (selectedOption === "voice") {
            openVoiceRecorderPanel();
        }
    });

    document.addEventListener("click", (event) => {
        if (!messageAttachMenu.contains(event.target) && event.target !== messageAttachButton) {
            setMessageAttachMenuOpen(false);
        }
    });

    document.addEventListener("keydown", (event) => {
        if (event.key === "Escape") {
            setMessageAttachMenuOpen(false);
        }
    });
}

sendMessageButton.addEventListener(
    "click",
    sendMessage
);


messageInput.addEventListener(
    "keydown",
    (event) => {

        if (event.key === "Enter") {

            event.preventDefault();

            sendMessage();

        }

    }
);


// ==========================
// NICKNAME PERSONALIZZABILE
// ==========================

async function getContactNickname(contactUid, originalNickname) {
    const currentUser = auth.currentUser;

    if (!currentUser) return originalNickname;

    try {
        const nicknameReference = doc(
            db,
            "users",
            currentUser.uid,
            "contactNicknames",
            contactUid
        );

        const nicknameDocument = await getDoc(nicknameReference);

        if (nicknameDocument.exists()) {
            const customNickname = nicknameDocument.data().nickname;

            if (typeof customNickname === "string" && customNickname.trim()) {
                return customNickname.trim();
            }
        }
    } catch (error) {
        console.error("Errore recupero soprannome personale:", error);
    }

    return originalNickname;
}

async function saveContactNickname(contactUid, nickname) {
    const currentUser = auth.currentUser;

    if (!currentUser) {
        throw new Error("Devi aver effettuato l'accesso.");
    }

    if (contactUid === currentUser.uid) {
        throw new Error("Non puoi rinominare te stesso.");
    }

    const nicknameReference = doc(
        db,
        "users",
        currentUser.uid,
        "contactNicknames",
        contactUid
    );

    const cleanNickname = nickname.trim();

    if (!cleanNickname) {
        await deleteDoc(nicknameReference);
        return;
    }

    if (cleanNickname.length > 40) {
        throw new Error("Il soprannome può contenere al massimo 40 caratteri.");
    }

    await setDoc(nicknameReference, {
        nickname: cleanNickname,
        updatedAt: serverTimestamp()
    });
}



// =========================
// CARICAMENTO CONVERSAZIONI
// =========================

function loadConversations() {

    if (unsubscribeChats) {

        unsubscribeChats();

        unsubscribeChats = null;

    }


    const currentUser = auth.currentUser;

    // Rilascia i listener dei badge se la sessione è terminata o cambia account.
    for (const [chatId, listenerEntry] of unreadMessageListeners) {
        if (!currentUser || listenerEntry.userUid !== currentUser.uid) {
            listenerEntry.unsubscribe();
            unreadMessageListeners.delete(chatId);
        }
    }

    if (!currentUser) {
        return;
    }

    const chatsReference =
        collection(
            db,
            "chats"
        );


    const chatsQuery =
        query(
            chatsReference,
            where(
                "participants",
                "array-contains",
                currentUser.uid
            )
        );


    unsubscribeChats =
        onSnapshot(
            chatsQuery,
            async (snapshot) => {

                const renderVersion =
                    ++conversationsRenderVersion;


                const conversationList =
                    document.querySelector(
                        ".conversation-list"
                    );


                if (!conversationList) {
                    return;
                }

                // Riusa i profili pubblici anche tra aggiornamenti diversi della
                // lista chat. Questo riduce letture Firestore e attese ripetute.
                const getPublicUserSnapshot = getCachedPublicUserSnapshot;

                const conversationResults =
                    await Promise.all(

                        snapshot.docs.map(
                            async (chatDocument) => {

                                const chatData =
                                    chatDocument.data();


                                  if (chatData.type === "group") {

                                            let lastMessage = chatData.lastMessage || "";

                                            if (lastMessage && chatData.lastSenderId) {

                                                try {

                                                    const senderDocument = await getPublicUserSnapshot(
                                                        chatData.lastSenderId
                                                    );

                                                    if (senderDocument.exists()) {

                                                        const senderNickname =
                                                            senderDocument.data().nickname || "Utente";

                                                        lastMessage =
                                                            `${senderNickname}: ${lastMessage}`;

                                                    }

                                                } catch (error) {

                                                    console.error(
                                                        "Errore recupero nickname ultimo mittente:",
                                                        error
                                                    );

                                                }

                                            }

                                            return {

                                                chatId: chatDocument.id,

                                                type: "group",

                                                uid: null,

                                                nickname: chatData.name,

                                                enclaveId:
                                                    `${chatData.participants.length} partecipanti`,

                                                lastMessage: lastMessage,

                                                lastMessageAt:
                                                    chatData.lastMessageAt || null,

                                                participants:
                                                    chatData.participants

                                            };

                                        }


                                const otherUserUid =
                                    chatData.participants.find(
                                        (uid) =>
                                            uid !==
                                            currentUser.uid
                                    );


                                if (!otherUserUid) {
                                    return null;
                                }


                                const userDocument =
                                    await getPublicUserSnapshot(otherUserUid);


                                if (
                                    !userDocument.exists()
                                ) {

                                    return null;

                                }



                            const userData = userDocument.data();

                                const displayedNickname = await getContactNickname(
                                    otherUserUid,
                                    userData.nickname || "Utente"
                                );

                                return {
                                    chatId: chatDocument.id,
                                    uid: otherUserUid,
                                    nickname: displayedNickname,
                                    originalNickname: userData.nickname || "Utente",
                                    enclaveId: userData.enclaveId,
                                    lastMessage: chatData.lastMessage || "",
                                    lastMessageAt: chatData.lastMessageAt || null
                                };


                            }
                        )

                    );


                if (
                    renderVersion !==
                    conversationsRenderVersion
                ) {

                    return;

                }


                const conversations =
                    conversationResults.filter(
                        (conversation) =>
                            conversation !== null
                    );


                const uniqueConversations =
                    new Map();


                conversations.forEach(

                    (conversation) => {

                        const conversationKey =
                            conversation.type === "group"
                                ? conversation.chatId
                                : conversation.uid;

                        const existing =
                            uniqueConversations.get(
                                conversationKey
                            );

                               if (!existing) {

                                   uniqueConversations.set(
                                        conversationKey,
                                        conversation
                                    );


                            return;

                        }


                        const existingTime =
                            existing.lastMessageAt
                                ?.toMillis?.() || 0;


                        const currentTime =
                            conversation.lastMessageAt
                                ?.toMillis?.() || 0;


                        if (
                            currentTime >
                            existingTime
                        ) {

                            uniqueConversations.set(
                                conversationKey,
                                conversation
                            );

                        }

                    }
                );


                const finalConversations =
                    Array.from(
                        uniqueConversations.values()
                    );


                finalConversations.sort(
                    (a, b) => {
                        const timeA = a.lastMessageAt?.toMillis?.() || 0;
                        const timeB = b.lastMessageAt?.toMillis?.() || 0;
                        return timeB - timeA;
                    }
                );

                if (renderVersion !== conversationsRenderVersion) {
                    return;
                }

                // Mantiene attivi soltanto i listener delle conversazioni presenti.
                // Evita sottoscrizioni orfane quando una chat viene rimossa o cambia account.
                const activeConversationIds = new Set(
                    finalConversations.map(conversation => conversation.chatId).filter(Boolean)
                );

                for (const [chatId, listenerEntry] of unreadMessageListeners) {
                    if (
                        !activeConversationIds.has(chatId) ||
                        listenerEntry.userUid !== currentUser.uid
                    ) {
                        listenerEntry.unsubscribe();
                        unreadMessageListeners.delete(chatId);
                    }
                }

                conversationList.innerHTML = "";


                if (
                    finalConversations.length === 0
                ) {

                    const empty =
                        document.createElement(
                            "div"
                        );


                    empty.className =
                        "no-conversations";


                    empty.textContent =
                        "Nessuna conversazione";


                    conversationList.appendChild(
                        empty
                    );


                    return;

                }


                finalConversations.forEach(
                    (conversation) => {

                        const conversationElement =
                            document.createElement(
                                "div"
                            );


                        conversationElement.className =
                            "conversation-item";
                        conversationElement.dataset.chatId = conversation.chatId;

                        if (conversation.type !== "group" && conversation.uid) {

                                    conversationElement.dataset.contactUid = conversation.uid;
                                }


                        const avatar =
                            document.createElement(
                                "div"
                            );


                        avatar.className =
                            "conversation-avatar";


                        avatar.textContent =
                            conversation.type === "group"
                                ? "👥"
                                : conversation.nickname
                                    .charAt(0)
                                    .toUpperCase();


                        const info =
                            document.createElement(
                                "div"
                            );


                        info.className =
                            "conversation-info";


                        const top =
                            document.createElement(
                                "div"
                            );


                        top.className =
                            "conversation-top";


                        const nickname =
                            document.createElement(
                                "span"
                            );


                        nickname.className =
                            "conversation-nickname";


                        nickname.textContent =
                            conversation.nickname;


                        const time =
                            document.createElement(
                                "span"
                            );


                        time.className =
                            "conversation-time";


                        if (
                            conversation.lastMessageAt
                        ) {

                            time.textContent =
                                conversation.lastMessageAt
                                    .toDate()
                                    .toLocaleTimeString(
                                        "it-IT",
                                        {
                                            hour:
                                                "2-digit",

                                            minute:
                                                "2-digit"
                                        }
                                    );

                        }


                        const preview =
                            document.createElement(
                                "div"
                            );


                        preview.className =
                            "conversation-preview";


                        preview.textContent =
                            conversation.lastMessage;


                        top.appendChild(nickname);

                            const meta = document.createElement("div");
                            meta.className = "conversation-meta";


                                const unreadBadge = document.createElement("span");
                                unreadBadge.className = "unread-badge";

                                unreadBadge.dataset.chatId = conversation.chatId;

                                meta.appendChild(time);
                                meta.appendChild(unreadBadge);

                                if (conversation.type !== "group" && conversation.uid) {
                                    const callIndicator = document.createElement("span");
                                    callIndicator.className = "incoming-call-indicator";
                                    callIndicator.setAttribute("aria-label", "");
                                    if (incomingCallIndicators.has(conversation.chatId)) {
                                        callIndicator.classList.add("visible");
                                        callIndicator.setAttribute("aria-label", "Chiamata in arrivo");
                                        callIndicator.title = "Chiamata in arrivo";
                                    }
                                    meta.appendChild(callIndicator);
                                }

                                // Riutilizza il listener della chat tra i render della lista.
                                // Il badge DOM viene ricreato, quindi il listener conserva il riferimento aggiornato.
                                const conversationIdForBadge = conversation.chatId;
                                const existingUnreadListener = unreadMessageListeners.get(conversationIdForBadge);

                                if (
                                    existingUnreadListener &&
                                    existingUnreadListener.userUid === currentUser.uid
                                ) {
                                    existingUnreadListener.badge = unreadBadge;
                                    updateUnreadBadge(
                                        conversationIdForBadge,
                                        unreadBadge,
                                        currentUser.uid
                                    );
                                } else {
                                    if (existingUnreadListener) {
                                        existingUnreadListener.unsubscribe();
                                    }

                                    const listenerEntry = {
                                        badge: unreadBadge,
                                        userUid: currentUser.uid,
                                        unsubscribe: null
                                    };

                                    // Ascolta soltanto l'ultimo messaggio della chat: serve solo a
                                    // far riaggiornare il badge. Prima leggeva TUTTI i messaggi di
                                    // TUTTE le chat a ogni apertura dell'app (quota Firestore).
                                    listenerEntry.unsubscribe = onSnapshot(
                                        query(
                                            collection(db, "chats", conversationIdForBadge, "messages"),
                                            orderBy("createdAt", "desc"),
                                            limit(1)
                                        ),
                                        () => {
                                            const activeListener = unreadMessageListeners.get(conversationIdForBadge);
                                            if (activeListener && activeListener.userUid === currentUser.uid) {
                                                updateUnreadBadge(
                                                    conversationIdForBadge,
                                                    activeListener.badge,
                                                    currentUser.uid
                                                );
                                            }
                                        },
                                        error => {
                                            console.error("ERRORE BADGE - DETTAGLI:", {
                                                chatId: conversationIdForBadge,
                                                userUid: currentUser.uid,
                                                code: error.code,
                                                message: error.message
                                            });
                                        }
                                    );

                                    unreadMessageListeners.set(conversationIdForBadge, listenerEntry);
                                }

                                top.appendChild(meta);


                        info.appendChild(
                            top
                        );


                        info.appendChild(
                            preview
                        );


                        conversationElement.appendChild(
                            avatar
                        );


                        conversationElement.appendChild(
                            info
                        );


                        conversationList.appendChild(
                            conversationElement
                        );


                        conversationElement.addEventListener(
                            "click",
                            () => {

                                clearUnreadBadge(conversation.chatId);

                                markChatAsRead(conversation.chatId);

                                chatEmptyState.classList.add(
                                    "hidden"
                                );


                                activeChat.classList.remove(
                                    "hidden"
                                );

                                if (conversation.type === "group") {

                                        chatUserNickname.textContent =
                                            conversation.nickname;

                                        chatUserId.textContent =
                                            conversation.enclaveId;

                                        chatUserAvatar.textContent =
                                            "👥";

                                        currentChatUserUid =
                                            null;
                                        if (startVoiceCallButton) startVoiceCallButton.classList.add("hidden");
                                        // Il listener globale delle chiamate resta attivo anche nei gruppi.

                                        currentChatId =
                                            conversation.chatId;


                                        chatUserInfo.classList.add(
                                            "group-chat-clickable"
                                        );

                                        chatUserInfo.onclick =
                                            () => {

                                                openGroupInfo(
                                                    conversation.chatId
                                                );

                                            };


                                        loadMessages(
                                            currentChatId
                                        );


                                        markChatViewOpen();


                                        if (
                                            window.innerWidth <=
                                            700
                                        ) {

                                            chatSidebar.style.display =
                                                "none";

                                            chatArea.style.display =
                                                "flex";

                                            chatArea.style.width =
                                                "100%";

                                        }


                                        return;

                                    }


                                chatUserNickname.textContent = conversation.nickname;

                                    chatUserInfo.classList.remove("group-chat-clickable");

                                    chatUserInfo.onclick = () => {
                                        openContactInfo(
                                            conversation.uid,
                                            conversation.originalNickname || conversation.nickname
                                        );
                                    };


                                chatUserId.textContent =
                                    conversation.enclaveId;


                                chatUserAvatar.textContent =
                                    conversation.nickname
                                        .charAt(0)
                                        .toUpperCase();


                                currentChatUserUid =
                                    conversation.uid;
                                if (startVoiceCallButton) startVoiceCallButton.classList.remove("hidden");


                                currentChatId =
                                    createChatId(
                                        currentUser.uid,
                                        conversation.uid
                                    );


                                loadMessages(
                                    currentChatId
                                );
                                listenForIncomingVoiceCalls();


                                markChatViewOpen();


                                if (
                                    window.innerWidth <=
                                    700
                                ) {

                                    chatSidebar.style.display =
                                        "none";


                                    chatArea.style.display =
                                        "flex";


                                    chatArea.style.width =
                                        "100%";

                                }

                            }
                        );

                    }
                );

            },
            (error) => {

                console.error(
                    "Errore caricamento conversazioni:",
                    error
                );

            }
        );

}


/* =========================
   TASTIERA MOBILE: ADATTA SOLO L'APP ALLA VISUAL VIEWPORT
   Su iOS la visualViewport può restare più piccola anche dopo la chiusura
   della tastiera. Usiamo quindi la visual viewport solo mentre l'input chat
   è davvero attivo e ripristiniamo il layout normale dopo il blur.
   ========================= */
(() => {
    const viewport = window.visualViewport;
    const mobileQuery = window.matchMedia("(max-width: 700px)");
    const chatInputSelector = ".chat-input-area input, .chat-input-area textarea";
    let restoreTimer = null;

    const isChatInputFocused = () => {
        const active = document.activeElement;
        return !!(active && active.matches && active.matches(chatInputSelector));
    };

    const clearKeyboardViewport = () => {
        document.documentElement.style.removeProperty("--enclave-visible-height");
        document.documentElement.style.removeProperty("--enclave-viewport-top");
        document.documentElement.classList.remove("enclave-keyboard-open");
    };

    const updateVisibleChatHeight = () => {
        if (!mobileQuery.matches || !viewport || !isChatInputFocused()) {
            clearKeyboardViewport();
            return;
        }

        document.documentElement.classList.add("enclave-keyboard-open");
        document.documentElement.style.setProperty(
            "--enclave-visible-height",
            `${Math.max(1, Math.round(viewport.height))}px`
        );
        document.documentElement.style.setProperty(
            "--enclave-viewport-top",
            `${Math.max(0, Math.round(viewport.offsetTop))}px`
        );
    };

    const scheduleRestore = () => {
        window.clearTimeout(restoreTimer);
        // iOS aggiorna la visualViewport con un leggero ritardo dopo aver
        // chiuso la tastiera: non ripristinare l'altezza mentre è ancora visibile.
        restoreTimer = window.setTimeout(() => {
            if (!isChatInputFocused()) clearKeyboardViewport();
            else updateVisibleChatHeight();
        }, 350);
    };

    if (viewport) {
        viewport.addEventListener("resize", updateVisibleChatHeight, { passive: true });
        viewport.addEventListener("scroll", updateVisibleChatHeight, { passive: true });
    }
    window.addEventListener("resize", updateVisibleChatHeight, { passive: true });
    window.addEventListener("orientationchange", scheduleRestore, { passive: true });

    document.addEventListener("focusin", event => {
        if (event.target && event.target.matches && event.target.matches(chatInputSelector)) {
            window.clearTimeout(restoreTimer);
            // Un frame lascia a Safari il tempo di aggiornare la visual viewport.
            window.requestAnimationFrame(updateVisibleChatHeight);
        }
    });

    document.addEventListener("focusout", event => {
        if (event.target && event.target.matches && event.target.matches(chatInputSelector)) {
            scheduleRestore();
        }
    });

    // La pagina parte sempre con il layout normale, senza conservare una
    // vecchia altezza ridotta da una precedente apertura della tastiera.
    clearKeyboardViewport();
})();


// =========================
// RIPRISTINO SESSIONE ALL'AVVIO
// =========================
(async () => {
    try {
        const rememberEnabled = localStorage.getItem(REMEMBER_CONNECTED_KEY) === "true";
        await setPersistence(
            auth,
            rememberEnabled ? browserLocalPersistence : browserSessionPersistence
        );

        // Firebase può ripristinare una vecchia sessione locale anche se la nuova
        // preferenza "Rimani connesso" è OFF. In quel caso richiediamo un login esplicito.
        await auth.authStateReady();
        let savedUser = auth.currentUser;
        const hasCurrentTabSession = sessionStorage.getItem("enclaveSessionAuthMarker") === "true";

        if (!rememberEnabled && savedUser && !hasCurrentTabSession) {
            await signOut(auth);
            savedUser = null;
        }

        if (savedUser && savedUser.emailVerified) {
            await loadUserProfile(savedUser);
            showHome();
            loadConversations();
            listenForIncomingVoiceCalls();
        } else if (savedUser && !savedUser.emailVerified) {
            showVerification(savedUser);
            checkEmailVerification(savedUser);
        } else {
            showRegister();
        }
    } catch (error) {
        console.error("Impossibile ripristinare la sessione Enclave:", error);
        showRegister();
    }
})();


// =========================
// ENCLAVEAI — SESSIONE TEMPORANEA
// =========================
const ENCLAVE_AI_WORKER_URL = "https://enclave-notification.gpvyw7wnf8.workers.dev/";

// NEXUS Engine - caricamento dinamico
let nexusEnginePromise = null;

function loadNexusEngine() {
  if (!nexusEnginePromise) {
    nexusEnginePromise = import("../nexus-engine/nexus-engine.js")
      .catch(error => {
        nexusEnginePromise = null;
        throw error;
      });
  }

  return nexusEnginePromise;
}

// Allegato temporaneo di EnclaveAI
let enclaveAIAttachment = null;
let enclaveAIAttachmentUrl = null;
let enclaveAIAnalysisContext = "";

let enclaveAIHistory = [];
let enclaveAIOverlay = null;
let enclaveAIWaiting = false;

function buildEnclaveAIPanel() {
    if (enclaveAIOverlay) return enclaveAIOverlay;

    const overlay = document.createElement("div");
    overlay.className = "enclave-ai-overlay";
    overlay.id = "enclaveAIOverlay";
    overlay.innerHTML = `
      <section class="enclave-ai-panel" role="dialog" aria-modal="true" aria-labelledby="enclaveAITitle">
        <header class="enclave-ai-header">
          <div class="enclave-ai-brand">
            <div class="enclave-ai-symbol"><span>✦</span></div>
            <div><div class="enclave-ai-eyebrow">ENCLAVE INTELLIGENCE</div><h2 id="enclaveAITitle">EnclaveAI</h2><div class="enclave-ai-status"><i></i> Pronto ad aiutarti</div></div>
          </div>
          <div class="enclave-ai-header-actions">
            <button type="button" class="enclave-ai-new" id="enclaveAINew" title="Nuova conversazione" aria-label="Nuova conversazione">↻</button>
            <button type="button" class="enclave-ai-close" id="enclaveAIClose" aria-label="Chiudi">×</button>
          </div>
        </header>
        <div class="enclave-ai-content" id="enclaveAIContent">
          <div class="enclave-ai-welcome" id="enclaveAIWelcome">
            <div class="enclave-ai-orb"><span>✦</span><b></b></div>
            <div class="enclave-ai-welcome-kicker">IL TUO SPAZIO INTELLIGENTE</div>
            <h3>Da dove<br>iniziamo?</h3>
            <p>Domande, idee, dubbi. Posso anche spiegarti cos’è Enclave e come si usa.</p>
            <div class="enclave-ai-suggestions">
              <button type="button" data-ai-prompt="Cos’è Enclave?"><span>✦</span> Cos’è Enclave?</button>
              <button type="button" data-ai-prompt="Spiegami come si usa Enclave."><span>⟡</span> Come si usa</button>
              <button type="button" data-ai-prompt="Spiegami un concetto difficile in modo semplice."><span>✧</span> Spiegami qualcosa</button>
            </div>
          </div>
          <div class="enclave-ai-messages" id="enclaveAIMessages" aria-live="polite"></div>
        </div>

<form class="enclave-ai-composer" id="enclaveAIForm">

<div class="enclave-ai-attachment" id="enclaveAIAttachmentPreview" hidden>
  <div class="enclave-ai-attachment-thumbnail" id="enclaveAIAttachmentThumbnail"></div>
  <span id="enclaveAIAttachmentName"></span>
  <button type="button" id="enclaveAIAttachmentRemove" aria-label="Rimuovi allegato">×</button>
</div>


  <div class="enclave-ai-composer-row">
    <button
      type="button"
      class="enclave-ai-attach"
      id="enclaveAIAttach"
      aria-label="Allega immagine o video"
      title="Allega immagine o video"
    >+</button>

    <input
      type="file"
      id="enclaveAIFile"
      accept="image/*,video/*"
      hidden
    >

    <textarea
      id="enclaveAIInput"
      rows="1"
      maxlength="4000"
      placeholder="Chiedi qualcosa a EnclaveAI…"
      aria-label="Messaggio per EnclaveAI"
    ></textarea>

    <button type="submit" id="enclaveAISend" aria-label="Invia messaggio">
      <span>↑</span>
    </button>
  </div>

  <div class="enclave-ai-disclaimer">
    Le conversazioni non vengono salvate da Enclave. Evita di inserire dati sensibili.
  </div>
</form>

      </section>`;
    document.body.appendChild(overlay);
    enclaveAIOverlay = overlay;

    overlay.querySelector("#enclaveAIClose").addEventListener("click", closeEnclaveAI);
    overlay.querySelector("#enclaveAINew").addEventListener("click", resetEnclaveAI);
    overlay.addEventListener("pointerdown", e => { if (e.target === overlay) closeEnclaveAI(); });
    overlay.querySelectorAll("[data-ai-prompt]").forEach(button => button.addEventListener("click", () => {
        const input = overlay.querySelector("#enclaveAIInput"); input.value = button.dataset.aiPrompt; input.focus();
        overlay.querySelector("#enclaveAIForm").requestSubmit();
    }));
    overlay.querySelector("#enclaveAIForm").addEventListener("submit", sendEnclaveAIMessage);

    // Gestione allegati temporanei di EnclaveAI
    const attachButton = overlay.querySelector("#enclaveAIAttach");
    const fileInput = overlay.querySelector("#enclaveAIFile");
    const attachmentPreview = overlay.querySelector("#enclaveAIAttachmentPreview");
    const attachmentName = overlay.querySelector("#enclaveAIAttachmentName");
    const attachmentRemove = overlay.querySelector("#enclaveAIAttachmentRemove");
    const attachmentThumbnail = overlay.querySelector("#enclaveAIAttachmentThumbnail");

    attachButton.addEventListener("click", () => {
        fileInput.value = "";
        fileInput.click();
    });

    fileInput.addEventListener("change", () => {
        const file = fileInput.files?.[0];
        if (!file) return;

        const isImage = file.type.startsWith("image/");
        const isVideo = file.type.startsWith("video/");

        if (!isImage && !isVideo) {
            alert("Formato non supportato. Seleziona un'immagine o un video.");
            fileInput.value = "";
            return;
        }

        if (enclaveAIAttachmentUrl) {
            URL.revokeObjectURL(enclaveAIAttachmentUrl);
            enclaveAIAttachmentUrl = null;
        }

        enclaveAIAttachment = file;
        enclaveAIAnalysisContext = "";

        attachmentName.textContent =
            `${isImage ? "Immagine" : "Video"}: ${file.name}`;

        attachmentThumbnail.replaceChildren();

enclaveAIAttachmentUrl = URL.createObjectURL(file);

const previewElement = document.createElement(
    isImage ? "img" : "video"
);

previewElement.src = enclaveAIAttachmentUrl;
previewElement.alt = isImage ? "Anteprima immagine" : "Anteprima video";

if (isVideo) {
    previewElement.muted = true;
    previewElement.playsInline = true;
    previewElement.controls = true;
}

attachmentThumbnail.appendChild(previewElement);
attachmentPreview.hidden = false;
    });

    attachmentRemove.addEventListener("click", () => {
        if (enclaveAIAttachmentUrl) {
            URL.revokeObjectURL(enclaveAIAttachmentUrl);
            enclaveAIAttachmentUrl = null;
        }

        enclaveAIAttachment = null;
        enclaveAIAnalysisContext = "";
        fileInput.value = "";
        attachmentPreview.hidden = true;
        attachmentName.textContent = "";
        attachmentThumbnail.replaceChildren();
    });

    overlay.querySelector("#enclaveAIInput").addEventListener("keydown", e => {
        if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); overlay.querySelector("#enclaveAIForm").requestSubmit(); }
    });
    return overlay;
}

function openEnclaveAI() {
    if (!auth.currentUser || !auth.currentUser.emailVerified) return;
    const overlay = buildEnclaveAIPanel();
    requestAnimationFrame(() => overlay.classList.add("is-open"));
    document.body.classList.add("enclave-ai-active");
    setTimeout(() => overlay.querySelector("#enclaveAIInput")?.focus(), 220);
}


function clearEnclaveAIAttachment() {
    if (enclaveAIAttachmentUrl) {
        URL.revokeObjectURL(enclaveAIAttachmentUrl);
        enclaveAIAttachmentUrl = null;
    }

    enclaveAIAttachment = null;
    enclaveAIAnalysisContext = "";

    if (!enclaveAIOverlay) return;

    const fileInput = enclaveAIOverlay.querySelector("#enclaveAIFile");
    const preview = enclaveAIOverlay.querySelector("#enclaveAIAttachmentPreview");
    const name = enclaveAIOverlay.querySelector("#enclaveAIAttachmentName");
    const thumbnail = enclaveAIOverlay.querySelector("#enclaveAIAttachmentThumbnail");

    if (fileInput) fileInput.value = "";
    if (preview) preview.hidden = true;
    if (name) name.textContent = "";
    if (thumbnail) thumbnail.replaceChildren();
}

function closeEnclaveAI() {
    if (!enclaveAIOverlay) return;

    clearEnclaveAIAttachment();

    enclaveAIOverlay.classList.remove("is-open");
    document.body.classList.remove("enclave-ai-active");
    enclaveAIHistory = [];

    setTimeout(() => {
        if (enclaveAIOverlay) {
            enclaveAIOverlay.remove();
            enclaveAIOverlay = null;
        }
    }, 260);
}

function resetEnclaveAI() {
    if (!enclaveAIOverlay) return;

    clearEnclaveAIAttachment();

    enclaveAIHistory = [];

    const messages = enclaveAIOverlay.querySelector("#enclaveAIMessages");
    messages.replaceChildren();

    enclaveAIOverlay.querySelector("#enclaveAIWelcome").hidden = false;
    enclaveAIOverlay.querySelector("#enclaveAIInput").focus();
}


const ENCLAVE_AI_GUIDE = [
    "Sei EnclaveAI, l'assistente dentro Enclave. Rispondi in italiano.",
    "Ogni risposta sta in un solo messaggio, entro 400 parole, ed è completa. Non interrompere una frase o un elenco a metà. L'ultima frase finisce con un punto.",
    "Non lasciare asterischi aperti.",
    "Puoi usare il grassetto markdown scrivendo le parole importanti tra doppi asterischi.",
    "Se ti chiedono cosa sai fare, descrivi tutte le funzionalità che puoi effettivamente offrire e spiega che rispondi a domande generali e che aiuti a usare Enclave, che è una PWA. EnclaveAI dispone già dell'integrazione con NEXUS Engine. NEXUS può analizzare localmente immagini e fotogrammi video per rilevare volti e stimare le loro espressioni prevalenti. Quando ricevi risultati NEXUS nel messaggio dell'utente, devi considerarli dati dell'analisi appena eseguita e utilizzarli per rispondere alle domande. Non descrivere questa integrazione come futura.",
    "Enclave è una PWA di messaggistica privata. Il motto mostrato in accesso è Private. Connected. La descrizione dell'app è: la tua area privata di messaggistica.",
    "Si usa dal browser e si può installare sulla schermata Home. Su iPhone: Condividi, poi Aggiungi a Home. Su Android: menu del browser, poi Installa app oppure Aggiungi a schermata Home. Installata, si apre a tutto schermo, senza la barra del browser.",
    "Per creare un account servono email, password e nickname. L'email va verificata prima di entrare. Dalla schermata di accesso si entra con email e password.",
    "In Impostazioni, scheda Avanzate, Rimani connesso mantiene l'accesso su quel dispositivo. Il pulsante Esci chiude la sessione e al ritorno chiede di nuovo l'accesso.",
    "Ogni account ha un nickname e un Enclave ID. Una chat privata si inizia cercando l'Enclave ID dell'altra persona. Dalle informazioni di un contatto si può impostare un soprannome visibile solo a chi lo imposta.",
    "Nelle chat private si scrivono messaggi, si può rispondere a un messaggio e compare la conferma di lettura. Il pulsante della cornetta in alto avvia una chiamata vocale solo in una chat privata, non in un gruppo.",
    "In Impostazioni, scheda Avanzate, la levetta Microfono riguarda le chiamate. Accesa, Enclave usa il permesso già concesso e non richiede il microfono a ogni chiamata. Spenta, il telefono può chiedere il microfono quando si inizia o si accetta una chiamata.",
    "I gruppi si creano dal pulsante +. Un gruppo può avere fino a 20 partecipanti. Si possono vedere i partecipanti, aggiungerne se c'è posto, e uscire dal gruppo.",
    "In Impostazioni, scheda Avanzate, la levetta Notifiche attiva o disattiva le notifiche dell'account. Il telefono deve comunque concedere il permesso. Mentre Enclave è aperto e in uso, la notifica di sistema non viene mostrata.",
    "In Impostazioni, scheda Generali, si modificano il proprio nickname, il colore delle bolle e lo sfondo. Colore e sfondo valgono per tutte le chat private e i gruppi.",
    "EnclaveAI si apre dal pulsante +. La conversazione dura solo finché il pannello è aperto e Enclave non la salva. Non va usata per dati sensibili.",
    "Il menu allegati con Immagine e Messaggio vocale non è una funzione attiva: non dire che si possono inviare foto o vocali.",
    "Le immagini allegate nel pannello EnclaveAI vengono analizzate localmente tramite NEXUS. Puoi interpretare i risultati ricevuti, come il numero di volti rilevati e le espressioni stimate. Non affermare che le immagini non sono supportate. NEXUS non identifica l'identità delle persone e non riconosce genericamente oggetti o scene. Le espressioni sono stime del modello e non dimostrano con certezza lo stato emotivo reale di una persona. Non confondere questa funzione con l'invio di immagini nelle chat.",
].join(" ");

function renderEnclaveAIText(text) {
    const escaped = String(text)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
    return escaped
        .replace(/`([^`\n]+)`/g, "<code>$1</code>")
        .replace(/\*\*([^*\n]+)\*\*/g, "<strong>$1</strong>")
        .replace(/__([^_\n]+)__/g, "<strong>$1</strong>")
        .replace(/(^|[^*])\*([^*\n]+)\*/g, "$1<em>$2</em>")
        .replace(/\n/g, "<br>");
}

function setEnclaveAIBubbleText(bubble, role, text) {
    if (role === "assistant") bubble.innerHTML = renderEnclaveAIText(text);
    else bubble.textContent = text;
}

function addEnclaveAIMessage(role, text) {
    const messages = enclaveAIOverlay.querySelector("#enclaveAIMessages");
    const item = document.createElement("div");
    item.className = `enclave-ai-message ${role === "user" ? "is-user" : "is-assistant"}`;
    const label = document.createElement("div"); label.className = "enclave-ai-message-label";
    label.textContent = role === "user" ? "TU" : "ENCLAVEAI";
    const bubble = document.createElement("div"); bubble.className = "enclave-ai-bubble";
    setEnclaveAIBubbleText(bubble, role, text);
    item.append(label, bubble); messages.appendChild(item);
    enclaveAIOverlay.querySelector("#enclaveAIContent").scrollTo({ top: enclaveAIOverlay.querySelector("#enclaveAIContent").scrollHeight, behavior: "smooth" });
    return item;
}

function messagesForEnclaveAI(messages) {
    const conversation = messages
        .filter(message => message && (message.role === "user" || message.role === "assistant") && typeof message.content === "string")
        .map(message => ({ role: message.role, content: message.content }));
    const firstUser = conversation.find(message => message.role === "user");
    if (firstUser) {
        firstUser.content = "Contesto per rispondere, da non ripetere all'utente:\n" + ENCLAVE_AI_GUIDE + "\n\nMessaggio dell'utente:\n" + firstUser.content;
    }
    return conversation;
}

async function requestEnclaveAIAnswer(idToken, messages) {
    const response = await fetch(ENCLAVE_AI_WORKER_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${idToken}` },
        body: JSON.stringify({
            action: "enclaveai",
            messages: messagesForEnclaveAI(messages)
        })
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(result.error || `Servizio temporaneamente non disponibile (${response.status}).`);
    return typeof result.answer === "string" ? result.answer.trim() : "";
}



function setEnclaveAINexusStage(container, stage, detail, progress) {
    if (!container) return;
    const stageLabel = container.querySelector("[data-nexus-stage]");
    const detailLabel = container.querySelector("[data-nexus-detail]");
    const progressBar = container.querySelector("[data-nexus-progress]");
    const progressValue = container.querySelector("[data-nexus-progress-value]");
    if (stageLabel) stageLabel.textContent = stage;
    if (detailLabel) detailLabel.textContent = detail;
    if (progressBar) progressBar.style.width = `${Math.max(0, Math.min(100, progress))}%`;
    if (progressValue) progressValue.textContent = `${Math.max(0, Math.min(100, Math.round(progress)))}%`;
}

function createEnclaveAINexusActivity() {
    const activity = document.createElement("div");
    activity.className = "enclave-ai-nexus-activity";
    activity.innerHTML = `
      <div class="enclave-ai-nexus-activity-top">
        <span class="enclave-ai-nexus-chip"><i></i> NEXUS ENGINE</span>
        <span class="enclave-ai-nexus-live">LOCAL PROCESSING</span>
      </div>
      <div class="enclave-ai-nexus-activity-title">Inizializzazione dei motori visivi</div>
      <div class="enclave-ai-nexus-activity-detail" data-nexus-detail>Preparazione del modulo di analisi locale…</div>
      <div class="enclave-ai-nexus-progress"><i data-nexus-progress></i></div>
      <div class="enclave-ai-nexus-activity-foot"><span data-nexus-stage>BOOT SEQUENCE</span><b data-nexus-progress-value>4%</b></div>`;
    return activity;
}

function renderEnclaveAINexusReport(visualData) {
    if (!visualData || !Array.isArray(visualData.frames)) return null;

    const report = document.createElement("section");
    report.className = "enclave-ai-nexus-report";
    report.setAttribute("aria-label", "Risultati visivi NEXUS");

    const totalFaces = visualData.frames.reduce((sum, frame) => sum + (frame.faces?.length || 0), 0);
    const expressionNames = {
        happy: "Felicità", sad: "Tristezza", angry: "Rabbia", fearful: "Paura",
        disgusted: "Disgusto", surprised: "Sorpresa", neutral: "Neutrale"
    };

    const header = document.createElement("div");
    header.className = "enclave-ai-nexus-report-header";
    header.innerHTML = `<div><span class="enclave-ai-nexus-overline">NEXUS / VISUAL INTELLIGENCE</span><strong>Rapporto di analisi</strong></div><span class="enclave-ai-nexus-verified"><i></i> COMPLETATA</span>`;
    report.appendChild(header);

    const stats = document.createElement("div");
    stats.className = "enclave-ai-nexus-stats";
    const statsData = [
        [String(totalFaces), visualData.type === "video" ? "RILEVAMENTI TOTALI" : "VOLTI RILEVATI"],
        [String(visualData.frames.length), visualData.type === "video" ? "FRAME ANALIZZATI" : "IMMAGINE ANALIZZATA"],
        [visualData.durationMs ? `${visualData.durationMs} ms` : "LOCALE", "TEMPO / ELABORAZIONE"]
    ];
    statsData.forEach(([value, label]) => {
        const stat = document.createElement("div");
        stat.className = "enclave-ai-nexus-stat";
        const strong = document.createElement("strong"); strong.textContent = value;
        const small = document.createElement("span"); small.textContent = label;
        stat.append(strong, small); stats.appendChild(stat);
    });
    report.appendChild(stats);

    const frames = document.createElement("div");
    frames.className = `enclave-ai-nexus-frames${visualData.type === "video" ? " is-video" : ""}`;

    visualData.frames.forEach((frame, frameIndex) => {
        const frameCard = document.createElement("article");
        frameCard.className = "enclave-ai-nexus-frame";
        const frameHeading = document.createElement("div");
        frameHeading.className = "enclave-ai-nexus-frame-heading";
        const frameName = document.createElement("span");
        frameName.textContent = visualData.type === "video" ? `FRAME 0${frameIndex + 1} · ${(frame.timestamp || 0).toFixed(1)}s` : "SOURCE IMAGE";
        const faceCount = document.createElement("b");
        faceCount.textContent = `${frame.faces?.length || 0} ${frame.faces?.length === 1 ? "VOLTO" : "VOLTI"}`;
        frameHeading.append(frameName, faceCount);

        const stage = document.createElement("div");
        stage.className = "enclave-ai-nexus-image-stage";
        const image = document.createElement("img");
        image.src = frame.src;
        image.alt = visualData.type === "video" ? `Fotogramma ${frameIndex + 1} analizzato da NEXUS` : "Immagine analizzata da NEXUS";
        image.loading = "lazy";
        stage.appendChild(image);

        (frame.faces || []).forEach((face, faceIndex) => {
            if (!Array.isArray(face.box) || face.box.length < 4 || !frame.width || !frame.height) return;
            const [x, y, width, height] = face.box;
            const box = document.createElement("div");
            box.className = "enclave-ai-nexus-face-box";
            box.style.left = `${Math.max(0, x / frame.width * 100)}%`;
            box.style.top = `${Math.max(0, y / frame.height * 100)}%`;
            box.style.width = `${Math.max(0, Math.min(100, width / frame.width * 100))}%`;
            box.style.height = `${Math.max(0, Math.min(100, height / frame.height * 100))}%`;
            const marker = document.createElement("span");
            marker.textContent = `FACE ${String(faceIndex + 1).padStart(2, "0")}`;
            box.appendChild(marker);
            stage.appendChild(box);
        });
        frameCard.append(frameHeading, stage);

        if (frame.faces?.length) {
            const faceList = document.createElement("div");
            faceList.className = "enclave-ai-nexus-face-list";
            frame.faces.forEach((face, faceIndex) => {
                const faceItem = document.createElement("div");
                faceItem.className = "enclave-ai-nexus-face-item";
                const faceTitle = document.createElement("span");
                faceTitle.textContent = `SOGGETTO ${String(faceIndex + 1).padStart(2, "0")}`;
                const expression = document.createElement("b");
                expression.textContent = face.mainExpression
                    ? `${expressionNames[face.mainExpression.toLowerCase()] || face.mainExpression} · ${face.confidence}%`
                    : "Espressione non determinata";
                faceItem.append(faceTitle, expression);
                faceList.appendChild(faceItem);
            });
            frameCard.appendChild(faceList);
        } else {
            const empty = document.createElement("div");
            empty.className = "enclave-ai-nexus-empty";
            empty.textContent = "Nessun volto rilevato in questo fotogramma";
            frameCard.appendChild(empty);
        }
        frames.appendChild(frameCard);
    });
    report.appendChild(frames);

    const footer = document.createElement("div");
    footer.className = "enclave-ai-nexus-report-footer";
    footer.textContent = "Elaborazione eseguita sul dispositivo. Le espressioni sono stime del modello e non identificano le persone.";
    report.appendChild(footer);
    return report;
}

async function analyzeEnclaveAIAttachment(onProgress = () => {}) {
    if (!enclaveAIAttachment) return { context: "", visualData: null };

    const file = enclaveAIAttachment;
    const startedAt = performance.now();
    onProgress("CARICAMENTO NEXUS", "Caricamento dei moduli di visione artificiale sul dispositivo…", 12);
    const nexus = await loadNexusEngine();
    onProgress("INIZIALIZZAZIONE MOTORE", "Modello facciale e rete di stima delle espressioni pronti per l'inferenza…", 38);

    if (file.type.startsWith("image/")) {
        const image = new Image();
        image.src = enclaveAIAttachmentUrl;
        await image.decode();
        onProgress("SCANSIONE IMMAGINE", "NEXUS sta analizzando i pixel e cercando volti…", 64);
        const result = await nexus.analyzeImage(image);
        const durationMs = Math.round(performance.now() - startedAt);
        onProgress("MAPPATURA RILEVAMENTI", `${result.faceCount} volti rilevati. Preparazione della mappa visiva…`, 92);
        const previewCanvas = document.createElement("canvas");
        const previewScale = Math.min(1, 1200 / image.naturalWidth);
        previewCanvas.width = Math.max(1, Math.round(image.naturalWidth * previewScale));
        previewCanvas.height = Math.max(1, Math.round(image.naturalHeight * previewScale));
        const previewContext = previewCanvas.getContext("2d");
        previewContext.drawImage(image, 0, 0, previewCanvas.width, previewCanvas.height);
        const previewSource = previewCanvas.toDataURL("image/jpeg", 0.82);

        const faces = result.faces.map((face, index) => {
            const expression = face.mainExpression
                ? `${face.mainExpression} (${face.confidence}%)`
                : "Espressione non determinata con sufficiente sicurezza";
            return `Volto ${index + 1}: espressione prevalente ${expression}.`;
        });
        const context = [
            "Analisi NEXUS dell'immagine:",
            `Volti rilevati: ${result.faceCount}.`,
            ...faces
        ].join("\n");
        return {
            context,
            visualData: {
                type: "image", durationMs,
                frames: [{ src: previewSource, width: image.naturalWidth, height: image.naturalHeight, faces: result.faces }]
            }
        };
    }

    if (file.type.startsWith("video/")) {
        const video = document.createElement("video");
        video.src = enclaveAIAttachmentUrl;
        video.muted = true;
        video.playsInline = true;
        video.preload = "auto";

        try {
            await new Promise((resolve, reject) => {
                video.onloadedmetadata = resolve;
                video.onerror = () => reject(new Error("Impossibile caricare il video selezionato."));
            });
            if (!video.duration || !video.videoWidth) throw new Error("Il video non è pronto per l'analisi.");
            if (video.readyState < 2) {
                await new Promise((resolve, reject) => {
                    video.onloadeddata = resolve;
                    video.onerror = () => reject(new Error("Impossibile leggere il primo fotogramma del video."));
                });
            }

            const timestamps = [0, video.duration / 2, Math.max(0, video.duration - 0.1)];
            const canvas = document.createElement("canvas");
            const context2d = canvas.getContext("2d");
            if (!context2d) throw new Error("Impossibile preparare l'analisi video.");
            const frames = [];
            const results = [];

            for (let index = 0; index < timestamps.length; index++) {
                const timestamp = timestamps[index];
                onProgress(`ANALISI FRAME 0${index + 1}/03`, `Esame del fotogramma a ${timestamp.toFixed(1)} secondi…`, 48 + index * 16);
                if (Math.abs(video.currentTime - timestamp) > 0.01) {
                    await new Promise((resolve, reject) => {
                        video.onseeked = resolve;
                        video.onerror = () => reject(new Error("Errore durante la lettura del video."));
                        video.currentTime = timestamp;
                    });
                }
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;
                context2d.drawImage(video, 0, 0, canvas.width, canvas.height);
                const result = await nexus.analyzeImage(canvas);
                results.push({ timestamp, faceCount: result.faceCount, faces: result.faces });
                const previewCanvas = document.createElement("canvas");
                const previewScale = Math.min(1, 960 / canvas.width);
                previewCanvas.width = Math.max(1, Math.round(canvas.width * previewScale));
                previewCanvas.height = Math.max(1, Math.round(canvas.height * previewScale));
                const previewContext = previewCanvas.getContext("2d");
                previewContext.drawImage(canvas, 0, 0, previewCanvas.width, previewCanvas.height);
                frames.push({ src: previewCanvas.toDataURL("image/jpeg", 0.76), width: canvas.width, height: canvas.height, timestamp, faces: result.faces });
            }

            const totalFaces = results.reduce((total, frame) => total + frame.faceCount, 0);
            const details = results.map((frame, index) => {
                const expressions = frame.faces.filter(face => face.mainExpression).map(face => face.mainExpression);
                return `Fotogramma ${index + 1} (${frame.timestamp.toFixed(1)}s): ${frame.faceCount} volti rilevati. ${expressions.length ? "Espressioni: " + expressions.join(", ") + "." : "Nessuna espressione determinata."}`;
            });
            return {
                context: [
                    "Analisi NEXUS del video completata.",
                    `Durata: ${video.duration.toFixed(1)} secondi.`,
                    "Fotogrammi analizzati: 3.",
                    `Rilevamenti complessivi di volti nei fotogrammi: ${totalFaces}.`,
                    ...details
                ].join("\n"),
                visualData: { type: "video", durationMs: Math.round(performance.now() - startedAt), frames }
            };
        } finally {
            video.removeAttribute("src");
            video.load();
        }
    }

    throw new Error("Formato allegato non supportato.");
}


async function sendEnclaveAIMessage(event) {
    event.preventDefault();

    if (enclaveAIWaiting) return;

    const input = enclaveAIOverlay.querySelector("#enclaveAIInput");
    const text = input.value.trim();
    const hasAttachment = Boolean(enclaveAIAttachment);

    if (!text && !hasAttachment) return;

    const user = auth.currentUser;

    if (!user || !user.emailVerified) {
        addEnclaveAIMessage("assistant", "Devi accedere a Enclave per utilizzare EnclaveAI.");
        return;
    }

    input.value = "";

    enclaveAIOverlay.querySelector("#enclaveAIWelcome").hidden = true;

    addEnclaveAIMessage(
        "user",
        text || "Analizza l'allegato selezionato."
    );

    enclaveAIWaiting = true;

    const send = enclaveAIOverlay.querySelector("#enclaveAISend");
    send.disabled = true;

    const typing = addEnclaveAIMessage(
        "assistant",
        hasAttachment ? "Analizzo il file con NEXUS…" : "Sto elaborando…"
    );

    typing.classList.add("is-typing");

    let userMessageAdded = false;

    try {
        let analysisContext = "";

        if (hasAttachment) {
            const activity = createEnclaveAINexusActivity();
            typing.querySelector(".enclave-ai-bubble")?.replaceChildren(activity);
            const analysis = await analyzeEnclaveAIAttachment((stage, detail, progress) => {
                setEnclaveAINexusStage(activity, stage, detail, progress);
            });
            analysisContext = analysis.context;
            enclaveAIAnalysisContext = analysisContext;

            const report = renderEnclaveAINexusReport(analysis.visualData);
            if (report && typing.isConnected) {
                enclaveAIOverlay.querySelector("#enclaveAIMessages").insertBefore(report, typing);
            }
            setEnclaveAINexusStage(activity, "ANALISI COMPLETATA", "Risultati locali pronti. EnclaveAI sta elaborando la risposta…", 100);
            activity.classList.add("is-complete");
        }

        const userContent = [
            text || "Analizza l'allegato selezionato.",
            analysisContext
                ? "\n\nRisultati dell'analisi locale NEXUS:\n" + analysisContext
                : ""
        ].join("");

        enclaveAIHistory.push({
            role: "user",
            content: userContent
        });

        userMessageAdded = true;

        enclaveAIHistory = enclaveAIHistory.slice(-12);

        const idToken = await user.getIdToken();



        let answer = await requestEnclaveAIAnswer(
    idToken,
    enclaveAIHistory
);

        if (!answer) {
            answer = "Non sono riuscito a generare una risposta.";
        }

        typing.remove();

        addEnclaveAIMessage("assistant", answer);

        enclaveAIHistory.push({
            role: "assistant",
            content: answer
        });

        enclaveAIHistory = enclaveAIHistory.slice(-12);

        if (hasAttachment) {
            clearEnclaveAIAttachment();
        }

    } catch (error) {
        console.error("EnclaveAI/NEXUS:", error);

        typing.remove();

        addEnclaveAIMessage(
            "assistant",
            error.message || "Non riesco a completare l'analisi in questo momento."
        );

        if (userMessageAdded) {
            enclaveAIHistory.pop();
        }

    } finally {
        enclaveAIWaiting = false;

        if (enclaveAIOverlay?.isConnected) {
            send.disabled = false;
            input.focus();
        }
    }
}