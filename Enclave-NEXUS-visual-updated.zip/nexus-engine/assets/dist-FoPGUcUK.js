import { n as e, o as t, r as n, t as r } from "./subjectSearchEngine-BAwZycqC.js";
// node_modules/@tensorflow/tfjs-core/dist/backends/backend.js
function i(e) {
	throw Error(`'${e}' not yet implemented or not found in the registry. This kernel may not be supported by the tfjs backend you have chosen`);
}
var a, o, s, c, l = e((() => {
	a = 1e-7, o = 1e-4, s = class {
		constructor(e, t) {
			this.backend = e, this.dataMover = t, this.data = /* @__PURE__ */ new WeakMap(), this.dataIdsCount = 0;
		}
		get(e) {
			return this.data.has(e) || this.dataMover.moveData(this.backend, e), this.data.get(e);
		}
		set(e, t) {
			this.dataIdsCount++, this.data.set(e, t);
		}
		has(e) {
			return this.data.has(e);
		}
		delete(e) {
			return this.dataIdsCount--, this.data.delete(e);
		}
		numDataIds() {
			return this.dataIdsCount;
		}
	}, c = class {
		refCount(e) {
			return i("refCount");
		}
		incRef(e) {
			return i("incRef");
		}
		timerAvailable() {
			return !0;
		}
		time(e) {
			return i("time");
		}
		read(e) {
			return i("read");
		}
		readSync(e) {
			return i("readSync");
		}
		readToGPU(e, t) {
			return i("readToGPU");
		}
		numDataIds() {
			return i("numDataIds");
		}
		disposeData(e, t) {
			return i("disposeData");
		}
		write(e, t, n) {
			return i("write");
		}
		move(e, t, n, r, a) {
			return i("move");
		}
		createTensorFromGPUData(e, t, n) {
			return i("createTensorFromGPUData");
		}
		memory() {
			return i("memory");
		}
		floatPrecision() {
			return i("floatPrecision");
		}
		epsilon() {
			return this.floatPrecision() === 32 ? a : o;
		}
		dispose() {
			return i("dispose");
		}
	};
}));
// node_modules/@tensorflow/tfjs-core/dist/util_base.js
function u(e) {
	let t = e.length, n = 0;
	for (; t > 0;) n = Math.random() * t | 0, t--, m(e, t, n);
}
function d(e, t) {
	if (e.length !== t.length) throw Error(`Array sizes must match to be shuffled together First array length was ${e.length}Second array length was ${t.length}`);
	let n = e.length, r = 0;
	for (; n > 0;) r = Math.random() * n | 0, n--, m(e, n, r), m(t, n, r);
}
function f(e, t, n) {
	return Math.max(e, Math.min(t, n));
}
function p(e) {
	return e % 2 == 0 ? e : e + 1;
}
function m(e, t, n) {
	let r = e[t];
	e[t] = e[n], e[n] = r;
}
function h(e) {
	let t = 0;
	for (let n = 0; n < e.length; n++) t += e[n];
	return t;
}
function g(e, t) {
	let n = Math.random();
	return t * n + (1 - n) * e;
}
function _(e, t) {
	let n = 0;
	for (let r = 0; r < e.length; r++) {
		let i = Number(e[r]) - Number(t[r]);
		n += i * i;
	}
	return n;
}
function v(e, t) {
	if (!e) throw Error(typeof t == "string" ? t : t());
}
function y(e, t, n = "") {
	v(S(e, t), () => n + ` Shapes ${e} and ${t} must match`);
}
function b(e) {
	v(e != null, () => "The input to the tensor constructor must be a non-null value.");
}
function x(e) {
	if (e.length === 0) return 1;
	let t = e[0];
	for (let n = 1; n < e.length; n++) t *= e[n];
	return t;
}
function ee(e) {
	return e.length === 0;
}
function te(e, t) {
	if (e === t) return !0;
	if (e == null || t == null || e.length !== t.length) return !1;
	for (let n = 0; n < e.length; n++) if (e[n] !== null && t[n] !== null && e[n] !== t[n]) return !1;
	return !0;
}
function S(e, t) {
	if (e === t) return !0;
	if (e == null || t == null || e.length !== t.length) return !1;
	for (let n = 0; n < e.length; n++) if (e[n] !== t[n]) return !1;
	return !0;
}
function ne(e) {
	return e % 1 == 0;
}
function re(e) {
	if (Math.tanh != null) return Math.tanh(e);
	if (e === Infinity) return 1;
	if (e === -Infinity) return -1;
	{
		let t = Math.exp(2 * e);
		return (t - 1) / (t + 1);
	}
}
function C(e) {
	let t = Math.ceil(Math.sqrt(e));
	return [t, Math.ceil(e / t)];
}
function ie(e) {
	let t = new Uint32Array(e);
	for (let n = 0; n < e; ++n) t[n] = n;
	return u(t), t;
}
function ae(e, t) {
	return t <= e.length ? e : e + " ".repeat(t - e.length);
}
function oe(e, t = (e) => 0, n, r) {
	return new Promise((i, a) => {
		let o = 0, s = () => {
			if (e()) {
				i();
				return;
			}
			o++;
			let c = t(o);
			n != null && o >= n ? a() : r == null ? setTimeout(s, c) : r(s, c);
		};
		s();
	});
}
function se(e, t) {
	let n = 1, r = -1;
	for (let t = 0; t < e.length; ++t) if (e[t] >= 0) n *= e[t];
	else if (e[t] === -1) {
		if (r !== -1) throw Error(`Shapes can only have 1 implicit size. Found -1 at dim ${r} and dim ${t}`);
		r = t;
	} else if (e[t] < 0) throw Error(`Shapes can not be < 0. Found ${e[t]} at dim ${t}`);
	if (r === -1) {
		if (t > 0 && t !== n) throw Error(`Size(${t}) must match the product of shape ${e}`);
		return e;
	}
	if (n === 0) throw Error(`Cannot infer the missing size in [${e}] when there are 0 elements`);
	if (t % n !== 0) throw Error(`The implicit shape can't be a fractional number. Got ${t} / ${n}`);
	let i = e.slice();
	return i[r] = t / n, i;
}
function ce(e, t) {
	let n = t.length;
	return e = e == null ? t.map((e, t) => t) : [].concat(e), v(e.every((e) => e >= -n && e < n), () => `All values in axis param must be in range [-${n}, ${n}) but got axis ${e}`), v(e.every((e) => ne(e)), () => `All values in axis param must be integers but got axis ${e}`), e.map((e) => e < 0 ? n + e : e);
}
function le(e, t) {
	let n = [], r = [], i = t != null && Array.isArray(t) && t.length === 0, a = t == null || i ? null : ce(t, e).sort(), o = 0;
	for (let t = 0; t < e.length; ++t) {
		if (a != null) {
			if (a[o] === t && e[t] !== 1) throw Error(`Can't squeeze axis ${t} since its dim '${e[t]}' is not 1`);
			(a[o] == null || a[o] > t) && e[t] === 1 && (n.push(e[t]), r.push(t)), a[o] <= t && o++;
		}
		e[t] !== 1 && (n.push(e[t]), r.push(t));
	}
	return {
		newShape: n,
		keptDims: r
	};
}
function ue(e, t) {
	return de(e, t);
}
function de(e, t) {
	let n = null;
	if (e == null || e === "float32") n = new Float32Array(t);
	else if (e === "int32") n = new Int32Array(t);
	else if (e === "bool") n = new Uint8Array(t);
	else if (e === "string") n = Array(t);
	else throw Error(`Unknown data type ${e}`);
	return n;
}
function fe(e, t) {
	for (let n = 0; n < e.length; n++) {
		let r = e[n];
		if (isNaN(r) || !isFinite(r)) throw Error(`A tensor of type ${t} being uploaded contains ${r}.`);
	}
}
function pe(e) {
	return e === "bool" || e === "complex64" || e === "float32" || e === "int32" || e === "string";
}
function me(e, t) {
	return !(t === "complex64" || t === "float32" && e !== "complex64" || t === "int32" && e !== "float32" && e !== "complex64" || t === "bool" && e === "bool");
}
function he(e) {
	if (e === "float32" || e === "int32") return 4;
	if (e === "complex64") return 8;
	if (e === "bool") return 1;
	throw Error(`Unknown dtype ${e}`);
}
function ge(e) {
	if (e == null) return 0;
	let t = 0;
	return e.forEach((e) => t += e.length), t;
}
function _e(e) {
	return typeof e == "string" || e instanceof String;
}
function ve(e) {
	return typeof e == "boolean";
}
function ye(e) {
	return typeof e == "number";
}
function be(e) {
	return Array.isArray(e) ? be(e[0]) : e instanceof Float32Array ? "float32" : e instanceof Int32Array || e instanceof Uint8Array || e instanceof Uint8ClampedArray ? "int32" : ye(e) ? "float32" : _e(e) ? "string" : ve(e) ? "bool" : "float32";
}
function xe(e) {
	return !!(e && e.constructor && e.call && e.apply);
}
function Se(e, t) {
	for (let n = t; n < e; ++n) if (e % n === 0) return n;
	return e;
}
function Ce(e) {
	let t = e.length;
	if (t < 2) return [];
	let n = Array(t - 1);
	n[t - 2] = e[t - 1];
	for (let r = t - 3; r >= 0; --r) n[r] = n[r + 1] * e[r + 1];
	return n;
}
function we(e, t, n, r = !1) {
	let i = [];
	if (t.length === 1) {
		let a = t[0] * (r ? 2 : 1);
		for (let t = 0; t < a; t++) i[t] = n[e + t];
	} else {
		let a = t[0], o = t.slice(1), s = o.reduce((e, t) => e * t) * (r ? 2 : 1);
		for (let t = 0; t < a; t++) i[t] = we(e + t * s, o, n, r);
	}
	return i;
}
function Te(e, t, n = !1) {
	if (e.length === 0) return t[0];
	let r = e.reduce((e, t) => e * t) * (n ? 2 : 1);
	if (r === 0) return [];
	if (r !== t.length) throw Error(`[${e}] does not match the input size ${t.length}${n ? " for a complex tensor" : ""}.`);
	return we(0, e, t, n);
}
function Ee(e, t) {
	if (Array.isArray(e)) return e;
	if (t === "float32") return e instanceof Float32Array ? e : new Float32Array(e);
	if (t === "int32") return e instanceof Int32Array ? e : new Int32Array(e);
	if (t === "bool" || t === "string") return Uint8Array.from(new Int32Array(e));
	throw Error(`Unknown dtype ${t}`);
}
function De(e, t) {
	let n = Oe(e, t);
	for (let e = 0; e < n.length; e++) n[e] = 1;
	return n;
}
function Oe(e, t) {
	if (t == null || t === "float32" || t === "complex64") return new Float32Array(e);
	if (t === "int32") return new Int32Array(e);
	if (t === "bool") return new Uint8Array(e);
	throw Error(`Unknown data type ${t}`);
}
function ke(e, t) {
	let n = e.reduce((e, t) => e * t, 1);
	if (t == null || t === "float32") return Te(e, new Float32Array(n));
	if (t === "int32") return Te(e, new Int32Array(n));
	if (t === "bool") return Te(e, new Uint8Array(n));
	throw Error(`Unknown data type ${t}`);
}
function Ae(e) {
	e.forEach((t) => {
		v(Number.isInteger(t) && t >= 0, () => `Tensor must have a shape comprised of positive integers but got shape [${e}].`);
	});
}
function je(e, t, n) {
	if (t === 0) return 0;
	if (t === 1) return e[0];
	let r = e[e.length - 1];
	for (let t = 0; t < e.length - 1; ++t) r += n[t] * e[t];
	return r;
}
function Me(e, t, n) {
	if (t === 0) return [];
	if (t === 1) return [e];
	let r = Array(t);
	for (let t = 0; t < r.length - 1; ++t) r[t] = Math.floor(e / n[t]), e -= r[t] * n[t];
	return r[r.length - 1] = e, r;
}
function Ne(e) {
	return e && e.then && typeof e.then == "function";
}
var Pe = e((() => {}));
// node_modules/@tensorflow/tfjs-core/dist/environment.js
function Fe(e) {
	let t = {};
	return e.replace(/[?&]([^=?&]+)(?:=([^&]*))?/g, (e, ...n) => (Ie(t, n[0], n[1]), n.join("="))), t;
}
function Ie(e, t, n) {
	e[decodeURIComponent(t)] = decodeURIComponent(n || "");
}
function Le(e, t) {
	let n = t.toLowerCase();
	return n === "true" || n === "false" ? n === "true" : `${+n}` === n ? +n : t;
}
function w() {
	return Ve;
}
function Re(e) {
	Ve = e;
}
var ze, Be, Ve, He = e((() => {
	Pe(), ze = "tfjsflags", Be = class {
		constructor(e) {
			this.global = e, this.flags = {}, this.flagRegistry = {}, this.urlFlags = {}, this.getQueryParams = Fe, this.populateURLFlags();
		}
		setPlatform(e, t) {
			this.platform != null && (w().getBool("IS_TEST") || w().getBool("PROD") || console.warn(`Platform ${this.platformName} has already been set. Overwriting the platform with ${e}.`)), this.platformName = e, this.platform = t;
		}
		registerFlag(e, t, n) {
			if (this.flagRegistry[e] = {
				evaluationFn: t,
				setHook: n
			}, this.urlFlags[e] != null) {
				let t = this.urlFlags[e];
				w().getBool("IS_TEST") || w().getBool("PROD") || console.warn(`Setting feature override from URL ${e}: ${t}.`), this.set(e, t);
			}
		}
		async getAsync(e) {
			return e in this.flags || (this.flags[e] = await this.evaluateFlag(e)), this.flags[e];
		}
		get(e) {
			if (e in this.flags) return this.flags[e];
			let t = this.evaluateFlag(e);
			if (Ne(t)) throw Error(`Flag ${e} cannot be synchronously evaluated. Please use getAsync() instead.`);
			return this.flags[e] = t, this.flags[e];
		}
		getNumber(e) {
			return this.get(e);
		}
		getBool(e) {
			return this.get(e);
		}
		getString(e) {
			return this.get(e);
		}
		getFlags() {
			return this.flags;
		}
		get features() {
			return this.flags;
		}
		set(e, t) {
			if (this.flagRegistry[e] == null) throw Error(`Cannot set flag ${e} as it has not been registered.`);
			this.flags[e] = t, this.flagRegistry[e].setHook != null && this.flagRegistry[e].setHook(t);
		}
		evaluateFlag(e) {
			if (this.flagRegistry[e] == null) throw Error(`Cannot evaluate flag '${e}': no evaluation function found.`);
			return this.flagRegistry[e].evaluationFn();
		}
		setFlags(e) {
			this.flags = Object.assign({}, e);
		}
		reset() {
			this.flags = {}, this.urlFlags = {}, this.populateURLFlags();
		}
		populateURLFlags() {
			if (this.global === void 0 || this.global.location === void 0 || this.global.location.search === void 0) return;
			let e = this.getQueryParams(this.global.location.search);
			ze in e && e[ze].split(",").forEach((e) => {
				let [t, n] = e.split(":");
				this.urlFlags[t] = Le(t, n);
			});
		}
	}, Ve = null;
}));
// node_modules/@tensorflow/tfjs-core/dist/global_util.js
function Ue() {
	if (Ke == null) {
		let e;
		if (typeof window < "u") e = window;
		else if (typeof global < "u") e = global;
		else if (typeof process < "u") e = process;
		else if (typeof self < "u") e = self;
		else throw Error("Could not find a global object");
		Ke = e;
	}
	return Ke;
}
function We() {
	let e = Ue();
	return e._tfGlobals ??= /* @__PURE__ */ new Map(), e._tfGlobals;
}
function Ge(e, t) {
	let n = We();
	if (n.has(e)) return n.get(e);
	{
		let r = t();
		return n.set(e, r), n.get(e);
	}
}
var Ke, qe = e((() => {})), Je, Ye, Xe, Ze, Qe, $e, et, tt, nt, rt, it, at, ot, st, ct, lt, ut, dt, ft, pt, mt, ht, gt, _t, vt, yt, bt, xt, St, Ct, wt, Tt, Et, Dt, Ot, kt, At, jt, Mt, Nt, Pt, Ft, It, Lt, Rt, zt, Bt, Vt, Ht, Ut, Wt, Gt, Kt, qt, Jt, Yt, Xt, Zt, Qt, $t, en, tn, nn, rn, an, on, sn, cn, ln, un, dn, fn, pn, mn, hn, gn, _n, vn, yn, bn, xn, Sn, Cn, wn, Tn, En, Dn, On, kn, An, jn, Mn, Nn, Pn, Fn, In, Ln, Rn, zn, Bn, Vn, Hn, Un, Wn, Gn, Kn, qn, Jn, Yn, Xn, Zn, Qn, $n, er, tr, nr, rr, ir, ar, or, sr, cr, lr, ur, dr, fr, pr, mr, hr, gr, _r, vr, yr, br, xr, Sr, Cr, wr, Tr, Er, Dr, Or, kr, Ar, jr, Mr, Nr, Pr, Fr, Ir, Lr, Rr, zr, Br, Vr, Hr, Ur, Wr, Gr, Kr, qr, Jr, Yr, Xr, Zr, Qr, $r, ei, ti, ni, ri, ii, ai, oi, si, ci, li, ui, di, fi, T = e((() => {
	Je = "Abs", Ye = "Acos", Xe = "Acosh", Ze = "Add", Qe = "AddN", $e = "All", et = "Any", tt = "ArgMax", nt = "ArgMin", rt = "Asin", it = "Asinh", at = "Atan", ot = "Atanh", st = "Atan2", ct = "AvgPool", lt = "AvgPoolGrad", ut = "AvgPool3D", dt = "AvgPool3DGrad", ft = "BatchMatMul", pt = "BatchToSpaceND", mt = "Bincount", ht = "BitwiseAnd", gt = "BroadcastTo", _t = "BroadcastArgs", vt = "Cast", yt = "Ceil", bt = "ClipByValue", xt = "Complex", St = "ComplexAbs", Ct = "Concat", wt = "Conv2D", Tt = "Conv2DBackpropFilter", Et = "Conv2DBackpropInput", Dt = "Conv3D", Ot = "Conv3DBackpropFilterV2", kt = "Conv3DBackpropInputV2", At = "Cos", jt = "Cosh", Mt = "Cumprod", Nt = "Cumsum", Pt = "CropAndResize", Ft = "DenseBincount", It = "DepthToSpace", Lt = "DepthwiseConv2dNative", Rt = "DepthwiseConv2dNativeBackpropFilter", zt = "DepthwiseConv2dNativeBackpropInput", Bt = "Diag", Vt = "Dilation2D", Ht = "Dilation2DBackpropInput", Ut = "Dilation2DBackpropFilter", Wt = "Draw", Gt = "RealDiv", Kt = "Einsum", qt = "Elu", Jt = "EluGrad", Yt = "Erf", Xt = "Equal", Zt = "Exp", Qt = "ExpandDims", $t = "Expm1", en = "FFT", tn = "Fill", nn = "FlipLeftRight", rn = "Floor", an = "FloorDiv", on = "FusedBatchNorm", sn = "GatherV2", cn = "GatherNd", ln = "Greater", un = "GreaterEqual", dn = "Identity", fn = "IFFT", pn = "Imag", mn = "IsFinite", hn = "IsInf", gn = "IsNan", _n = "LeakyRelu", vn = "Less", yn = "LessEqual", bn = "LinSpace", xn = "Log", Sn = "Log1p", Cn = "LogicalAnd", wn = "LogicalNot", Tn = "LogicalOr", En = "LogicalXor", Dn = "LogSoftmax", On = "LowerBound", kn = "LRN", An = "LRNGrad", jn = "MatrixBandPart", Mn = "Max", Nn = "Maximum", Pn = "MaxPool", Fn = "MaxPoolGrad", In = "MaxPool3D", Ln = "MaxPool3DGrad", Rn = "MaxPoolWithArgmax", zn = "Mean", Bn = "Min", Vn = "Minimum", Hn = "MirrorPad", Un = "Mod", Wn = "Multinomial", Gn = "Multiply", Kn = "Neg", qn = "NotEqual", Jn = "NonMaxSuppressionV3", Yn = "NonMaxSuppressionV4", Xn = "NonMaxSuppressionV5", Zn = "OnesLike", Qn = "OneHot", $n = "Pack", er = "PadV2", tr = "Pool", nr = "Pow", rr = "Prelu", ir = "Prod", ar = "RaggedGather", or = "RaggedRange", sr = "RaggedTensorToTensor", cr = "Range", lr = "Real", ur = "Reciprocal", dr = "Relu", fr = "Reshape", pr = "ResizeNearestNeighbor", mr = "ResizeNearestNeighborGrad", hr = "ResizeBilinear", gr = "ResizeBilinearGrad", _r = "Relu6", vr = "Reverse", yr = "Round", br = "Rsqrt", xr = "ScatterNd", Sr = "TensorScatterUpdate", Cr = "SearchSorted", wr = "Select", Tr = "Selu", Er = "Slice", Dr = "Sin", Or = "Sinh", kr = "Sign", Ar = "Sigmoid", jr = "Softplus", Mr = "Sqrt", Nr = "Sum", Pr = "SpaceToBatchND", Fr = "SplitV", Ir = "Softmax", Lr = "SparseFillEmptyRows", Rr = "SparseReshape", zr = "SparseSegmentMean", Br = "SparseSegmentSum", Vr = "SparseToDense", Hr = "SquaredDifference", Ur = "Square", Wr = "StaticRegexReplace", Gr = "StridedSlice", Kr = "StringNGrams", qr = "StringSplit", Jr = "StringToHashBucketFast", Yr = "Sub", Xr = "Tan", Zr = "Tanh", Qr = "Tile", $r = "TopK", ei = "Transform", ti = "Transpose", ni = "Unique", ri = "Unpack", ii = "UnsortedSegmentSum", ai = "UpperBound", oi = "ZerosLike", si = "Step", ci = "FromPixels", li = "RotateWithOffset", ui = "_FusedMatMul", di = "FusedConv2D", fi = "FusedDepthwiseConv2D";
}));
// node_modules/@tensorflow/tfjs-core/dist/log.js
function pi(...e) {
	w().getBool("IS_TEST") || w().getBool("PROD") || console.warn(...e);
}
function mi(...e) {
	w().getBool("IS_TEST") || w().getBool("PROD") || console.log(...e);
}
var hi = e((() => {
	He();
}));
// node_modules/@tensorflow/tfjs-core/dist/kernel_registry.js
function gi(e, t) {
	let n = wi(e, t);
	return Ti.get(n);
}
function _i(e) {
	return Ei.get(e);
}
function vi(e) {
	let t = Ti.entries(), n = [];
	for (;;) {
		let { done: r, value: i } = t.next();
		if (r) break;
		let [a, o] = i, [s] = a.split("_");
		s === e && n.push(o);
	}
	return n;
}
function yi(e) {
	let { kernelName: t, backendName: n } = e, r = wi(t, n);
	Ti.has(r) && pi(`The kernel '${t}' for backend '${n}' is already registered`), Ti.set(r, e);
}
function bi(e) {
	let { kernelName: t } = e;
	Ei.has(t) && w().getBool("DEBUG") && pi(`Overriding the gradient for '${t}'`), Ei.set(t, e);
}
function xi(e, t) {
	let n = wi(e, t);
	if (!Ti.has(n)) throw Error(`The kernel '${e}' for backend '${t}' is not registered`);
	Ti.delete(n);
}
function Si(e) {
	if (!Ei.has(e)) throw Error(`The gradient '${e}' for backend is not registered`);
	Ei.delete(e);
}
function Ci(e, t) {
	vi(e).forEach((e) => {
		yi(Object.assign({}, e, { backendName: t }));
	});
}
function wi(e, t) {
	return `${t}_${e}`;
}
var Ti, Ei, Di = e((() => {
	He(), qe(), hi(), Ti = Ge("kernelRegistry", () => /* @__PURE__ */ new Map()), Ei = Ge("gradRegistry", () => /* @__PURE__ */ new Map());
}));
// node_modules/@tensorflow/tfjs-core/dist/platforms/is_typed_array_browser.js
function Oi(e) {
	return e instanceof Float32Array || e instanceof Int32Array || e instanceof Uint8Array || e instanceof Uint8ClampedArray;
}
var ki = e((() => {})), Ai = /* @__PURE__ */ r(((e, t) => {
	t.exports = r;
	var n = null;
	try {
		n = new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array([
			0,
			97,
			115,
			109,
			1,
			0,
			0,
			0,
			1,
			13,
			2,
			96,
			0,
			1,
			127,
			96,
			4,
			127,
			127,
			127,
			127,
			1,
			127,
			3,
			7,
			6,
			0,
			1,
			1,
			1,
			1,
			1,
			6,
			6,
			1,
			127,
			1,
			65,
			0,
			11,
			7,
			50,
			6,
			3,
			109,
			117,
			108,
			0,
			1,
			5,
			100,
			105,
			118,
			95,
			115,
			0,
			2,
			5,
			100,
			105,
			118,
			95,
			117,
			0,
			3,
			5,
			114,
			101,
			109,
			95,
			115,
			0,
			4,
			5,
			114,
			101,
			109,
			95,
			117,
			0,
			5,
			8,
			103,
			101,
			116,
			95,
			104,
			105,
			103,
			104,
			0,
			0,
			10,
			191,
			1,
			6,
			4,
			0,
			35,
			0,
			11,
			36,
			1,
			1,
			126,
			32,
			0,
			173,
			32,
			1,
			173,
			66,
			32,
			134,
			132,
			32,
			2,
			173,
			32,
			3,
			173,
			66,
			32,
			134,
			132,
			126,
			34,
			4,
			66,
			32,
			135,
			167,
			36,
			0,
			32,
			4,
			167,
			11,
			36,
			1,
			1,
			126,
			32,
			0,
			173,
			32,
			1,
			173,
			66,
			32,
			134,
			132,
			32,
			2,
			173,
			32,
			3,
			173,
			66,
			32,
			134,
			132,
			127,
			34,
			4,
			66,
			32,
			135,
			167,
			36,
			0,
			32,
			4,
			167,
			11,
			36,
			1,
			1,
			126,
			32,
			0,
			173,
			32,
			1,
			173,
			66,
			32,
			134,
			132,
			32,
			2,
			173,
			32,
			3,
			173,
			66,
			32,
			134,
			132,
			128,
			34,
			4,
			66,
			32,
			135,
			167,
			36,
			0,
			32,
			4,
			167,
			11,
			36,
			1,
			1,
			126,
			32,
			0,
			173,
			32,
			1,
			173,
			66,
			32,
			134,
			132,
			32,
			2,
			173,
			32,
			3,
			173,
			66,
			32,
			134,
			132,
			129,
			34,
			4,
			66,
			32,
			135,
			167,
			36,
			0,
			32,
			4,
			167,
			11,
			36,
			1,
			1,
			126,
			32,
			0,
			173,
			32,
			1,
			173,
			66,
			32,
			134,
			132,
			32,
			2,
			173,
			32,
			3,
			173,
			66,
			32,
			134,
			132,
			130,
			34,
			4,
			66,
			32,
			135,
			167,
			36,
			0,
			32,
			4,
			167,
			11
		])), {}).exports;
	} catch {}
	function r(e, t, n) {
		this.low = e | 0, this.high = t | 0, this.unsigned = !!n;
	}
	r.prototype.__isLong__, Object.defineProperty(r.prototype, "__isLong__", { value: !0 });
	function i(e) {
		return (e && e.__isLong__) === !0;
	}
	r.isLong = i;
	var a = {}, o = {};
	function s(e, t) {
		var n, r, i;
		return t ? (e >>>= 0, (i = 0 <= e && e < 256) && (r = o[e], r) ? r : (n = l(e, (e | 0) < 0 ? -1 : 0, !0), i && (o[e] = n), n)) : (e |= 0, (i = -128 <= e && e < 128) && (r = a[e], r) ? r : (n = l(e, e < 0 ? -1 : 0, !1), i && (a[e] = n), n));
	}
	r.fromInt = s;
	function c(e, t) {
		if (isNaN(e)) return t ? b : y;
		if (t) {
			if (e < 0) return b;
			if (e >= g) return ne;
		} else {
			if (e <= -_) return re;
			if (e + 1 >= _) return S;
		}
		return e < 0 ? c(-e, t).neg() : l(e % h | 0, e / h | 0, t);
	}
	r.fromNumber = c;
	function l(e, t, n) {
		return new r(e, t, n);
	}
	r.fromBits = l;
	var u = Math.pow;
	function d(e, t, n) {
		if (e.length === 0) throw Error("empty string");
		if (e === "NaN" || e === "Infinity" || e === "+Infinity" || e === "-Infinity") return y;
		if (typeof t == "number" ? (n = t, t = !1) : t = !!t, n ||= 10, n < 2 || 36 < n) throw RangeError("radix");
		var r;
		if ((r = e.indexOf("-")) > 0) throw Error("interior hyphen");
		if (r === 0) return d(e.substring(1), t, n).neg();
		for (var i = c(u(n, 8)), a = y, o = 0; o < e.length; o += 8) {
			var s = Math.min(8, e.length - o), l = parseInt(e.substring(o, o + s), n);
			if (s < 8) {
				var f = c(u(n, s));
				a = a.mul(f).add(c(l));
			} else a = a.mul(i), a = a.add(c(l));
		}
		return a.unsigned = t, a;
	}
	r.fromString = d;
	function f(e, t) {
		return typeof e == "number" ? c(e, t) : typeof e == "string" ? d(e, t) : l(e.low, e.high, typeof t == "boolean" ? t : e.unsigned);
	}
	r.fromValue = f;
	var p = 65536, m = 1 << 24, h = p * p, g = h * h, _ = g / 2, v = s(m), y = s(0);
	r.ZERO = y;
	var b = s(0, !0);
	r.UZERO = b;
	var x = s(1);
	r.ONE = x;
	var ee = s(1, !0);
	r.UONE = ee;
	var te = s(-1);
	r.NEG_ONE = te;
	var S = l(-1, 2147483647, !1);
	r.MAX_VALUE = S;
	var ne = l(-1, -1, !0);
	r.MAX_UNSIGNED_VALUE = ne;
	var re = l(0, -2147483648, !1);
	r.MIN_VALUE = re;
	var C = r.prototype;
	C.toInt = function() {
		return this.unsigned ? this.low >>> 0 : this.low;
	}, C.toNumber = function() {
		return this.unsigned ? (this.high >>> 0) * h + (this.low >>> 0) : this.high * h + (this.low >>> 0);
	}, C.toString = function(e) {
		if (e ||= 10, e < 2 || 36 < e) throw RangeError("radix");
		if (this.isZero()) return "0";
		if (this.isNegative()) {
			if (this.eq(re)) {
				var t = c(e), n = this.div(t), r = n.mul(t).sub(this);
				return n.toString(e) + r.toInt().toString(e);
			}
			return "-" + this.neg().toString(e);
		}
		for (var i = c(u(e, 6), this.unsigned), a = this, o = "";;) {
			var s = a.div(i), l = (a.sub(s.mul(i)).toInt() >>> 0).toString(e);
			if (a = s, a.isZero()) return l + o;
			for (; l.length < 6;) l = "0" + l;
			o = "" + l + o;
		}
	}, C.getHighBits = function() {
		return this.high;
	}, C.getHighBitsUnsigned = function() {
		return this.high >>> 0;
	}, C.getLowBits = function() {
		return this.low;
	}, C.getLowBitsUnsigned = function() {
		return this.low >>> 0;
	}, C.getNumBitsAbs = function() {
		if (this.isNegative()) return this.eq(re) ? 64 : this.neg().getNumBitsAbs();
		for (var e = this.high == 0 ? this.low : this.high, t = 31; t > 0 && !(e & 1 << t); t--);
		return this.high == 0 ? t + 1 : t + 33;
	}, C.isZero = function() {
		return this.high === 0 && this.low === 0;
	}, C.eqz = C.isZero, C.isNegative = function() {
		return !this.unsigned && this.high < 0;
	}, C.isPositive = function() {
		return this.unsigned || this.high >= 0;
	}, C.isOdd = function() {
		return (this.low & 1) == 1;
	}, C.isEven = function() {
		return !(this.low & 1);
	}, C.equals = function(e) {
		return i(e) || (e = f(e)), this.unsigned !== e.unsigned && this.high >>> 31 == 1 && e.high >>> 31 == 1 ? !1 : this.high === e.high && this.low === e.low;
	}, C.eq = C.equals, C.notEquals = function(e) {
		return !this.eq(e);
	}, C.neq = C.notEquals, C.ne = C.notEquals, C.lessThan = function(e) {
		return this.comp(e) < 0;
	}, C.lt = C.lessThan, C.lessThanOrEqual = function(e) {
		return this.comp(e) <= 0;
	}, C.lte = C.lessThanOrEqual, C.le = C.lessThanOrEqual, C.greaterThan = function(e) {
		return this.comp(e) > 0;
	}, C.gt = C.greaterThan, C.greaterThanOrEqual = function(e) {
		return this.comp(e) >= 0;
	}, C.gte = C.greaterThanOrEqual, C.ge = C.greaterThanOrEqual, C.compare = function(e) {
		if (i(e) || (e = f(e)), this.eq(e)) return 0;
		var t = this.isNegative(), n = e.isNegative();
		return t && !n ? -1 : !t && n ? 1 : this.unsigned ? e.high >>> 0 > this.high >>> 0 || e.high === this.high && e.low >>> 0 > this.low >>> 0 ? -1 : 1 : this.sub(e).isNegative() ? -1 : 1;
	}, C.comp = C.compare, C.negate = function() {
		return !this.unsigned && this.eq(re) ? re : this.not().add(x);
	}, C.neg = C.negate, C.add = function(e) {
		i(e) || (e = f(e));
		var t = this.high >>> 16, n = this.high & 65535, r = this.low >>> 16, a = this.low & 65535, o = e.high >>> 16, s = e.high & 65535, c = e.low >>> 16, u = e.low & 65535, d = 0, p = 0, m = 0, h = 0;
		return h += a + u, m += h >>> 16, h &= 65535, m += r + c, p += m >>> 16, m &= 65535, p += n + s, d += p >>> 16, p &= 65535, d += t + o, d &= 65535, l(m << 16 | h, d << 16 | p, this.unsigned);
	}, C.subtract = function(e) {
		return i(e) || (e = f(e)), this.add(e.neg());
	}, C.sub = C.subtract, C.multiply = function(e) {
		if (this.isZero()) return y;
		if (i(e) || (e = f(e)), n) return l(n.mul(this.low, this.high, e.low, e.high), n.get_high(), this.unsigned);
		if (e.isZero()) return y;
		if (this.eq(re)) return e.isOdd() ? re : y;
		if (e.eq(re)) return this.isOdd() ? re : y;
		if (this.isNegative()) return e.isNegative() ? this.neg().mul(e.neg()) : this.neg().mul(e).neg();
		if (e.isNegative()) return this.mul(e.neg()).neg();
		if (this.lt(v) && e.lt(v)) return c(this.toNumber() * e.toNumber(), this.unsigned);
		var t = this.high >>> 16, r = this.high & 65535, a = this.low >>> 16, o = this.low & 65535, s = e.high >>> 16, u = e.high & 65535, d = e.low >>> 16, p = e.low & 65535, m = 0, h = 0, g = 0, _ = 0;
		return _ += o * p, g += _ >>> 16, _ &= 65535, g += a * p, h += g >>> 16, g &= 65535, g += o * d, h += g >>> 16, g &= 65535, h += r * p, m += h >>> 16, h &= 65535, h += a * d, m += h >>> 16, h &= 65535, h += o * u, m += h >>> 16, h &= 65535, m += t * p + r * d + a * u + o * s, m &= 65535, l(g << 16 | _, m << 16 | h, this.unsigned);
	}, C.mul = C.multiply, C.divide = function(e) {
		if (i(e) || (e = f(e)), e.isZero()) throw Error("division by zero");
		if (n) return !this.unsigned && this.high === -2147483648 && e.low === -1 && e.high === -1 ? this : l((this.unsigned ? n.div_u : n.div_s)(this.low, this.high, e.low, e.high), n.get_high(), this.unsigned);
		if (this.isZero()) return this.unsigned ? b : y;
		var t, r, a;
		if (this.unsigned) {
			if (e.unsigned || (e = e.toUnsigned()), e.gt(this)) return b;
			if (e.gt(this.shru(1))) return ee;
			a = b;
		} else {
			if (this.eq(re)) return e.eq(x) || e.eq(te) ? re : e.eq(re) ? x : (t = this.shr(1).div(e).shl(1), t.eq(y) ? e.isNegative() ? x : te : (r = this.sub(e.mul(t)), a = t.add(r.div(e)), a));
			if (e.eq(re)) return this.unsigned ? b : y;
			if (this.isNegative()) return e.isNegative() ? this.neg().div(e.neg()) : this.neg().div(e).neg();
			if (e.isNegative()) return this.div(e.neg()).neg();
			a = y;
		}
		for (r = this; r.gte(e);) {
			t = Math.max(1, Math.floor(r.toNumber() / e.toNumber()));
			for (var o = Math.ceil(Math.log(t) / Math.LN2), s = o <= 48 ? 1 : u(2, o - 48), d = c(t), p = d.mul(e); p.isNegative() || p.gt(r);) t -= s, d = c(t, this.unsigned), p = d.mul(e);
			d.isZero() && (d = x), a = a.add(d), r = r.sub(p);
		}
		return a;
	}, C.div = C.divide, C.modulo = function(e) {
		return i(e) || (e = f(e)), n ? l((this.unsigned ? n.rem_u : n.rem_s)(this.low, this.high, e.low, e.high), n.get_high(), this.unsigned) : this.sub(this.div(e).mul(e));
	}, C.mod = C.modulo, C.rem = C.modulo, C.not = function() {
		return l(~this.low, ~this.high, this.unsigned);
	}, C.and = function(e) {
		return i(e) || (e = f(e)), l(this.low & e.low, this.high & e.high, this.unsigned);
	}, C.or = function(e) {
		return i(e) || (e = f(e)), l(this.low | e.low, this.high | e.high, this.unsigned);
	}, C.xor = function(e) {
		return i(e) || (e = f(e)), l(this.low ^ e.low, this.high ^ e.high, this.unsigned);
	}, C.shiftLeft = function(e) {
		return i(e) && (e = e.toInt()), (e &= 63) == 0 ? this : e < 32 ? l(this.low << e, this.high << e | this.low >>> 32 - e, this.unsigned) : l(0, this.low << e - 32, this.unsigned);
	}, C.shl = C.shiftLeft, C.shiftRight = function(e) {
		return i(e) && (e = e.toInt()), (e &= 63) == 0 ? this : e < 32 ? l(this.low >>> e | this.high << 32 - e, this.high >> e, this.unsigned) : l(this.high >> e - 32, this.high >= 0 ? 0 : -1, this.unsigned);
	}, C.shr = C.shiftRight, C.shiftRightUnsigned = function(e) {
		if (i(e) && (e = e.toInt()), e &= 63, e === 0) return this;
		var t = this.high;
		if (e < 32) {
			var n = this.low;
			return l(n >>> e | t << 32 - e, t >>> e, this.unsigned);
		}
		return l(e === 32 ? t : t >>> e - 32, 0, this.unsigned);
	}, C.shru = C.shiftRightUnsigned, C.shr_u = C.shiftRightUnsigned, C.toSigned = function() {
		return this.unsigned ? l(this.low, this.high, !1) : this;
	}, C.toUnsigned = function() {
		return this.unsigned ? this : l(this.low, this.high, !0);
	}, C.toBytes = function(e) {
		return e ? this.toBytesLE() : this.toBytesBE();
	}, C.toBytesLE = function() {
		var e = this.high, t = this.low;
		return [
			t & 255,
			t >>> 8 & 255,
			t >>> 16 & 255,
			t >>> 24,
			e & 255,
			e >>> 8 & 255,
			e >>> 16 & 255,
			e >>> 24
		];
	}, C.toBytesBE = function() {
		var e = this.high, t = this.low;
		return [
			e >>> 24,
			e >>> 16 & 255,
			e >>> 8 & 255,
			e & 255,
			t >>> 24,
			t >>> 16 & 255,
			t >>> 8 & 255,
			t & 255
		];
	}, r.fromBytes = function(e, t, n) {
		return n ? r.fromBytesLE(e, t) : r.fromBytesBE(e, t);
	}, r.fromBytesLE = function(e, t) {
		return new r(e[0] | e[1] << 8 | e[2] << 16 | e[3] << 24, e[4] | e[5] << 8 | e[6] << 16 | e[7] << 24, t);
	}, r.fromBytesBE = function(e, t) {
		return new r(e[4] << 24 | e[5] << 16 | e[6] << 8 | e[7], e[0] << 24 | e[1] << 16 | e[2] << 8 | e[3], t);
	};
}));
// node_modules/@tensorflow/tfjs-core/dist/hash_util.js
function ji(e) {
	return Wi.fromString(e, !0, 16);
}
function Mi(e) {
	return e.xor(e.shru(47));
}
function Ni(e, t, n) {
	let r = e.slice(t, t + n);
	return Wi.fromBytes(Array.from(r), !0, !0);
}
function E(e, t) {
	return Ni(e, t, 8);
}
function Pi(e, t) {
	return Ni(e, t, 4);
}
function Fi(e, t) {
	return t === 0 ? e : e.shru(t).or(e.shl(64 - t));
}
function Ii(e, t, n = ji("9ddfea08eb382d69")) {
	let r = e.xor(t).mul(n);
	r = r.xor(r.shru(47));
	let i = t.xor(r).mul(n);
	return i = i.xor(i.shru(47)), i = i.mul(n), i;
}
function Li(e, t, n, r, i, a) {
	i = i.add(e), a = Fi(a.add(i).add(r), 21);
	let o = i;
	return i = i.add(t), i = i.add(n), a = a.add(Fi(i, 44)), [i.add(r), a.add(o)];
}
function Ri(e, t, n, r) {
	return Li(E(e, t), E(e, t + 8), E(e, t + 16), E(e, t + 24), n, r);
}
function zi(e, t = e.length) {
	if (t >= 8) {
		let n = qi.add(t * 2), r = E(e, 0).add(qi), i = E(e, t - 8);
		return Ii(Fi(i, 37).mul(n).add(r), Fi(r, 25).add(i).mul(n), n);
	}
	if (t >= 4) {
		let n = qi.add(t * 2);
		return Ii(Pi(e, 0).shl(3).add(t), Pi(e, t - 4), n);
	}
	if (t > 0) {
		let n = e[0], r = e[t >> 1], i = e[t - 1], a = n + (r << 8), o = t + (i << 2);
		return Mi(qi.mul(a).xor(Gi.mul(o))).mul(qi);
	}
	return qi;
}
function Bi(e, t = e.length) {
	let n = qi.add(t * 2), r = E(e, 0).mul(Ki), i = E(e, 8), a = E(e, t - 8).mul(n), o = E(e, t - 16).mul(qi);
	return Ii(Fi(r.add(i), 43).add(Fi(a, 30)).add(o), r.add(Fi(i.add(qi), 18)).add(a), n);
}
function Vi(e, t = e.length) {
	let n = qi.add(t * 2), r = E(e, 0).mul(qi), i = E(e, 8), a = E(e, t - 8).mul(n), o = E(e, t - 16).mul(qi), s = Fi(r.add(i), 43).add(Fi(a, 30)).add(o), c = Ii(s, r.add(Fi(i.add(qi), 18)).add(a), n), l = E(e, 16).mul(n), u = E(e, 24), d = s.add(E(e, t - 32)).mul(n), f = c.add(E(e, t - 24)).mul(n);
	return Ii(Fi(l.add(u), 43).add(Fi(d, 30)).add(f), l.add(Fi(u.add(r), 18)).add(d), n);
}
function Hi(e, t = e.length) {
	let n = Wi.fromNumber(81, !0);
	if (t <= 32) return t <= 16 ? zi(e, t) : Bi(e, t);
	if (t <= 64) return Vi(e, t);
	let r = n, i = n.mul(Ki).add(113), a = Mi(i.mul(qi).add(113)).mul(qi), o = [Wi.UZERO, Wi.UZERO], s = [Wi.UZERO, Wi.UZERO];
	r = r.mul(qi).add(E(e, 0));
	let c = 0, l = (t - 1 >> 6) * 64, u = l + (t - 1 & 63) - 63;
	do
		r = Fi(r.add(i).add(o[0]).add(E(e, c + 8)), 37).mul(Ki), i = Fi(i.add(o[1]).add(E(e, c + 48)), 42).mul(Ki), r = r.xor(s[1]), i = i.add(o[0]).add(E(e, c + 40)), a = Fi(a.add(s[0]), 33).mul(Ki), o = Ri(e, c, o[1].mul(Ki), r.add(s[0])), s = Ri(e, c + 32, a.add(s[1]), i.add(E(e, c + 16))), [a, r] = [r, a], c += 64;
	while (c !== l);
	let d = Ki.add(a.and(255).shl(1));
	return c = u, s[0] = s[0].add(t - 1 & 63), o[0] = o[0].add(s[0]), s[0] = s[0].add(o[0]), r = Fi(r.add(i).add(o[0]).add(E(e, c + 8)), 37).mul(d), i = Fi(i.add(o[1]).add(E(e, c + 48)), 42).mul(d), r = r.xor(s[1].mul(9)), i = i.add(o[0].mul(9).add(E(e, c + 40))), a = Fi(a.add(s[0]), 33).mul(d), o = Ri(e, c, o[1].mul(d), r.add(s[0])), s = Ri(e, c + 32, a.add(s[1]), i.add(E(e, c + 16))), [a, r] = [r, a], Ii(Ii(o[0], s[0], d).add(Mi(i).mul(Gi)).add(a), Ii(o[1], s[1], d).add(r), d);
}
var Ui, Wi, Gi, Ki, qi, Ji = e((() => {
	Ui = /* @__PURE__ */ t(Ai()), Wi = Ui.default || Ui, Gi = ji("c3a5c85c97cb3127"), Ki = ji("b492b66fbe98f273"), qi = ji("9ae16a3b2f90404f");
})), Yi = /* @__PURE__ */ n({
	arraysEqual: () => S,
	arraysEqualWithNull: () => te,
	assert: () => v,
	assertNonNegativeIntegerDimensions: () => Ae,
	assertNonNull: () => b,
	assertShapesMatch: () => y,
	bytesFromStringArray: () => ge,
	bytesPerElement: () => he,
	checkConversionForErrors: () => fe,
	clamp: () => f,
	computeStrides: () => Ce,
	convertBackendValuesAndArrayBuffer: () => Ee,
	createScalarValue: () => Xi,
	createShuffledIndices: () => ie,
	decodeString: () => na,
	distSquared: () => _,
	encodeString: () => ta,
	fetch: () => ea,
	fingerPrint64: () => Hi,
	flatten: () => ia,
	getArrayFromDType: () => de,
	getTypedArrayFromDType: () => ue,
	hasEncodingLoss: () => me,
	hexToLong: () => ji,
	indexToLoc: () => Me,
	inferDtype: () => be,
	inferFromImplicitShape: () => se,
	isBoolean: () => ve,
	isFunction: () => xe,
	isInt: () => ne,
	isNumber: () => ye,
	isPromise: () => Ne,
	isScalarShape: () => ee,
	isString: () => _e,
	isTypedArray: () => ra,
	isValidDtype: () => pe,
	locToIndex: () => je,
	makeOnesTypedArray: () => De,
	makeZerosNestedTypedArray: () => ke,
	makeZerosTypedArray: () => Oe,
	nearestDivisor: () => Se,
	nearestLargerEven: () => p,
	now: () => $i,
	parseAxisParam: () => ce,
	randUniform: () => g,
	repeatedTry: () => oe,
	rightPad: () => ae,
	shuffle: () => u,
	shuffleCombo: () => d,
	sizeFromShape: () => x,
	sizeToSquarishShape: () => C,
	squeezeShape: () => le,
	sum: () => h,
	swap: () => m,
	tanh: () => re,
	toNestedArray: () => Te,
	toTypedArray: () => Qi
});
function Xi(e, t) {
	return t === "string" ? ta(e) : Qi([e], t);
}
function Zi(e, t) {
	return e instanceof Float32Array && t === "float32" || e instanceof Int32Array && t === "int32" || e instanceof Uint8Array && t === "bool";
}
function Qi(e, t) {
	if (t === "string") throw Error("Cannot convert a string[] to a TypedArray");
	if (Array.isArray(e) && (e = ia(e)), w().getBool("DEBUG") && fe(e, t), Zi(e, t)) return e;
	if (t == null || t === "float32" || t === "complex64") return new Float32Array(e);
	if (t === "int32") return new Int32Array(e);
	if (t === "bool") {
		let t = new Uint8Array(e.length);
		for (let n = 0; n < t.length; ++n) Math.round(e[n]) !== 0 && (t[n] = 1);
		return t;
	}
	throw Error(`Unknown data type ${t}`);
}
function $i() {
	return w().platform.now();
}
function ea(e, t) {
	return w().platform.fetch(e, t);
}
function ta(e, t = "utf-8") {
	return t ||= "utf-8", w().platform.encode(e, t);
}
function na(e, t = "utf-8") {
	return t ||= "utf-8", w().platform.decode(e, t);
}
function ra(e) {
	return w().platform.isTypedArray == null ? Oi(e) : w().platform.isTypedArray(e);
}
function ia(e, t = [], n = !1) {
	if (t ??= [], typeof e == "boolean" || typeof e == "number" || typeof e == "string" || Ne(e) || e == null || ra(e) && n) t.push(e);
	else if (Array.isArray(e) || ra(e)) for (let r = 0; r < e.length; ++r) ia(e[r], t, n);
	else {
		let r = -1;
		for (let t of Object.keys(e)) /^([1-9]+[0-9]*|0)$/.test(t) && (r = Math.max(r, Number(t)));
		for (let i = 0; i <= r; i++) ia(e[i], t, n);
	}
	return t;
}
var D = e((() => {
	He(), ki(), Pe(), Pe(), Ji();
}));
// node_modules/@tensorflow/tfjs-core/dist/profiler.js
function aa(e, t, n) {
	if (t !== "float32") return !1;
	for (let t = 0; t < e.length; t++) {
		let r = e[t];
		if (isNaN(r) || !isFinite(r)) return console.warn(`Found ${r} in the result of '${n}'`), !0;
	}
	return !1;
}
var oa, sa, ca = e((() => {
	He(), D(), oa = class {
		constructor(e, t) {
			this.backendTimer = e, this.logger = t, t ?? (this.logger = new sa());
		}
		profileKernel(e, t, n) {
			let r, i = () => {
				r = n();
			}, a, o = $i();
			if (this.backendTimer.timerAvailable()) a = this.backendTimer.time(i);
			else {
				i();
				for (let e of r) e.dataSync();
				a = Promise.resolve({ kernelMs: $i() - o });
			}
			if (w().getBool("CHECK_COMPUTATION_FOR_ERRORS")) for (let t = 0; t < r.length; t++) {
				let n = r[t];
				n.data().then((t) => {
					aa(t, n.dtype, e);
				});
			}
			return {
				kernelName: e,
				outputs: r,
				inputs: t,
				timeMs: a.then((e) => e.kernelMs),
				extraInfo: a.then((e) => e.getExtraProfileInfo == null ? "" : e.getExtraProfileInfo())
			};
		}
		logKernelProfile(e) {
			let { kernelName: t, outputs: n, timeMs: r, inputs: i, extraInfo: a } = e;
			n.forEach((e) => {
				Promise.all([
					e.data(),
					r,
					a
				]).then((n) => {
					this.logger.logKernelProfile(t, e, n[0], n[1], i, n[2]);
				});
			});
		}
	}, sa = class {
		logKernelProfile(e, t, n, r, i, a) {
			let o = typeof r == "number" ? ae(`${r}ms`, 9) : r.error, s = ae(e, 25), c = t.rank, l = t.size, u = ae(t.shape.toString(), 14), d = "";
			for (let e in i) {
				let n = i[e];
				if (n != null) {
					let r = n.shape || t.shape, i = r.length;
					d += `${e}: ${i}D ${i > 0 ? r : ""} `;
				}
			}
			console.log(`%c${s}\t%c${o}\t%c${c}D ${u}\t%c${l}\t%c${d}\t%c${a}`, "font-weight:bold", "color:red", "color:blue", "color: orange", "color: green", "color: steelblue");
		}
	};
}));
// node_modules/@tensorflow/tfjs-core/dist/tape.js
function la(e, t, n) {
	let r = {}, i = {};
	for (let e = 0; e < t.length; e++) r[t[e].id] = !0;
	for (let n = 0; n < e.length; n++) {
		let a = e[n], o = a.inputs;
		for (let e in o) {
			let n = o[e], s = !1;
			for (let e = 0; e < t.length; e++) if (r[n.id]) {
				a.outputs.forEach((e) => r[e.id] = !0), s = !0, i[a.id] = !0;
				break;
			}
			if (s) break;
		}
	}
	let a = {};
	a[n.id] = !0;
	let o = {};
	for (let t = e.length - 1; t >= 0; t--) {
		let n = e[t], r = n.inputs;
		for (let e = 0; e < n.outputs.length; e++) if (a[n.outputs[e].id]) {
			for (let e in r) a[r[e].id] = !0, o[n.id] = !0;
			break;
		}
	}
	let s = [];
	for (let t = 0; t < e.length; t++) {
		let n = e[t];
		if (i[n.id] && o[n.id]) {
			let e = {};
			for (let t in n.inputs) {
				let i = n.inputs[t];
				r[i.id] && (e[t] = i);
			}
			let t = Object.assign({}, n);
			t.inputs = e, t.outputs = n.outputs, s.push(t);
		}
	}
	return s;
}
function ua(e, t, n, r) {
	for (let i = t.length - 1; i >= 0; i--) {
		let a = t[i], o = [];
		if (a.outputs.forEach((t) => {
			let n = e[t.id];
			n == null ? o.push(null) : o.push(n);
		}), a.gradient == null) throw Error(`Cannot compute gradient: gradient function not found for ${a.kernelName}.`);
		let s = a.gradient(o);
		for (let t in a.inputs) {
			if (!(t in s)) throw Error(`Cannot backprop through input ${t}. Available gradients found: ${Object.keys(s)}.`);
			let i = n(() => s[t]());
			if (i.dtype !== "float32") throw Error(`Error in gradient for op ${a.kernelName}. The gradient of input ${t} must have 'float32' dtype, but has '${i.dtype}'`);
			let o = a.inputs[t];
			if (!S(i.shape, o.shape)) throw Error(`Error in gradient for op ${a.kernelName}. The gradient of input '${t}' has shape '${i.shape}', which does not match the shape of the input '${o.shape}'`);
			if (e[o.id] == null) e[o.id] = i;
			else {
				let t = e[o.id];
				e[o.id] = r(t, i), t.dispose();
			}
		}
	}
}
var da = e((() => {
	D();
}));
// node_modules/@tensorflow/tfjs-core/dist/tensor_format.js
function fa(e, t, n, r) {
	let i = Ce(t), a = pa(e, t, n, i), o = t.length, s = ga(e, t, n, i, a), c = ["Tensor"];
	return r && (c.push(`  dtype: ${n}`), c.push(`  rank: ${o}`), c.push(`  shape: [${t}]`), c.push("  values:")), c.push(s.map((e) => "    " + e).join("\n")), c.join("\n");
}
function pa(e, t, n, r) {
	let i = x(t), a = r[r.length - 1], o = Array(a).fill(0), s = t.length, c = n === "complex64" ? _a(e) : e;
	if (s > 1) for (let e = 0; e < i / a; e++) {
		let t = e * a;
		for (let e = 0; e < a; e++) o[e] = Math.max(o[e], ma(c[t + e], 0, n).length);
	}
	return o;
}
function ma(e, t, n) {
	let r;
	return r = Array.isArray(e) ? `${parseFloat(e[0].toFixed(ba))} + ${parseFloat(e[1].toFixed(ba))}j` : _e(e) ? `'${e}'` : n === "bool" ? ha(e) : parseFloat(e.toFixed(ba)).toString(), ae(r, t);
}
function ha(e) {
	return e === 0 ? "false" : "true";
}
function ga(e, t, n, r, i, a = !0) {
	let o = n === "complex64" ? 2 : 1, s = t[0], c = t.length;
	if (c === 0) return n === "complex64" ? [ma(_a(e)[0], 0, n)] : n === "bool" ? [ha(e[0])] : [e[0].toString()];
	if (c === 1) {
		if (s > va) {
			let t = ya * o, r = Array.from(e.slice(0, t)), a = Array.from(e.slice((s - ya) * o, s * o));
			return n === "complex64" && (r = _a(r), a = _a(a)), ["[" + r.map((e, t) => ma(e, i[t], n)).join(", ") + ", ..., " + a.map((e, t) => ma(e, i[s - ya + t], n)).join(", ") + "]"];
		}
		return ["[" + (n === "complex64" ? _a(e) : Array.from(e)).map((e, t) => ma(e, i[t], n)).join(", ") + "]"];
	}
	let l = t.slice(1), u = r.slice(1), d = r[0] * o, f = [];
	if (s > va) {
		for (let t = 0; t < ya; t++) {
			let r = t * d, a = r + d;
			f.push(...ga(e.slice(r, a), l, n, u, i, !1));
		}
		f.push("...");
		for (let t = s - ya; t < s; t++) {
			let r = t * d, a = r + d;
			f.push(...ga(e.slice(r, a), l, n, u, i, t === s - 1));
		}
	} else for (let t = 0; t < s; t++) {
		let r = t * d, a = r + d;
		f.push(...ga(e.slice(r, a), l, n, u, i, t === s - 1));
	}
	let p = c === 2 ? "," : "";
	f[0] = "[" + (s > 0 ? f[0] + p : "");
	for (let e = 1; e < f.length - 1; e++) f[e] = " " + f[e] + p;
	let m = ",\n";
	for (let e = 2; e < c; e++) m += "\n";
	return f[f.length - 1] = " " + f[f.length - 1] + "]" + (a ? "" : m), f;
}
function _a(e) {
	let t = [];
	for (let n = 0; n < e.length; n += 2) t.push([e[n], e[n + 1]]);
	return t;
}
var va, ya, ba, xa = e((() => {
	D(), va = 20, ya = 3, ba = 7;
}));
// node_modules/@tensorflow/tfjs-core/dist/tensor.js
function Sa(e) {
	Ea = e;
}
function Ca(e) {
	Da = e;
}
function wa() {
	return Ge("Tensor", () => O);
}
var Ta, Ea, Da, O, Oa, ka = e((() => {
	qe(), xa(), D(), Ta = class {
		constructor(e, t, n) {
			if (this.dtype = t, this.shape = e.slice(), this.size = x(e), n != null) {
				let e = n.length;
				v(e === this.size, () => `Length of values '${e}' does not match the size inferred by the shape '${this.size}'.`);
			}
			if (t === "complex64") throw Error("complex64 dtype TensorBuffers are not supported. Please create a TensorBuffer for the real and imaginary parts separately and call tf.complex(real, imag).");
			this.values = n || de(t, this.size), this.strides = Ce(e);
		}
		set(e, ...t) {
			t.length === 0 && (t = [0]), v(t.length === this.rank, () => `The number of provided coordinates (${t.length}) must match the rank (${this.rank})`);
			let n = this.locToIndex(t);
			this.values[n] = e;
		}
		get(...e) {
			e.length === 0 && (e = [0]);
			let t = 0;
			for (let n of e) {
				if (n < 0 || n >= this.shape[t]) {
					let t = `Requested out of range element at ${e}.   Buffer shape=${this.shape}`;
					throw Error(t);
				}
				t++;
			}
			let n = e[e.length - 1];
			for (let t = 0; t < e.length - 1; ++t) n += this.strides[t] * e[t];
			return this.values[n];
		}
		locToIndex(e) {
			if (this.rank === 0) return 0;
			if (this.rank === 1) return e[0];
			let t = e[e.length - 1];
			for (let n = 0; n < e.length - 1; ++n) t += this.strides[n] * e[n];
			return t;
		}
		indexToLoc(e) {
			if (this.rank === 0) return [];
			if (this.rank === 1) return [e];
			let t = Array(this.shape.length);
			for (let n = 0; n < t.length - 1; ++n) t[n] = Math.floor(e / this.strides[n]), e -= t[n] * this.strides[n];
			return t[t.length - 1] = e, t;
		}
		get rank() {
			return this.shape.length;
		}
		toTensor() {
			return Ea().makeTensor(this.values, this.shape, this.dtype);
		}
	}, Ea = null, Da = null, O = class {
		constructor(e, t, n, r) {
			this.kept = !1, this.isDisposedInternal = !1, this.shape = e.slice(), this.dtype = t || "float32", this.size = x(e), this.strides = Ce(e), this.dataId = n, this.id = r, this.rankType = this.rank < 5 ? this.rank.toString() : "higher";
		}
		get rank() {
			return this.shape.length;
		}
		async buffer() {
			let e = await this.data();
			return Da.buffer(this.shape, this.dtype, e);
		}
		bufferSync() {
			return Da.buffer(this.shape, this.dtype, this.dataSync());
		}
		async array() {
			let e = await this.data();
			return Te(this.shape, e, this.dtype === "complex64");
		}
		arraySync() {
			return Te(this.shape, this.dataSync(), this.dtype === "complex64");
		}
		async data() {
			this.throwIfDisposed();
			let e = Ea().read(this.dataId);
			if (this.dtype === "string") {
				let t = await e;
				try {
					return t.map((e) => na(e));
				} catch {
					throw Error("Failed to decode the string bytes into utf-8. To get the original bytes, call tensor.bytes().");
				}
			}
			return e;
		}
		dataToGPU(e) {
			return this.throwIfDisposed(), Ea().readToGPU(this.dataId, e);
		}
		dataSync() {
			this.throwIfDisposed();
			let e = Ea().readSync(this.dataId);
			if (this.dtype === "string") try {
				return e.map((e) => na(e));
			} catch {
				throw Error("Failed to decode the string bytes into utf-8. To get the original bytes, call tensor.bytes().");
			}
			return e;
		}
		async bytes() {
			this.throwIfDisposed();
			let e = await Ea().read(this.dataId);
			return this.dtype === "string" ? e : new Uint8Array(e.buffer);
		}
		dispose() {
			this.isDisposed || (this.kerasMask && this.kerasMask.dispose(), Ea().disposeTensor(this), this.isDisposedInternal = !0);
		}
		get isDisposed() {
			return this.isDisposedInternal;
		}
		throwIfDisposed() {
			if (this.isDisposed) throw Error("Tensor is disposed.");
		}
		print(e = !1) {
			return Da.print(this, e);
		}
		clone() {
			return this.throwIfDisposed(), Da.clone(this);
		}
		toString(e = !1) {
			return fa(this.dataSync(), this.shape, this.dtype, e);
		}
		cast(e) {
			return this.throwIfDisposed(), Da.cast(this, e);
		}
		variable(e = !0, t, n) {
			return this.throwIfDisposed(), Ea().makeVariable(this, e, t, n);
		}
	}, Object.defineProperty(O, Symbol.hasInstance, { value: (e) => !!e && e.data != null && e.dataSync != null && e.throwIfDisposed != null }), wa(), Oa = class extends O {
		constructor(e, t, n, r) {
			super(e.shape, e.dtype, e.dataId, r), this.trainable = t, this.name = n;
		}
		assign(e) {
			if (e.dtype !== this.dtype) throw Error(`dtype of the new value (${e.dtype}) and previous value (${this.dtype}) must match`);
			if (!S(e.shape, this.shape)) throw Error(`shape of the new value (${e.shape}) and previous value (${this.shape}) must match`);
			Ea().disposeTensor(this), this.dataId = e.dataId, Ea().incRef(this, null);
		}
		dispose() {
			Ea().disposeVariable(this), this.isDisposedInternal = !0;
		}
	}, Object.defineProperty(Oa, Symbol.hasInstance, { value: (e) => e instanceof O && e.assign != null && e.assign instanceof Function });
}));
// node_modules/@tensorflow/tfjs-core/dist/types.js
function Aa(e, t) {
	if (e === "string" || t === "string") {
		if (e === "string" && t === "string") return "string";
		throw Error(`Can not upcast ${e} with ${t}`);
	}
	return za[e][t];
}
function ja(e) {
	return Aa(e, "int32");
}
function Ma(e) {
	return typeof e == "object" && !!e && "texture" in e && e.texture instanceof WebGLTexture;
}
function Na(e) {
	return typeof GPUBuffer < "u" && typeof e == "object" && !!e && "buffer" in e && e.buffer instanceof GPUBuffer;
}
var Pa, Fa, Ia, La, Ra, za, Ba = e((() => {
	(function(e) {
		e.R0 = "R0", e.R1 = "R1", e.R2 = "R2", e.R3 = "R3", e.R4 = "R4", e.R5 = "R5", e.R6 = "R6";
	})(Pa ||= {}), (function(e) {
		e.float32 = "float32", e.int32 = "int32", e.bool = "int32", e.complex64 = "complex64";
	})(Fa ||= {}), (function(e) {
		e.float32 = "float32", e.int32 = "int32", e.bool = "bool", e.complex64 = "complex64";
	})(Ia ||= {}), (function(e) {
		e.float32 = "float32", e.int32 = "float32", e.bool = "float32", e.complex64 = "complex64";
	})(La ||= {}), (function(e) {
		e.float32 = "complex64", e.int32 = "complex64", e.bool = "complex64", e.complex64 = "complex64";
	})(Ra ||= {}), za = {
		float32: La,
		int32: Fa,
		bool: Ia,
		complex64: Ra
	};
})), Va = /* @__PURE__ */ n({
	assertTypesMatch: () => Ha,
	getTensorsInContainer: () => Wa,
	isTensorInList: () => Ua,
	makeTypesMatch: () => k
});
function k(e, t) {
	if (e.dtype === t.dtype) return [e, t];
	let n = Aa(e.dtype, t.dtype);
	return [e.cast(n), t.cast(n)];
}
function Ha(e, t) {
	v(e.dtype === t.dtype, () => `The dtypes of the first(${e.dtype}) and second(${t.dtype}) input must match`);
}
function Ua(e, t) {
	return t.some((t) => t.id === e.id);
}
function Wa(e) {
	let t = [];
	return Ga(e, t, /* @__PURE__ */ new Set()), t;
}
function Ga(e, t, n) {
	if (e == null) return;
	if (e instanceof O) {
		t.push(e);
		return;
	}
	if (!Ka(e)) return;
	let r = e;
	for (let e in r) {
		let i = r[e];
		n.has(i) || (n.add(i), Ga(i, t, n));
	}
}
function Ka(e) {
	return Array.isArray(e) || typeof e == "object";
}
var A = e((() => {
	ka(), Ba(), D();
}));
// node_modules/@tensorflow/tfjs-core/dist/engine.js
function qa(e) {
	return e.kernelName != null;
}
function Ja(e) {
	let t = De(x(e), "float32");
	return j.makeTensor(t, e, "float32");
}
function Ya() {
	let e = Ue();
	if (e._tfengine == null) {
		let t = new Be(e);
		e._tfengine = new Qa(t);
	}
	return Re(e._tfengine.ENV), Sa(() => e._tfengine), e._tfengine;
}
function Xa(e, t) {
	let n = {
		a: e,
		b: t
	};
	return j.runKernel("Add", n);
}
var Za, Qa, j, M = e((() => {
	l(), He(), qe(), T(), Di(), hi(), ca(), da(), ka(), A(), D(), Za = class {
		constructor() {
			this.registeredVariables = {}, this.nextTapeNodeId = 0, this.numBytes = 0, this.numTensors = 0, this.numStringTensors = 0, this.numDataBuffers = 0, this.gradientDepth = 0, this.kernelDepth = 0, this.scopeStack = [], this.numDataMovesStack = [], this.nextScopeId = 0, this.tensorInfo = /* @__PURE__ */ new WeakMap(), this.profiling = !1, this.activeProfile = {
				newBytes: 0,
				newTensors: 0,
				peakBytes: 0,
				kernels: [],
				result: null,
				get kernelNames() {
					return Array.from(new Set(this.kernels.map((e) => e.name)));
				}
			};
		}
		dispose() {
			for (let e in this.registeredVariables) this.registeredVariables[e].dispose();
		}
	}, Qa = class e {
		constructor(e) {
			this.ENV = e, this.registry = {}, this.registryFactory = {}, this.pendingBackendInitId = 0, this.state = new Za();
		}
		async ready() {
			if (this.pendingBackendInit != null) return this.pendingBackendInit.then(() => {});
			if (this.backendInstance != null) return;
			let e = this.getSortedBackends();
			for (let t = 0; t < e.length; t++) {
				let n = e[t];
				if (await this.initializeBackend(n).success) {
					await this.setBackend(n);
					return;
				}
			}
			throw Error("Could not initialize any backends, all backend initializations failed.");
		}
		get backend() {
			if (this.pendingBackendInit != null) throw Error(`Backend '${this.backendName}' has not yet been initialized. Make sure to await tf.ready() or await tf.setBackend() before calling other methods`);
			if (this.backendInstance == null) {
				let { name: e, asyncInit: t } = this.initializeBackendsAndReturnBest();
				if (t) throw Error(`The highest priority backend '${e}' has not yet been initialized. Make sure to await tf.ready() or await tf.setBackend() before calling other methods`);
				this.setBackend(e);
			}
			return this.backendInstance;
		}
		backendNames() {
			return Object.keys(this.registryFactory);
		}
		findBackend(e) {
			if (!(e in this.registry)) {
				if (e in this.registryFactory) {
					let { asyncInit: t } = this.initializeBackend(e);
					if (t) return null;
				} else return null;
			}
			return this.registry[e];
		}
		findBackendFactory(e) {
			return e in this.registryFactory ? this.registryFactory[e].factory : null;
		}
		registerBackend(e, t, n = 1) {
			return e in this.registryFactory ? (pi(`${e} backend was already registered. Reusing existing backend factory.`), !1) : (this.registryFactory[e] = {
				factory: t,
				priority: n
			}, !0);
		}
		async setBackend(e) {
			if (this.registryFactory[e] == null) throw Error(`Backend name '${e}' not found in registry`);
			if (this.backendName = e, this.registry[e] == null) {
				this.backendInstance = null;
				let { success: t, asyncInit: n } = this.initializeBackend(e);
				if (!(n ? await t : t)) return !1;
			}
			return this.backendInstance = this.registry[e], this.setupRegisteredKernels(), this.profiler = new oa(this.backendInstance), !0;
		}
		setupRegisteredKernels() {
			vi(this.backendName).forEach((e) => {
				e.setupFunc != null && e.setupFunc(this.backendInstance);
			});
		}
		disposeRegisteredKernels(e) {
			vi(e).forEach((t) => {
				t.disposeFunc != null && t.disposeFunc(this.registry[e]);
			});
		}
		initializeBackend(e) {
			let t = this.registryFactory[e];
			if (t == null) throw Error(`Cannot initialize backend ${e}, no registration found.`);
			try {
				let n = t.factory();
				if (n && !(n instanceof c) && typeof n.then == "function") {
					let t = ++this.pendingBackendInitId, r = n.then((n) => t < this.pendingBackendInitId ? !1 : (this.registry[e] = n, this.pendingBackendInit = null, !0)).catch((n) => (t < this.pendingBackendInitId || (this.pendingBackendInit = null, pi(`Initialization of backend ${e} failed`), pi(n.stack || n.message)), !1));
					return this.pendingBackendInit = r, {
						success: r,
						asyncInit: !0
					};
				}
				return this.registry[e] = n, {
					success: !0,
					asyncInit: !1
				};
			} catch (t) {
				return pi(`Initialization of backend ${e} failed`), pi(t.stack || t.message), {
					success: !1,
					asyncInit: !1
				};
			}
		}
		removeBackend(e) {
			if (!(e in this.registryFactory)) throw Error(`${e} backend not found in registry`);
			this.backendName === e && this.pendingBackendInit != null && this.pendingBackendInitId++, e in this.registry && (this.disposeRegisteredKernels(e), this.registry[e].dispose(), delete this.registry[e]), delete this.registryFactory[e], this.backendName === e && (this.pendingBackendInit = null, this.backendName = null, this.backendInstance = null);
		}
		getSortedBackends() {
			if (Object.keys(this.registryFactory).length === 0) throw Error("No backend found in registry.");
			return Object.keys(this.registryFactory).sort((e, t) => this.registryFactory[t].priority - this.registryFactory[e].priority);
		}
		initializeBackendsAndReturnBest() {
			let e = this.getSortedBackends();
			for (let t = 0; t < e.length; t++) {
				let n = e[t], { success: r, asyncInit: i } = this.initializeBackend(n);
				if (i || r) return {
					name: n,
					asyncInit: i
				};
			}
			throw Error("Could not initialize any backends, all backend initializations failed.");
		}
		moveData(e, t) {
			let n = this.state.tensorInfo.get(t), r = n.backend, i = this.readSync(t), a = r.refCount(t);
			r.disposeData(t, !0), n.backend = e, e.move(t, i, n.shape, n.dtype, a), this.shouldCheckForMemLeaks() && this.state.numDataMovesStack[this.state.numDataMovesStack.length - 1]++;
		}
		tidy(e, t) {
			let n = null;
			if (t == null) {
				if (typeof e != "function") throw Error("Please provide a function to tidy()");
				t = e;
			} else {
				if (typeof e != "string" && !(e instanceof String)) throw Error("When calling with two arguments, the first argument to tidy() must be a string");
				if (typeof t != "function") throw Error("When calling with two arguments, the 2nd argument to tidy() must be a function");
				n = e;
			}
			let r;
			return this.scopedRun(() => this.startScope(n), () => this.endScope(r), () => (r = t(), r instanceof Promise && console.error("Cannot return a Promise inside of tidy."), r));
		}
		scopedRun(e, t, n) {
			e();
			try {
				let e = n();
				return t(), e;
			} catch (e) {
				throw t(), e;
			}
		}
		nextTensorId() {
			return e.nextTensorId++;
		}
		nextVariableId() {
			return e.nextVariableId++;
		}
		clone(e) {
			let t = j.runKernel(dn, { x: e }), n = { x: e };
			return this.addTapeNode(this.state.activeScope.name, n, [t], (e) => ({ x: () => {
				let t = { x: e };
				return j.runKernel(vt, t, { dtype: "float32" });
			} }), [], {}), t;
		}
		runKernel(e, t, n) {
			if (this.backendName ?? this.backend, gi(e, this.backendName) == null) throw Error(`Kernel '${e}' not registered for backend '${this.backendName}'`);
			return this.runKernelFunc({
				kernelName: e,
				inputs: t,
				attrs: n
			});
		}
		shouldCheckForMemLeaks() {
			return this.ENV.getBool("IS_TEST");
		}
		checkKernelForMemLeak(e, t, n) {
			let r = this.backend.numDataIds(), i = 0;
			n.forEach((e) => {
				i += e.dtype === "complex64" ? 3 : 1;
			});
			let a = this.state.numDataMovesStack[this.state.numDataMovesStack.length - 1], o = r - t - i - a;
			if (o > 0) throw Error(`Backend '${this.backendName}' has an internal memory leak (${o} data ids) after running '${e}'`);
		}
		runKernelFunc(e) {
			let t, n = [], r = this.isTapeOn(), i = this.state.numBytes, a = this.state.numTensors;
			this.shouldCheckForMemLeaks() && this.state.numDataMovesStack.push(0);
			let o;
			this.backendName ?? this.backend;
			let s, c = qa(e) ? e.kernelName : this.state.activeScope == null ? "" : this.state.activeScope.name;
			if (qa(e)) {
				let { kernelName: t, inputs: i, attrs: a } = e;
				this.backendName ?? this.backend;
				let c = gi(t, this.backendName);
				v(c != null, () => `Cannot find registered kernel '${t}' for backend '${this.backendName}'`), o = () => {
					let e = this.backend.numDataIds();
					s = c.kernelFunc({
						inputs: i,
						attrs: a,
						backend: this.backend
					});
					let o = Array.isArray(s) ? s : [s];
					this.shouldCheckForMemLeaks() && this.checkKernelForMemLeak(t, e, o);
					let l = o.map((e) => e.rank == null ? this.makeTensorFromTensorInfo(e) : e);
					if (r) {
						let e = this.getTensorsForGradient(t, i, l);
						n = this.saveTensorsForBackwardMode(e);
					}
					return l;
				};
			} else {
				let { forwardFunc: t } = e, i = (e) => {
					r && (n = e.map((e) => this.keep(this.clone(e))));
				};
				o = () => {
					let e = this.backend.numDataIds();
					s = this.tidy(() => t(this.backend, i));
					let n = Array.isArray(s) ? s : [s];
					return this.shouldCheckForMemLeaks() && this.checkKernelForMemLeak(c, e, n), n;
				};
			}
			let { inputs: l, attrs: u } = e, d = qa(e) ? null : e.backwardsFunc, f;
			return this.scopedRun(() => this.state.kernelDepth++, () => this.state.kernelDepth--, () => {
				!this.ENV.getBool("DEBUG") && !this.state.profiling ? t = o() : (f = this.profiler.profileKernel(c, l, () => o()), this.ENV.getBool("DEBUG") && this.profiler.logKernelProfile(f), t = f.outputs);
			}), r && this.addTapeNode(c, l, t, d, n, u), this.state.profiling && this.state.activeProfile.kernels.push({
				name: c,
				bytesAdded: this.state.numBytes - i,
				totalBytesSnapshot: this.state.numBytes,
				tensorsAdded: this.state.numTensors - a,
				totalTensorsSnapshot: this.state.numTensors,
				inputShapes: Object.keys(l).map((e) => l[e] == null ? null : l[e].shape),
				outputShapes: t.map((e) => e.shape),
				kernelTimeMs: f.timeMs,
				extraInfo: f.extraInfo
			}), Array.isArray(s) ? t : t[0];
		}
		saveTensorsForBackwardMode(e) {
			return e.map((e) => this.keep(this.clone(e)));
		}
		getTensorsForGradient(e, t, n) {
			let r = _i(e);
			if (r != null) {
				let e = r.inputsToSave || [], i = r.outputsToSave || [], a;
				r.saveAllInputs ? (v(Array.isArray(t), () => "saveAllInputs is true, expected inputs to be an array."), a = Object.keys(t).map((e) => t[e])) : a = e.map((e) => t[e]);
				let o = n.filter((e, t) => i[t]);
				return a.concat(o);
			}
			return [];
		}
		makeTensor(e, t, n, r) {
			if (e == null) throw Error("Values passed to engine.makeTensor() are null");
			n ||= "float32", r ||= this.backend;
			let i = e;
			n === "string" && _e(e[0]) && (i = e.map((e) => ta(e)));
			let a = r.write(i, t, n), o = new O(t, n, a, this.nextTensorId());
			if (this.trackTensor(o, r), n === "string") {
				let e = this.state.tensorInfo.get(a), t = ge(i);
				this.state.numBytes += t - e.bytes, e.bytes = t;
			}
			return o;
		}
		makeTensorFromDataId(e, t, n, r) {
			n ||= "float32";
			let i = {
				dataId: e,
				shape: t,
				dtype: n
			};
			return this.makeTensorFromTensorInfo(i, r);
		}
		makeTensorFromTensorInfo(e, t) {
			let { dataId: n, shape: r, dtype: i } = e, a = new O(r, i, n, this.nextTensorId());
			return this.trackTensor(a, t), a;
		}
		makeVariable(e, t = !0, n, r) {
			n ||= this.nextVariableId().toString(), r != null && r !== e.dtype && (e = e.cast(r));
			let i = new Oa(e, t, n, this.nextTensorId());
			if (this.state.registeredVariables[i.name] != null) throw Error(`Variable with name ${i.name} was already registered`);
			return this.state.registeredVariables[i.name] = i, this.incRef(i, this.backend), i;
		}
		trackTensor(e, t) {
			this.state.numTensors++, e.dtype === "string" && this.state.numStringTensors++;
			let n = 0;
			e.dtype !== "complex64" && e.dtype !== "string" && (n = e.size * he(e.dtype)), this.state.numBytes += n, this.state.tensorInfo.has(e.dataId) || (this.state.numDataBuffers++, this.state.tensorInfo.set(e.dataId, {
				backend: t || this.backend,
				dtype: e.dtype,
				shape: e.shape,
				bytes: n
			})), e instanceof Oa || this.track(e);
		}
		incRef(e, t) {
			this.trackTensor(e, t), this.backend.incRef(e.dataId);
		}
		removeDataId(e, t) {
			this.state.tensorInfo.has(e) && this.state.tensorInfo.get(e).backend === t && (this.state.tensorInfo.delete(e), this.state.numDataBuffers--);
		}
		disposeTensor(e) {
			if (!this.state.tensorInfo.has(e.dataId)) return;
			let t = this.state.tensorInfo.get(e.dataId);
			if (this.state.numTensors--, e.dtype === "string" && (this.state.numStringTensors--, this.state.numBytes -= t.bytes), e.dtype !== "complex64" && e.dtype !== "string") {
				let t = e.size * he(e.dtype);
				this.state.numBytes -= t;
			}
			t.backend.disposeData(e.dataId) && this.removeDataId(e.dataId, t.backend);
		}
		disposeVariables() {
			for (let e in this.state.registeredVariables) {
				let t = this.state.registeredVariables[e];
				this.disposeVariable(t);
			}
		}
		disposeVariable(e) {
			this.disposeTensor(e), this.state.registeredVariables[e.name] != null && delete this.state.registeredVariables[e.name];
		}
		memory() {
			let e = this.backend.memory();
			return e.numTensors = this.state.numTensors, e.numDataBuffers = this.state.numDataBuffers, e.numBytes = this.state.numBytes, this.state.numStringTensors > 0 && (e.unreliable = !0, e.reasons ??= [], e.reasons.push("Memory usage by string tensors is approximate (2 bytes per character)")), e;
		}
		async profile(e) {
			this.state.profiling = !0;
			let t = this.state.numBytes, n = this.state.numTensors;
			this.state.activeProfile.kernels = [], this.state.activeProfile.result = await e(), this.state.profiling = !1, this.state.activeProfile.peakBytes = Math.max(...this.state.activeProfile.kernels.map((e) => e.totalBytesSnapshot)), this.state.activeProfile.newBytes = this.state.numBytes - t, this.state.activeProfile.newTensors = this.state.numTensors - n;
			for (let e of this.state.activeProfile.kernels) e.kernelTimeMs = await e.kernelTimeMs, e.extraInfo = await e.extraInfo;
			return this.state.activeProfile;
		}
		isTapeOn() {
			return this.state.gradientDepth > 0 && this.state.kernelDepth === 0;
		}
		addTapeNode(e, t, n, r, i, a) {
			let o = {
				id: this.state.nextTapeNodeId++,
				kernelName: e,
				inputs: t,
				outputs: n,
				saved: i
			}, s = _i(e);
			s != null && (r = s.gradFunc), r != null && (o.gradient = (e) => (e = e.map((e, t) => {
				if (e == null) {
					let e = n[t], r = Oe(e.size, e.dtype);
					return this.makeTensor(r, e.shape, e.dtype);
				}
				return e;
			}), r(e.length > 1 ? e : e[0], i, a))), this.state.activeTape.push(o);
		}
		keep(e) {
			return e.kept = !0, e;
		}
		startTape() {
			this.state.gradientDepth === 0 && (this.state.activeTape = []), this.state.gradientDepth++;
		}
		endTape() {
			this.state.gradientDepth--;
		}
		startScope(e) {
			let t = {
				track: [],
				name: "unnamed scope",
				id: this.state.nextScopeId++
			};
			e && (t.name = e), this.state.scopeStack.push(t), this.state.activeScope = t;
		}
		endScope(e) {
			let t = Wa(e), n = new Set(t.map((e) => e.id));
			for (let e = 0; e < this.state.activeScope.track.length; e++) {
				let t = this.state.activeScope.track[e];
				!t.kept && !n.has(t.id) && t.dispose();
			}
			let r = this.state.scopeStack.pop();
			this.state.activeScope = this.state.scopeStack.length === 0 ? null : this.state.scopeStack[this.state.scopeStack.length - 1], t.forEach((e) => {
				!e.kept && e.scopeId === r.id && this.track(e);
			});
		}
		gradients(e, t, n, r = !1) {
			if (v(t.length > 0, () => "gradients() received an empty list of xs."), n != null && n.dtype !== "float32") throw Error(`dy must have 'float32' dtype, but has '${n.dtype}'`);
			let i = this.scopedRun(() => this.startTape(), () => this.endTape(), () => this.tidy("forward", e));
			v(i instanceof O, () => "The result y returned by f() must be a tensor.");
			let a = la(this.state.activeTape, t, i);
			if (!r && a.length === 0 && t.length > 0) throw Error("Cannot compute gradient of y=f(x) with respect to x. Make sure that the f you passed encloses all operations that lead from x to y.");
			return this.tidy("backward", () => {
				let e = {};
				e[i.id] = n ?? Ja(i.shape), ua(e, a, (e) => this.tidy(e), Xa);
				let r = t.map((t) => e[t.id]);
				return this.state.gradientDepth === 0 && (this.state.activeTape.forEach((e) => {
					for (let t of e.saved) t.dispose();
				}), this.state.activeTape = null), {
					value: i,
					grads: r
				};
			});
		}
		customGrad(e) {
			return v(xe(e), () => "The f passed in customGrad(f) must be a function."), (...t) => {
				v(t.every((e) => e instanceof O), () => "The args passed in customGrad(f)(x1, x2,...) must all be tensors");
				let n, r = {};
				return t.forEach((e, t) => {
					r[t] = e;
				}), this.runKernelFunc({
					forwardFunc: (r, i) => (n = e(...t, i), v(n.value instanceof O, () => "The function f passed in customGrad(f) must return an object where `obj.value` is a tensor"), v(xe(n.gradFunc), () => "The function f passed in customGrad(f) must return an object where `obj.gradFunc` is a function."), n.value),
					backwardsFunc: (e, r) => {
						let i = n.gradFunc(e, r), a = Array.isArray(i) ? i : [i];
						v(a.length === t.length, () => "The function f passed in customGrad(f) must return an object where `obj.gradFunc` is a function that returns the same number of tensors as inputs passed to f(...)."), v(a.every((e) => e instanceof O), () => "The function f passed in customGrad(f) must return an object where `obj.gradFunc` is a function that returns a list of only tensors.");
						let o = {};
						return a.forEach((e, t) => {
							o[t] = () => e;
						}), o;
					},
					inputs: r
				});
			};
		}
		readSync(e) {
			return this.state.tensorInfo.get(e).backend.readSync(e);
		}
		read(e) {
			return this.state.tensorInfo.get(e).backend.read(e);
		}
		readToGPU(e, t) {
			return this.state.tensorInfo.get(e).backend.readToGPU(e, t);
		}
		async time(e) {
			let t = $i(), n = await this.backend.time(e);
			return n.wallMs = $i() - t, n;
		}
		track(e) {
			return this.state.activeScope != null && (e.scopeId = this.state.activeScope.id, this.state.activeScope.track.push(e)), e;
		}
		get registeredVariables() {
			return this.state.registeredVariables;
		}
		reset() {
			this.pendingBackendInitId++, this.state.dispose(), this.ENV.reset(), this.state = new Za();
			for (let e in this.registry) this.disposeRegisteredKernels(e), this.registry[e].dispose(), delete this.registry[e];
			this.backendName = null, this.backendInstance = null, this.pendingBackendInit = null;
		}
	}, Qa.nextTensorId = 0, Qa.nextVariableId = 0, j = Ya();
})), $a = /* @__PURE__ */ n({
	isBrowser: () => ro,
	isMobile: () => no,
	mockIsMobile: () => to
});
function eo() {
	return typeof navigator < "u" && navigator != null;
}
function to(e) {
	io = e;
}
function no(e) {
	if (io !== void 0) return io;
	if (e || eo()) {
		if (e ||= navigator, e.product === "ReactNative") return !0;
		let t = e.userAgent || e.vendor || (typeof window < "u" ? window.opera : "");
		if (!t) {
			let t = e;
			return t.userAgentData && t.userAgentData.mobile;
		}
		return /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(t) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(t.substr(0, 4));
	}
	return !1;
}
function ro() {
	return typeof window < "u" && window.document != null || typeof WorkerGlobalScope < "u";
}
var io, ao = e((() => {})), oo, so = e((() => {
	M(), ao(), He(), oo = w(), oo.registerFlag("DEBUG", () => !1, (e) => {
		e && console.warn("Debugging mode is ON. The output of every math call will be downloaded to CPU and checked for NaNs. This significantly impacts performance.");
	}), oo.registerFlag("IS_BROWSER", () => ro()), oo.registerFlag("IS_NODE", () => typeof process < "u" && process.versions !== void 0 && process.versions.node !== void 0), oo.registerFlag("IS_CHROME", () => typeof navigator < "u" && navigator != null && navigator.userAgent != null && /Chrome/.test(navigator.userAgent) && /Google Inc/.test(navigator.vendor)), oo.registerFlag("IS_SAFARI", () => typeof navigator < "u" && navigator != null && navigator.userAgent != null && /Safari/.test(navigator.userAgent) && /Apple/.test(navigator.vendor)), oo.registerFlag("PROD", () => !1), oo.registerFlag("TENSORLIKE_CHECK_SHAPE_CONSISTENCY", () => oo.getBool("DEBUG")), oo.registerFlag("DEPRECATION_WARNINGS_ENABLED", () => !0), oo.registerFlag("IS_TEST", () => !1), oo.registerFlag("CHECK_COMPUTATION_FOR_ERRORS", () => oo.getBool("DEBUG")), oo.registerFlag("WRAP_TO_IMAGEBITMAP", () => !1), oo.registerFlag("CANVAS2D_WILL_READ_FREQUENTLY_FOR_GPU", () => !1), oo.registerFlag("USE_SETTIMEOUTCUSTOM", () => !1);
}));
// node_modules/@tensorflow/tfjs-core/dist/tensor_util_env.js
function co(e, t) {
	let n = e;
	if (ra(e)) return t === "string" ? [] : [e.length];
	if (Ma(e)) {
		let t = e.channels || "RGBA";
		return [e.height, e.width * t.length];
	}
	if (Na(e)) return [e.buffer.size / (t == null ? 4 : he(t))];
	if (!Array.isArray(e)) return [];
	let r = [];
	for (; Array.isArray(n) || ra(n) && t !== "string";) r.push(n.length), n = n[0];
	return Array.isArray(e) && w().getBool("TENSORLIKE_CHECK_SHAPE_CONSISTENCY") && lo(e, r, []), r;
}
function lo(e, t, n) {
	if (n ||= [], !Array.isArray(e) && !ra(e)) {
		v(t.length === 0, () => `Element arr[${n.join("][")}] is a primitive, but should be an array/TypedArray of ${t[0]} elements`);
		return;
	}
	v(t.length > 0, () => `Element arr[${n.join("][")}] should be a primitive, but is an array of ${e.length} elements`), v(e.length === t[0], () => `Element arr[${n.join("][")}] should have ${t[0]} elements, but has ${e.length} elements`);
	let r = t.slice(1);
	for (let t = 0; t < e.length; ++t) lo(e[t], r, n.concat(t));
}
function uo(e, t, n, r) {
	if (e !== "string_or_numeric") {
		if (e == null) throw Error("Expected dtype cannot be null.");
		if (e !== "numeric" && e !== t || e === "numeric" && t === "string") throw Error(`Argument '${n}' passed to '${r}' must be ${e} tensor, but got ${t} tensor`);
	}
}
function N(e, t, n, r = "numeric") {
	if (e instanceof wa()) return uo(r, e.dtype, t, n), e;
	let i = be(e);
	if (i !== "string" && [
		"bool",
		"int32",
		"float32"
	].indexOf(r) >= 0 && (i = r), uo(r, i, t, n), e == null || !ra(e) && !Array.isArray(e) && typeof e != "number" && typeof e != "boolean" && typeof e != "string") {
		let r = e == null ? "null" : e.constructor.name;
		throw Error(`Argument '${t}' passed to '${n}' must be a Tensor or TensorLike, but got '${r}'`);
	}
	let a = co(e, i);
	!ra(e) && !Array.isArray(e) && (e = [e]);
	let o = i === "string" ? ia(e, [], !0) : Qi(e, i);
	return j.makeTensor(o, a, i);
}
function fo(e, t, n, r = "numeric") {
	if (!Array.isArray(e)) throw Error(`Argument ${t} passed to ${n} must be a \`Tensor[]\` or \`TensorLike[]\``);
	return e.map((e, i) => N(e, `${t}[${i}]`, n, r));
}
var P = e((() => {
	M(), He(), ka(), Ba(), D(), Pe();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/operation.js
function F(e) {
	let t = Object.keys(e);
	if (t.length !== 1) throw Error(`Please provide an object with a single key (operation name) mapping to a function. Got an object with ${t.length} keys.`);
	let n = t[0], r = e[n];
	n.endsWith("_") && (n = n.substring(0, n.length - 1)), n += po;
	let i = (...e) => {
		j.startScope(n);
		try {
			let t = r(...e);
			return Ne(t) && console.error("Cannot return a Promise inside of tidy."), j.endScope(t), t;
		} catch (e) {
			throw j.endScope(null), e;
		}
	};
	return Object.defineProperty(i, "name", {
		value: n,
		configurable: !0
	}), i;
}
var po, I = e((() => {
	M(), D(), po = "__op";
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/complex.js
function mo(e, t) {
	let n = N(e, "real", "complex"), r = N(t, "imag", "complex");
	y(n.shape, r.shape, `real and imag shapes, ${n.shape} and ${r.shape}, must match in call to tf.complex().`);
	let i = {
		real: n,
		imag: r
	};
	return j.runKernel(xt, i);
}
var ho, go = e((() => {
	M(), T(), P(), D(), I(), ho = /* @__PURE__ */ F({ complex_: mo });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/tensor_ops_util.js
function _o(e, t, n, r) {
	if (r == null) r = be(e);
	else if (r === "complex64") throw Error("Cannot construct a complex64 tensor directly. Please use tf.complex(real, imag).");
	if (Na(e) || Ma(e)) {
		if (r !== "float32" && r !== "int32") throw Error(`Creating tensor from GPU data only supports 'float32'|'int32' dtype, while the dtype is ${r}.`);
		return j.backend.createTensorFromGPUData(e, t || n, r);
	}
	if (!ra(e) && !Array.isArray(e) && typeof e != "number" && typeof e != "boolean" && typeof e != "string") throw Error("values passed to tensor(values) must be a number/boolean/string or an array of numbers/booleans/strings, or a TypedArray");
	if (t != null) {
		Ae(t);
		let e = x(t), r = x(n);
		v(e === r, () => `Based on the provided shape, [${t}], the tensor should have ${e} values but has ${r}`);
		for (let e = 0; e < n.length; ++e) {
			let r = n[e], i = e !== n.length - 1 || r !== x(t.slice(e));
			v(n[e] === t[e] || !i, () => `Error creating a new Tensor. Inferred shape (${n}) does not match the provided shape (${t}). `);
		}
	}
	return !ra(e) && !Array.isArray(e) && (e = [e]), t ||= n, e = r === "string" ? ia(e, [], !0) : Qi(e, r), j.makeTensor(e, t, r);
}
var vo = e((() => {
	M(), Ba(), D();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/tensor.js
function yo(e, t, n) {
	return _o(e, t, co(e, n), n);
}
var bo = e((() => {
	P(), vo();
})), xo, So = e((() => {
	xo = {
		float32: 4,
		float16: 2,
		int32: 4,
		uint16: 2,
		uint8: 1,
		bool: 1,
		complex64: 8
	};
}));
// node_modules/@tensorflow/tfjs-core/dist/io/composite_array_buffer.js
function Co(e, t) {
	let n = 0, r = e.length;
	for (; n <= r;) {
		let i = Math.floor((r - n) / 2) + n, a = t(e[i]);
		if (a === 0) return i;
		a < 0 ? r = i : n = i + 1;
	}
	return -1;
}
var wo, To = e((() => {
	D(), wo = class e {
		static join(t) {
			return new e(t).slice();
		}
		constructor(e) {
			if (this.shards = [], this.previousShardIndex = 0, e == null || (e instanceof Array || (e = [e]), e = e.map((e) => ra(e) ? e.buffer : e), e.length === 0)) return;
			this.bufferUniformSize = e[0].byteLength;
			let t = 0;
			for (let n = 0; n < e.length; n++) {
				let r = e[n];
				n !== e.length - 1 && r.byteLength !== this.bufferUniformSize && (this.bufferUniformSize = void 0);
				let i = t + r.byteLength;
				this.shards.push({
					buffer: r,
					start: t,
					end: i
				}), t = i;
			}
			this.shards.length === 0 && (this.byteLength = 0), this.byteLength = this.shards[this.shards.length - 1].end;
		}
		slice(e = 0, t = this.byteLength) {
			if (this.shards.length === 0 || (e = isNaN(Number(e)) ? 0 : e, t = isNaN(Number(t)) ? 0 : t, e = Math.max(0, e), t = Math.min(this.byteLength, t), t <= e)) return /* @__PURE__ */ new ArrayBuffer(0);
			let n = this.findShardForByte(e);
			if (n === -1) throw Error(`Could not find start shard for byte ${e}`);
			let r = t - e, i = new ArrayBuffer(r), a = new Uint8Array(i), o = 0;
			for (let r = n; r < this.shards.length; r++) {
				let n = this.shards[r], i = e + o - n.start, s = o, c = Math.min(t, n.end) - n.start, l = new Uint8Array(n.buffer, i, c - i);
				if (a.set(l, s), o += l.length, t < n.end) break;
			}
			return i;
		}
		findShardForByte(e) {
			if (this.shards.length === 0 || e < 0 || e >= this.byteLength) return -1;
			if (this.bufferUniformSize != null) return this.previousShardIndex = Math.floor(e / this.bufferUniformSize), this.previousShardIndex;
			function t(t) {
				return e < t.start ? -1 : +(e >= t.end);
			}
			if (t(this.shards[this.previousShardIndex]) === 0) return this.previousShardIndex;
			let n = Co(this.shards, t);
			return n === -1 ? -1 : (this.previousShardIndex = n, this.previousShardIndex);
		}
	};
}));
// node_modules/@tensorflow/tfjs-core/dist/globals.js
function Eo() {
	w().set("PROD", !0);
}
function Do() {
	w().set("DEBUG", !0);
}
function Oo() {
	w().set("DEPRECATION_WARNINGS_ENABLED", !1), console.warn("TensorFlow.js deprecation warnings have been disabled.");
}
function ko(e) {
	w().getBool("DEPRECATION_WARNINGS_ENABLED") && console.warn(e + " You can disable deprecation warnings with tf.disableDeprecationWarnings().");
}
function Ao() {
	j.disposeVariables();
}
function jo() {
	return j;
}
function Mo() {
	return j.memory();
}
function No(e) {
	return j.profile(e);
}
function L(e, t) {
	return j.tidy(e, t);
}
function Po(e) {
	Wa(e).forEach((e) => e.dispose());
}
function Fo(e) {
	return j.keep(e);
}
function Io(e) {
	return j.time(e);
}
function Lo(e) {
	return j.setBackend(e);
}
function Ro() {
	return j.ready();
}
function zo() {
	return j.backendName;
}
function Bo(e) {
	j.removeBackend(e);
}
function Vo(e) {
	return j.findBackend(e);
}
function Ho(e) {
	return j.findBackendFactory(e);
}
function Uo(e, t, n = 1) {
	return j.registerBackend(e, t, n);
}
function Wo() {
	return j.backend;
}
function Go(e, t) {
	w().setPlatform(e, t);
}
var Ko = e((() => {
	M(), He(), ka(), A();
}));
// node_modules/@tensorflow/tfjs-core/dist/io/io_utils.js
async function qo(e, t) {
	let n = [], r = [], i = Array.isArray(e) ? e.map((e) => e.name) : Object.keys(e);
	for (let a = 0; a < i.length; ++a) {
		let o = i[a], s = Array.isArray(e) ? e[a].tensor : e[o];
		if (s.dtype !== "float32" && s.dtype !== "int32" && s.dtype !== "bool" && s.dtype !== "string" && s.dtype !== "complex64") throw Error(`Unsupported dtype in weight '${o}': ${s.dtype}`);
		let c = {
			name: o,
			shape: s.shape,
			dtype: s.dtype
		};
		if (s.dtype === "string") {
			let e = new Promise(async (e) => {
				let t = await s.bytes(), n = t.reduce((e, t) => e + t.length, 0) + hs * t.length, r = new Uint8Array(n), i = 0;
				for (let e = 0; e < t.length; e++) {
					let n = t[e], a = new Uint8Array(new Uint32Array([n.length]).buffer);
					r.set(a, i), i += hs, r.set(n, i), i += n.length;
				}
				e(r);
			});
			r.push(e);
		} else r.push(s.data());
		t != null && (c.group = t), n.push(c);
	}
	return {
		data: es(await Promise.all(r)),
		specs: n
	};
}
function Jo(e, t) {
	let n = new wo(e), r = {}, i = 0;
	for (let e of t) {
		let t = Yo(e, (e, t) => n.slice(i + e, i + t));
		r[e.name] = Zo(e, n.slice(i, i + t)), i += t;
	}
	return r;
}
function Yo(e, t) {
	let n = x(e.shape), r;
	if ("quantization" in e) {
		let t = e.quantization;
		r = xo[t.dtype];
	} else if (e.dtype === "string") {
		let e = 0;
		for (let r = 0; r < n; r++) e += hs + new Uint32Array(t(e, e + hs))[0];
		return e;
	} else r = xo[e.dtype];
	return n * r;
}
async function Xo(e, t) {
	let n = x(e.shape), r;
	if ("quantization" in e) {
		let t = e.quantization;
		r = xo[t.dtype];
	} else if (e.dtype === "string") {
		let e = 0;
		for (let r = 0; r < n; r++) e += hs + new Uint32Array(await t(e, e + hs))[0];
		return e;
	} else r = xo[e.dtype];
	return n * r;
}
function Zo(e, t) {
	let n = e.name, r = e.dtype, i = e.shape, a = x(i), o, s = 0;
	if ("quantization" in e) {
		let i = e.quantization;
		if (i.dtype === "uint8" || i.dtype === "uint16") {
			if (!("min" in i && "scale" in i)) throw Error(`Weight ${e.name} with quantization ${i.dtype} doesn't have corresponding metadata min and scale.`);
		} else if (i.dtype === "float16") {
			if (r !== "float32") throw Error(`Weight ${e.name} is quantized with ${i.dtype} which only supports weights of type float32 not ${r}.`);
		} else throw Error(`Weight ${e.name} has unknown quantization dtype ${i.dtype}. Supported quantization dtypes are: 'uint8', 'uint16', and 'float16'.`);
		let c = xo[i.dtype], l = i.dtype === "uint8" ? new Uint8Array(t) : new Uint16Array(t);
		if (r === "float32") {
			if (i.dtype === "uint8" || i.dtype === "uint16") {
				o = new Float32Array(l.length);
				for (let e = 0; e < l.length; e++) {
					let t = l[e];
					o[e] = t * i.scale + i.min;
				}
			} else if (i.dtype === "float16") o = ms()(l);
			else throw Error(`Unsupported quantization type ${i.dtype} for weight type float32.`);
		} else if (r === "int32") {
			if (i.dtype !== "uint8" && i.dtype !== "uint16") throw Error(`Unsupported quantization type ${i.dtype} for weight type int32.`);
			o = new Int32Array(l.length);
			for (let e = 0; e < l.length; e++) {
				let t = l[e];
				o[e] = Math.round(t * i.scale + i.min);
			}
		} else throw Error(`Unsupported dtype in weight '${n}': ${r}`);
		s += a * c;
	} else if (r === "string") {
		let n = x(e.shape);
		o = [];
		for (let e = 0; e < n; e++) {
			let e = new Uint32Array(t.slice(s, s + hs))[0];
			s += hs;
			let n = new Uint8Array(t.slice(s, s + e));
			o.push(n), s += e;
		}
	} else {
		let e = xo[r];
		if (r === "float32") o = new Float32Array(t);
		else if (r === "int32") o = new Int32Array(t);
		else if (r === "bool") o = new Uint8Array(t);
		else if (r === "complex64") {
			o = new Float32Array(t);
			let e = new Float32Array(o.length / 2), n = new Float32Array(o.length / 2);
			for (let t = 0; t < e.length; t++) e[t] = o[t * 2], n[t] = o[t * 2 + 1];
			let r = yo(e, i, "float32"), a = yo(n, i, "float32"), s = ho(r, a);
			return r.dispose(), a.dispose(), s;
		} else throw Error(`Unsupported dtype in weight '${n}': ${r}`);
		s += a * e;
	}
	return yo(o, i, r);
}
async function Qo(e, t, n) {
	let r = new Uint8Array(t);
	for (; r.byteLength < n;) {
		let { done: t, value: i } = await e.read();
		if (t && i == null) {
			let e = n - r.byteLength;
			throw Error(`Reader is done but ${e} bytes are still expected`);
		}
		let a = new Uint8Array(r.length + i.byteLength);
		a.set(r, 0), a.set(new Uint8Array(i), r.length), r = a;
	}
	return r.buffer;
}
async function $o(e, t) {
	let n = {}, r = e.getReader(), i = /* @__PURE__ */ new ArrayBuffer(0);
	for (let e of t) {
		let t = await Xo(e, async (e, t) => (i = await Qo(r, i, t), i.slice(e, t)));
		i = await Qo(r, i, t);
		let a = i.slice(0, t);
		i = i.slice(t);
		let o = Zo(e, a);
		if (n[e.name] = o, zo() === "webgpu") {
			let e = Wo();
			"uploadToGPU" in e && x(o.shape) >= w().get("WEBGPU_CPU_HANDOFF_SIZE_THRESHOLD") && e.uploadToGPU(o.dataId);
		}
	}
	return n;
}
function es(e) {
	if (e === null) throw Error(`Invalid input value: ${JSON.stringify(e)}`);
	let t = 0, n = [];
	e.forEach((e) => {
		if (t += e.byteLength, n.push(e.byteLength === e.buffer.byteLength ? e : new e.constructor(e)), !(e instanceof Float32Array || e instanceof Int32Array || e instanceof Uint8Array)) throw Error(`Unsupported TypedArray subtype: ${e.constructor.name}`);
	});
	let r = new Uint8Array(t), i = 0;
	return n.forEach((e) => {
		r.set(new Uint8Array(e.buffer), i), i += e.byteLength;
	}), r.buffer;
}
function ts(e) {
	return gs ? Buffer.byteLength(e, "utf8") : new Blob([e]).size;
}
function ns(e) {
	if (gs) return Buffer.from(e).toString("base64");
	let t = new Uint8Array(e), n = "";
	for (let e = 0, r = t.length; e < r; e++) n += String.fromCharCode(t[e]);
	return btoa(n);
}
function rs(e) {
	if (gs) {
		let t = Buffer.from(e, "base64");
		return t.buffer.slice(t.byteOffset, t.byteOffset + t.byteLength);
	}
	let t = atob(e), n = new Uint8Array(t.length);
	for (let e = 0; e < t.length; ++e) n.set([t.charCodeAt(e)], e);
	return n.buffer;
}
function is(e) {
	return wo.join(e);
}
function as(e) {
	for (e = e.trim(); e.endsWith("/");) e = e.slice(0, e.length - 1);
	let t = e.split("/");
	return t[t.length - 1];
}
function os(e, t) {
	let n = {
		modelTopology: e.modelTopology,
		format: e.format,
		generatedBy: e.generatedBy,
		convertedBy: e.convertedBy,
		weightsManifest: t
	};
	return e.signature != null && (n.signature = e.signature), e.userDefinedMetadata != null && (n.userDefinedMetadata = e.userDefinedMetadata), e.modelInitializer != null && (n.modelInitializer = e.modelInitializer), e.initializerSignature != null && (n.initializerSignature = e.initializerSignature), e.trainingConfig != null && (n.trainingConfig = e.trainingConfig), n;
}
function ss(e, t, n) {
	let r = {
		modelTopology: e.modelTopology,
		format: e.format,
		generatedBy: e.generatedBy,
		convertedBy: e.convertedBy
	};
	if (e.trainingConfig != null && (r.trainingConfig = e.trainingConfig), e.weightsManifest != null) {
		if (!t) throw Error("modelJSON has weightsManifest but weightSpecs is null");
		if (!n) throw Error("modelJSON has weightsManifest but weightData is null");
		r.weightSpecs = t, r.weightData = n;
	}
	return e.signature != null && (r.signature = e.signature), e.userDefinedMetadata != null && (r.userDefinedMetadata = e.userDefinedMetadata), e.modelInitializer != null && (r.modelInitializer = e.modelInitializer), e.initializerSignature != null && (r.initializerSignature = e.initializerSignature), r;
}
async function cs(e, t) {
	let n, r;
	return e.weightsManifest != null && ([n, r] = await t(e.weightsManifest)), ss(e, n, r);
}
function ls(e) {
	if (e.modelTopology instanceof ArrayBuffer) throw Error("Expected JSON model topology, received ArrayBuffer.");
	return {
		dateSaved: /* @__PURE__ */ new Date(),
		modelTopologyType: "JSON",
		modelTopologyBytes: e.modelTopology == null ? 0 : ts(JSON.stringify(e.modelTopology)),
		weightSpecsBytes: e.weightSpecs == null ? 0 : ts(JSON.stringify(e.weightSpecs)),
		weightDataBytes: e.weightData == null ? 0 : new wo(e.weightData).byteLength
	};
}
function us(e) {
	let t = [];
	for (let n of e) t.push(...n.weights);
	return t;
}
function ds() {
	let e = (e) => {
		let t = e << 13, n = 0;
		for (; !(t & 8388608);) n -= 8388608, t <<= 1;
		return t &= -8388609, n += 947912704, t | n;
	}, t = /* @__PURE__ */ new Uint32Array(2048);
	t[0] = 0;
	for (let n = 1; n < 1024; n++) t[n] = e(n);
	for (let e = 1024; e < 2048; e++) t[e] = 939524096 + (e - 1024 << 13);
	return t;
}
function fs() {
	let e = /* @__PURE__ */ new Uint32Array(64);
	e[0] = 0, e[31] = 1199570944, e[32] = 2147483648, e[63] = 3347054592;
	for (let t = 1; t < 31; t++) e[t] = t << 23;
	for (let t = 33; t < 63; t++) e[t] = 2147483648 + (t - 32 << 23);
	return e;
}
function ps() {
	let e = /* @__PURE__ */ new Uint32Array(64);
	for (let t = 0; t < 64; t++) e[t] = 1024;
	return e[0] = e[32] = 0, e;
}
function ms() {
	let e = ds(), t = fs(), n = ps();
	return (r) => {
		let i = /* @__PURE__ */ new ArrayBuffer(4 * r.length), a = new Uint32Array(i);
		for (let i = 0; i < r.length; i++) {
			let o = r[i], s = e[n[o >> 10] + (o & 1023)] + t[o >> 10];
			a[i] = s;
		}
		return new Float32Array(i);
	};
}
var hs, gs, _s = e((() => {
	go(), bo(), D(), So(), To(), Ko(), He(), hs = 4, gs = typeof Buffer < "u" && (typeof Blob > "u" || typeof atob > "u" || typeof btoa > "u");
})), vs, ys, bs, xs, Ss, Cs = e((() => {
	vs = class e {
		constructor() {
			this.saveRouters = [], this.loadRouters = [];
		}
		static getInstance() {
			return e.instance ??= new e(), e.instance;
		}
		static registerSaveRouter(t) {
			e.getInstance().saveRouters.push(t);
		}
		static registerLoadRouter(t) {
			e.getInstance().loadRouters.push(t);
		}
		static getSaveHandlers(t) {
			return e.getHandlers(t, "save");
		}
		static getLoadHandlers(t, n) {
			return e.getHandlers(t, "load", n);
		}
		static getHandlers(t, n, r) {
			let i = [];
			return (n === "load" ? e.getInstance().loadRouters : e.getInstance().saveRouters).forEach((e) => {
				let n = e(t, r);
				n !== null && i.push(n);
			}), i;
		}
	}, ys = (e) => vs.registerSaveRouter(e), bs = (e) => vs.registerLoadRouter(e), xs = (e) => vs.getSaveHandlers(e), Ss = (e, t) => vs.getLoadHandlers(e, t);
}));
// node_modules/@tensorflow/tfjs-core/dist/io/indexed_db.js
function ws() {
	if (!w().getBool("IS_BROWSER")) throw Error("Failed to obtain IndexedDB factory because the current environmentis not a web browser.");
	let e = typeof window > "u" ? self : window, t = e.indexedDB || e.mozIndexedDB || e.webkitIndexedDB || e.msIndexedDB || e.shimIndexedDB;
	if (t == null) throw Error("The current browser does not appear to support IndexedDB.");
	return t;
}
function Ts(e) {
	let t = e.result;
	t.createObjectStore(As, { keyPath: "modelPath" }), t.createObjectStore(js, { keyPath: "modelPath" });
}
function Es(e) {
	return new Ms(e);
}
function Ds(e) {
	return e.startsWith(Ms.URL_SCHEME) ? e.slice(Ms.URL_SCHEME.length) : e;
}
var Os, ks, As, js, Ms, Ns, Ps, Fs = e((() => {
	so(), He(), _s(), Cs(), To(), Os = "tensorflowjs", ks = 1, As = "models_store", js = "model_info_store", Ms = class {
		constructor(e) {
			if (this.indexedDB = ws(), e == null || !e) throw Error("For IndexedDB, modelPath must not be null, undefined or empty.");
			this.modelPath = e;
		}
		async save(e) {
			if (e.modelTopology instanceof ArrayBuffer) throw Error("BrowserLocalStorage.save() does not support saving model topology in binary formats yet.");
			return this.databaseAction(this.modelPath, e);
		}
		async load() {
			return this.databaseAction(this.modelPath);
		}
		databaseAction(e, t) {
			return new Promise((e, n) => {
				let r = this.indexedDB.open(Os, ks);
				r.onupgradeneeded = () => Ts(r), r.onsuccess = () => {
					let i = r.result;
					if (t == null) {
						let t = i.transaction(As, "readonly"), r = t.objectStore(As).get(this.modelPath);
						r.onsuccess = () => {
							if (r.result == null) return i.close(), n(/* @__PURE__ */ Error(`Cannot find model with path '${this.modelPath}' in IndexedDB.`));
							e(r.result.modelArtifacts);
						}, r.onerror = (e) => (i.close(), n(r.error)), t.oncomplete = () => i.close();
					} else {
						t.weightData = wo.join(t.weightData);
						let r = ls(t), a = i.transaction(js, "readwrite"), o = a.objectStore(js), s;
						try {
							s = o.put({
								modelPath: this.modelPath,
								modelArtifactsInfo: r
							});
						} catch (e) {
							return n(e);
						}
						let c;
						s.onsuccess = () => {
							c = i.transaction(As, "readwrite");
							let s = c.objectStore(As), l;
							try {
								l = s.put({
									modelPath: this.modelPath,
									modelArtifacts: t,
									modelArtifactsInfo: r
								});
							} catch (e) {
								return n(e);
							}
							l.onsuccess = () => e({ modelArtifactsInfo: r }), l.onerror = (e) => {
								o = a.objectStore(js);
								let t = o.delete(this.modelPath);
								t.onsuccess = () => (i.close(), n(l.error)), t.onerror = (e) => (i.close(), n(l.error));
							};
						}, s.onerror = (e) => (i.close(), n(s.error)), a.oncomplete = () => {
							c == null ? i.close() : c.oncomplete = () => i.close();
						};
					}
				}, r.onerror = (e) => n(r.error);
			});
		}
	}, Ms.URL_SCHEME = "indexeddb://", Ns = (e) => w().getBool("IS_BROWSER") && !Array.isArray(e) && e.startsWith(Ms.URL_SCHEME) ? Es(e.slice(Ms.URL_SCHEME.length)) : null, vs.registerSaveRouter(Ns), vs.registerLoadRouter(Ns), Ps = class {
		constructor() {
			this.indexedDB = ws();
		}
		async listModels() {
			return new Promise((e, t) => {
				let n = this.indexedDB.open(Os, ks);
				n.onupgradeneeded = () => Ts(n), n.onsuccess = () => {
					let r = n.result, i = r.transaction(js, "readonly"), a = i.objectStore(js).getAll();
					a.onsuccess = () => {
						let t = {};
						for (let e of a.result) t[e.modelPath] = e.modelArtifactsInfo;
						e(t);
					}, a.onerror = (e) => (r.close(), t(a.error)), i.oncomplete = () => r.close();
				}, n.onerror = (e) => t(n.error);
			});
		}
		async removeModel(e) {
			return e = Ds(e), new Promise((t, n) => {
				let r = this.indexedDB.open(Os, ks);
				r.onupgradeneeded = () => Ts(r), r.onsuccess = () => {
					let i = r.result, a = i.transaction(js, "readwrite"), o = a.objectStore(js), s = o.get(e), c;
					s.onsuccess = () => {
						if (s.result == null) return i.close(), n(/* @__PURE__ */ Error(`Cannot find model with path '${e}' in IndexedDB.`));
						{
							let r = o.delete(e), a = () => {
								c = i.transaction(As, "readwrite");
								let r = c.objectStore(As).delete(e);
								r.onsuccess = () => t(s.result.modelArtifactsInfo), r.onerror = (e) => n(s.error);
							};
							r.onsuccess = a, r.onerror = (e) => (a(), i.close(), n(s.error));
						}
					}, s.onerror = (e) => (i.close(), n(s.error)), a.oncomplete = () => {
						c == null ? i.close() : c.oncomplete = () => i.close();
					};
				}, r.onerror = (e) => n(r.error);
			});
		}
	};
}));
// node_modules/@tensorflow/tfjs-core/dist/io/local_storage.js
function Is(e) {
	return {
		info: [
			Hs,
			e,
			Us
		].join(Vs),
		topology: [
			Hs,
			e,
			Ws
		].join(Vs),
		weightSpecs: [
			Hs,
			e,
			Gs
		].join(Vs),
		weightData: [
			Hs,
			e,
			Ks
		].join(Vs),
		modelMetadata: [
			Hs,
			e,
			qs
		].join(Vs)
	};
}
function Ls(e) {
	for (let t of Object.values(e)) window.localStorage.removeItem(t);
}
function Rs(e) {
	let t = e.split(Vs);
	if (t.length < 3) throw Error(`Invalid key format: ${e}`);
	return t.slice(1, t.length - 1).join(Vs);
}
function zs(e) {
	return e.startsWith(Js.URL_SCHEME) ? e.slice(Js.URL_SCHEME.length) : e;
}
function Bs(e) {
	return new Js(e);
}
var Vs, Hs, Us, Ws, Gs, Ks, qs, Js, Ys, Xs, Zs = e((() => {
	so(), He(), D(), _s(), To(), Cs(), Vs = "/", Hs = "tensorflowjs_models", Us = "info", Ws = "model_topology", Gs = "weight_specs", Ks = "weight_data", qs = "model_metadata", Js = class {
		constructor(e) {
			if (!w().getBool("IS_BROWSER") || typeof window > "u" || window.localStorage === void 0) throw Error("The current environment does not support local storage.");
			if (this.LS = window.localStorage, e == null || !e) throw Error("For local storage, modelPath must not be null, undefined or empty.");
			this.modelPath = e, this.keys = Is(this.modelPath);
		}
		async save(e) {
			if (e.modelTopology instanceof ArrayBuffer) throw Error("BrowserLocalStorage.save() does not support saving model topology in binary formats yet.");
			{
				let t = JSON.stringify(e.modelTopology), n = JSON.stringify(e.weightSpecs), r = ls(e), i = wo.join(e.weightData);
				try {
					this.LS.setItem(this.keys.info, JSON.stringify(r)), this.LS.setItem(this.keys.topology, t), this.LS.setItem(this.keys.weightSpecs, n), this.LS.setItem(this.keys.weightData, ns(i));
					let a = {
						format: e.format,
						generatedBy: e.generatedBy,
						convertedBy: e.convertedBy,
						signature: e.signature == null ? void 0 : e.signature,
						userDefinedMetadata: e.userDefinedMetadata == null ? void 0 : e.userDefinedMetadata,
						modelInitializer: e.modelInitializer == null ? void 0 : e.modelInitializer,
						initializerSignature: e.initializerSignature == null ? void 0 : e.initializerSignature,
						trainingConfig: e.trainingConfig == null ? void 0 : e.trainingConfig
					};
					return this.LS.setItem(this.keys.modelMetadata, JSON.stringify(a)), { modelArtifactsInfo: r };
				} catch {
					throw Ls(this.keys), Error(`Failed to save model '${this.modelPath}' to local storage: size quota being exceeded is a possible cause of this failure: modelTopologyBytes=${r.modelTopologyBytes}, weightSpecsBytes=${r.weightSpecsBytes}, weightDataBytes=${r.weightDataBytes}.`);
				}
			}
		}
		async load() {
			let e = JSON.parse(this.LS.getItem(this.keys.info));
			if (e == null) throw Error(`In local storage, there is no model with name '${this.modelPath}'`);
			if (e.modelTopologyType !== "JSON") throw Error("BrowserLocalStorage does not support loading non-JSON model topology yet.");
			let t = {}, n = JSON.parse(this.LS.getItem(this.keys.topology));
			if (n == null) throw Error(`In local storage, the topology of model '${this.modelPath}' is missing.`);
			t.modelTopology = n;
			let r = JSON.parse(this.LS.getItem(this.keys.weightSpecs));
			if (r == null) throw Error(`In local storage, the weight specs of model '${this.modelPath}' are missing.`);
			t.weightSpecs = r;
			let i = this.LS.getItem(this.keys.modelMetadata);
			if (i != null) {
				let e = JSON.parse(i);
				t.format = e.format, t.generatedBy = e.generatedBy, t.convertedBy = e.convertedBy, e.signature != null && (t.signature = e.signature), e.userDefinedMetadata != null && (t.userDefinedMetadata = e.userDefinedMetadata), e.modelInitializer != null && (t.modelInitializer = e.modelInitializer), e.initializerSignature != null && (t.initializerSignature = e.initializerSignature), e.trainingConfig != null && (t.trainingConfig = e.trainingConfig);
			}
			let a = this.LS.getItem(this.keys.weightData);
			if (a == null) throw Error(`In local storage, the binary weight values of model '${this.modelPath}' are missing.`);
			return t.weightData = rs(a), t;
		}
	}, Js.URL_SCHEME = "localstorage://", Ys = (e) => w().getBool("IS_BROWSER") && !Array.isArray(e) && e.startsWith(Js.URL_SCHEME) ? Bs(e.slice(Js.URL_SCHEME.length)) : null, vs.registerSaveRouter(Ys), vs.registerLoadRouter(Ys), Xs = class {
		constructor() {
			v(w().getBool("IS_BROWSER"), () => "Current environment is not a web browser"), v(typeof window > "u" || window.localStorage !== void 0, () => "Current browser does not appear to support localStorage"), this.LS = window.localStorage;
		}
		async listModels() {
			let e = {};
			for (let t = 0; t < this.LS.length; ++t) {
				let n = this.LS.key(t);
				if (n.startsWith("tensorflowjs_models/") && n.endsWith("/info")) {
					let t = Rs(n);
					e[t] = JSON.parse(this.LS.getItem(n));
				}
			}
			return e;
		}
		async removeModel(e) {
			e = zs(e);
			let t = Is(e);
			if (this.LS.getItem(t.info) == null) throw Error(`Cannot find model at path '${e}'`);
			let n = JSON.parse(this.LS.getItem(t.info));
			return Ls(t), n;
		}
	};
}));
// node_modules/@tensorflow/tfjs-core/dist/io/model_management.js
function Qs(e) {
	if (e.indexOf(ic) === -1) throw Error(`The url string provided does not contain a scheme. Supported schemes are: ${ac.getSchemes().join(",")}`);
	return {
		scheme: e.split(ic)[0],
		path: e.split(ic)[1]
	};
}
async function $s(e, t, n = !1) {
	v(e !== t, () => `Old path and new path are the same: '${e}'`);
	let r = vs.getLoadHandlers(e);
	v(r.length > 0, () => `Copying failed because no load handler is found for source URL ${e}.`), v(r.length < 2, () => `Copying failed because more than one (${r.length}) load handlers for source URL ${e}.`);
	let i = r[0], a = vs.getSaveHandlers(t);
	v(a.length > 0, () => `Copying failed because no save handler is found for destination URL ${t}.`), v(a.length < 2, () => `Copying failed because more than one (${r.length}) save handlers for destination URL ${t}.`);
	let o = a[0], s = Qs(e).scheme, c = Qs(e).path, l = s === Qs(e).scheme, u = await i.load();
	n && l && await ac.getManager(s).removeModel(c);
	let d = await o.save(u);
	return n && !l && await ac.getManager(s).removeModel(c), d.modelArtifactsInfo;
}
async function ec() {
	let e = ac.getSchemes(), t = {};
	for (let n of e) {
		let e = await ac.getManager(n).listModels();
		for (let r in e) {
			let i = n + ic + r;
			t[i] = e[r];
		}
	}
	return t;
}
async function tc(e) {
	let t = Qs(e);
	return ac.getManager(t.scheme).removeModel(t.path);
}
async function nc(e, t) {
	return $s(e, t, !1);
}
async function rc(e, t) {
	return $s(e, t, !0);
}
var ic, ac, oc = e((() => {
	D(), Cs(), ic = "://", ac = class e {
		constructor() {
			this.managers = {};
		}
		static getInstance() {
			return e.instance ??= new e(), e.instance;
		}
		static registerManager(t, n) {
			v(t != null, () => "scheme must not be undefined or null."), t.endsWith(ic) && (t = t.slice(0, t.indexOf(ic))), v(t.length > 0, () => "scheme must not be an empty string.");
			let r = e.getInstance();
			v(r.managers[t] == null, () => `A model store manager is already registered for scheme '${t}'.`), r.managers[t] = n;
		}
		static getManager(t) {
			let n = e.getInstance().managers[t];
			if (n == null) throw Error(`Cannot find model manager for scheme '${t}'`);
			return n;
		}
		static getSchemes() {
			return Object.keys(e.getInstance().managers);
		}
	};
})), sc, cc = e((() => {
	if (so(), He(), Fs(), Zs(), oc(), ki(), sc = class {
		constructor() {
			this.messageName = "setTimeoutCustom", this.functionRefs = [], this.handledMessageCount = 0, this.hasEventListener = !1;
		}
		fetch(e, t) {
			return fetch(e, t);
		}
		now() {
			return performance.now();
		}
		encode(e, t) {
			if (t !== "utf-8" && t !== "utf8") throw Error(`Browser's encoder only supports utf-8, but got ${t}`);
			return this.textEncoder ??= new TextEncoder(), this.textEncoder.encode(e);
		}
		decode(e, t) {
			return new TextDecoder(t).decode(e);
		}
		setTimeoutCustom(e, t) {
			typeof window > "u" || !w().getBool("USE_SETTIMEOUTCUSTOM") ? setTimeout(e, t) : (this.functionRefs.push(e), setTimeout(() => {
				window.postMessage({
					name: this.messageName,
					index: this.functionRefs.length - 1
				}, "*");
			}, t), this.hasEventListener || (this.hasEventListener = !0, window.addEventListener("message", (e) => {
				if (e.source === window && e.data.name === this.messageName) {
					e.stopPropagation();
					let t = this.functionRefs[e.data.index];
					t(), this.handledMessageCount++, this.handledMessageCount === this.functionRefs.length && (this.functionRefs = [], this.handledMessageCount = 0);
				}
			}, !0)));
		}
		isTypedArray(e) {
			return Oi(e);
		}
	}, w().get("IS_BROWSER")) {
		w().setPlatform("browser", new sc());
		try {
			ac.registerManager(Js.URL_SCHEME, new Xs());
		} catch {}
		try {
			ac.registerManager(Ms.URL_SCHEME, new Ps());
		} catch {}
	}
})), lc = /* @__PURE__ */ r(((e, t) => {
	t.exports = {};
})), uc, dc, fc, pc = e((() => {
	He(), uc = { importFetch: () => lc() }, fc = class {
		constructor() {
			this.util = lc(), this.textEncoder = new this.util.TextEncoder();
		}
		fetch(e, t) {
			return w().global.fetch == null ? (dc ??= uc.importFetch(), dc(e, t)) : w().global.fetch(e, t);
		}
		now() {
			let e = process.hrtime();
			return e[0] * 1e3 + e[1] / 1e6;
		}
		encode(e, t) {
			if (t !== "utf-8" && t !== "utf8") throw Error(`Node built-in encoder only supports utf-8, but got ${t}`);
			return this.textEncoder.encode(e);
		}
		decode(e, t) {
			return e.length === 0 ? "" : new this.util.TextDecoder(t).decode(e);
		}
		isTypedArray(e) {
			return this.util.types.isFloat32Array(e) || this.util.types.isInt32Array(e) || this.util.types.isUint8Array(e) || this.util.types.isUint8ClampedArray(e);
		}
	}, w().get("IS_NODE") && !w().get("IS_BROWSER") && w().setPlatform("node", new fc());
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/buffer.js
function mc(e, t = "float32", n) {
	return t ||= "float32", Ae(e), new Ta(e, t, n);
}
var hc = e((() => {
	ka(), D();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/cast.js
function gc(e, t) {
	let n = N(e, "x", "cast");
	if (!pe(t)) throw Error(`Failed to cast to unknown dtype ${t}`);
	if (t === "string" && n.dtype !== "string" || t !== "string" && n.dtype === "string") throw Error("Only strings can be casted to strings");
	let r = { x: n }, i = { dtype: t };
	return j.runKernel(vt, r, i);
}
var R, _c = e((() => {
	M(), T(), P(), D(), I(), R = /* @__PURE__ */ F({ cast_: gc });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/clone.js
function vc(e) {
	let t = { x: N(e, "x", "clone", "string_or_numeric") };
	return j.runKernel(dn, t);
}
var yc, bc = e((() => {
	M(), T(), P(), I(), yc = /* @__PURE__ */ F({ clone_: vc });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/print.js
function xc(e, t = !1) {
	console.log(e.toString(t));
}
var Sc = e((() => {})), Cc = e((() => {
	M(), so(), cc(), pc(), hc(), _c(), bc(), Sc(), ka(), Ya(), Ca({
		buffer: mc,
		cast: R,
		clone: yc,
		print: xc
	});
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/add.js
function wc(e, t) {
	let n = N(e, "a", "add"), r = N(t, "b", "add");
	[n, r] = k(n, r);
	let i = {
		a: n,
		b: r
	};
	return j.runKernel("Add", i);
}
var z, B = e((() => {
	M(), T(), A(), P(), I(), z = /* @__PURE__ */ F({ add_: wc });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/floorDiv.js
function Tc(e, t) {
	let n = N(e, "a", "floorDiv"), r = N(t, "b", "floorDiv");
	[n, r] = k(n, r);
	let i = {
		a: n,
		b: r
	};
	return j.runKernel(an, i);
}
var Ec, Dc = e((() => {
	M(), T(), A(), P(), I(), Ec = /* @__PURE__ */ F({ floorDiv_: Tc });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/div.js
function Oc(e, t) {
	let n = N(e, "a", "div"), r = N(t, "b", "div");
	if ([n, r] = k(n, r), n.dtype === "int32" && r.dtype === "int32") return Ec(n, r);
	let i = {
		a: n,
		b: r
	};
	return j.runKernel(Gt, i, {});
}
var V, kc = e((() => {
	M(), T(), A(), P(), Dc(), I(), V = /* @__PURE__ */ F({ div_: Oc });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/mul.js
function Ac(e, t) {
	let n = N(e, "a", "mul"), r = N(t, "b", "mul");
	[n, r] = k(n, r);
	let i = {
		a: n,
		b: r
	};
	return j.runKernel(Gn, i);
}
var H, U = e((() => {
	M(), T(), A(), P(), I(), H = /* @__PURE__ */ F({ mul_: Ac });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/abs.js
function jc(e) {
	let t = N(e, "x", "abs");
	if (t.dtype === "complex64") {
		let e = { x: t };
		return j.runKernel(St, e);
	}
	{
		let e = { x: t };
		return j.runKernel("Abs", e);
	}
}
var Mc, Nc = e((() => {
	M(), T(), P(), I(), Mc = /* @__PURE__ */ F({ abs_: jc });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/acos.js
function Pc(e) {
	let t = { x: N(e, "x", "acos") };
	return j.runKernel(Ye, t);
}
var Fc, Ic = e((() => {
	M(), T(), P(), I(), Fc = /* @__PURE__ */ F({ acos_: Pc });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/acosh.js
function Lc(e) {
	let t = { x: N(e, "x", "acosh") };
	return j.runKernel(Xe, t);
}
var Rc, zc = e((() => {
	M(), T(), P(), I(), Rc = /* @__PURE__ */ F({ acosh_: Lc });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/add_n.js
function Bc(e) {
	v(Array.isArray(e), () => "The argument passed to tf.addN() must be a list of tensors"), v(e.length >= 1, () => `Must pass at least one tensor to tf.addN(), but got ${e.length}`);
	let t = e.map((e, t) => N(e, `tensors${t}`, "addN")), n = t[0];
	t.forEach((e) => {
		if (e.dtype !== n.dtype) throw Error("All tensors passed to tf.addN() must have the same dtype");
	}), t.forEach((e) => {
		if (!S(e.shape, n.shape)) throw Error("All tensors passed to tf.addN() must have the same shape");
	});
	let r = t;
	return j.runKernel(Qe, r);
}
var Vc, Hc = e((() => {
	M(), T(), P(), D(), I(), Vc = /* @__PURE__ */ F({ addN_: Bc });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/all.js
function Uc(e, t = null, n = !1) {
	let r = { x: N(e, "x", "all", "bool") }, i = {
		axis: t,
		keepDims: n
	};
	return j.runKernel("All", r, i);
}
var Wc, Gc = e((() => {
	M(), T(), P(), I(), Wc = /* @__PURE__ */ F({ all_: Uc });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/any.js
function Kc(e, t = null, n = !1) {
	let r = { x: N(e, "x", "any", "bool") }, i = {
		axis: t,
		keepDims: n
	};
	return j.runKernel("Any", r, i);
}
var qc, Jc = e((() => {
	M(), T(), P(), I(), qc = /* @__PURE__ */ F({ any_: Kc });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/arg_max.js
function Yc(e, t = 0) {
	let n = { x: N(e, "x", "argMax") }, r = { axis: t };
	return j.runKernel(tt, n, r);
}
var Xc, Zc = e((() => {
	M(), T(), P(), I(), Xc = /* @__PURE__ */ F({ argMax_: Yc });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/arg_min.js
function Qc(e, t = 0) {
	let n = { x: N(e, "x", "argMin") }, r = { axis: t };
	return j.runKernel(nt, n, r);
}
var $c, el = e((() => {
	M(), T(), P(), I(), $c = /* @__PURE__ */ F({ argMin_: Qc });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/asin.js
function tl(e) {
	let t = { x: N(e, "x", "asin") };
	return j.runKernel(rt, t);
}
var nl, rl = e((() => {
	M(), T(), P(), I(), nl = /* @__PURE__ */ F({ asin_: tl });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/asinh.js
function il(e) {
	let t = { x: N(e, "x", "asinh") };
	return j.runKernel(it, t);
}
var al, ol = e((() => {
	M(), T(), P(), I(), al = /* @__PURE__ */ F({ asinh_: il });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/atan.js
function sl(e) {
	let t = { x: N(e, "x", "atan") };
	return j.runKernel(at, t);
}
var cl, ll = e((() => {
	M(), T(), P(), I(), cl = /* @__PURE__ */ F({ atan_: sl });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/atan2.js
function ul(e, t) {
	let n = N(e, "a", "atan2"), r = N(t, "b", "atan2");
	[n, r] = k(n, r);
	let i = {
		a: n,
		b: r
	};
	return j.runKernel(st, i);
}
var dl, fl = e((() => {
	M(), T(), A(), P(), I(), dl = /* @__PURE__ */ F({ atan2_: ul });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/atanh.js
function pl(e) {
	let t = { x: N(e, "x", "atanh") };
	return j.runKernel(ot, t);
}
var ml, hl = e((() => {
	M(), T(), P(), I(), ml = /* @__PURE__ */ F({ atanh_: pl });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/conv_util.js
function gl(e, t, n, r, i = "NHWC", a) {
	let o = e[3];
	return yl(e, [...t, o], n, a, r, null, null, Nl(i));
}
function _l(e, t, n, r, i, a, o = "channelsLast") {
	let [s, c] = wl(t), l;
	if (o === "channelsLast") l = [
		s,
		c,
		e[3],
		e[3]
	];
	else if (o === "channelsFirst") l = [
		s,
		c,
		e[1],
		e[1]
	];
	else throw Error(`Unknown dataFormat ${o}`);
	return yl(e, l, n, r, i, a, !1, o);
}
function vl(e, t, n, r, i, a, o = "NDHWC") {
	let [s, c, l] = Tl(t), u, d;
	if (o === "NDHWC") d = "channelsLast", u = [
		s,
		c,
		l,
		e[4],
		e[4]
	];
	else if (o === "NCDHW") d = "channelsFirst", u = [
		s,
		c,
		l,
		e[1],
		e[1]
	];
	else throw Error(`Unknown dataFormat ${o}`);
	return bl(e, u, n, r, i, !1, d, a);
}
function yl(e, t, n, r, i, a, o = !1, s = "channelsLast") {
	let [c, l, u, d] = [
		-1,
		-1,
		-1,
		-1
	];
	if (s === "channelsLast") [c, l, u, d] = e;
	else if (s === "channelsFirst") [c, d, l, u] = e;
	else throw Error(`Unknown dataFormat ${s}`);
	let [f, p, , m] = t, [h, g] = wl(n), [_, v] = wl(r), y = El(f, _), b = El(p, v), { padInfo: x, outHeight: ee, outWidth: te } = Dl(i, l, u, h, g, y, b, a, s), S = o ? m * d : m, ne;
	return s === "channelsFirst" ? ne = [
		c,
		S,
		ee,
		te
	] : s === "channelsLast" && (ne = [
		c,
		ee,
		te,
		S
	]), {
		batchSize: c,
		dataFormat: s,
		inHeight: l,
		inWidth: u,
		inChannels: d,
		outHeight: ee,
		outWidth: te,
		outChannels: S,
		padInfo: x,
		strideHeight: h,
		strideWidth: g,
		filterHeight: f,
		filterWidth: p,
		effectiveFilterHeight: y,
		effectiveFilterWidth: b,
		dilationHeight: _,
		dilationWidth: v,
		inShape: e,
		outShape: ne,
		filterShape: t
	};
}
function bl(e, t, n, r, i, a = !1, o = "channelsLast", s) {
	let [c, l, u, d, f] = [
		-1,
		-1,
		-1,
		-1,
		-1
	];
	if (o === "channelsLast") [c, l, u, d, f] = e;
	else if (o === "channelsFirst") [c, f, l, u, d] = e;
	else throw Error(`Unknown dataFormat ${o}`);
	let [p, m, h, , g] = t, [_, v, y] = Tl(n), [b, x, ee] = Tl(r), te = El(p, b), S = El(m, x), ne = El(h, ee), { padInfo: re, outDepth: C, outHeight: ie, outWidth: ae } = Ol(i, l, u, d, _, v, y, te, S, ne, s), oe = a ? g * f : g, se;
	return o === "channelsFirst" ? se = [
		c,
		oe,
		C,
		ie,
		ae
	] : o === "channelsLast" && (se = [
		c,
		C,
		ie,
		ae,
		oe
	]), {
		batchSize: c,
		dataFormat: o,
		inDepth: l,
		inHeight: u,
		inWidth: d,
		inChannels: f,
		outDepth: C,
		outHeight: ie,
		outWidth: ae,
		outChannels: oe,
		padInfo: re,
		strideDepth: _,
		strideHeight: v,
		strideWidth: y,
		filterDepth: p,
		filterHeight: m,
		filterWidth: h,
		effectiveFilterDepth: te,
		effectiveFilterHeight: S,
		effectiveFilterWidth: ne,
		dilationDepth: b,
		dilationHeight: x,
		dilationWidth: ee,
		inShape: e,
		outShape: se,
		filterShape: t
	};
}
function xl(e, t, n, r, i) {
	r ??= Cl(e, t, n);
	let a = e[0], o = e[1];
	return [kl((a - t + 2 * r) / n + 1, i), kl((o - t + 2 * r) / n + 1, i)];
}
function Sl(e, t, n, r, i, a) {
	i ??= Cl(e, t[0], r[0]);
	let o = [
		0,
		0,
		0,
		n
	];
	for (let n = 0; n < 3; n++) e[n] + 2 * i >= t[n] && (o[n] = kl((e[n] - t[n] + 2 * i) / r[n] + 1, a));
	return o;
}
function Cl(e, t, n, r = 1) {
	let i = El(t, r);
	return Math.floor((e[0] * (n - 1) - n + i) / 2);
}
function wl(e) {
	return typeof e == "number" ? [
		e,
		e,
		e
	] : e.length === 2 ? [
		e[0],
		e[1],
		1
	] : e;
}
function Tl(e) {
	return typeof e == "number" ? [
		e,
		e,
		e
	] : e;
}
function El(e, t) {
	return t <= 1 ? e : e + (e - 1) * (t - 1);
}
function Dl(e, t, n, r, i, a, o, s, c) {
	let l, u, d;
	if (typeof e == "number") {
		l = {
			top: e,
			bottom: e,
			left: e,
			right: e,
			type: e === 0 ? "VALID" : "NUMBER"
		};
		let i = xl([t, n], a, r, e, s);
		u = i[0], d = i[1];
	} else if (e === "same") {
		u = Math.ceil(t / r), d = Math.ceil(n / i);
		let e = Math.max(0, (u - 1) * r + a - t), s = Math.max(0, (d - 1) * i + o - n), c = Math.floor(e / 2), f = e - c, p = Math.floor(s / 2);
		l = {
			top: c,
			bottom: f,
			left: p,
			right: s - p,
			type: "SAME"
		};
	} else if (e === "valid") l = {
		top: 0,
		bottom: 0,
		left: 0,
		right: 0,
		type: "VALID"
	}, u = Math.ceil((t - a + 1) / r), d = Math.ceil((n - o + 1) / i);
	else if (typeof e == "object") {
		let f = c === "channelsLast" ? e[1][0] : e[2][0], p = c === "channelsLast" ? e[1][1] : e[2][1], m = c === "channelsLast" ? e[2][0] : e[3][0], h = c === "channelsLast" ? e[2][1] : e[3][1];
		l = {
			top: f,
			bottom: p,
			left: m,
			right: h,
			type: f === 0 && p === 0 && m === 0 && h === 0 ? "VALID" : "EXPLICIT"
		}, u = kl((t - a + f + p) / r + 1, s), d = kl((n - o + m + h) / i + 1, s);
	} else throw Error(`Unknown padding parameter: ${e}`);
	return {
		padInfo: l,
		outHeight: u,
		outWidth: d
	};
}
function Ol(e, t, n, r, i, a, o, s, c, l, u) {
	let d, f, p, m;
	if (e === "valid" && (e = 0), typeof e == "number") {
		d = {
			top: e,
			bottom: e,
			left: e,
			right: e,
			front: e,
			back: e,
			type: e === 0 ? "VALID" : "NUMBER"
		};
		let h = Sl([
			t,
			n,
			r,
			1
		], [
			s,
			c,
			l
		], 1, [
			i,
			a,
			o
		], e, u);
		f = h[0], p = h[1], m = h[2];
	} else if (e === "same") {
		f = Math.ceil(t / i), p = Math.ceil(n / a), m = Math.ceil(r / o);
		let e = (f - 1) * i + s - t, u = (p - 1) * a + c - n, h = (m - 1) * o + l - r, g = Math.floor(e / 2), _ = e - g, v = Math.floor(u / 2), y = u - v, b = Math.floor(h / 2);
		d = {
			top: v,
			bottom: y,
			left: b,
			right: h - b,
			front: g,
			back: _,
			type: "SAME"
		};
	} else throw Error(`Unknown padding parameter: ${e}`);
	return {
		padInfo: d,
		outDepth: f,
		outHeight: p,
		outWidth: m
	};
}
function kl(e, t) {
	if (!t) return Math.trunc(e);
	switch (t) {
		case "round": return Math.round(e);
		case "ceil": return Math.ceil(e);
		case "floor": return Math.floor(e);
		default: throw Error(`Unknown roundingMode ${t}`);
	}
}
function Al(e) {
	let [t, n, r] = wl(e);
	return t === 1 && n === 1 && r === 1;
}
function jl(e, t) {
	return Al(e) || Al(t);
}
function Ml(e) {
	return wl(e).every((e) => e > 0);
}
function Nl(e) {
	if (e === "NHWC") return "channelsLast";
	if (e === "NCHW") return "channelsFirst";
	throw Error(`Unknown dataFormat ${e}`);
}
function Pl(e, t, n) {
	if (n != null) {
		if (typeof t == "string") throw Error(`Error in ${e}: pad must be an integer when using dimRoundingMode ${n} but got pad ${t}.`);
		if (typeof t == "number") v(ne(t), () => `Error in ${e}: pad must be an integer when using dimRoundingMode ${n} but got pad ${t}.`);
		else if (typeof t == "object") t.forEach((t) => {
			t.forEach((t) => {
				v(ne(t), () => `Error in ${e}: pad must be an integer when using dimRoundingMode ${n} but got pad ${t}.`);
			});
		});
		else throw Error(`Error in ${e}: Unknown padding parameter: ${t}`);
	}
}
var Fl = e((() => {
	D();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/reshape.js
function Il(e, t) {
	let n = { x: N(e, "x", "reshape", "string_or_numeric") }, r = { shape: t };
	return j.runKernel(fr, n, r);
}
var W, G = e((() => {
	M(), T(), P(), I(), W = /* @__PURE__ */ F({ reshape_: Il });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/avg_pool.js
function Ll(e, t, n, r, i) {
	let a = N(e, "x", "avgPool", "float32");
	v(jl(n, 1), () => `Error in avgPool: Either strides or dilations must be 1. Got strides ${n} and dilations '1'`);
	let o = a, s = !1;
	a.rank === 3 && (s = !0, o = W(a, [
		1,
		a.shape[0],
		a.shape[1],
		a.shape[2]
	])), v(o.rank === 4, () => `Error in avgPool: x must be rank 4 but got rank ${o.rank}.`), Pl("avgPool", r, i);
	let c = { x: o }, l = {
		filterSize: t,
		strides: n,
		pad: r,
		dimRoundingMode: i
	}, u = j.runKernel(ct, c, l);
	return u = R(u, a.dtype), s ? W(u, [
		u.shape[1],
		u.shape[2],
		u.shape[3]
	]) : u;
}
var Rl, zl = e((() => {
	M(), T(), P(), D(), _c(), Fl(), I(), G(), Rl = /* @__PURE__ */ F({ avgPool_: Ll });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/avg_pool_3d.js
function Bl(e, t, n, r, i, a = "NDHWC") {
	let o = N(e, "x", "avgPool3d", "float32"), s = o, c = !1;
	o.rank === 4 && (c = !0, s = W(o, [
		1,
		o.shape[0],
		o.shape[1],
		o.shape[2],
		o.shape[3]
	])), v(s.rank === 5, () => `Error in avgPool3d: x must be rank 5 but got rank ${s.rank}.`), v(a === "NDHWC", () => `Error in avgPool3d: Only NDHWC is currently supported, but got dataFormat of ${a}`), v(typeof n == "number" && n > 0 || Array.isArray(n) && n[0] > 0 && n[1] > 0 && n[2] > 0, () => `Error in avgPool3d: Stride must be > 0, but got '${n}'`), Pl("avgPool3d", r, i);
	let l = { x: s }, u = {
		filterSize: t,
		strides: n,
		pad: r,
		dimRoundingMode: i,
		dataFormat: a
	}, d = j.runKernel(ut, l, u);
	return d = R(d, s.dtype), c ? W(d, [
		d.shape[1],
		d.shape[2],
		d.shape[3],
		d.shape[4]
	]) : d;
}
var Vl, Hl = e((() => {
	M(), T(), P(), D(), _c(), Fl(), I(), G(), Vl = /* @__PURE__ */ F({ avgPool3d_: Bl });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/concat.js
function Ul(e, t = 0) {
	v(e.length >= 1, () => "Pass at least one tensor to concat");
	let n = fo(e, "tensors", "concat", "string_or_numeric");
	if (n[0].dtype === "complex64" && n.forEach((e) => {
		if (e.dtype !== "complex64") throw Error(`Cannot concatenate complex64 tensors with a tensor
          with dtype ${e.dtype}. `);
	}), n.length === 1) return yc(n[0]);
	let r = n, i = { axis: t };
	return j.runKernel(Ct, r, i);
}
var Wl, Gl = e((() => {
	M(), T(), P(), D(), bc(), I(), Wl = /* @__PURE__ */ F({ concat_: Ul });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/mat_mul.js
function Kl(e, t, n = !1, r = !1) {
	let i = N(e, "a", "matMul"), a = N(t, "b", "matMul");
	[i, a] = k(i, a);
	let o = {
		a: i,
		b: a
	}, s = {
		transposeA: n,
		transposeB: r
	};
	return j.runKernel(ft, o, s);
}
var K, ql = e((() => {
	M(), T(), A(), P(), I(), K = /* @__PURE__ */ F({ matMul_: Kl });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/sigmoid.js
function Jl(e) {
	let t = { x: N(e, "x", "sigmoid", "float32") };
	return j.runKernel(Ar, t);
}
var Yl, Xl = e((() => {
	M(), T(), P(), I(), Yl = /* @__PURE__ */ F({ sigmoid_: Jl });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/slice.js
function Zl(e, t, n) {
	let r = N(e, "x", "slice", "string_or_numeric");
	if (r.rank === 0) throw Error("Slicing scalar is not possible");
	let i = { x: r }, a = {
		begin: t,
		size: n
	};
	return j.runKernel(Er, i, a);
}
var q, Ql = e((() => {
	M(), T(), P(), I(), q = /* @__PURE__ */ F({ slice_: Zl });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/tanh.js
function $l(e) {
	let t = { x: N(e, "x", "tanh", "float32") };
	return j.runKernel(Zr, t);
}
var eu, tu = e((() => {
	M(), T(), P(), I(), eu = /* @__PURE__ */ F({ tanh_: $l });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/basic_lstm_cell.js
function nu(e, t, n, r, i, a) {
	let o = N(e, "forgetBias", "basicLSTMCell"), s = N(t, "lstmKernel", "basicLSTMCell"), c = N(n, "lstmBias", "basicLSTMCell"), l = N(r, "data", "basicLSTMCell"), u = N(i, "c", "basicLSTMCell"), d = N(a, "h", "basicLSTMCell"), f = Wl([l, d], 1), p = K(f, s), m = z(p, c), h = m.shape[0], g = m.shape[1] / 4, _ = [h, g], v = q(m, [0, 0], _), y = q(m, [0, g], _), b = q(m, [0, g * 2], _), x = q(m, [0, g * 3], _), ee = z(H(Yl(v), eu(y)), H(u, Yl(z(o, b))));
	return [ee, H(eu(ee), Yl(x))];
}
var ru, iu = e((() => {
	P(), B(), Gl(), ql(), U(), I(), Xl(), Ql(), tu(), ru = /* @__PURE__ */ F({ basicLSTMCell_: nu });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/batch_to_space_nd.js
function au(e, t, n) {
	let r = N(e, "x", "batchToSpaceND"), i = t.reduce((e, t) => e * t);
	v(r.rank >= 1 + t.length, () => `input rank is ${r.rank} but should be > than blockShape.length ${t.length}`), v(n.length === t.length, () => `crops.length is ${n.length} but should be equal to blockShape.length  ${t.length}`), v(r.shape[0] % i === 0, () => `input tensor batch is ${r.shape[0]} but is not divisible by the product of the elements of blockShape ${t.join(" * ")} === ${i}`);
	let a = { x: r }, o = {
		blockShape: t,
		crops: n
	};
	return j.runKernel(pt, a, o);
}
var ou, su = e((() => {
	M(), T(), P(), D(), I(), ou = /* @__PURE__ */ F({ batchToSpaceND_: au });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/batchnorm_util.js
function cu(e) {
	let t;
	return t = e.rank === 0 || e.rank === 1 ? W(e, [
		1,
		1,
		1,
		e.size
	]) : e.rank === 2 ? W(e, [
		1,
		1,
		e.shape[0],
		e.shape[1]
	]) : e.rank === 3 ? W(e, [
		1,
		e.shape[0],
		e.shape[1],
		e.shape[2]
	]) : e, t;
}
var lu = e((() => {
	G();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/batchnorm.js
function uu(e, t, n, r, i, a) {
	a ??= .001;
	let o = N(e, "x", "batchNorm"), s = N(t, "mean", "batchNorm"), c = N(n, "variance", "batchNorm"), l;
	i != null && (l = N(i, "scale", "batchNorm"));
	let u;
	r != null && (u = N(r, "offset", "batchNorm")), v(s.rank === c.rank, () => "Batch normalization gradient requires mean and variance to have equal ranks."), v(u == null || s.rank === u.rank, () => "Batch normalization gradient requires mean and offset to have equal ranks."), v(l == null || s.rank === l.rank, () => "Batch normalization gradient requires mean and scale to have equal ranks.");
	let d = {
		x: cu(o),
		scale: l,
		offset: u,
		mean: s,
		variance: c
	}, f = { varianceEpsilon: a }, p = j.runKernel(on, d, f);
	return W(p, o.shape);
}
var du, fu = e((() => {
	M(), T(), P(), D(), lu(), I(), G(), du = /* @__PURE__ */ F({ batchNorm_: uu });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/batchnorm2d.js
function pu(e, t, n, r, i, a) {
	let o = N(e, "x", "batchNorm"), s = N(t, "mean", "batchNorm"), c = N(n, "variance", "batchNorm"), l;
	i != null && (l = N(i, "scale", "batchNorm"));
	let u;
	return r != null && (u = N(r, "offset", "batchNorm")), v(o.rank === 2, () => `Error in batchNorm2D: x must be rank 2 but got rank ${o.rank}.`), v(s.rank === 2 || s.rank === 1, () => `Error in batchNorm2D: mean must be rank 2 or rank 1 but got rank ${s.rank}.`), v(c.rank === 2 || c.rank === 1, () => `Error in batchNorm2D: variance must be rank 2 or rank 1 but got rank ${c.rank}.`), l != null && v(l.rank === 2 || l.rank === 1, () => `Error in batchNorm2D: scale must be rank 2 or rank 1 but got rank ${l.rank}.`), u != null && v(u.rank === 2 || u.rank === 1, () => `Error in batchNorm2D: offset must be rank 2 or rank 1 but got rank ${u.rank}.`), du(o, s, c, u, l, a);
}
var mu, hu = e((() => {
	P(), D(), fu(), I(), mu = /* @__PURE__ */ F({ batchNorm2d_: pu });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/batchnorm3d.js
function gu(e, t, n, r, i, a) {
	let o = N(e, "x", "batchNorm"), s = N(t, "mean", "batchNorm"), c = N(n, "variance", "batchNorm"), l;
	i != null && (l = N(i, "scale", "batchNorm"));
	let u;
	return r != null && (u = N(r, "offset", "batchNorm")), v(o.rank === 3, () => `Error in batchNorm3D: x must be rank 3 but got rank ${o.rank}.`), v(s.rank === 3 || s.rank === 1, () => `Error in batchNorm3D: mean must be rank 3 or rank 1 but got rank ${s.rank}.`), v(c.rank === 3 || c.rank === 1, () => `Error in batchNorm3D: variance must be rank 3 or rank 1 but got rank ${c.rank}.`), l != null && v(l.rank === 3 || l.rank === 1, () => `Error in batchNorm3D: scale must be rank 3 or rank 1 but got rank ${l.rank}.`), u != null && v(u.rank === 3 || u.rank === 1, () => `Error in batchNorm3D: offset must be rank 3 or rank 1 but got rank ${u.rank}.`), du(o, s, c, u, l, a);
}
var _u, vu = e((() => {
	P(), D(), fu(), I(), _u = /* @__PURE__ */ F({ batchNorm3d_: gu });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/batchnorm4d.js
function yu(e, t, n, r, i, a) {
	let o = N(e, "x", "batchNorm"), s = N(t, "mean", "batchNorm"), c = N(n, "variance", "batchNorm"), l;
	i != null && (l = N(i, "scale", "batchNorm"));
	let u;
	return r != null && (u = N(r, "offset", "batchNorm")), v(o.rank === 4, () => `Error in batchNorm4D: x must be rank 4 but got rank ${o.rank}.`), v(s.rank === 4 || s.rank === 1, () => `Error in batchNorm4D: mean must be rank 4 or rank 1 but got rank ${s.rank}.`), v(c.rank === 4 || c.rank === 1, () => `Error in batchNorm4D: variance must be rank 4 or rank 1 but got rank ${c.rank}.`), l != null && v(l.rank === 4 || l.rank === 1, () => `Error in batchNorm4D: scale must be rank 4 or rank 1 but got rank ${l.rank}.`), u != null && v(u.rank === 4 || u.rank === 1, () => `Error in batchNorm4D: offset must be rank 4 or rank 1 but got rank ${u.rank}.`), du(o, s, c, u, l, a);
}
var bu, xu = e((() => {
	P(), D(), fu(), I(), bu = /* @__PURE__ */ F({ batchNorm4d_: yu });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/bincount.js
function Su(e, t, n) {
	let r = N(e, "x", "bincount"), i = N(t, "weights", "bincount");
	v(r.dtype === "int32", () => `Error in bincount: input dtype must be int32, but got ${r.dtype}`), v(n >= 0, () => `size must be non-negative, but got ${n}.`), v(i.size === r.size || i.size === 0, () => `Error in bincount: weights must have the same size as input or0-length, but got input shape: ${r.shape}, weights shape: ${i.shape}.`);
	let a = {
		x: r,
		weights: i
	}, o = { size: n };
	return j.runKernel(mt, a, o);
}
var Cu, wu = e((() => {
	M(), T(), P(), D(), I(), Cu = /* @__PURE__ */ F({ bincount_: Su });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/bitwise_and.js
function Tu(e, t) {
	let n = N(e, "x", "bitwiseAnd"), r = N(t, "y", "bitwiseAnd");
	if (!S(n.shape, r.shape)) throw Error(`BitwiseAnd: Tensors must have the same shape. x: ${n.shape}, y: ${r.shape}`);
	if (n.dtype !== "int32" || r.dtype !== "int32") throw Error(`BitwiseAnd: Only supports 'int32' values in tensor, found type of x: ${n.dtype} and type of y: ${r.dtype}`);
	let i = {
		a: n,
		b: r
	};
	return j.runKernel(ht, i);
}
var Eu, Du = e((() => {
	M(), T(), P(), Pe(), I(), Eu = /* @__PURE__ */ F({ bitwiseAnd_: Tu });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/broadcast_args.js
function Ou(e, t) {
	let n = N(e, "s0", "broadcastArgs", "int32"), r = N(t, "s1", "broadcastArgs", "int32");
	if (n.rank !== 1) throw Error(`broadcastArgs(): first input must be a vector (rank=1). Has rank ${n.rank}`);
	if (r.rank !== 1) throw Error(`broadcastArgs(): second input must be a vector (rank=1). Has rank ${r.rank}`);
	let i = {
		s0: n,
		s1: r
	};
	return j.runKernel(_t, i);
}
var ku, Au = e((() => {
	M(), T(), P(), I(), ku = /* @__PURE__ */ F({ broadcastArgs_: Ou });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/broadcast_to.js
function ju(e, t) {
	let n = N(e, "broadcastTo", "x"), r = n.shape;
	if (Ae(t), t.length < n.rank) throw Error(`broadcastTo(): shape.length=${t.length} < input.rank=${n.rank}.`);
	if (t.length > n.rank) {
		let e = n.shape.slice();
		for (; e.length < t.length;) e.unshift(1);
		n = W(n, e);
	}
	let i = n.shape, a = Array.from(t);
	for (let e = t.length - 1; e >= 0; e--) if (i[e] === t[e]) a[e] = 1;
	else if (n.shape[e] !== 1) throw Error(`broadcastTo(): [${r}] cannot be broadcast to [${t}].`);
	if (a.map((e, t) => e > 1 ? t : -1).filter((e) => e >= 0).length === 0) return yc(n);
	let o = { x: n }, s = { reps: a };
	return j.runKernel(Qr, o, s);
}
var Mu, Nu = e((() => {
	M(), T(), P(), Pe(), bc(), I(), G(), Mu = /* @__PURE__ */ F({ broadcastTo_: ju });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/ceil.js
function Pu(e) {
	let t = { x: N(e, "x", "ceil", "float32") };
	return j.runKernel(yt, t);
}
var Fu, Iu = e((() => {
	M(), T(), P(), I(), Fu = /* @__PURE__ */ F({ ceil_: Pu });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/fill.js
function Lu(e, t, n) {
	Ae(e), n ||= be(t);
	let r = {
		shape: e,
		value: t,
		dtype: n
	};
	return j.runKernel(tn, {}, r);
}
var Ru = e((() => {
	M(), T(), D(), Pe();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/clip_by_value.js
function zu(e, t, n) {
	let r = N(e, "x", "clipByValue");
	if (v(t <= n, () => `Error in clip: min (${t}) must be less than or equal to max (${n}).`), t === n) return Lu(r.shape, t, r.dtype);
	let i = { x: r }, a = {
		clipValueMin: t,
		clipValueMax: n
	};
	return j.runKernel(bt, i, a);
}
var Bu, Vu = e((() => {
	M(), T(), P(), D(), Ru(), I(), Bu = /* @__PURE__ */ F({ clipByValue_: zu });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/concat_1d.js
function Hu(e) {
	return Wl(e, 0);
}
var Uu, Wu = e((() => {
	Gl(), I(), Uu = /* @__PURE__ */ F({ concat1d_: Hu });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/concat_2d.js
function Gu(e, t) {
	return Wl(e, t);
}
var Ku, qu = e((() => {
	Gl(), I(), Ku = /* @__PURE__ */ F({ concat2d_: Gu });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/concat_3d.js
function Ju(e, t) {
	return Wl(e, t);
}
var Yu, Xu = e((() => {
	Gl(), I(), Yu = /* @__PURE__ */ F({ concat3d_: Ju });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/concat_4d.js
function Zu(e, t) {
	return Wl(e, t);
}
var Qu, $u = e((() => {
	Gl(), I(), Qu = /* @__PURE__ */ F({ concat4d_: Zu });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/conv2d.js
function ed(e, t, n, r, i = "NHWC", a = [1, 1], o) {
	let s = N(e, "x", "conv2d", "float32"), c = N(t, "filter", "conv2d", "float32"), l = s, u = !1;
	s.rank === 3 && (u = !0, l = W(s, [
		1,
		s.shape[0],
		s.shape[1],
		s.shape[2]
	])), v(l.rank === 4, () => `Error in conv2d: input must be rank 4, but got rank ${l.rank}.`), v(c.rank === 4, () => `Error in conv2d: filter must be rank 4, but got rank ${c.rank}.`), Pl("conv2d", r, o);
	let d = i === "NHWC" ? l.shape[3] : l.shape[1];
	v(d === c.shape[2], () => `Error in conv2d: depth of input (${d}) must match input depth for filter ${c.shape[2]}.`), v(jl(n, a), () => `Error in conv2D: Either strides or dilations must be 1. Got strides ${n} and dilations '${a}'`), v(Ml(a), () => "Error in conv2D: Dilated rates should be larger than 0."), v(Ml(n), () => "Error in conv2D: Strides should be larger than 0.");
	let f = {
		x: l,
		filter: c
	}, p = {
		strides: n,
		pad: r,
		dataFormat: i,
		dilations: a,
		dimRoundingMode: o
	}, m = j.runKernel(wt, f, p);
	return u ? W(m, [
		m.shape[1],
		m.shape[2],
		m.shape[3]
	]) : m;
}
var td, nd = e((() => {
	M(), T(), P(), D(), Fl(), I(), G(), td = /* @__PURE__ */ F({ conv2d_: ed });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/conv1d.js
function rd(e, t, n, r, i = "NWC", a = 1, o) {
	let s = N(e, "x", "conv1d"), c = N(t, "filter", "conv1d"), l = s, u = !1;
	s.rank === 2 && (u = !0, l = W(s, [
		1,
		s.shape[0],
		s.shape[1]
	])), v(l.rank === 3, () => `Error in conv1d: input must be rank 3, but got rank ${l.rank}.`), v(c.rank === 3, () => `Error in conv1d: filter must be rank 3, but got rank ${c.rank}.`), Pl("conv1d", r, o), v(l.shape[2] === c.shape[1], () => `Error in conv1d: depth of input (${l.shape[2]}) must match input depth for filter ${c.shape[1]}.`), v(jl(n, a), () => `Error in conv1D: Either stride or dilation must be 1. Got stride ${n} and dilation '${a}'`), v(Ml(a), () => "Error in conv1D: Dilated rates should be larger than 0."), v(Ml(n), () => "Error in conv1D: Stride should be larger than 0."), v(i === "NWC", () => `Error in conv1d: got dataFormat of ${i} but only NWC is currently supported.`);
	let d = W(c, [
		1,
		c.shape[0],
		c.shape[1],
		c.shape[2]
	]), f = W(l, [
		l.shape[0],
		1,
		l.shape[1],
		l.shape[2]
	]), p = td(f, d, [1, n], r, "NHWC", [1, a], o);
	return u ? W(p, [p.shape[2], p.shape[3]]) : W(p, [
		p.shape[0],
		p.shape[2],
		p.shape[3]
	]);
}
var id, ad = e((() => {
	P(), D(), nd(), Fl(), I(), G(), id = /* @__PURE__ */ F({ conv1d_: rd });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/conv2d_backprop_input.js
function od(e, t, n, r, i, a = "NHWC", o) {
	v(e.length === t.rank, () => `Length of inShape (${e.length}) and rank of dy (${t.rank}) must match`);
	let s = e, c = t, l = !1;
	t.rank === 3 && (l = !0, c = W(t, [
		1,
		t.shape[0],
		t.shape[1],
		t.shape[2]
	]), s = [
		1,
		e[0],
		e[1],
		e[2]
	]), v(s.length === 4, () => `Error in conv2dDerInput: inShape must be length 4, but got length ${s.length}.`), v(c.rank === 4, () => `Error in conv2dDerInput: dy must be rank 4, but got rank ${c.rank}`), v(n.rank === 4, () => `Error in conv2dDerInput: filter must be rank 4, but got rank ${n.rank}`);
	let u = a === "NHWC" ? s[3] : s[1], d = a === "NHWC" ? c.shape[3] : c.shape[1];
	v(u === n.shape[2], () => `Error in conv2dDerInput: depth of input (${u}) must match input depth for filter ${n.shape[2]}.`), v(d === n.shape[3], () => `Error in conv2dDerInput: depth of output (${d}) must match output depth for filter ${n.shape[3]}.`), Pl("conv2dDerInput", i, o);
	let f = {
		dy: c,
		filter: n
	}, p = {
		strides: r,
		pad: i,
		dataFormat: a,
		dimRoundingMode: o,
		inputShape: s
	}, m = j.runKernel(Et, f, p);
	return l ? W(m, [
		m.shape[1],
		m.shape[2],
		m.shape[3]
	]) : m;
}
var sd, cd = e((() => {
	M(), T(), D(), Fl(), I(), G(), sd = /* @__PURE__ */ F({ conv2DBackpropInput_: od });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/conv2d_transpose.js
function ld(e, t, n, r, i, a) {
	let o = N(e, "x", "conv2dTranspose"), s = N(t, "filter", "conv2dTranspose");
	return sd(n, o, s, r, i, "NHWC", a);
}
var ud, dd = e((() => {
	P(), cd(), I(), ud = /* @__PURE__ */ F({ conv2dTranspose_: ld });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/conv3d.js
function fd(e, t, n, r, i = "NDHWC", a = [
	1,
	1,
	1
]) {
	let o = N(e, "x", "conv3d"), s = N(t, "filter", "conv3d"), c = o, l = !1;
	o.rank === 4 && (l = !0, c = W(o, [
		1,
		o.shape[0],
		o.shape[1],
		o.shape[2],
		o.shape[3]
	])), v(c.rank === 5, () => `Error in conv3d: input must be rank 5, but got rank ${c.rank}.`), v(s.rank === 5, () => `Error in conv3d: filter must be rank 5, but got rank ${s.rank}.`), v(c.shape[4] === s.shape[3], () => `Error in conv3d: depth of input (${c.shape[4]}) must match input depth for filter ${s.shape[3]}.`), v(jl(n, a), () => `Error in conv3D: Either strides or dilations must be 1. Got strides ${n} and dilations '${a}'`), v(i === "NDHWC", () => `Error in conv3d: got dataFormat of ${i} but only NDHWC is currently supported.`), v(Ml(a), () => "Error in conv3D: Dilated rates should be larger than 0."), v(Ml(n), () => "Error in conv3D: Strides should be larger than 0.");
	let u = {
		x: c,
		filter: s
	}, d = {
		strides: n,
		pad: r,
		dataFormat: i,
		dilations: a
	}, f = j.runKernel(Dt, u, d);
	return l ? W(f, [
		f.shape[1],
		f.shape[2],
		f.shape[3],
		f.shape[4]
	]) : f;
}
var pd, md = e((() => {
	M(), T(), P(), D(), Fl(), I(), G(), pd = /* @__PURE__ */ F({ conv3d_: fd });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/conv3d_backprop_input.js
function hd(e, t, n, r, i) {
	v(e.length === t.rank, () => `Length of inShape (${e.length}) and rank of dy (${t.rank}) must match`);
	let a = e, o = t, s = !1;
	t.rank === 4 && (s = !0, o = W(t, [
		1,
		t.shape[0],
		t.shape[1],
		t.shape[2],
		t.shape[3]
	]), a = [
		1,
		e[0],
		e[1],
		e[2],
		e[3]
	]);
	let c = a[4], l = o.shape[4];
	v(a.length === 5, () => `Error in conv3dDerInput: inShape must be length 5, but got length ${a.length}.`), v(o.rank === 5, () => `Error in conv3dDerInput: dy must be rank 5, but got rank ${o.rank}`), v(n.rank === 5, () => `Error in conv3dDerInput: filter must be rank 5, but got rank ${n.rank}`), v(c === n.shape[3], () => `Error in conv3dDerInput: depth of input (${c}) must match input depth for filter ${n.shape[3]}.`), v(l === n.shape[4], () => `Error in conv3dDerInput: depth of output (${l}) must match output depth for filter ${n.shape[4]}.`);
	let u = {
		dy: o,
		filter: n
	}, d = {
		pad: i,
		strides: r,
		inputShape: a
	}, f = j.runKernel(kt, u, d);
	return s ? W(f, [
		f.shape[1],
		f.shape[2],
		f.shape[3],
		f.shape[4]
	]) : f;
}
var gd, _d = e((() => {
	M(), T(), D(), I(), G(), gd = /* @__PURE__ */ F({ conv3DBackpropInput_: hd });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/conv3d_transpose.js
function vd(e, t, n, r, i) {
	let a = N(e, "x", "conv3dTranspose"), o = N(t, "filter", "conv3dTranspose");
	return gd(n, a, o, r, i);
}
var yd, bd = e((() => {
	P(), _d(), I(), yd = /* @__PURE__ */ F({ conv3dTranspose_: vd });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/cos.js
function xd(e) {
	let t = { x: N(e, "x", "cos", "float32") };
	return j.runKernel("Cos", t);
}
var Sd, Cd = e((() => {
	M(), T(), P(), I(), Sd = /* @__PURE__ */ F({ cos_: xd });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/cosh.js
function wd(e) {
	let t = { x: N(e, "x", "cosh", "float32") };
	return j.runKernel(jt, t);
}
var Td, Ed = e((() => {
	M(), T(), P(), I(), Td = /* @__PURE__ */ F({ cosh_: wd });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/cumprod.js
function Dd(e, t = 0, n = !1, r = !1) {
	let i = { x: N(e, "x", "cumprod") }, a = {
		axis: t,
		exclusive: n,
		reverse: r
	};
	return j.runKernel(Mt, i, a);
}
var Od, kd = e((() => {
	M(), T(), P(), I(), Od = /* @__PURE__ */ F({ cumprod_: Dd });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/cumsum.js
function Ad(e, t = 0, n = !1, r = !1) {
	let i = { x: N(e, "x", "cumsum") }, a = {
		axis: t,
		exclusive: n,
		reverse: r
	};
	return j.runKernel(Nt, i, a);
}
var jd, Md = e((() => {
	M(), T(), P(), I(), jd = /* @__PURE__ */ F({ cumsum_: Ad });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/dense_bincount.js
function Nd(e, t, n, r = !1) {
	let i = N(e, "x", "denseBincount"), a = N(t, "weights", "denseBincount");
	v(i.dtype === "int32", () => `Error in denseBincount: input dtype must be int32, but got ${i.dtype}`), v(i.rank <= 2, () => `Error in denseBincount: input must be at most rank 2, but got rank ${i.rank}.`), v(n >= 0, () => `size must be non-negative, but got ${n}.`), v(a.size === i.size || a.size === 0, () => `Error in denseBincount: weights must have the same shape as x or 0-length, but got x shape: ${i.shape}, weights shape: ${a.shape}.`);
	let o = {
		x: i,
		weights: a
	}, s = {
		size: n,
		binaryOutput: r
	};
	return j.runKernel(Ft, o, s);
}
var Pd, Fd = e((() => {
	M(), T(), P(), D(), I(), Pd = /* @__PURE__ */ F({ denseBincount_: Nd });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/depth_to_space.js
function Id(e, t, n = "NHWC") {
	let r = N(e, "x", "depthToSpace", "float32"), i = n === "NHWC" ? r.shape[1] : r.shape[2], a = n === "NHWC" ? r.shape[2] : r.shape[3], o = n === "NHWC" ? r.shape[3] : r.shape[1];
	v(t > 1, () => `blockSize should be > 1 for depthToSpace, but was: ${t}`), v(i * t >= 0, () => `Negative dimension size caused by overflow when multiplying
    ${i} and ${t}  for depthToSpace with input shape
    ${r.shape}`), v(a * t >= 0, () => `Negative dimension size caused by overflow when multiplying
    ${a} and ${t} for depthToSpace with input shape
        ${r.shape}`), v(o % (t * t) === 0, () => `Dimension size must be evenly divisible by ${t * t} but is ${o} for depthToSpace with input shape ${r.shape}`);
	let s = { x: r }, c = {
		blockSize: t,
		dataFormat: n
	};
	return j.runKernel(It, s, c);
}
var Ld, Rd = e((() => {
	M(), T(), P(), D(), I(), Ld = /* @__PURE__ */ F({ depthToSpace_: Id });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/depthwise_conv2d.js
function zd(e, t, n, r, i = "NHWC", a = [1, 1], o) {
	let s = N(e, "x", "depthwiseConv2d", "float32"), c = N(t, "filter", "depthwiseConv2d", "float32"), l = s, u = !1;
	s.rank === 3 && (u = !0, l = W(s, [
		1,
		s.shape[0],
		s.shape[1],
		s.shape[2]
	])), v(l.rank === 4, () => `Error in depthwiseConv2d: input must be rank 4, but got rank ${l.rank}.`), v(c.rank === 4, () => `Error in depthwiseConv2d: filter must be rank 4, but got rank ${c.rank}.`);
	let d = i === "NHWC" ? l.shape[3] : l.shape[1];
	v(d === c.shape[2], () => `Error in depthwiseConv2d: number of input channels (${d}) must match the inChannels dimension in filter ${c.shape[2]}.`), Pl("depthwiseConv2d", r, o);
	let f = {
		x: l,
		filter: c
	}, p = {
		strides: n,
		pad: r,
		dataFormat: i,
		dilations: a,
		dimRoundingMode: o
	}, m = j.runKernel(Lt, f, p);
	return u ? W(m, [
		m.shape[1],
		m.shape[2],
		m.shape[3]
	]) : m;
}
var Bd, Vd = e((() => {
	M(), T(), P(), D(), Fl(), I(), G(), Bd = /* @__PURE__ */ F({ depthwiseConv2d_: zd });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/diag.js
function Hd(e) {
	let t = { x: N(e, "x", "diag") };
	return j.runKernel(Bt, t);
}
var Ud, Wd = e((() => {
	M(), T(), P(), I(), Ud = /* @__PURE__ */ F({ diag_: Hd });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/dilation2d.js
function Gd(e, t, n, r, i = [1, 1], a = "NHWC") {
	let o = N(e, "x", "dilation2d"), s = N(t, "filter", "dilation2d");
	v(o.rank === 3 || o.rank === 4, () => `Error in dilation2d: input must be rank 3 or 4, but got rank ${o.rank}.`), v(s.rank === 3, () => `Error in dilation2d: filter must be rank 3, but got rank ${s.rank}.`), v(a === "NHWC", () => `Error in dilation2d: Only NHWC is currently supported, but got dataFormat of ${a}`);
	let c = o, l = !1;
	o.rank === 3 && (c = W(o, [
		1,
		o.shape[0],
		o.shape[1],
		o.shape[2]
	]), l = !0), v(c.shape[3] === s.shape[2], () => `Error in dilation2d:  input and filter must have the same depth: ${c.shape[3]} vs ${s.shape[2]}`);
	let u = {
		x: c,
		filter: s
	}, d = {
		strides: n,
		pad: r,
		dilations: i
	}, f = j.runKernel(Vt, u, d);
	return l ? W(f, [
		f.shape[1],
		f.shape[2],
		f.shape[3]
	]) : f;
}
var Kd, qd = e((() => {
	M(), T(), P(), D(), I(), G(), Kd = /* @__PURE__ */ F({ dilation2d_: Gd });
})), Jd = /* @__PURE__ */ n({
	assertAndGetBroadcastShape: () => J,
	getBroadcastDims: () => Yd,
	getReductionAxes: () => Xd
});
function Yd(e, t) {
	let n = e.length, r = [];
	for (let i = 0; i < n; i++) {
		let a = n - 1 - i, o = e[a] || 1;
		(t[t.length - 1 - i] || 1) > 1 && o === 1 && r.unshift(a);
	}
	return r;
}
function Xd(e, t) {
	let n = [];
	for (let r = 0; r < t.length; r++) {
		let i = e[e.length - r - 1], a = t.length - r - 1, o = t[a];
		(i == null || i === 1 && o > 1) && n.unshift(a);
	}
	return n;
}
function J(e, t) {
	let n = Math.max(e.length, t.length), r = Array(n);
	for (let i = 0; i < n; i++) {
		let a = e[e.length - i - 1];
		a ??= 1;
		let o = t[t.length - i - 1];
		if (o ??= 1, a === 1) r[n - i - 1] = o;
		else if (o === 1) r[n - i - 1] = a;
		else if (a !== o) {
			let n = `Operands could not be broadcast together with shapes ${e} and ${t}.`;
			throw Error(n);
		} else r[n - i - 1] = a;
	}
	return r;
}
var Zd = e((() => {}));
// node_modules/@tensorflow/tfjs-core/dist/ops/equal.js
function Qd(e, t) {
	let n = N(e, "a", "equal", "string_or_numeric"), r = N(t, "b", "equal", "string_or_numeric");
	[n, r] = k(n, r), J(n.shape, r.shape);
	let i = {
		a: n,
		b: r
	};
	return j.runKernel(Xt, i);
}
var $d, ef = e((() => {
	M(), T(), A(), P(), Zd(), I(), $d = /* @__PURE__ */ F({ equal_: Qd });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/where.js
function tf(e, t, n) {
	let r = N(t, "a", "where"), i = N(n, "b", "where"), a = N(e, "condition", "where", "bool"), o = J(J(a.shape, r.shape), i.shape), s = {
		condition: Mu(a, o),
		t: Mu(r, o),
		e: Mu(i, o)
	};
	return j.runKernel(wr, s);
}
var nf, rf = e((() => {
	M(), T(), P(), Nu(), Zd(), I(), nf = /* @__PURE__ */ F({ where_: tf });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/zeros_like.js
function af(e) {
	let t = { x: N(e, "x", "zerosLike") };
	return j.runKernel(oi, t);
}
var of, sf = e((() => {
	M(), T(), P(), I(), of = /* @__PURE__ */ F({ zerosLike_: af });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/div_no_nan.js
function cf(e, t) {
	let n = N(e, "a", "div"), r = N(t, "b", "div");
	[n, r] = k(n, r);
	let i = V(n, r), a = of(i), o = $d(r, a);
	return nf(o, a, i);
}
var lf, uf = e((() => {
	A(), P(), kc(), ef(), I(), rf(), sf(), lf = /* @__PURE__ */ F({ divNoNan_: cf });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/dot.js
function df(e, t) {
	let n = N(e, "t1", "dot"), r = N(t, "t2", "dot");
	v((n.rank === 1 || n.rank === 2) && (r.rank === 1 || r.rank === 2), () => `Error in dot: inputs must all be rank 1 or 2, but got ranks ${n.rank} and ${r.rank}.`);
	let i = n.rank === 1 ? n.size : n.shape[1], a = r.rank === 1 ? r.size : r.shape[0];
	if (v(i === a, () => `Error in dot: inner dimensions of inputs must match, but got ${i} and ${a}.`), n.rank === 1 && r.rank === 1) {
		let e = W(n, [1, -1]), t = W(r, [-1, 1]), i = K(e, t);
		return W(i, []);
	}
	if (n.rank === 1 && r.rank === 2) {
		let e = W(n, [1, -1]), t = W(r, [r.shape[0], r.shape[1]]), i = K(e, t);
		return W(i, [i.size]);
	}
	if (n.rank === 2 && r.rank === 1) {
		let e = W(r, [-1, 1]), t = K(n, e);
		return W(t, [t.size]);
	}
	{
		let e = W(r, [r.shape[0], r.shape[1]]);
		return K(n, e);
	}
}
var ff, pf = e((() => {
	P(), D(), ql(), I(), G(), ff = /* @__PURE__ */ F({ dot_: df });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/einsum.js
function mf(e, ...t) {
	let n = t.map((e, t) => N(e, `tensors${t}`, "einsum")), r = { equation: e };
	return j.runKernel(Kt, n, r);
}
var hf, gf = e((() => {
	M(), T(), P(), I(), hf = /* @__PURE__ */ F({ einsum_: mf });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/elu.js
function _f(e) {
	let t = { x: N(e, "x", "elu", "float32") };
	return j.runKernel("Elu", t);
}
var vf, yf = e((() => {
	M(), T(), P(), I(), vf = /* @__PURE__ */ F({ elu_: _f });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/ensure_shape.js
function bf(e, t) {
	let n = N(e, "x", "ensureShape", "string_or_numeric");
	if (!te(n.shape, t)) throw Error(`EnsureShape: Shape of tensor ${n.shape} is not compatible with expected shape ${t}`);
	return e;
}
var xf, Sf = e((() => {
	P(), Pe(), I(), xf = /* @__PURE__ */ F({ ensureShape_: bf });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/erf.js
function Cf(e) {
	let t = N(e, "x", "erf");
	v(t.dtype === "int32" || t.dtype === "float32", () => "Input dtype must be `int32` or `float32`."), t.dtype === "int32" && (t = R(t, "float32"));
	let n = { x: t };
	return j.runKernel("Erf", n);
}
var wf, Tf = e((() => {
	M(), T(), P(), D(), _c(), I(), wf = /* @__PURE__ */ F({ erf_: Cf });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/axis_util.js
function Ef(e, t) {
	for (let n = 0; n < e.length; ++n) if (e[e.length - n - 1] !== t - 1 - n) return !1;
	return !0;
}
function Df(e, t, n) {
	let r = e.length + t.length, i = [], a = 0, o = 0;
	for (let s = 0; s < r; s++) n.indexOf(s) === -1 ? i.push(e[a++]) : i.push(t[o++]);
	return i;
}
function Of(e, t) {
	let n = [], r = e.length;
	for (let i = 0; i < r; i++) t.indexOf(i) === -1 && n.push(e[i]);
	return [n, t.map((t) => e[t])];
}
function kf(e, t) {
	return Df(e, t.map((e) => 1), t);
}
function Af(e, t, n) {
	v(Ef(t, n), () => `${e} supports only inner-most axes for now. Got axes ${t} and rank-${n} input.`);
}
function jf(e, t) {
	if (Ef(e, t)) return null;
	let n = [];
	for (let r = 0; r < t; ++r) e.indexOf(r) === -1 && n.push(r);
	return e.forEach((e) => n.push(e)), n;
}
function Mf(e) {
	return e.map((e, t) => [t, e]).sort((e, t) => e[1] - t[1]).map((e) => e[0]);
}
function Nf(e, t) {
	let n = [];
	for (let r = t - e; r < t; ++r) n.push(r);
	return n;
}
var Pf = e((() => {
	D();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/max.js
function Ff(e, t = null, n = !1) {
	let r = { x: N(e, "x", "max") }, i = {
		reductionIndices: t,
		keepDims: n
	};
	return j.runKernel("Max", r, i);
}
var If, Lf = e((() => {
	M(), T(), P(), I(), If = /* @__PURE__ */ F({ max_: Ff });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/min.js
function Rf(e, t = null, n = !1) {
	let r = { x: N(e, "x", "min") }, i = {
		axis: t,
		keepDims: n
	};
	return j.runKernel("Min", r, i);
}
var zf, Bf = e((() => {
	M(), T(), P(), I(), zf = /* @__PURE__ */ F({ min_: Rf });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/pow.js
function Vf(e, t) {
	let n = N(e, "base", "pow"), r = N(t, "exp", "pow");
	[n, r] = k(n, r);
	let i = {
		a: n,
		b: r
	};
	return j.runKernel("Pow", i);
}
var Hf, Uf = e((() => {
	M(), T(), A(), P(), I(), Hf = /* @__PURE__ */ F({ pow_: Vf });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/scalar.js
function Y(e, t) {
	if ((ra(e) && t !== "string" || Array.isArray(e)) && t !== "complex64") throw Error("Error creating a new Scalar: value must be a primitive (number|boolean|string)");
	if (t === "string" && ra(e) && !(e instanceof Uint8Array)) throw Error("When making a scalar from encoded string, the value must be `Uint8Array`.");
	return _o(e, [], [], t);
}
var Wf = e((() => {
	D(), vo();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/sqrt.js
function Gf(e) {
	let t = { x: N(e, "x", "sqrt", "float32") };
	return j.runKernel(Mr, t);
}
var Kf, qf = e((() => {
	M(), T(), P(), I(), Kf = /* @__PURE__ */ F({ sqrt_: Gf });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/square.js
function Jf(e) {
	let t = N(e, "x", "square");
	return j.runKernel("Square", { x: t }, {});
}
var Yf, Xf = e((() => {
	M(), P(), I(), Yf = /* @__PURE__ */ F({ square_: Jf });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/sum.js
function Zf(e, t = null, n = !1) {
	let r = N(e, "x", "sum");
	r.dtype === "bool" && (r = R(r, "int32"));
	let i = { x: r }, a = {
		axis: t,
		keepDims: n
	};
	return j.runKernel("Sum", i, a);
}
var X, Qf = e((() => {
	M(), T(), P(), _c(), I(), X = /* @__PURE__ */ F({ sum_: Zf });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/norm.js
function $f(e, t = "euclidean", n = null, r = !1) {
	e = N(e, "x", "norm");
	let i = ep(e, t, n), a = i.shape;
	if (r) {
		let t = ce(n, e.shape);
		a = kf(i.shape, t);
	}
	return W(i, a);
}
function ep(e, t, n = null) {
	if (e.rank === 0) return Mc(e);
	if (e.rank !== 1 && n === null) return ep(W(e, [-1]), t, n);
	if (e.rank === 1 || typeof n == "number" || Array.isArray(n) && n.length === 1) {
		if (t === 1) return X(Mc(e), n);
		if (t === Infinity) return If(Mc(e), n);
		if (t === -Infinity) return zf(Mc(e), n);
		if (t === "euclidean" || t === 2) return Kf(X(Hf(Mc(e), Y(2, "int32")), n));
		throw Error(`Error in norm: invalid ord value: ${t}`);
	}
	if (Array.isArray(n) && n.length === 2) {
		if (t === 1) return If(X(Mc(e), n[0]), n[1] - 1);
		if (t === Infinity) return If(X(Mc(e), n[1]), n[0]);
		if (t === -Infinity) return zf(X(Mc(e), n[1]), n[0]);
		if (t === "fro" || t === "euclidean") return Kf(X(Yf(e), n));
		throw Error(`Error in norm: invalid ord value: ${t}`);
	}
	throw Error(`Error in norm: invalid axis: ${n}`);
}
var tp, np = e((() => {
	P(), D(), Nc(), Pf(), Lf(), Bf(), I(), Uf(), G(), Wf(), qf(), Xf(), Qf(), tp = /* @__PURE__ */ F({ norm_: $f });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/euclidean_norm.js
function rp(e, t = null, n = !1) {
	return tp(e, "euclidean", t, n);
}
var ip, ap = e((() => {
	np(), I(), ip = /* @__PURE__ */ F({ euclideanNorm_: rp });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/exp.js
function op(e) {
	let t = { x: N(e, "x", "exp") };
	return j.runKernel("Exp", t);
}
var sp, cp = e((() => {
	M(), T(), P(), I(), sp = /* @__PURE__ */ F({ exp_: op });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/expand_dims.js
function lp(e, t = 0) {
	let n = N(e, "x", "expandDims", "string_or_numeric");
	v(t <= n.rank, () => "Axis must be <= rank of the tensor");
	let r = { input: n }, i = { dim: t };
	return j.runKernel(Qt, r, i);
}
var up, dp = e((() => {
	M(), T(), P(), D(), I(), up = /* @__PURE__ */ F({ expandDims_: lp });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/expm1.js
function fp(e) {
	let t = { x: N(e, "x", "expm1") };
	return j.runKernel($t, t);
}
var pp, mp = e((() => {
	M(), T(), P(), I(), pp = /* @__PURE__ */ F({ expm1_: fp });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/tile.js
function hp(e, t) {
	let n = N(e, "x", "tile", "string_or_numeric");
	v(n.rank === t.length, () => `Error in transpose: rank of input ${n.rank} must match length of reps ${t}.`);
	let r = { x: n }, i = { reps: t };
	return j.runKernel(Qr, r, i);
}
var gp, _p = e((() => {
	M(), T(), P(), D(), I(), gp = /* @__PURE__ */ F({ tile_: hp });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/eye.js
function vp(e, t, n, r = "float32") {
	t ??= e;
	let i = mc([e, t], r), a = e <= t ? e : t;
	for (let e = 0; e < a; ++e) i.set(1, e, e);
	let o = W(i.toTensor(), [e, t]);
	if (n == null) return o;
	if (n.length === 1) return gp(up(o, 0), [
		n[0],
		1,
		1
	]);
	if (n.length === 2) return gp(up(up(o, 0), 0), [
		n[0],
		n[1],
		1,
		1
	]);
	if (n.length === 3) return gp(up(up(up(o, 0), 0), 0), [
		n[0],
		n[1],
		n[2],
		1,
		1
	]);
	throw Error(`eye() currently supports only 1D and 2D batchShapes, but received ${n.length}D.`);
}
var yp, bp = e((() => {
	hc(), dp(), I(), G(), _p(), yp = /* @__PURE__ */ F({ eye_: vp });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/floor.js
function xp(e) {
	let t = { x: N(e, "x", "floor", "float32") };
	return j.runKernel(rn, t);
}
var Sp, Cp = e((() => {
	M(), T(), P(), I(), Sp = /* @__PURE__ */ F({ floor_: xp });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/gather.js
function wp(e, t, n = 0, r = 0) {
	let i = {
		x: N(e, "x", "gather"),
		indices: N(t, "indices", "gather", "int32")
	}, a = {
		axis: n,
		batchDims: r
	};
	return j.runKernel(sn, i, a);
}
var Tp, Ep = e((() => {
	M(), T(), P(), I(), Tp = /* @__PURE__ */ F({ gather_: wp });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/greater.js
function Dp(e, t) {
	let n = N(e, "a", "greater", "string_or_numeric"), r = N(t, "b", "greater", "string_or_numeric");
	[n, r] = k(n, r), J(n.shape, r.shape);
	let i = {
		a: n,
		b: r
	};
	return j.runKernel(ln, i);
}
var Op, kp = e((() => {
	M(), T(), A(), P(), Zd(), I(), Op = /* @__PURE__ */ F({ greater_: Dp });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/greater_equal.js
function Ap(e, t) {
	let n = N(e, "a", "greaterEqual", "string_or_numeric"), r = N(t, "b", "greaterEqual", "string_or_numeric");
	[n, r] = k(n, r), J(n.shape, r.shape);
	let i = {
		a: n,
		b: r
	};
	return j.runKernel(un, i);
}
var jp, Mp = e((() => {
	M(), T(), A(), P(), Zd(), I(), jp = /* @__PURE__ */ F({ greaterEqual_: Ap });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/imag.js
function Np(e) {
	let t = { input: N(e, "input", "imag") };
	return j.runKernel(pn, t);
}
var Pp, Fp = e((() => {
	M(), T(), P(), I(), Pp = /* @__PURE__ */ F({ imag_: Np });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/is_finite.js
function Ip(e) {
	let t = { x: N(e, "x", "isFinite") };
	return j.runKernel(mn, t);
}
var Lp, Rp = e((() => {
	M(), T(), P(), I(), Lp = /* @__PURE__ */ F({ isFinite_: Ip });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/is_inf.js
function zp(e) {
	let t = { x: N(e, "x", "isInf") };
	return j.runKernel(hn, t);
}
var Bp, Vp = e((() => {
	M(), T(), P(), I(), Bp = /* @__PURE__ */ F({ isInf_: zp });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/is_nan.js
function Hp(e) {
	let t = { x: N(e, "x", "isNaN") };
	return j.runKernel(gn, t);
}
var Up, Wp = e((() => {
	M(), T(), P(), I(), Up = /* @__PURE__ */ F({ isNaN_: Hp });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/leaky_relu.js
function Gp(e, t = .2) {
	let n = { x: N(e, "x", "leakyRelu") }, r = { alpha: t };
	return j.runKernel(_n, n, r);
}
var Kp, qp = e((() => {
	M(), T(), P(), I(), Kp = /* @__PURE__ */ F({ leakyRelu_: Gp });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/less.js
function Jp(e, t) {
	let n = N(e, "a", "less", "string_or_numeric"), r = N(t, "b", "less", "string_or_numeric");
	[n, r] = k(n, r), J(n.shape, r.shape);
	let i = {
		a: n,
		b: r
	};
	return j.runKernel(vn, i);
}
var Yp, Xp = e((() => {
	M(), T(), A(), P(), Zd(), I(), Yp = /* @__PURE__ */ F({ less_: Jp });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/less_equal.js
function Zp(e, t) {
	let n = N(e, "a", "lessEqual", "string_or_numeric"), r = N(t, "b", "lessEqual", "string_or_numeric");
	[n, r] = k(n, r), J(n.shape, r.shape);
	let i = {
		a: n,
		b: r
	};
	return j.runKernel(yn, i);
}
var Qp, $p = e((() => {
	M(), T(), A(), P(), Zd(), I(), Qp = /* @__PURE__ */ F({ lessEqual_: Zp });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/linspace.js
function em(e, t, n) {
	if (n <= 0) throw Error("The number of values should be positive.");
	let r = {
		start: e,
		stop: t,
		num: n
	};
	return j.runKernel(bn, {}, r);
}
var tm = e((() => {
	M(), T();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/local_response_normalization.js
function nm(e, t = 5, n = 1, r = 1, i = .5) {
	let a = N(e, "x", "localResponseNormalization");
	v(a.rank === 4 || a.rank === 3, () => `Error in localResponseNormalization: x must be rank 3 or 4 but got
               rank ${a.rank}.`), v(ne(t), () => `Error in localResponseNormalization: depthRadius must be an integer but got depthRadius ${t}.`);
	let o = a, s = !1;
	a.rank === 3 && (s = !0, o = W(a, [
		1,
		a.shape[0],
		a.shape[1],
		a.shape[2]
	]));
	let c = { x: o }, l = {
		depthRadius: t,
		bias: n,
		alpha: r,
		beta: i
	}, u = j.runKernel("LRN", c, l);
	return s ? W(u, [
		u.shape[1],
		u.shape[2],
		u.shape[3]
	]) : u;
}
var rm, im = e((() => {
	M(), T(), P(), D(), I(), G(), rm = /* @__PURE__ */ F({ localResponseNormalization_: nm });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/log.js
function am(e) {
	let t = { x: N(e, "x", "log", "float32") };
	return j.runKernel("Log", t);
}
var om, sm = e((() => {
	M(), T(), P(), I(), om = /* @__PURE__ */ F({ log_: am });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/log1p.js
function cm(e) {
	let t = { x: N(e, "x", "log1p") };
	return j.runKernel(Sn, t);
}
var lm, um = e((() => {
	M(), T(), P(), I(), lm = /* @__PURE__ */ F({ log1p_: cm });
}));
// node_modules/@tensorflow/tfjs-core/dist/gradients.js
function dm(e) {
	return v(xe(e), () => "The f passed in grad(f) must be a function"), (t, n) => {
		let r = N(t, "x", "tf.grad", "string_or_numeric"), i = n == null ? null : N(n, "dy", "tf.grad");
		return j.tidy(() => {
			let { value: t, grads: n } = j.gradients(() => e(r), [r], i);
			return i != null && y(t.shape, i.shape, "The shape of dy passed in grad(f)(x, dy) must match the shape returned by f(x)"), _m(n), n[0];
		});
	};
}
function fm(e) {
	return v(xe(e), () => "The f passed in grads(f) must be a function"), (t, n) => {
		v(Array.isArray(t), () => "The args passed in grads(f)(args) must be an array of `Tensor`s or `TensorLike`s");
		let r = fo(t, "args", "tf.grads", "string_or_numeric"), i = n == null ? null : N(n, "dy", "tf.grads");
		return j.tidy(() => {
			let { value: t, grads: n } = j.gradients(() => e(...r), r, i);
			return i != null && y(t.shape, i.shape, "The shape of dy passed in grads(f)([x1,...], dy) must match the shape returned by f([x1,...])"), _m(n), n;
		});
	};
}
function pm(e) {
	return v(xe(e), () => "The f passed in valueAndGrad(f) must be a function"), (t, n) => {
		v(t instanceof O, () => "The x passed in valueAndGrad(f)(x) must be a tensor"), v(n == null || n instanceof O, () => "The dy passed in valueAndGrad(f)(x, dy) must be a tensor");
		let { grads: r, value: i } = j.gradients(() => e(t), [t], n);
		return _m(r), {
			grad: r[0],
			value: i
		};
	};
}
function mm(e) {
	return v(xe(e), () => "The f passed in valueAndGrads(f) must be a function"), (t, n) => {
		v(Array.isArray(t) && t.every((e) => e instanceof O), () => "The args passed in valueAndGrads(f)(args) must be array of tensors"), v(n == null || n instanceof O, () => "The dy passed in valueAndGrads(f)(args, dy) must be a tensor");
		let r = j.gradients(() => e(...t), t, n);
		return n != null && y(r.value.shape, n.shape, "The shape of dy passed in valueAndGrads(f)([x1,...], dy) must match the shape returned by f([x1,...])"), _m(r.grads), r;
	};
}
function hm(e, t) {
	v(xe(e), () => "The f passed in variableGrads(f) must be a function"), v(t == null || Array.isArray(t) && t.every((e) => e instanceof Oa), () => "The varList passed in variableGrads(f, varList) must be an array of variables");
	let n = t != null;
	if (!n) {
		t = [];
		for (let e in j.registeredVariables) t.push(j.registeredVariables[e]);
	}
	let r = n ? t.filter((e) => !e.trainable) : null, i = t.length;
	t = t.filter((e) => e.trainable), v(t.length > 0, () => `variableGrads() expects at least one of the input variables to be trainable, but none of the ${i} variables is trainable.`);
	let { value: a, grads: o } = j.gradients(e, t, null, !0);
	v(o.some((e) => e != null), () => "Cannot find a connection between any variable and the result of the loss function y=f(x). Please make sure the operations that use variables are inside the function f passed to minimize()."), v(a.rank === 0, () => `The f passed in variableGrads(f) must return a scalar, but it returned a rank-${a.rank} tensor`);
	let s = {};
	return t.forEach((e, t) => {
		o[t] != null && (s[e.name] = o[t]);
	}), r?.forEach((e) => s[e.name] = null), {
		value: a,
		grads: s
	};
}
function gm(e) {
	return j.customGrad(e);
}
function _m(e) {
	if (e.filter((e) => e == null).length > 0) throw Error("Cannot compute gradient of y=f(x) with respect to x. Make sure that\n    the f you passed encloses all operations that lead from x to y.");
}
var vm = e((() => {
	M(), ka(), P(), D();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/neg.js
function ym(e) {
	let t = { x: N(e, "x", "neg") };
	return j.runKernel("Neg", t);
}
var bm, xm = e((() => {
	M(), T(), P(), I(), bm = /* @__PURE__ */ F({ neg_: ym });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/softplus.js
function Sm(e) {
	let t = { x: N(e, "x", "softplus") };
	return j.runKernel(jr, t);
}
var Cm, wm = e((() => {
	M(), T(), P(), I(), Cm = /* @__PURE__ */ F({ softplus_: Sm });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/log_sigmoid.js
function Tm(e) {
	let t = N(e, "x", "logSigmoid");
	return gm((e) => ({
		value: bm(Cm(bm(e))),
		gradFunc: (t) => H(t, Yl(bm(e)))
	}))(t);
}
var Em, Dm = e((() => {
	vm(), P(), U(), xm(), I(), Xl(), wm(), Em = /* @__PURE__ */ F({ logSigmoid_: Tm });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/sub.js
function Om(e, t) {
	let n = N(e, "a", "sub"), r = N(t, "b", "sub");
	[n, r] = k(n, r);
	let i = {
		a: n,
		b: r
	};
	return j.runKernel("Sub", i);
}
var Z, km = e((() => {
	M(), T(), A(), P(), I(), Z = /* @__PURE__ */ F({ sub_: Om });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/log_softmax.js
function Am(e, t = -1) {
	let n = N(e, "logits", "logSoftmax");
	if (t === -1 && (t = n.rank - 1), t !== n.rank - 1) throw Error(`Log Softmax along a non-last dimension is not yet supported. Logits was rank ${n.rank} and axis was ${t}`);
	return gm((e, n) => {
		let r = If(e, t, !0), i = Z(e, r), a = Z(R(i, "float32"), om(X(sp(i), t, !0)));
		return n([a]), {
			value: a,
			gradFunc: (e, n) => {
				let [r] = n, i = sp(r);
				return Z(e, H(X(e, t, !0), i));
			}
		};
	})(n);
}
var jm, Mm = e((() => {
	vm(), P(), _c(), cp(), sm(), Lf(), U(), I(), km(), Qf(), jm = /* @__PURE__ */ F({ logSoftmax_: Am });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/log_sum_exp.js
function Nm(e, t = null, n = !1) {
	let r = N(e, "x", "logSumExp"), i = ce(t, r.shape), a = If(r, i, !0), o = Z(r, a), s = sp(o), c = X(s, i), l = om(c), u = z(W(a, l.shape), l);
	if (n) {
		let e = kf(u.shape, i);
		return W(u, e);
	}
	return u;
}
var Pm, Fm = e((() => {
	P(), D(), B(), Pf(), cp(), sm(), Lf(), I(), G(), km(), Qf(), Pm = /* @__PURE__ */ F({ logSumExp_: Nm });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/logical_and.js
function Im(e, t) {
	let n = N(e, "a", "logicalAnd", "bool"), r = N(t, "b", "logicalAnd", "bool");
	J(n.shape, r.shape);
	let i = {
		a: n,
		b: r
	};
	return j.runKernel(Cn, i);
}
var Lm, Rm = e((() => {
	M(), T(), P(), Zd(), I(), Lm = /* @__PURE__ */ F({ logicalAnd_: Im });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/logical_not.js
function zm(e) {
	let t = { x: N(e, "x", "logicalNot", "bool") };
	return j.runKernel(wn, t);
}
var Bm, Vm = e((() => {
	M(), T(), P(), I(), Bm = /* @__PURE__ */ F({ logicalNot_: zm });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/logical_or.js
function Hm(e, t) {
	let n = N(e, "a", "logicalOr", "bool"), r = N(t, "b", "logicalOr", "bool");
	J(n.shape, r.shape);
	let i = {
		a: n,
		b: r
	};
	return j.runKernel(Tn, i);
}
var Um, Wm = e((() => {
	M(), T(), P(), Zd(), I(), Um = /* @__PURE__ */ F({ logicalOr_: Hm });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/logical_xor.js
function Gm(e, t) {
	let n = N(e, "a", "logicalXor", "bool"), r = N(t, "b", "logicalXor", "bool");
	return J(n.shape, r.shape), Lm(Um(e, t), Bm(Lm(e, t)));
}
var Km, qm = e((() => {
	P(), Zd(), Rm(), Vm(), Wm(), I(), Km = /* @__PURE__ */ F({ logicalXor_: Gm });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/search_sorted.js
function Jm(e, t, n = "left") {
	let r = N(e, "sortedSequence", "searchSorted"), i = N(t, "values", "searchSorted"), a = r.shape[r.shape.length - 1], o = i.shape[i.shape.length - 1], s = W(r, [-1, a]), c = W(i, [-1, o]);
	if (s.rank < 2) throw Error("Sorted input argument must be at least 2-dimensional");
	if (s.shape[0] !== c.shape[0]) throw Error("Leading dimension of 'sortedSequence' and 'values' must match.");
	if (x(c.shape) >= Ym) throw Error(`values tensor size must less than ${Ym}`);
	if (s.shape[1] >= Ym) throw Error(`trailing dim_size must less than ${Ym} for int32 output type, was ${s.shape[1]}`);
	let l = {
		sortedSequence: s,
		values: c
	}, u = { side: n };
	return j.runKernel(Cr, l, u);
}
var Ym, Xm, Zm = e((() => {
	M(), T(), P(), Pe(), I(), G(), Ym = 2147483648, Xm = /* @__PURE__ */ F({ searchSorted_: Jm });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/lower_bound.js
function Qm(e, t) {
	return Xm(e, t, "left");
}
var $m = e((() => {
	Zm();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/max_pool.js
function eh(e, t, n, r, i) {
	let a = N(e, "x", "maxPool"), o = a, s = !1;
	a.rank === 3 && (s = !0, o = W(a, [
		1,
		a.shape[0],
		a.shape[1],
		a.shape[2]
	])), v(o.rank === 4, () => `Error in maxPool: input must be rank 4 but got rank ${o.rank}.`), v(jl(n, 1), () => `Error in maxPool: Either strides or dilations must be 1. Got strides ${n} and dilations '1'`), Pl("maxPool", r, i);
	let c = { x: o }, l = {
		filterSize: t,
		strides: n,
		pad: r,
		dimRoundingMode: i
	}, u = j.runKernel(Pn, c, l);
	return s ? W(u, [
		u.shape[1],
		u.shape[2],
		u.shape[3]
	]) : u;
}
var th, nh = e((() => {
	M(), T(), P(), D(), Fl(), I(), G(), th = /* @__PURE__ */ F({ maxPool_: eh });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/max_pool_3d.js
function rh(e, t = [
	1,
	1,
	1
], n, r, i, a = "NDHWC") {
	let o = N(e, "x", "maxPool3d"), s = o, c = !1;
	o.rank === 4 && (c = !0, s = W(o, [
		1,
		o.shape[0],
		o.shape[1],
		o.shape[2],
		o.shape[3]
	])), v(s.rank === 5, () => `Error in maxPool3d: x must be rank 5 but got rank ${s.rank}.`), v(a === "NDHWC", () => `Error in maxPool3d: Only NDHWC is currently supported, but got dataFormat of ${a}`), Pl("maxPool3d", r, i);
	let l = { x: s }, u = {
		filterSize: t,
		strides: n,
		pad: r,
		dimRoundingMode: i,
		dataFormat: a
	}, d = j.runKernel(In, l, u);
	return c ? W(d, [
		d.shape[1],
		d.shape[2],
		d.shape[3],
		d.shape[4]
	]) : d;
}
var ih, ah = e((() => {
	M(), T(), P(), D(), Fl(), I(), G(), ih = /* @__PURE__ */ F({ maxPool3d_: rh });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/max_pool_with_argmax.js
function oh(e, t, n, r, i = !1) {
	let a = { x: N(e, "x", "maxPoolWithArgmax") }, o = {
		filterSize: t,
		strides: n,
		pad: r,
		includeBatchInIndex: i
	}, s = j.runKernel(Rn, a, o);
	return {
		result: s[0],
		indexes: s[1]
	};
}
var sh, ch = e((() => {
	M(), T(), P(), I(), sh = /* @__PURE__ */ F({ maxPoolWithArgmax_: oh });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/maximum.js
function lh(e, t) {
	let n = N(e, "a", "maximum"), r = N(t, "b", "maximum");
	[n, r] = k(n, r), n.dtype === "bool" && (n = R(n, "int32"), r = R(r, "int32")), J(n.shape, r.shape);
	let i = {
		a: n,
		b: r
	};
	return j.runKernel(Nn, i);
}
var uh, dh = e((() => {
	M(), T(), A(), P(), Zd(), _c(), I(), uh = /* @__PURE__ */ F({ maximum_: lh });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/mean.js
function fh(e, t = null, n = !1) {
	let r = { x: N(e, "x", "mean") }, i = {
		axis: t,
		keepDims: n
	};
	return j.runKernel(zn, r, i);
}
var ph, mh = e((() => {
	M(), T(), P(), I(), ph = /* @__PURE__ */ F({ mean_: fh });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/zeros.js
function hh(e, t = "float32") {
	if (Ae(e), t === "complex64") {
		let t = hh(e, "float32"), n = hh(e, "float32");
		return ho(t, n);
	}
	let n = Oe(x(e), t);
	return j.makeTensor(n, e, t);
}
var gh = e((() => {
	M(), D(), go();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/ones.js
function _h(e, t = "float32") {
	if (Ae(e), t === "complex64") {
		let t = _h(e, "float32"), n = hh(e, "float32");
		return ho(t, n);
	}
	let n = De(x(e), t);
	return j.makeTensor(n, e, t);
}
var vh = e((() => {
	M(), D(), Pe(), go(), gh();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/meshgrid.js
function yh(e, t, { indexing: n = "xy" } = {}) {
	if (n !== "xy" && n !== "ij") throw TypeError(`${n} is not a valid third argument to meshgrid`);
	if (e === void 0) return [];
	let r = N(e, "x", "meshgrid", e instanceof O ? e.dtype : "float32");
	if (t === void 0) return [r];
	let i = N(t, "y", "meshgrid", t instanceof O ? t.dtype : "float32"), a = x(r.shape), o = x(i.shape);
	return n === "xy" ? (r = W(r, [1, -1]), i = W(i, [-1, 1]), [K(_h([o, 1], r.dtype), r), K(i, _h([1, a], i.dtype))]) : (r = W(r, [-1, 1]), i = W(i, [1, -1]), [K(r, _h([1, o], r.dtype)), K(_h([a, 1], i.dtype), i)]);
}
var bh = e((() => {
	ql(), vh(), G(), ka(), P(), Pe();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/minimum.js
function xh(e, t) {
	let n = N(e, "a", "minimum"), r = N(t, "b", "minimum");
	[n, r] = k(n, r), n.dtype === "bool" && (n = R(n, "int32"), r = R(r, "int32")), J(n.shape, r.shape);
	let i = {
		a: n,
		b: r
	};
	return j.runKernel(Vn, i);
}
var Sh, Ch = e((() => {
	M(), T(), A(), P(), Zd(), _c(), I(), Sh = /* @__PURE__ */ F({ minimum_: xh });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/mirror_pad.js
function wh(e, t, n) {
	v(n === "reflect" || n === "symmetric", () => `Invalid mode. Mode must be either reflect or symmetric. Got ${n}.`);
	let r = N(e, "x", "mirrorPad");
	if (r.rank === 0) throw Error("mirrorPad(scalar) is not defined. Pass non-scalar to mirrorPad");
	v(t.length === r.rank, () => `Padding doesn't match input. Must be ${r.rank}. Got ${t.length}.`);
	let i = +(n === "reflect");
	for (let e = 0; e < r.rank; e++) v(t[e].length === 2, () => "Invalid number of paddings. Must be length of 2 each."), v(t[e][0] >= 0 && t[e][0] <= r.shape[e] - i && t[e][1] >= 0 && t[e][1] <= r.shape[e] - i, () => `Padding in dimension ${e} cannot be greater than or equal to ${r.shape[e] - i} or less than 0 for input of shape ${r.shape}`);
	let a = {
		paddings: t,
		mode: n
	}, o = { x: r };
	return j.runKernel(Hn, o, a);
}
var Th, Eh = e((() => {
	M(), T(), P(), D(), I(), Th = /* @__PURE__ */ F({ mirrorPad_: wh });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/mod.js
function Dh(e, t) {
	let n = N(e, "a", "mod"), r = N(t, "b", "mod");
	[n, r] = k(n, r);
	let i = {
		a: n,
		b: r
	};
	return j.runKernel("Mod", i);
}
var Oh, kh = e((() => {
	M(), T(), A(), P(), I(), Oh = /* @__PURE__ */ F({ mod_: Dh });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/moments.js
function Ah(e, t = null, n = !1) {
	e = N(e, "x", "moments");
	let r = ce(t, e.shape), i = ph(e, r, n), a = i.shape;
	n || (a = kf(i.shape, r));
	let o = Yf(Z(R(e, "float32"), W(i, a)));
	return {
		mean: i,
		variance: ph(o, r, n)
	};
}
var jh, Mh = e((() => {
	P(), D(), Pf(), _c(), mh(), I(), G(), Xf(), km(), jh = /* @__PURE__ */ F({ moments_: Ah });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/multi_rnn_cell.js
function Nh(e, t, n, r) {
	let i = N(t, "data", "multiRNNCell"), a = fo(n, "c", "multiRNNCell"), o = fo(r, "h", "multiRNNCell"), s = i, c = [];
	for (let t = 0; t < e.length; t++) {
		let n = e[t](s, a[t], o[t]);
		c.push(n[0]), c.push(n[1]), s = n[1];
	}
	let l = [], u = [];
	for (let e = 0; e < c.length; e += 2) l.push(c[e]), u.push(c[e + 1]);
	return [l, u];
}
var Ph, Fh = e((() => {
	P(), I(), Ph = /* @__PURE__ */ F({ multiRNNCell_: Nh });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/multinomial.js
function Ih(e, t, n, r = !1) {
	let i = N(e, "logits", "multinomial"), a = i.size, o = i.rank;
	if (a < 2) throw Error(`Error in multinomial: you need at least 2 outcomes, but got ${a}.`);
	if (o > 2) throw Error(`Rank of probabilities must be 1 or 2, but is ${o}`);
	n ||= Math.random();
	let s = { logits: o === 1 ? W(i, [1, -1]) : i }, c = {
		numSamples: t,
		seed: n,
		normalized: r
	}, l = j.runKernel(Wn, s, c);
	return o === 1 ? W(l, [l.size]) : l;
}
var Lh, Rh = e((() => {
	M(), T(), P(), I(), G(), Lh = /* @__PURE__ */ F({ multinomial_: Ih });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/not_equal.js
function zh(e, t) {
	let n = N(e, "a", "notEqual", "string_or_numeric"), r = N(t, "b", "notEqual", "string_or_numeric");
	[n, r] = k(n, r), J(n.shape, r.shape);
	let i = {
		a: n,
		b: r
	};
	return j.runKernel(qn, i);
}
var Bh, Vh = e((() => {
	M(), T(), A(), P(), Zd(), I(), Bh = /* @__PURE__ */ F({ notEqual_: zh });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/one_hot.js
function Hh(e, t, n = 1, r = 0, i = "int32") {
	if (t < 2) throw Error(`Error in oneHot: depth must be >=2, but it is ${t}`);
	let a = { indices: N(e, "indices", "oneHot", "int32") }, o = {
		dtype: i,
		depth: t,
		onValue: n,
		offValue: r
	};
	return j.runKernel(Qn, a, o);
}
var Uh, Wh = e((() => {
	M(), T(), P(), I(), Uh = /* @__PURE__ */ F({ oneHot_: Hh });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/ones_like.js
function Gh(e) {
	let t = { x: N(e, "x", "onesLike") };
	return j.runKernel(Zn, t);
}
var Kh, qh = e((() => {
	M(), T(), P(), I(), Kh = /* @__PURE__ */ F({ onesLike_: Gh });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/outer_product.js
function Jh(e, t) {
	let n = N(e, "v1", "outerProduct"), r = N(t, "v2", "outerProduct");
	v(n.rank === 1 && r.rank === 1, () => `Error in outerProduct: inputs must be rank 1, but got ranks ${n.rank} and ${r.rank}.`);
	let i = W(n, [-1, 1]), a = W(r, [1, -1]);
	return K(i, a);
}
var Yh, Xh = e((() => {
	P(), D(), ql(), I(), G(), Yh = /* @__PURE__ */ F({ outerProduct_: Jh });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/pad.js
function Zh(e, t, n = 0) {
	let r = N(e, "x", "pad");
	if (r.rank === 0) throw Error("pad(scalar) is not defined. Pass non-scalar to pad");
	let i = {
		paddings: t,
		constantValue: n
	}, a = { x: r };
	return j.runKernel(er, a, i);
}
var Qh, $h = e((() => {
	M(), T(), P(), I(), Qh = /* @__PURE__ */ F({ pad_: Zh });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/pad1d.js
function eg(e, t, n = 0) {
	return v(t.length === 2, () => "Invalid number of paddings. Must be length of 2."), Qh(e, [t], n);
}
var tg, ng = e((() => {
	D(), I(), $h(), tg = /* @__PURE__ */ F({ pad1d_: eg });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/pad2d.js
function rg(e, t, n = 0) {
	return v(t.length === 2 && t[0].length === 2 && t[1].length === 2, () => "Invalid number of paddings. Must be length of 2 each."), Qh(e, t, n);
}
var ig, ag = e((() => {
	D(), I(), $h(), ig = /* @__PURE__ */ F({ pad2d_: rg });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/pad3d.js
function og(e, t, n = 0) {
	return v(t.length === 3 && t[0].length === 2 && t[1].length === 2 && t[2].length === 2, () => "Invalid number of paddings. Must be length of 2 each."), Qh(e, t, n);
}
var sg, cg = e((() => {
	D(), I(), $h(), sg = /* @__PURE__ */ F({ pad3d_: og });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/pad4d.js
function lg(e, t, n = 0) {
	return v(t.length === 4 && t[0].length === 2 && t[1].length === 2 && t[2].length === 2 && t[3].length === 2, () => "Invalid number of paddings. Must be length of 2 each."), Qh(e, t, n);
}
var ug, dg = e((() => {
	D(), I(), $h(), ug = /* @__PURE__ */ F({ pad4d_: lg });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/space_to_batch_nd.js
function fg(e, t, n) {
	let r = N(e, "x", "spaceToBatchND");
	v(r.rank >= 1 + t.length, () => `input rank ${r.rank} should be > than [blockShape] ${t.length}`), v(n.length === t.length, () => `paddings.shape[0] ${n.length} must be equal to [blockShape] ${t.length}`), v(r.shape.reduce((e, r, i) => i > 0 && i <= t.length ? e && (r + n[i - 1][0] + n[i - 1][1]) % t[i - 1] === 0 : e, !0), () => `input spatial dimensions ${r.shape.slice(1)} with paddings ${n.toString()} must be divisible by blockShapes ${t.toString()}`);
	let i = { x: r }, a = {
		blockShape: t,
		paddings: n
	};
	return j.runKernel(Pr, i, a);
}
var pg, mg = e((() => {
	M(), T(), P(), D(), I(), pg = /* @__PURE__ */ F({ spaceToBatchND_: fg });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/pool.js
function hg(e, t, n, r, i, a, o) {
	i ??= [1, 1], a ??= 1, r === 0 && (r = "valid");
	let s = N(e, "x", "maxPool"), c = s, l = !1;
	s.rank === 3 && (l = !0, c = W(s, [
		1,
		s.shape[0],
		s.shape[1],
		s.shape[2]
	])), v(jl(a, i), () => `Error in pool: Either strides or dilations must be 1. Got strides ${a} and dilations '${i}'`);
	let u = _l(c.shape, t, a, i, r), d = [u.dilationHeight, u.dilationWidth], f;
	f = r === "same" ? _g([u.filterHeight, u.filterWidth], d) : [[0, 0], [0, 0]];
	let p = d[0] === 1 && d[1] === 1, [m, h] = gg([u.inHeight, u.inWidth], d, f), g = p ? r : "valid", _ = p ? c : pg(c, d, m), y = (n === "avg" ? () => Rl(_, t, a, g, o) : () => th(_, t, a, g, o))(), b = p ? y : ou(y, d, h);
	return l ? W(b, [
		b.shape[1],
		b.shape[2],
		b.shape[3]
	]) : b;
}
function gg(e, t, n) {
	let r = n.map((e) => e[0]), i = n.map((e) => e[1]), a = e.concat(r, i), o = t.map((e, t) => (e - a[t] % e) % e), s = i.map((e, t) => e + o[t]);
	return [t.map((e, t) => [r[t], s[t]]), t.map((e, t) => [0, o[t]])];
}
function _g(e, t) {
	let n = e.map((e, n) => e + (e - 1) * (t[n] - 1)).map((e) => e - 1), r = n.map((e) => Math.floor(e / 2)), i = n.map((e, t) => e - r[t]);
	return n.map((e, t) => [r[t], i[t]]);
}
var vg, yg = e((() => {
	P(), D(), zl(), su(), Fl(), nh(), I(), G(), mg(), vg = /* @__PURE__ */ F({ pool_: hg });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/prelu.js
function bg(e, t) {
	let n = {
		x: N(e, "x", "prelu"),
		alpha: N(t, "alpha", "prelu")
	};
	return j.runKernel(rr, n);
}
var xg, Sg = e((() => {
	M(), T(), P(), I(), xg = /* @__PURE__ */ F({ prelu_: bg });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/prod.js
function Cg(e, t = null, n = !1) {
	let r = N(e, "x", "prod");
	r.dtype === "bool" && (r = R(r, "int32"));
	let i = { x: r }, a = {
		axis: t,
		keepDims: n
	};
	return j.runKernel(ir, i, a);
}
var wg, Tg = e((() => {
	M(), T(), P(), _c(), I(), wg = /* @__PURE__ */ F({ prod_: Cg });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/ragged_gather.js
function Eg(e, t, n, r) {
	let i = {
		paramsNestedSplits: e.map((e, t) => N(e, `tensors${t}`, "raggedGather", "int32")),
		paramsDenseValues: N(t, "paramsDenseValues", "raggedGather"),
		indices: N(n, "indices", "raggedGather", "int32")
	}, a = { outputRaggedRank: r }, o = j.runKernel(ar, i, a);
	return {
		outputNestedSplits: o.slice(0, o.length - 1),
		outputDenseValues: o[o.length - 1]
	};
}
var Dg, Og = e((() => {
	M(), T(), P(), I(), Dg = /* @__PURE__ */ F({ raggedGather_: Eg });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/ragged_range.js
function kg(e, t, n) {
	let r = N(e, "starts", "raggedRange"), i = {
		starts: r,
		limits: N(t, "limits", "raggedRange", r.dtype),
		deltas: N(n, "deltas", "raggedRange", r.dtype)
	}, a = j.runKernel(or, i);
	return {
		rtNestedSplits: a[0],
		rtDenseValues: a[1]
	};
}
var Ag, jg = e((() => {
	M(), T(), P(), I(), Ag = /* @__PURE__ */ F({ raggedRange_: kg });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/ragged_tensor_to_tensor.js
function Mg(e, t, n, r, i) {
	let a = N(e, "shape", "raggedTensorToTensor", "int32"), o = N(t, "values", "raggedTensorToTensor"), s = {
		shape: a,
		values: o,
		defaultValue: N(n, "defaultValue", "raggedTensorToTensor", o.dtype),
		rowPartitionTensors: r.map((e, t) => N(e, `tensors${t}`, "raggedTensorToTensor", "int32"))
	}, c = { rowPartitionTypes: i };
	return j.runKernel(sr, s, c);
}
var Ng, Pg = e((() => {
	M(), T(), P(), I(), Ng = /* @__PURE__ */ F({ raggedTensorToTensor_: Mg });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/rand.js
function Fg(e, t, n) {
	Ae(e);
	let r = x(e), i = null;
	if (n == null || n === "float32") i = new Float32Array(r);
	else if (n === "int32") i = new Int32Array(r);
	else if (n === "bool") i = new Uint8Array(r);
	else throw Error(`Unknown data type ${n}`);
	for (let e = 0; e < r; e++) i[e] = t();
	return j.makeTensor(i, e, n);
}
var Ig, Lg = e((() => {
	M(), D(), Pe(), I(), Ig = /* @__PURE__ */ F({ rand_: Fg });
})), Rg = /* @__PURE__ */ r(((e, t, n) => {
	(function(e, t, n) {
		function r(e) {
			var t = this, n = o();
			t.next = function() {
				var e = 2091639 * t.s0 + t.c * 23283064365386963e-26;
				return t.s0 = t.s1, t.s1 = t.s2, t.s2 = e - (t.c = e | 0);
			}, t.c = 1, t.s0 = n(" "), t.s1 = n(" "), t.s2 = n(" "), t.s0 -= n(e), t.s0 < 0 && (t.s0 += 1), t.s1 -= n(e), t.s1 < 0 && (t.s1 += 1), t.s2 -= n(e), t.s2 < 0 && (t.s2 += 1), n = null;
		}
		function i(e, t) {
			return t.c = e.c, t.s0 = e.s0, t.s1 = e.s1, t.s2 = e.s2, t;
		}
		function a(e, t) {
			var n = new r(e), a = t && t.state, o = n.next;
			return o.int32 = function() {
				return n.next() * 4294967296 | 0;
			}, o.double = function() {
				return o() + (o() * 2097152 | 0) * 11102230246251565e-32;
			}, o.quick = o, a && (typeof a == "object" && i(a, n), o.state = function() {
				return i(n, {});
			}), o;
		}
		function o() {
			var e = 4022871197;
			return function(t) {
				t = String(t);
				for (var n = 0; n < t.length; n++) {
					e += t.charCodeAt(n);
					var r = .02519603282416938 * e;
					e = r >>> 0, r -= e, r *= e, e = r >>> 0, r -= e, e += r * 4294967296;
				}
				return (e >>> 0) * 23283064365386963e-26;
			};
		}
		t && t.exports ? t.exports = a : n && n.amd ? n(function() {
			return a;
		}) : this.alea = a;
	})(n, typeof t == "object" && t, typeof define == "function" && define);
})), zg = /* @__PURE__ */ r(((e, t, n) => {
	(function(e, t, n) {
		function r(e) {
			var t = this, n = "";
			t.x = 0, t.y = 0, t.z = 0, t.w = 0, t.next = function() {
				var e = t.x ^ t.x << 11;
				return t.x = t.y, t.y = t.z, t.z = t.w, t.w ^= t.w >>> 19 ^ e ^ e >>> 8;
			}, e === (e | 0) ? t.x = e : n += e;
			for (var r = 0; r < n.length + 64; r++) t.x ^= n.charCodeAt(r) | 0, t.next();
		}
		function i(e, t) {
			return t.x = e.x, t.y = e.y, t.z = e.z, t.w = e.w, t;
		}
		function a(e, t) {
			var n = new r(e), a = t && t.state, o = function() {
				return (n.next() >>> 0) / 4294967296;
			};
			return o.double = function() {
				do
					var e = ((n.next() >>> 11) + (n.next() >>> 0) / 4294967296) / (1 << 21);
				while (e === 0);
				return e;
			}, o.int32 = n.next, o.quick = o, a && (typeof a == "object" && i(a, n), o.state = function() {
				return i(n, {});
			}), o;
		}
		t && t.exports ? t.exports = a : n && n.amd ? n(function() {
			return a;
		}) : this.xor128 = a;
	})(n, typeof t == "object" && t, typeof define == "function" && define);
})), Bg = /* @__PURE__ */ r(((e, t, n) => {
	(function(e, t, n) {
		function r(e) {
			var t = this, n = "";
			t.next = function() {
				var e = t.x ^ t.x >>> 2;
				return t.x = t.y, t.y = t.z, t.z = t.w, t.w = t.v, (t.d = t.d + 362437 | 0) + (t.v = t.v ^ t.v << 4 ^ (e ^ e << 1)) | 0;
			}, t.x = 0, t.y = 0, t.z = 0, t.w = 0, t.v = 0, e === (e | 0) ? t.x = e : n += e;
			for (var r = 0; r < n.length + 64; r++) t.x ^= n.charCodeAt(r) | 0, r == n.length && (t.d = t.x << 10 ^ t.x >>> 4), t.next();
		}
		function i(e, t) {
			return t.x = e.x, t.y = e.y, t.z = e.z, t.w = e.w, t.v = e.v, t.d = e.d, t;
		}
		function a(e, t) {
			var n = new r(e), a = t && t.state, o = function() {
				return (n.next() >>> 0) / 4294967296;
			};
			return o.double = function() {
				do
					var e = ((n.next() >>> 11) + (n.next() >>> 0) / 4294967296) / (1 << 21);
				while (e === 0);
				return e;
			}, o.int32 = n.next, o.quick = o, a && (typeof a == "object" && i(a, n), o.state = function() {
				return i(n, {});
			}), o;
		}
		t && t.exports ? t.exports = a : n && n.amd ? n(function() {
			return a;
		}) : this.xorwow = a;
	})(n, typeof t == "object" && t, typeof define == "function" && define);
})), Vg = /* @__PURE__ */ r(((e, t, n) => {
	(function(e, t, n) {
		function r(e) {
			var t = this;
			t.next = function() {
				var e = t.x, n = t.i, r = e[n], i;
				return r ^= r >>> 7, i = r ^ r << 24, r = e[n + 1 & 7], i ^= r ^ r >>> 10, r = e[n + 3 & 7], i ^= r ^ r >>> 3, r = e[n + 4 & 7], i ^= r ^ r << 7, r = e[n + 7 & 7], r ^= r << 13, i ^= r ^ r << 9, e[n] = i, t.i = n + 1 & 7, i;
			};
			function n(e, t) {
				var n, r = [];
				if (t === (t | 0)) r[0] = t;
				else for (t = "" + t, n = 0; n < t.length; ++n) r[n & 7] = r[n & 7] << 15 ^ t.charCodeAt(n) + r[n + 1 & 7] << 13;
				for (; r.length < 8;) r.push(0);
				for (n = 0; n < 8 && r[n] === 0; ++n);
				for (n == 8 ? r[7] = -1 : r[n], e.x = r, e.i = 0, n = 256; n > 0; --n) e.next();
			}
			n(t, e);
		}
		function i(e, t) {
			return t.x = e.x.slice(), t.i = e.i, t;
		}
		function a(e, t) {
			e ??= +/* @__PURE__ */ new Date();
			var n = new r(e), a = t && t.state, o = function() {
				return (n.next() >>> 0) / 4294967296;
			};
			return o.double = function() {
				do
					var e = ((n.next() >>> 11) + (n.next() >>> 0) / 4294967296) / (1 << 21);
				while (e === 0);
				return e;
			}, o.int32 = n.next, o.quick = o, a && (a.x && i(a, n), o.state = function() {
				return i(n, {});
			}), o;
		}
		t && t.exports ? t.exports = a : n && n.amd ? n(function() {
			return a;
		}) : this.xorshift7 = a;
	})(n, typeof t == "object" && t, typeof define == "function" && define);
})), Hg = /* @__PURE__ */ r(((e, t, n) => {
	(function(e, t, n) {
		function r(e) {
			var t = this;
			t.next = function() {
				var e = t.w, n = t.X, r = t.i, i, a;
				return t.w = e = e + 1640531527 | 0, a = n[r + 34 & 127], i = n[r = r + 1 & 127], a ^= a << 13, i ^= i << 17, a ^= a >>> 15, i ^= i >>> 12, a = n[r] = a ^ i, t.i = r, a + (e ^ e >>> 16) | 0;
			};
			function n(e, t) {
				var n, r, i, a, o, s = [], c = 128;
				for (t === (t | 0) ? (r = t, t = null) : (t += "\0", r = 0, c = Math.max(c, t.length)), i = 0, a = -32; a < c; ++a) t && (r ^= t.charCodeAt((a + 32) % t.length)), a === 0 && (o = r), r ^= r << 10, r ^= r >>> 15, r ^= r << 4, r ^= r >>> 13, a >= 0 && (o = o + 1640531527 | 0, n = s[a & 127] ^= r + o, i = n == 0 ? i + 1 : 0);
				for (i >= 128 && (s[(t && t.length || 0) & 127] = -1), i = 127, a = 512; a > 0; --a) r = s[i + 34 & 127], n = s[i = i + 1 & 127], r ^= r << 13, n ^= n << 17, r ^= r >>> 15, n ^= n >>> 12, s[i] = r ^ n;
				e.w = o, e.X = s, e.i = i;
			}
			n(t, e);
		}
		function i(e, t) {
			return t.i = e.i, t.w = e.w, t.X = e.X.slice(), t;
		}
		function a(e, t) {
			e ??= +/* @__PURE__ */ new Date();
			var n = new r(e), a = t && t.state, o = function() {
				return (n.next() >>> 0) / 4294967296;
			};
			return o.double = function() {
				do
					var e = ((n.next() >>> 11) + (n.next() >>> 0) / 4294967296) / (1 << 21);
				while (e === 0);
				return e;
			}, o.int32 = n.next, o.quick = o, a && (a.X && i(a, n), o.state = function() {
				return i(n, {});
			}), o;
		}
		t && t.exports ? t.exports = a : n && n.amd ? n(function() {
			return a;
		}) : this.xor4096 = a;
	})(n, typeof t == "object" && t, typeof define == "function" && define);
})), Ug = /* @__PURE__ */ r(((e, t, n) => {
	(function(e, t, n) {
		function r(e) {
			var t = this, n = "";
			t.next = function() {
				var e = t.b, n = t.c, r = t.d, i = t.a;
				return e = e << 25 ^ e >>> 7 ^ n, n = n - r | 0, r = r << 24 ^ r >>> 8 ^ i, i = i - e | 0, t.b = e = e << 20 ^ e >>> 12 ^ n, t.c = n = n - r | 0, t.d = r << 16 ^ n >>> 16 ^ i, t.a = i - e | 0;
			}, t.a = 0, t.b = 0, t.c = -1640531527, t.d = 1367130551, e === Math.floor(e) ? (t.a = e / 4294967296 | 0, t.b = e | 0) : n += e;
			for (var r = 0; r < n.length + 20; r++) t.b ^= n.charCodeAt(r) | 0, t.next();
		}
		function i(e, t) {
			return t.a = e.a, t.b = e.b, t.c = e.c, t.d = e.d, t;
		}
		function a(e, t) {
			var n = new r(e), a = t && t.state, o = function() {
				return (n.next() >>> 0) / 4294967296;
			};
			return o.double = function() {
				do
					var e = ((n.next() >>> 11) + (n.next() >>> 0) / 4294967296) / (1 << 21);
				while (e === 0);
				return e;
			}, o.int32 = n.next, o.quick = o, a && (typeof a == "object" && i(a, n), o.state = function() {
				return i(n, {});
			}), o;
		}
		t && t.exports ? t.exports = a : n && n.amd ? n(function() {
			return a;
		}) : this.tychei = a;
	})(n, typeof t == "object" && t, typeof define == "function" && define);
})), Wg = /* @__PURE__ */ r(((e, t, n) => {
	(function(e, n, r) {
		var i = 256, a = 6, o = 52, s = "random", c = r.pow(i, a), l = r.pow(2, o), u = l * 2, d = i - 1, f;
		function p(e, t, o) {
			var d = [];
			t = t == 1 ? { entropy: !0 } : t || {};
			var f = _(g(t.entropy ? [e, y(n)] : e ?? v(), 3), d), p = new m(d), b = function() {
				for (var e = p.g(a), t = c, n = 0; e < l;) e = (e + n) * i, t *= i, n = p.g(1);
				for (; e >= u;) e /= 2, t /= 2, n >>>= 1;
				return (e + n) / t;
			};
			return b.int32 = function() {
				return p.g(4) | 0;
			}, b.quick = function() {
				return p.g(4) / 4294967296;
			}, b.double = b, _(y(p.S), n), (t.pass || o || function(e, t, n, i) {
				return i && (i.S && h(i, p), e.state = function() {
					return h(p, {});
				}), n ? (r[s] = e, t) : e;
			})(b, f, "global" in t ? t.global : this == r, t.state);
		}
		function m(e) {
			var t, n = e.length, r = this, a = 0, o = r.i = r.j = 0, s = r.S = [];
			for (n || (e = [n++]); a < i;) s[a] = a++;
			for (a = 0; a < i; a++) s[a] = s[o = d & o + e[a % n] + (t = s[a])], s[o] = t;
			(r.g = function(e) {
				for (var t, n = 0, a = r.i, o = r.j, s = r.S; e--;) t = s[a = d & a + 1], n = n * i + s[d & (s[a] = s[o = d & o + t]) + (s[o] = t)];
				return r.i = a, r.j = o, n;
			})(i);
		}
		function h(e, t) {
			return t.i = e.i, t.j = e.j, t.S = e.S.slice(), t;
		}
		function g(e, t) {
			var n = [], r = typeof e, i;
			if (t && r == "object") for (i in e) try {
				n.push(g(e[i], t - 1));
			} catch {}
			return n.length ? n : r == "string" ? e : e + "\0";
		}
		function _(e, t) {
			for (var n = e + "", r, i = 0; i < n.length;) t[d & i] = d & (r ^= t[d & i] * 19) + n.charCodeAt(i++);
			return y(t);
		}
		function v() {
			try {
				var t;
				return f && (t = f.randomBytes) ? t = t(i) : (t = new Uint8Array(i), (e.crypto || e.msCrypto).getRandomValues(t)), y(t);
			} catch {
				var r = e.navigator, a = r && r.plugins;
				return [
					+/* @__PURE__ */ new Date(),
					e,
					a,
					e.screen,
					y(n)
				];
			}
		}
		function y(e) {
			return String.fromCharCode.apply(0, e);
		}
		if (_(r.random(), n), typeof t == "object" && t.exports) {
			t.exports = p;
			try {
				f = lc();
			} catch {}
		} else typeof define == "function" && define.amd ? define(function() {
			return p;
		}) : r["seed" + s] = p;
	})(typeof self < "u" ? self : n, [], Math);
})), Gg = /* @__PURE__ */ r(((e, t) => {
	var n = Rg(), r = zg(), i = Bg(), a = Vg(), o = Hg(), s = Ug(), c = Wg();
	c.alea = n, c.xor128 = r, c.xorwow = i, c.xorshift7 = a, c.xor4096 = o, c.tychei = s, t.exports = c;
})), Kg = /* @__PURE__ */ n({
	TEST_EPSILON_FLOAT16: () => o_,
	createVideoElement: () => r_,
	encodeStrings: () => n_,
	expectArrayBuffersEqual: () => t_,
	expectArraysClose: () => qg,
	expectArraysEqual: () => Zg,
	expectNumbersClose: () => Qg,
	expectPromiseToFail: () => Xg,
	expectValuesInRange: () => e_,
	play: () => i_,
	testEpsilon: () => Jg
});
function qg(e, t, n) {
	return n ??= Jg(), Yg(e, t, (e, t) => $g(e, t, n));
}
function Jg() {
	return j.backend.floatPrecision() === 32 ? a_ : o_;
}
function Yg(e, t, n) {
	let r = !0;
	if ((ra(e) || ra(t)) && (r = !1), ra(e) && ra(t) && (r = !0), r) {
		let n = e.constructor.name, r = t.constructor.name;
		if (n !== r) throw Error(`Arrays are of different type. Actual: ${n}. Expected: ${r}`);
	}
	if (Array.isArray(e) && Array.isArray(t)) {
		let n = co(e), r = co(t);
		if (!S(n, r)) throw Error(`Arrays have different shapes. Actual: [${n}]. Expected: [${r}]`);
	}
	let i = ra(e) ? e : ia(e), a = ra(t) ? t : ia(t);
	if (i.length !== a.length) throw Error(`Arrays have different lengths actual: ${i.length} vs expected: ${a.length}.\nActual:   ${i}.\nExpected: ${a}.`);
	for (let e = 0; e < a.length; ++e) {
		let t = i[e], r = a[e];
		if (!n(t, r)) throw Error(`Arrays differ: actual[${e}] = ${t}, expected[${e}] = ${r}.\nActual:   ${i}.\nExpected: ${a}.`);
	}
	typeof expect < "u" && expect().nothing();
}
function Xg(e, t) {
	e().then(() => t.fail(), () => t()), typeof expect < "u" && expect().nothing();
}
function Zg(e, t) {
	let n = typeof t == "string" || typeof t == "number" || typeof t == "boolean" ? [t] : t;
	return _e(e) || _e(e[0]) || _e(t) || _e(t[0]) ? Yg(e, n, (e, t) => e == t) : Yg(e, t, (e, t) => $g(e, t, 0));
}
function Qg(e, t, n) {
	if (n ??= Jg(), !$g(e, t, n)) throw Error(`Numbers differ: actual === ${e}, expected === ${t}`);
	typeof expect < "u" && expect().nothing();
}
function $g(e, t, n) {
	return !isFinite(e) && !isFinite(t) || !(isNaN(e) || isNaN(t) || Math.abs(e - t) > n);
}
function e_(e, t, n) {
	for (let r = 0; r < e.length; r++) if (e[r] < t || e[r] > n) throw Error(`Value out of range:${e[r]} low: ${t}, high: ${n}`);
}
function t_(e, t) {
	let n = new Float32Array(e), r = new Float32Array(t);
	if (n.length !== r.length) throw Error(`Expected ArrayBuffer to be of length ${r.length}, but it was ${n.length}`);
	for (let e = 0; e < r.length; e++) if (n[e] !== r[e]) throw Error(`Expected ArrayBuffer value at ${e} to be ${r[e]} but got ${n[e]} instead`);
}
function n_(e) {
	for (let t = 0; t < e.length; t++) {
		let n = e[t];
		Array.isArray(n) ? n_(n) : e[t] = ta(n);
	}
	return e;
}
function r_(e) {
	let t = document.createElement("video");
	return "playsInline" in t && (t.playsInline = !0), t.muted = !0, t.loop = !0, t.style.position = "fixed", t.style.left = "0px", t.style.top = "0px", t.preload = "auto", t.appendChild(e), new Promise((e) => {
		t.addEventListener("loadeddata", (n) => e(t)), t.load();
	});
}
async function i_(e) {
	await e.play(), "requestVideoFrameCallback" in e && await new Promise((t) => {
		e.requestVideoFrameCallback(t);
	});
}
var a_, o_, s_ = e((() => {
	M(), P(), D(), a_ = .001, o_ = .1;
})), c_, l_, u_, d_, f_ = e((() => {
	c_ = /* @__PURE__ */ t(Gg()), l_ = class {
		constructor(e, t, n, r, i) {
			this.mean = e, this.stdDev = t, this.dtype = n, this.nextVal = NaN, this.truncated = r, this.truncated && (this.upper = this.mean + this.stdDev * 2, this.lower = this.mean - this.stdDev * 2);
			let a = i || Math.random();
			this.random = c_.alea(a.toString());
		}
		nextValue() {
			if (!isNaN(this.nextVal)) {
				let e = this.nextVal;
				return this.nextVal = NaN, e;
			}
			let e, t, n = !1;
			for (; !n;) {
				let r, i, a;
				do
					r = 2 * this.random() - 1, i = 2 * this.random() - 1, a = r * r + i * i;
				while (a >= 1 || a === 0);
				let o = Math.sqrt(-2 * Math.log(a) / a);
				e = this.mean + this.stdDev * r * o, t = this.mean + this.stdDev * i * o, (!this.truncated || this.isValidTruncated(e)) && (n = !0);
			}
			return (!this.truncated || this.isValidTruncated(t)) && (this.nextVal = this.convertValue(t)), this.convertValue(e);
		}
		convertValue(e) {
			return this.dtype == null || this.dtype === "float32" ? e : Math.round(e);
		}
		isValidTruncated(e) {
			return e <= this.upper && e >= this.lower;
		}
	}, u_ = class {
		constructor(e, t, n, r) {
			this.alpha = e, this.beta = 1 / t, this.dtype = n;
			let i = r || Math.random();
			this.randu = c_.alea(i.toString()), this.randn = new l_(0, 1, n, !1, this.randu()), this.d = e < 1 ? e + 2 / 3 : e - 1 / 3, this.c = 1 / Math.sqrt(9 * this.d);
		}
		nextValue() {
			let e, t, n, r, i, a;
			for (;;) {
				do
					r = this.randn.nextValue(), a = 1 + this.c * r;
				while (a <= 0);
				if (a *= a * a, e = r * r, t = 1 - .331 * e * e, n = .5 * e + this.d * (1 - a + Math.log(a)), i = this.randu(), i < t || Math.log(i) < n) break;
			}
			return a = 1 / this.beta * this.d * a, this.alpha < 1 && (a *= this.randu() ** (1 / this.alpha)), this.convertValue(a);
		}
		convertValue(e) {
			return this.dtype === "float32" ? e : Math.round(e);
		}
	}, d_ = class {
		constructor(e = 0, t = 1, n, r) {
			if (this.canReturnFloat = () => this.dtype == null || this.dtype === "float32", this.min = e, this.range = t - e, this.dtype = n, r ??= Math.random(), typeof r == "number" && (r = r.toString()), !this.canReturnFloat() && this.range <= 1) throw Error(`The difference between ${e} - ${t} <= 1 and dtype is not float`);
			this.random = c_.alea(r);
		}
		convertValue(e) {
			return this.canReturnFloat() ? e : Math.round(e);
		}
		nextValue() {
			return this.convertValue(this.min + this.range * this.random());
		}
	};
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/random_gamma.js
function p_(e, t, n = 1, r = "float32", i) {
	if (Ae(e), n ??= 1, r ??= "float32", r !== "float32" && r !== "int32") throw Error(`Unsupported data type ${r}`);
	let a = new u_(t, n, r, i), o = mc(e, r);
	for (let e = 0; e < o.values.length; e++) o.values[e] = a.nextValue();
	return o.toTensor();
}
var m_, h_ = e((() => {
	Pe(), hc(), I(), f_(), m_ = /* @__PURE__ */ F({ randomGamma_: p_ });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/random_normal.js
function g_(e, t = 0, n = 1, r, i) {
	if (Ae(e), r != null && r === "bool") throw Error(`Unsupported data type ${r}`);
	let a = new l_(t, n, r, !1, i), o = mc(e, r);
	for (let e = 0; e < o.values.length; e++) o.values[e] = a.nextValue();
	return o.toTensor();
}
var __, v_ = e((() => {
	Pe(), hc(), I(), f_(), __ = /* @__PURE__ */ F({ randomNormal_: g_ });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/random_standard_normal.js
function y_(e, t, n) {
	if (t != null && t === "bool") throw Error(`Unsupported data type ${t}`);
	return __(e, 0, 1, t, n);
}
var b_, x_ = e((() => {
	I(), v_(), b_ = /* @__PURE__ */ F({ randomStandardNormal_: y_ });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/random_uniform.js
function S_(e, t = 0, n = 1, r = "float32", i) {
	Ae(e);
	let a = mc(e, r), o = new d_(t, n, null, i);
	for (let e = 0; e < a.values.length; e++) a.values[e] = o.nextValue();
	return a.toTensor();
}
var C_, w_ = e((() => {
	Pe(), hc(), I(), f_(), C_ = /* @__PURE__ */ F({ randomUniform_: S_ });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/random_uniform_int.js
function T_(e, t, n, r) {
	return C_(e, t, n, "int32", r);
}
var E_, D_ = e((() => {
	I(), w_(), E_ = /* @__PURE__ */ F({ randomUniformInt_: T_ });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/range.js
function O_(e, t, n = 1, r = "float32") {
	if (n === 0) throw Error("Cannot have a step of zero");
	let i = {
		start: e,
		stop: t,
		step: n,
		dtype: r
	};
	return j.runKernel(cr, {}, i);
}
var k_ = e((() => {
	M(), T();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/real.js
function A_(e) {
	let t = { input: N(e, "input", "real") };
	return j.runKernel(lr, t);
}
var j_, M_ = e((() => {
	M(), T(), P(), I(), j_ = /* @__PURE__ */ F({ real_: A_ });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/reciprocal.js
function N_(e) {
	let t = { x: N(e, "x", "reciprocal") };
	return j.runKernel(ur, t);
}
var P_, F_ = e((() => {
	M(), T(), P(), I(), P_ = /* @__PURE__ */ F({ reciprocal_: N_ });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/relu.js
function I_(e) {
	let t = { x: N(e, "x", "relu") };
	return j.runKernel(dr, t);
}
var L_, R_ = e((() => {
	M(), T(), P(), I(), L_ = /* @__PURE__ */ F({ relu_: I_ });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/relu6.js
function z_(e) {
	let t = { x: N(e, "x", "relu6") };
	return j.runKernel(_r, t);
}
var B_, V_ = e((() => {
	M(), T(), P(), I(), B_ = /* @__PURE__ */ F({ relu6_: z_ });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/reverse.js
function H_(e, t) {
	let n = { x: N(e, "x", "reverse") }, r = { dims: t };
	return j.runKernel(vr, n, r);
}
var U_, W_ = e((() => {
	M(), T(), P(), I(), U_ = /* @__PURE__ */ F({ reverse_: H_ });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/reverse_1d.js
function G_(e) {
	let t = N(e, "x", "reverse");
	return v(t.rank === 1, () => `Error in reverse1D: x must be rank 1 but got rank ${t.rank}.`), U_(t, 0);
}
var K_, q_ = e((() => {
	P(), D(), I(), W_(), K_ = /* @__PURE__ */ F({ reverse1d_: G_ });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/reverse_2d.js
function J_(e, t) {
	let n = N(e, "x", "reverse");
	return v(n.rank === 2, () => `Error in reverse2D: x must be rank 2 but got rank ${n.rank}.`), U_(n, t);
}
var Y_, X_ = e((() => {
	P(), D(), I(), W_(), Y_ = /* @__PURE__ */ F({ reverse2d_: J_ });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/reverse_3d.js
function Z_(e, t) {
	let n = N(e, "x", "reverse");
	return v(n.rank === 3, () => `Error in reverse3D: x must be rank 3 but got rank ${n.rank}.`), U_(n, t);
}
var Q_, $_ = e((() => {
	P(), D(), I(), W_(), Q_ = /* @__PURE__ */ F({ reverse3d_: Z_ });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/reverse_4d.js
function ev(e, t) {
	let n = N(e, "x", "reverse");
	return v(n.rank === 4, () => `Error in reverse4D: x must be rank 4 but got rank ${n.rank}.`), U_(n, t);
}
var tv, nv = e((() => {
	P(), D(), I(), W_(), tv = /* @__PURE__ */ F({ reverse4d_: ev });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/round.js
function rv(e) {
	let t = { x: N(e, "x", "round") };
	return j.runKernel(yr, t);
}
var iv, av = e((() => {
	M(), T(), P(), I(), iv = /* @__PURE__ */ F({ round_: rv });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/rsqrt.js
function ov(e) {
	let t = { x: N(e, "x", "rsqrt", "float32") };
	return j.runKernel(br, t);
}
var sv, cv = e((() => {
	M(), T(), P(), I(), sv = /* @__PURE__ */ F({ rsqrt_: ov });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/selu.js
function lv(e) {
	let t = { x: N(e, "x", "selu") };
	return j.runKernel(Tr, t);
}
var uv, dv = e((() => {
	M(), T(), P(), I(), uv = /* @__PURE__ */ F({ selu_: lv });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/separable_conv2d.js
function fv(e, t, n, r, i, a = [1, 1], o = "NHWC") {
	let s = N(e, "x", "separableConv2d"), c = N(t, "depthwiseFilter", "separableConv2d"), l = N(n, "pointwiseFilter", "separableConv2d"), u = s, d = !1;
	if (s.rank === 3 && (d = !0, u = W(s, [
		1,
		s.shape[0],
		s.shape[1],
		s.shape[2]
	])), o === "NCHW") throw Error("separableConv2d currently does not support dataFormat NCHW; only NHWC is supported");
	v(u.rank === 4, () => `Error in separableConv2d: input must be rank 4, but got rank ${u.rank}.`), v(c.rank === 4, () => `Error in separableConv2d: depthwise filter must be rank 4, but got rank ${c.rank}.`), v(l.rank === 4, () => `Error in separableConv2d: pointwise filter must be rank 4, but got rank ${c.rank}.`), v(l.shape[0] === 1, () => `Error in separableConv2d: the first dimension of pointwise filter  must be 1, but got ${l.shape[0]}.`), v(l.shape[1] === 1, () => `Error in separableConv2d: the second dimension of pointwise filter must be 1, but got ${l.shape[1]}.`);
	let f = c.shape[2], p = c.shape[3];
	v(l.shape[2] === f * p, () => `Error in separableConv2d: the third dimension of pointwise filter must be ${f * p}, but got ${l.shape[2]}.`);
	let m = Bd(u, c, r, i, o, a), h = td(m, l, 1, "valid", o);
	return d ? W(h, [
		h.shape[1],
		h.shape[2],
		h.shape[3]
	]) : h;
}
var pv, mv = e((() => {
	P(), D(), nd(), Vd(), I(), G(), pv = /* @__PURE__ */ F({ separableConv2d_: fv });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/setdiff1d_async.js
async function hv(e, t) {
	let n = N(e, "x", "setdiff1d"), r = N(t, "y", "setdiff1d");
	v(n.dtype === r.dtype, () => `x and y should have the same dtype, but got x (${n.dtype}) and y (${r.dtype}).`), v(n.rank === 1, () => `x should be 1D tensor, but got x (${n.shape}).`), v(r.rank === 1, () => `y should be 1D tensor, but got y (${r.shape}).`);
	let i = await n.data(), a = await r.data(), o = new Set(a), s = 0;
	for (let e = 0; e < i.length; e++) o.has(i[e]) || s++;
	let c = new Ta([s], n.dtype), l = new Ta([s], "int32");
	for (let e = 0, t = 0; e < i.length; e++) o.has(i[e]) || (c.values[t] = i[e], l.values[t] = e, t++);
	return [c.toTensor(), l.toTensor()];
}
var gv, _v = e((() => {
	ka(), P(), D(), gv = hv;
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/sign.js
function vv(e) {
	let t = { x: N(e, "x", "sign") };
	return j.runKernel(kr, t);
}
var yv, bv = e((() => {
	M(), T(), P(), I(), yv = /* @__PURE__ */ F({ sign_: vv });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/sin.js
function xv(e) {
	let t = { x: N(e, "x", "sin", "float32") };
	return j.runKernel("Sin", t);
}
var Sv, Cv = e((() => {
	M(), T(), P(), I(), Sv = /* @__PURE__ */ F({ sin_: xv });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/sinh.js
function wv(e) {
	let t = { x: N(e, "x", "sinh") };
	return j.runKernel(Or, t);
}
var Tv, Ev = e((() => {
	M(), T(), P(), I(), Tv = /* @__PURE__ */ F({ sinh_: wv });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/slice1d.js
function Dv(e, t, n) {
	let r = N(e, "x", "slice1d");
	return v(r.rank === 1, () => `slice1d expects a rank-1 tensor, but got a rank-${r.rank} tensor`), q(r, [t], [n]);
}
var Ov, kv = e((() => {
	P(), D(), I(), Ql(), Ov = /* @__PURE__ */ F({ slice1d_: Dv });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/slice2d.js
function Av(e, t, n) {
	let r = N(e, "x", "slice2d");
	return v(r.rank === 2, () => `slice2d expects a rank-2 tensor, but got a rank-${r.rank} tensor`), q(r, t, n);
}
var jv, Mv = e((() => {
	P(), D(), I(), Ql(), jv = /* @__PURE__ */ F({ slice2d_: Av });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/slice3d.js
function Nv(e, t, n) {
	let r = N(e, "x", "slice3d");
	return v(r.rank === 3, () => `slice3d expects a rank-3 tensor, but got a rank-${r.rank} tensor`), q(r, t, n);
}
var Pv, Fv = e((() => {
	P(), D(), I(), Ql(), Pv = /* @__PURE__ */ F({ slice3d_: Nv });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/slice4d.js
function Iv(e, t, n) {
	let r = N(e, "x", "slice4d");
	return v(r.rank === 4, () => `slice4d expects a rank-4 tensor, but got a rank-${r.rank} tensor`), q(r, t, n);
}
var Lv, Rv = e((() => {
	P(), D(), I(), Ql(), Lv = /* @__PURE__ */ F({ slice4d_: Iv });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/softmax.js
function zv(e, t = -1) {
	let n = N(e, "logits", "softmax", "float32");
	if (t === -1 && (t = n.rank - 1), t !== n.rank - 1) throw Error(`Softmax along a non-last dimension is not yet supported. Logits was rank ${n.rank} and dim was ${t}`);
	let r = { logits: n }, i = { dim: t };
	return j.runKernel(Ir, r, i);
}
var Bv, Vv = e((() => {
	M(), T(), P(), I(), Bv = /* @__PURE__ */ F({ softmax_: zv });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/spectral/fft.js
function Hv(e) {
	v(e.dtype === "complex64", () => `The dtype for tf.spectral.fft() must be complex64 but got ${e.dtype}.`);
	let t = { input: e };
	return j.runKernel("FFT", t);
}
var Uv, Wv = e((() => {
	M(), T(), D(), I(), Uv = /* @__PURE__ */ F({ fft_: Hv });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/spectral/ifft.js
function Gv(e) {
	v(e.dtype === "complex64", () => `The dtype for tf.spectral.ifft() must be complex64 but got ${e.dtype}.`);
	let t = { input: e };
	return j.runKernel(fn, t);
}
var Kv, qv = e((() => {
	M(), T(), D(), I(), Kv = /* @__PURE__ */ F({ ifft_: Gv });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/spectral/irfft.js
function Jv(e) {
	let t = e.shape[e.shape.length - 1], n = e.size / t, r;
	if (t <= 2) {
		let i = W(e, [n, t]);
		r = Kv(i);
	} else {
		let i = [n, 2 * (t - 1)], a = W(j_(e), [n, t]), o = W(Pp(e), [n, t]), s = U_(q(a, [0, 1], [n, t - 2]), 1), c = H(U_(q(o, [0, 1], [n, t - 2]), 1), Y(-1)), l = Wl([a, s], 1), u = Wl([o, c], 1), d = W(ho(l, u), [i[0], i[1]]);
		r = Kv(d);
	}
	if (r = j_(r), e.rank === 3 && e.shape[0] !== 0) {
		let t = r, n = e.shape[0];
		r = W(r, [
			n,
			r.shape[0] / n,
			r.shape[1]
		]), t.dispose();
	}
	return r;
}
var Yv, Xv = e((() => {
	go(), Gl(), Fp(), U(), I(), M_(), G(), W_(), Wf(), Ql(), qv(), Yv = /* @__PURE__ */ F({ irfft_: Jv });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/split.js
function Zv(e, t, n = 0) {
	let r = { x: N(e, "x", "split") }, i = {
		numOrSizeSplits: t,
		axis: n
	};
	return j.runKernel(Fr, r, i);
}
var Qv, $v = e((() => {
	M(), T(), P(), I(), Qv = /* @__PURE__ */ F({ split_: Zv });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/spectral/rfft.js
function ey(e, t) {
	v(e.dtype === "float32", () => `The dtype for rfft() must be real value but got ${e.dtype}`);
	let n = e.shape[e.shape.length - 1], r = e.size / n, i;
	if (t != null && t < n) {
		let r = e.shape.map((e) => 0), a = e.shape.map((e) => e);
		a[e.shape.length - 1] = t, i = q(e, r, a), n = t;
	} else if (t != null && t > n) {
		let r = e.shape.map((e) => e);
		r[e.shape.length - 1] = t - n, i = Wl([e, hh(r)], e.shape.length - 1), n = t;
	} else i = e;
	let a = of(i), o = W(ho(i, a), [r, n]), s = Uv(o), c = Math.floor(n / 2) + 1, l = j_(s), u = Pp(s), d = Qv(l, [c, n - c], l.shape.length - 1), f = Qv(u, [c, n - c], u.shape.length - 1), p = i.shape.slice();
	return p[i.shape.length - 1] = c, W(ho(d[0], f[0]), p);
}
var ty, ny = e((() => {
	D(), go(), Gl(), Fp(), I(), M_(), G(), Ql(), $v(), gh(), sf(), Wv(), ty = /* @__PURE__ */ F({ rfft_: ey });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/squared_difference.js
function ry(e, t) {
	let n = N(e, "a", "squaredDifference"), r = N(t, "b", "squaredDifference");
	[n, r] = k(n, r), J(n.shape, r.shape);
	let i = {
		a: n,
		b: r
	};
	return j.runKernel(Hr, i, {});
}
var iy, ay = e((() => {
	M(), T(), A(), P(), Zd(), I(), iy = /* @__PURE__ */ F({ squaredDifference_: ry });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/squeeze.js
function oy(e, t) {
	let n = N(e, "x", "squeeze", "string_or_numeric");
	return W(n, le(n.shape, t).newShape);
}
var sy, cy = e((() => {
	P(), D(), I(), G(), sy = /* @__PURE__ */ F({ squeeze_: oy });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/stack.js
function ly(e, t = 0) {
	let n = fo(e, "tensors", "stack", "string_or_numeric");
	v(n.length >= 1, () => "Pass at least one tensor to tf.stack"), n.length > 0 && v(t <= n[0].rank, () => "Axis must be <= rank of the tensor");
	let r = n, i = { axis: t };
	return j.runKernel($n, r, i);
}
var uy, dy = e((() => {
	M(), T(), P(), D(), I(), uy = /* @__PURE__ */ F({ stack_: ly });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/step.js
function fy(e, t = 0) {
	let n = { x: N(e, "x", "step") }, r = { alpha: t };
	return j.runKernel(si, n, r);
}
var py, my = e((() => {
	M(), T(), P(), I(), py = /* @__PURE__ */ F({ step_: fy });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/strided_slice.js
function hy(e, t, n, r, i = 0, a = 0, o = 0, s = 0, c = 0) {
	let l = { x: N(e, "x", "stridedSlice", "string_or_numeric") }, u = {
		begin: t,
		end: n,
		strides: r,
		beginMask: i,
		endMask: a,
		ellipsisMask: o,
		newAxisMask: s,
		shrinkAxisMask: c
	};
	return j.runKernel(Gr, l, u);
}
var gy, _y = e((() => {
	M(), T(), P(), I(), gy = /* @__PURE__ */ F({ stridedSlice_: hy });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/tan.js
function vy(e) {
	let t = { x: N(e, "x", "tan", "float32") };
	return j.runKernel("Tan", t);
}
var yy, by = e((() => {
	M(), T(), P(), I(), yy = /* @__PURE__ */ F({ tan_: vy });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/tensor1d.js
function xy(e, t) {
	b(e);
	let n = co(e, t);
	if (n.length !== 1) throw Error("tensor1d() requires values to be a flat/TypedArray");
	return _o(e, null, n, t);
}
var Sy = e((() => {
	P(), D(), vo();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/tensor2d.js
function Cy(e, t, n) {
	if (b(e), t != null && t.length !== 2) throw Error("tensor2d() requires shape to have two numbers");
	let r = co(e, n);
	if (r.length !== 2 && r.length !== 1) throw Error("tensor2d() requires values to be number[][] or flat/TypedArray");
	if (r.length === 1 && t == null) throw Error("tensor2d() requires shape to be provided when `values` are a flat/TypedArray");
	return _o(e, t, r, n);
}
var wy = e((() => {
	P(), D(), vo();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/tensor3d.js
function Ty(e, t, n) {
	if (b(e), t != null && t.length !== 3) throw Error("tensor3d() requires shape to have three numbers");
	let r = co(e, n);
	if (r.length !== 3 && r.length !== 1) throw Error("tensor3d() requires values to be number[][][] or flat/TypedArray");
	if (r.length === 1 && t == null) throw Error("tensor3d() requires shape to be provided when `values` are a flat array");
	return _o(e, t, r, n);
}
var Ey = e((() => {
	P(), D(), vo();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/tensor4d.js
function Dy(e, t, n) {
	if (b(e), t != null && t.length !== 4) throw Error("tensor4d() requires shape to have four numbers");
	let r = co(e, n);
	if (r.length !== 4 && r.length !== 1) throw Error("tensor4d() requires values to be number[][][][] or flat/TypedArray");
	if (r.length === 1 && t == null) throw Error("tensor4d() requires shape to be provided when `values` are a flat array");
	return _o(e, t, r, n);
}
var Oy = e((() => {
	P(), D(), vo();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/tensor5d.js
function ky(e, t, n) {
	if (b(e), t != null && t.length !== 5) throw Error("tensor5d() requires shape to have five numbers");
	let r = co(e, n);
	if (r.length !== 5 && r.length !== 1) throw Error("tensor5d() requires values to be number[][][][][] or flat/TypedArray");
	if (r.length === 1 && t == null) throw Error("tensor5d() requires shape to be provided when `values` are a flat array");
	return _o(e, t, r, n);
}
var Ay = e((() => {
	P(), D(), vo();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/tensor6d.js
function jy(e, t, n) {
	if (b(e), t != null && t.length !== 6) throw Error("tensor6d() requires shape to have six numbers");
	let r = co(e, n);
	if (r.length !== 6 && r.length !== 1) throw Error("tensor6d() requires values to be number[][][][][][] or flat/TypedArray");
	if (r.length === 1 && t == null) throw Error("tensor6d() requires shape to be provided when `values` are a flat array");
	return t ||= r, _o(e, t, r, n);
}
var My = e((() => {
	P(), D(), vo();
})), Ny = /* @__PURE__ */ n({
	calculateShapes: () => Iy,
	validateInput: () => Fy,
	validateUpdateShape: () => Py
});
function Py(e, t, n) {
	let r = t.rank > 1 ? t.shape[t.rank - 1] : 1, i = t.rank > 1 ? t.rank - 1 : 1, a = `Must have updates.shape = indices.shape[:batchDim] + shape[sliceDim:], got updates.shape: ${n.shape}, indices.shape: ${t.shape}, shape: ${e}, sliceDim: ${r}, and batchDim: ${i}.`;
	if (n.rank < i) throw Error(a + ` update.rank < ${i}. `);
	if (e.length < r + (n.rank - i)) throw Error(a + ` Output shape length < ${r + (n.rank - i)}`);
	if (n.rank !== i + e.length - r) throw Error(a + ` update.rank != ${i + e.length - r}`);
	for (let e = 0; e < i; ++e) if (n.shape[e] !== t.shape[e]) throw Error(a + ` updates.shape[${e}] (${n.shape[e]}) != indices.shape[${e}] (${t.shape[e]}).`);
	for (let t = 0; t < n.rank - i; ++t) if (n.shape[t + i] !== e[t + r]) throw Error(a + ` updates.shape[${t + i}] (${n.shape[t + i]}) != shape[${t + i}] (${e[t + i]})`);
}
function Fy(e, t, n) {
	if (t.rank < 1) throw Error(`tf.scatterND() expects the indices to be rank 1 or higher, but the rank was ${t.rank}.`);
	if (e.rank < 1) throw Error(`tf.scatterND() expects the updates to be rank 1 or higher, but the rank was ${e.rank}.`);
	if (t.dtype !== "int32") throw Error(`The dtype of 'indices' should be int32, but got dtype: ${t.dtype}`);
	if (n.length < 1) throw Error(`Output rank must be greater or equal to 1, but got shape: ${n}`);
	if (n.length === 0) {
		if (t.size === 0) throw Error(`Indices specified for empty output. indices shape: ${t.shape}`);
		if (e.size === 0) throw Error(`Updates specified for empty output. updates shape: ${e.shape}`);
	}
	Py(n, t, e);
}
function Iy(e, t, n) {
	let r = t.shape.length, i = r > 1 ? t.shape[r - 1] : 1, a = n.length, o = 1;
	for (let e = i; e < a; ++e) o *= n[e];
	let s = i < 1 ? 1 : i, c = x(t.shape) / s, l = [...Ce(n.slice(0, i)), 1], u = x(n);
	return {
		sliceRank: i,
		numUpdates: c,
		sliceSize: o,
		strides: l,
		outputSize: u
	};
}
var Ly = e((() => {
	D();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/tensor_scatter_update.js
function Ry(e, t, n) {
	let r = N(e, "tensor", "tensorScatterupdate"), i = N(t, "indices", "tensorScatterupdate", "int32"), a = N(n, "updates", "tensorScatterupdate");
	if (Fy(a, i, r.shape), r.dtype !== a.dtype) throw Error(`tensor and updates must have the same dtype, instead they are ${r.dtype} and ${a.dtype}.`);
	let o = {
		tensor: r,
		indices: i,
		updates: a
	};
	return j.runKernel(Sr, o, {});
}
var zy, By = e((() => {
	M(), T(), P(), I(), Ly(), zy = F({ tensorScatterUpdate_: Ry });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/topk.js
function Vy(e, t = 1, n = !0) {
	let r = N(e, "x", "topk");
	if (r.rank === 0) throw Error("topk() expects the input to be of rank 1 or higher");
	let i = r.shape[r.shape.length - 1];
	if (t < 0) throw Error(`'k' passed to topk() must be >= 0 but got ${t}`);
	if (t > i) throw Error(`'k' passed to topk() must be <= the last dimension (${i}) but got ${t}`);
	let a = { x: r }, o = {
		k: t,
		sorted: n
	}, [s, c] = j.runKernel($r, a, o);
	return {
		values: s,
		indices: c
	};
}
var Hy, Uy = e((() => {
	M(), T(), P(), I(), Hy = /* @__PURE__ */ F({ topk_: Vy });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/truncated_normal.js
function Wy(e, t = 0, n = 1, r, i) {
	if (Ae(e), r != null && r === "bool") throw Error("Unsupported data type $ { dtype }");
	let a = new l_(t, n, r, !0, i), o = mc(e, r);
	for (let e = 0; e < o.values.length; e++) o.values[e] = a.nextValue();
	return o.toTensor();
}
var Gy, Ky = e((() => {
	Pe(), hc(), I(), f_(), Gy = /* @__PURE__ */ F({ truncatedNormal_: Wy });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/unique.js
function qy(e, t = 0) {
	let n = N(e, "x", "unique", "string_or_numeric");
	v(n.rank > 0, () => "The input tensor must be at least 1D");
	let r = { x: n }, i = { axis: t }, [a, o] = j.runKernel(ni, r, i);
	return {
		values: a,
		indices: o
	};
}
var Jy, Yy = e((() => {
	M(), T(), P(), D(), I(), Jy = /* @__PURE__ */ F({ unique_: qy });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/unsorted_segment_sum.js
function Xy(e, t, n) {
	let r = N(e, "x", "unsortedSegmentSum"), i = N(t, "segmentIds", "unsortedSegmentSum", "int32");
	v(ne(n), () => "numSegments must be of dtype int");
	let a = {
		x: r,
		segmentIds: i
	}, o = { numSegments: n };
	return j.runKernel(ii, a, o);
}
var Zy, Qy = e((() => {
	M(), T(), P(), D(), I(), Zy = /* @__PURE__ */ F({ unsortedSegmentSum_: Xy });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/unstack.js
function $y(e, t = 0) {
	let n = N(e, "x", "unstack", "string_or_numeric");
	v(t >= -n.shape.length && t < n.shape.length, () => `Axis = ${t} is not in [-${n.shape.length}, ${n.shape.length})`);
	let r = { value: n }, i = { axis: t };
	return j.runKernel(ri, r, i);
}
var eb, tb = e((() => {
	M(), T(), P(), D(), I(), eb = /* @__PURE__ */ F({ unstack_: $y });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/upper_bound.js
function nb(e, t) {
	return Xm(e, t, "right");
}
var rb = e((() => {
	Zm();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/variable.js
function ib(e, t = !0, n, r) {
	return j.makeVariable(e, t, n, r);
}
var ab = e((() => {
	M();
}));
// node_modules/@tensorflow/tfjs-core/dist/backends/where_impl.js
function ob(e, t) {
	let n = [];
	for (let e = 0; e < t.length; e++) t[e] && n.push(e);
	let r = mc(e, "int32"), i = mc([n.length, e.length], "int32");
	for (let t = 0; t < n.length; t++) {
		let a = r.indexToLoc(n[t]), o = t * e.length;
		i.values.set(a, o);
	}
	return i.toTensor();
}
var sb = e((() => {
	hc();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/where_async.js
async function cb(e) {
	let t = N(e, "condition", "whereAsync", "bool"), n = await t.data(), r = ob(t.shape, n);
	return e !== t && t.dispose(), r;
}
var lb, ub = e((() => {
	sb(), P(), lb = cb;
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/boolean_mask.js
async function db(e, t, n) {
	let r = N(e, "tensor", "boolMask"), i = N(t, "mask", "boolMask", "bool"), a = n ?? 0, o = i.rank, s = r.shape;
	v(o > 0, () => "mask cannot be scalar"), y(s.slice(a, a + o), i.shape, "mask's shape must match the first K dimensions of tensor's shape,");
	let c = 1;
	for (let e = a; e < a + o; e++) c *= s[e];
	let l = s.slice(0, a).concat([c], s.slice(a + o)), u = W(r, l), d = W(i, [-1]), f = await lb(d), p = sy(f, [1]), m = Tp(u, p, a);
	return e !== r && r.dispose(), t !== i && i.dispose(), p.dispose(), u.dispose(), d.dispose(), f.dispose(), m;
}
var fb, pb = e((() => {
	P(), D(), Ep(), G(), cy(), ub(), fb = db;
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/transpose.js
function mb(e, t, n) {
	let r = N(e, "x", "transpose");
	if (t ??= r.shape.map((e, t) => t).reverse(), v(r.rank === t.length, () => `Error in transpose: rank of input ${r.rank} must match length of perm ${t}.`), t.forEach((e) => {
		v(e >= 0 && e < r.rank, () => `All entries in 'perm' must be between 0 and ${r.rank - 1} but got ${t}`);
	}), r.rank <= 1) return r.clone();
	let i = { x: r }, a = { perm: t };
	return r.dtype === "complex64" ? L(() => {
		let e = j_(r), t = Pp(r);
		return e = j.runKernel(ti, { x: e }, a), t = j.runKernel(ti, { x: t }, a), n && (t = bm(t)), ho(e, t);
	}) : j.runKernel(ti, i, a);
}
var hb, gb = e((() => {
	M(), Ko(), T(), P(), D(), go(), Fp(), xm(), I(), M_(), hb = /* @__PURE__ */ F({ transpose_: mb });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/moving_average.js
function _b(e, t, n, r, i = !0) {
	let a = N(e, "v", "movingAverage"), o = N(t, "x", "movingAverage"), s = N(n, "decay", "movingAverage");
	Ha(a, o), v(S(a.shape, o.shape), () => "Shape mismatch in v and x");
	let c = Y(1), l = Z(c, s), u = H(Z(o, a), l);
	if (i) {
		v(r != null, () => "When using zeroDebias: true, step is required.");
		let e = N(r, "step", "movingAverage");
		u = V(u, Z(c, Hf(s, e)));
	}
	return z(a, u);
}
var vb, yb = e((() => {
	A(), P(), D(), B(), kc(), U(), I(), Uf(), Wf(), km(), vb = /* @__PURE__ */ F({ movingAverage_: _b });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/scatter_nd.js
function bb(e, t, n) {
	Ae(n);
	let r = N(e, "indices", "scatterND", "int32"), i = N(t, "updates", "scatterND");
	Fy(i, r, n);
	let a = {
		indices: r,
		updates: i
	}, o = { shape: n };
	return j.runKernel(xr, a, o);
}
var xb, Sb = e((() => {
	M(), T(), P(), Pe(), I(), Ly(), xb = /* @__PURE__ */ F({ scatterND_: bb });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/sparse_to_dense_util.js
function Cb(e, t, n, r) {
	if (e.dtype !== "int32") throw Error(`tf.sparseToDense() expects the indices to be int32 type, but the dtype was ${e.dtype}.`);
	if (e.rank > 2) throw Error(`sparseIndices should be a scalar, vector, or matrix, but got shape ${e.shape}.`);
	let i = e.rank > 0 ? e.shape[0] : 1, a = e.rank > 1 ? e.shape[1] : 1;
	if (n.length !== a) throw Error(`outputShape has incorrect number of elements:, ${n.length}, should be: ${a}.`);
	let o = t.size;
	if (!(t.rank === 0 || t.rank === 1 && o === i)) throw Error(`sparseValues has incorrect shape ${t.shape}, should be [] or [${i}]`);
	if (t.dtype !== r.dtype) throw Error("sparseValues.dtype must match defaultValues.dtype");
}
var wb = e((() => {}));
// node_modules/@tensorflow/tfjs-core/dist/ops/sparse_to_dense.js
function Tb(e, t, n, r = 0) {
	Ae(n);
	let i = N(e, "sparseIndices", "sparseToDense", "int32"), a = N(t, "sparseValues", "sparseToDense", "string_or_numeric"), o = N(r, "defaultValue", "sparseToDense", a.dtype);
	Cb(i, a, n, o);
	let s = {
		sparseIndices: i,
		sparseValues: a,
		defaultValue: o
	}, c = { outputShape: n };
	return j.runKernel(Vr, s, c);
}
var Eb, Db = e((() => {
	M(), T(), wb(), P(), Pe(), I(), Eb = /* @__PURE__ */ F({ sparseToDense_: Tb });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/gather_nd.js
function Ob(e, t) {
	let n = N(t, "indices", "gatherND", "int32"), r = {
		params: N(e, "x", "gatherND", "string_or_numeric"),
		indices: n
	};
	return j.runKernel(cn, r);
}
var kb, Ab = e((() => {
	M(), T(), P(), I(), kb = /* @__PURE__ */ F({ gatherND_: Ob });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/dropout_util.js
function jb(e, t) {
	if (t == null) return e.shape.slice();
	if (S(e.shape, t)) return t;
	if (e.shape.length === t.length) {
		let n = [];
		for (let r = 0; r < e.shape.length; r++) t[r] == null && e.shape[r] != null ? n.push(e.shape[r]) : n.push(t[r]);
		return n;
	}
	return t;
}
var Mb = e((() => {
	D();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/dropout.js
function Nb(e, t, n, r) {
	let i = N(e, "x", "dropout");
	if (v(i.dtype === "float32", () => `x has to be a floating point tensor since it's going to be scaled, but got a ${i.dtype} tensor instead.`), v(t >= 0 && t < 1, () => `rate must be a float in the range [0, 1), but got ${t}.`), t === 0) return e instanceof O ? i.clone() : i;
	let a = jb(i, n), o = 1 - t, s = V(Sp(z(C_(a, 0, 1, "float32", r), o)), o);
	return H(i, s);
}
var Pb, Fb = e((() => {
	ka(), P(), D(), B(), kc(), Mb(), Cp(), U(), I(), w_(), Pb = /* @__PURE__ */ F({ dropout_: Nb });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/signal_ops_util.js
function Ib(e) {
	return Math.floor(2 ** Math.ceil(Math.log(e) / Math.log(2)));
}
function Lb(e, t, n) {
	let r = 1 - e % 2, i = new Float32Array(e);
	for (let a = 0; a < e; ++a) {
		let o = 2 * Math.PI * a / (e + r - 1);
		i[a] = t - n * Math.cos(o);
	}
	return xy(i, "float32");
}
var Rb = e((() => {
	Sy();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/in_top_k.js
async function zb(e, t, n = 1) {
	let r = N(e, "predictions", "inTopK"), i = N(t, "targets", "inTopK");
	v(r.rank > 1, () => `inTopK() expects the predictions to be of rank 2 or higher, but got ${r.rank}`), v(r.rank - 1 === i.rank, () => `predictions rank should be 1 larger than targets rank, but got predictions rank ${r.rank} and targets rank ${i.rank}`), y(r.shape.slice(0, r.shape.length - 1), i.shape, "predictions's shape should be align with the targets' shape, except the last dimension.");
	let a = r.shape[r.shape.length - 1];
	v(n > 0 && n <= a, () => `'k' passed to inTopK() must be > 0 && <= the predictions last dimension (${a}), but got ${n}`);
	let o = await r.data(), s = await i.data(), [c, l] = [o.length / a, a], u = ue("bool", c);
	for (let e = 0; e < c; e++) {
		let t = e * l, r = o.subarray(t, t + l), i = [];
		for (let e = 0; e < r.length; e++) i.push({
			value: r[e],
			index: e
		});
		i.sort((e, t) => t.value - e.value), u[e] = 0;
		for (let t = 0; t < n; t++) if (i[t].index === s[e]) {
			u[e] = 1;
			break;
		}
	}
	return e !== r && r.dispose(), t !== i && i.dispose(), yo(u, i.shape, "bool");
}
var Bb, Vb = e((() => {
	P(), D(), bo(), Bb = zb;
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/conv2d_backprop_filter.js
function Hb(e, t, n, r, i, a = "NHWC", o) {
	let s = e;
	e.rank === 3 && (s = W(e, [
		1,
		e.shape[0],
		e.shape[1],
		e.shape[2]
	]));
	let c = t;
	c.rank === 3 && (c = W(t, [
		1,
		t.shape[0],
		t.shape[1],
		t.shape[2]
	])), v(s.rank === 4, () => `Error in conv2dDerFilter: input must be rank 4, but got shape ${s.shape}.`), v(c.rank === 4, () => `Error in conv2dDerFilter: dy must be rank 4, but got shape ${c.shape}.`), v(n.length === 4, () => `Error in conv2dDerFilter: filterShape must be length 4, but got ${n}.`);
	let l = a === "NHWC" ? s.shape[3] : s.shape[1], u = a === "NHWC" ? c.shape[3] : c.shape[1];
	v(l === n[2], () => `Error in conv2dDerFilter: depth of input ${l}) must match input depth in filter (${n[2]}.`), v(u === n[3], () => `Error in conv2dDerFilter: depth of dy (${u}) must match output depth for filter (${n[3]}).`), Pl("conv2dDerFilter", i, o);
	let d = {
		x: s,
		dy: c
	}, f = {
		strides: r,
		pad: i,
		dataFormat: a,
		dimRoundingMode: o,
		filterShape: n
	};
	return j.runKernel(Tt, d, f);
}
var Ub, Wb = e((() => {
	M(), T(), D(), Fl(), I(), G(), Ub = /* @__PURE__ */ F({ conv2DBackpropFilter_: Hb });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/fused_util.js
function Gb(e, t, n) {
	if (n == null || n === "linear") return e;
	if (n === "relu") return H(e, py(t));
	throw Error(`Cannot compute gradient for fused activation ${n}.`);
}
function Kb(e, t) {
	let n = t, r = Xd(e.shape, t.shape);
	return r.length > 0 && (n = X(n, r)), W(n, e.shape);
}
function qb(e, t, n, r) {
	if (t === "linear") return e;
	if (t === "relu") return L_(e);
	if (t === "elu") return vf(e);
	if (t === "relu6") return B_(e);
	if (t === "prelu") return xg(e, n);
	if (t === "leakyrelu") return Kp(e, r);
	if (t === "sigmoid") return Yl(e);
	throw Error(`Unknown fused activation ${t}.`);
}
var Jb, Yb = e((() => {
	Zd(), yf(), qp(), U(), Sg(), R_(), V_(), G(), Xl(), my(), Qf(), Jb = (e, t) => !(e > 0) || t === "linear";
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/fused/conv2d.js
function Xb({ x: e, filter: t, strides: n, pad: r, dataFormat: i = "NHWC", dilations: a = [1, 1], dimRoundingMode: o, bias: s, activation: c = "linear", preluActivationWeights: l, leakyreluAlpha: u }) {
	if (c ||= "linear", Jb(j.state.gradientDepth, c) === !1) {
		v(i === "NHWC", () => `Error in fused conv2d: got dataFormat of ${i} but only NHWC is currently supported for the case of gradient depth is 0 and the activation is not linear.`);
		let d = td(e, t, n, r, i, a, o);
		return s != null && (d = z(d, s)), qb(d, c, l, u);
	}
	let d = N(e, "x", "conv2d", "float32"), f = N(t, "filter", "conv2d", "float32"), p = d, m = !1;
	d.rank === 3 && (m = !0, p = W(d, [
		1,
		d.shape[0],
		d.shape[1],
		d.shape[2]
	])), v(p.rank === 4, () => `Error in fused conv2d: input must be rank 4, but got rank ${p.rank}.`), v(f.rank === 4, () => `Error in fused conv2d: filter must be rank 4, but got rank ${f.rank}.`), Pl("fused conv2d", r, o);
	let h = i === "NHWC" ? p.shape[3] : p.shape[1];
	v(f.shape[2] === h, () => `Error in conv2d: depth of input (${h}) must match input depth for filter ${f.shape[2]}.`), v(jl(n, a), () => `Error in conv2D: Either strides or dilations must be 1. Got strides ${n} and dilations '${a}'`);
	let g = yl(p.shape, f.shape, n, a, r, o), _;
	s != null && (_ = N(s, "bias", "fused conv2d"), [_] = k(_, d), i === "NHWC" ? J(g.outShape, _.shape) : (v(_.shape.length <= 1, () => `Error in fused conv2d: only supports scalar or 1-D Tensor bias for NCHW format but got the bias of rank-${_.shape.length}.`), v(_.shape.length === 0 || _.shape[0] === g.outChannels || _.shape[0] === 1, () => `Error in fused conv2d: bias shape (${_.shape}) is not compatible with the number of output channels (${g.outChannels})`)));
	let y;
	if (l != null) {
		let e = l.shape;
		if (v(e.length <= 1 || e.length === 3, () => `Error in fused conv2d: only supports scalar, 1-D Tensor or 3-D Tensor PReLU activation weights but got a tensor of rank-${e.length}.`), e.length === 1) v(e[0] === 1 || e[0] === g.outChannels, () => `Error in fused conv2d: PReLU activation weights (${e}) is not compatible with the number of output channels (${g.outChannels}).`);
		else if (e.length === 3) try {
			J(e, g.outShape);
		} catch {
			let t = `Error in fused conv2d: PReLU activation weights (${e}) is not compatible with the output shape of the conv2d (${g.outShape}).`;
			throw Error(t);
		}
		y = N(l, "prelu weights", "fused conv2d");
	}
	let b = (e, t) => {
		v(i === "NHWC", () => `Error in gradient of fused conv2D: got dataFormat of ${i} but only NHWC is currently supported.`);
		let [o, s, l, u] = t, d = Gb(e, l, c);
		v(Al(a), () => `Error in gradient of fused conv2D: dilation rates greater than 1 are not yet supported in gradients. Got dilations '${a}'`);
		let f = [sd(s.shape, d, o, n, r), Ub(s, d, o.shape, n, r)];
		if (u != null) {
			let e = Kb(u, d);
			f.push(e);
		}
		return f;
	}, x = {
		x: p,
		filter: f,
		bias: _,
		preluActivationWeights: y
	}, ee = {
		strides: n,
		pad: r,
		dataFormat: i,
		dilations: a,
		dimRoundingMode: o,
		activation: c,
		leakyreluAlpha: u
	};
	return s == null ? gm((e, t, n) => {
		let r = j.runKernel(di, x, ee);
		return n([
			t,
			e,
			r
		]), m && (r = W(r, [
			r.shape[1],
			r.shape[2],
			r.shape[3]
		])), {
			value: r,
			gradFunc: b
		};
	})(p, f) : gm((e, t, n, r) => {
		let i = j.runKernel(di, x, ee);
		return r([
			t,
			e,
			i,
			n
		]), m && (i = W(i, [
			i.shape[1],
			i.shape[2],
			i.shape[3]
		])), {
			value: i,
			gradFunc: b
		};
	})(p, f, _);
}
var Zb, Qb = e((() => {
	M(), vm(), T(), A(), P(), D(), B(), Zd(), nd(), Wb(), cd(), Fl(), Yb(), I(), G(), Zb = /* @__PURE__ */ F({ fusedConv2d_: Xb });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/depthwise_conv2d_native_backprop_filter.js
function $b(e, t, n, r, i, a = [1, 1], o) {
	let s = e;
	e.rank === 3 && (s = W(e, [
		1,
		e.shape[0],
		e.shape[1],
		e.shape[2]
	]));
	let c = t;
	c.rank === 3 && (c = W(t, [
		1,
		t.shape[0],
		t.shape[1],
		t.shape[2]
	]));
	let l = {
		x: s,
		dy: c
	}, u = {
		strides: r,
		pad: i,
		dimRoundingMode: o,
		dilations: a,
		filterShape: n
	};
	return j.runKernel(Rt, l, u);
}
var ex, tx = e((() => {
	M(), T(), I(), G(), ex = F({ depthwiseConv2dNativeBackpropFilter_: $b });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/depthwise_conv2d_native_backprop_input.js
function nx(e, t, n, r, i, a = [1, 1], o) {
	let s = t, c = !1;
	t.rank === 3 && (c = !0, s = W(t, [
		1,
		t.shape[0],
		t.shape[1],
		t.shape[2]
	]));
	let l = {
		dy: s,
		filter: n
	}, u = {
		strides: r,
		pad: i,
		dimRoundingMode: o,
		dilations: a,
		inputShape: e
	}, d = j.runKernel(zt, l, u);
	return c ? W(d, [
		d.shape[1],
		d.shape[2],
		d.shape[3]
	]) : d;
}
var rx, ix = e((() => {
	M(), T(), I(), G(), rx = F({ depthwiseConv2dNativeBackpropInput_: nx });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/fused/depthwise_conv2d.js
function ax({ x: e, filter: t, strides: n, pad: r, dataFormat: i = "NHWC", dilations: a = [1, 1], dimRoundingMode: o, bias: s, activation: c = "linear", preluActivationWeights: l, leakyreluAlpha: u }) {
	if (Jb(j.state.gradientDepth, c) === !1) {
		let d = Bd(e, t, n, r, i, a, o);
		return s != null && (d = z(d, s)), qb(d, c, l, u);
	}
	let d = N(e, "x", "depthwiseConv2d", "float32"), f = N(t, "filter", "depthwiseConv2d", "float32"), p = d, m = !1;
	d.rank === 3 && (m = !0, p = W(d, [
		1,
		d.shape[0],
		d.shape[1],
		d.shape[2]
	])), v(p.rank === 4, () => `Error in fused depthwiseConv2d: input must be rank 4, but got rank ${p.rank}.`), v(f.rank === 4, () => `Error in fused depthwiseConv2d: filter must be rank 4, but got rank ${f.rank}.`), v(p.shape[3] === f.shape[2], () => `Error in fused depthwiseConv2d: number of input channels (${p.shape[3]}) must match the inChannels dimension in filter ${f.shape[2]}.`), a ??= [1, 1], v(jl(n, a), () => `Error in fused depthwiseConv2d: Either strides or dilations must be 1. Got strides ${n} and dilations '${a}'`), Pl("fused depthwiseConv2d", r, o);
	let h = yl(p.shape, f.shape, n, a, r, o, !0), g;
	s != null && (g = N(s, "bias", "fused conv2d"), [g] = k(g, d), J(h.outShape, g.shape));
	let _;
	l != null && (_ = N(l, "prelu weights", "fused depthwiseConv2d"));
	let y = (e, t) => {
		v(Al(a), () => `Error in gradient of fused depthwiseConv2d: dilation rates greater than 1 are not yet supported. Got dilations '${a}'`);
		let [i, s, l, u] = t, d = Gb(e, l, c), f = rx(s.shape, d, i, n, r, a, o), p = ex(s, d, i.shape, n, r, a, o);
		return u == null ? [f, p] : [
			f,
			p,
			Kb(g, d)
		];
	}, b = {
		x: p,
		filter: f,
		bias: g,
		preluActivationWeights: _
	}, x = {
		strides: n,
		pad: r,
		dataFormat: i,
		dilations: a,
		dimRoundingMode: o,
		activation: c,
		leakyreluAlpha: u
	};
	return s == null ? gm((e, t, n) => {
		let r = j.runKernel(fi, b, x);
		return n([
			t,
			e,
			r
		]), m && (r = W(r, [
			r.shape[1],
			r.shape[2],
			r.shape[3]
		])), {
			value: r,
			gradFunc: y
		};
	})(p, f) : gm((e, t, n, r) => {
		let i = j.runKernel(fi, b, x);
		return r([
			t,
			e,
			i,
			n
		]), m && (i = W(i, [
			i.shape[1],
			i.shape[2],
			i.shape[3]
		])), {
			value: i,
			gradFunc: y
		};
	})(p, f, g);
}
var ox, sx = e((() => {
	M(), vm(), T(), A(), P(), D(), B(), Zd(), Fl(), Vd(), tx(), ix(), Yb(), I(), G(), ox = /* @__PURE__ */ F({ fusedDepthwiseConv2d_: ax });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/fused/mat_mul.js
function cx({ a: e, b: t, transposeA: n = !1, transposeB: r = !1, bias: i, activation: a = "linear", preluActivationWeights: o, leakyreluAlpha: s = .2 }) {
	if (Jb(j.state.gradientDepth, a) === !1) {
		let c = K(e, t, n, r);
		return i != null && (c = z(c, i)), qb(c, a, o, s);
	}
	let c = N(e, "a", "fused matMul"), l = N(t, "b", "fused matMul");
	[c, l] = k(c, l);
	let u = n ? c.shape[c.rank - 2] : c.shape[c.rank - 1], d = r ? l.shape[l.rank - 1] : l.shape[l.rank - 2], f = n ? c.shape[c.rank - 1] : c.shape[c.rank - 2], p = r ? l.shape[l.rank - 2] : l.shape[l.rank - 1], m = c.shape.slice(0, -2), h = l.shape.slice(0, -2), g = x(m), _ = x(h);
	v(u === d, () => `Error in fused matMul: inner shapes (${u}) and (${d}) of Tensors with shapes ${c.shape} and ${l.shape} and transposeA=${n} and transposeB=${r} must match.`);
	let y = J(c.shape.slice(0, -2), l.shape.slice(0, -2)).concat([f, p]), b = n ? W(c, [
		g,
		u,
		f
	]) : W(c, [
		g,
		f,
		u
	]), ee = r ? W(l, [
		_,
		p,
		d
	]) : W(l, [
		_,
		d,
		p
	]), te;
	i != null && (te = N(i, "bias", "fused matMul"), [te] = k(te, c), J(y, te.shape));
	let S;
	o != null && (S = N(o, "prelu weights", "fused matMul"));
	let ne = (e, t) => {
		let [o, s, c, l] = t, u = Gb(W(e, c.shape), c, a), d, f;
		if (!n && !r ? (d = K(u, s, !1, !0), f = K(o, u, !0, !1)) : !n && r ? (d = K(u, s, !1, !1), f = K(u, o, !0, !1)) : n && !r ? (d = K(s, u, !1, !0), f = K(o, u, !1, !1)) : (d = K(s, u, !0, !0), f = K(u, o, !0, !0)), i != null) {
			let e = Kb(l, u);
			return [
				d,
				f,
				e
			];
		}
		return [d, f];
	}, re = {
		a: b,
		b: ee,
		bias: te,
		preluActivationWeights: S
	}, C = {
		transposeA: n,
		transposeB: r,
		activation: a,
		leakyreluAlpha: s
	};
	return i == null ? gm((e, t, n) => {
		let r = j.runKernel(ui, re, C);
		return n([
			e,
			t,
			r
		]), {
			value: W(r, y),
			gradFunc: ne
		};
	})(b, ee) : gm((e, t, n, r) => {
		let i = j.runKernel(ui, re, C);
		return r([
			e,
			t,
			i,
			n
		]), {
			value: W(i, y),
			gradFunc: ne
		};
	})(b, ee, te);
}
var lx, ux = e((() => {
	M(), vm(), T(), A(), P(), D(), B(), Zd(), Yb(), ql(), I(), G(), lx = /* @__PURE__ */ F({ fusedMatMul_: cx });
})), dx = /* @__PURE__ */ n({
	conv2d: () => Zb,
	depthwiseConv2d: () => ox,
	matMul: () => lx
}), fx = e((() => {
	Qb(), sx(), ux();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/signal/hamming_window.js
function px(e) {
	return Lb(e, .54, .46);
}
var mx, hx = e((() => {
	I(), Rb(), mx = /* @__PURE__ */ F({ hammingWindow_: px });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/signal/hann_window.js
function gx(e) {
	return Lb(e, .5, .5);
}
var _x, vx = e((() => {
	I(), Rb(), _x = /* @__PURE__ */ F({ hannWindow_: gx });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/signal/frame.js
function yx(e, t, n, r = !1, i = 0) {
	let a = 0, o = [];
	for (; a + t <= e.size;) o.push(q(e, a, t)), a += n;
	if (r) for (; a < e.size;) {
		let r = a + t - e.size, s = Wl([q(e, a, t - r), Lu([r], i)]);
		o.push(s), a += n;
	}
	return o.length === 0 ? Cy([], [0, t]) : W(Wl(o), [o.length, t]);
}
var bx, xx = e((() => {
	Gl(), Ru(), I(), G(), Ql(), wy(), bx = /* @__PURE__ */ F({ frame_: yx });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/signal/stft.js
function Sx(e, t, n, r, i = _x) {
	r ??= Ib(t);
	let a = bx(e, t, n), o = H(a, i(t));
	return ty(o, r);
}
var Cx, wx = e((() => {
	U(), I(), Rb(), ny(), xx(), vx(), Cx = /* @__PURE__ */ F({ stft_: Sx });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/image/crop_and_resize.js
function Tx(e, t, n, r, i = "bilinear", a = 0) {
	let o = N(e, "image", "cropAndResize"), s = N(t, "boxes", "cropAndResize", "float32"), c = N(n, "boxInd", "cropAndResize", "int32"), l = s.shape[0];
	v(o.rank === 4, () => `Error in cropAndResize: image must be rank 4,but got rank ${o.rank}.`), v(s.rank === 2 && s.shape[1] === 4, () => `Error in cropAndResize: boxes must be have size [${l},4] but had shape ${s.shape}.`), v(c.rank === 1 && c.shape[0] === l, () => `Error in cropAndResize: boxInd must be have size [${l}] but had shape ${s.shape}.`), v(r.length === 2, () => `Error in cropAndResize: cropSize must be of length 2, but got length ${r.length}.`), v(r[0] >= 1 && r[1] >= 1, () => `cropSize must be atleast [1,1], but was ${r}`), v(i === "bilinear" || i === "nearest", () => `method must be bilinear or nearest, but was ${i}`);
	let u = {
		image: o,
		boxes: s,
		boxInd: c
	}, d = {
		method: i,
		extrapolationValue: a,
		cropSize: r
	};
	return j.runKernel(Pt, u, d);
}
var Ex, Dx = e((() => {
	M(), T(), P(), D(), I(), Ex = /* @__PURE__ */ F({ cropAndResize_: Tx });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/image/flip_left_right.js
function Ox(e) {
	let t = N(e, "image", "flipLeftRight", "float32");
	v(t.rank === 4, () => `Error in flipLeftRight: image must be rank 4,but got rank ${t.rank}.`);
	let n = { image: t };
	return j.runKernel(nn, n, {});
}
var kx, Ax = e((() => {
	M(), T(), P(), D(), I(), kx = /* @__PURE__ */ F({ flipLeftRight_: Ox });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/image/grayscale_to_rgb.js
function jx(e) {
	let t = N(e, "image", "grayscaleToRGB"), n = t.rank - 1, r = t.shape[n];
	v(t.rank >= 2, () => `Error in grayscaleToRGB: images must be at least rank 2, but got rank ${t.rank}.`), v(r === 1, () => `Error in grayscaleToRGB: last dimension of a grayscale image should be size 1, but got size ${r}.`);
	let i = Array(t.rank);
	return i.fill(1, 0, n), i[n] = 3, gp(t, i);
}
var Mx, Nx = e((() => {
	P(), D(), I(), _p(), Mx = /* @__PURE__ */ F({ grayscaleToRGB_: jx });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/image/rgb_to_grayscale.js
function Px(e) {
	let t = N(e, "image", "RGBToGrayscale"), n = t.rank - 1, r = t.shape[n];
	v(t.rank >= 2, () => `Error in RGBToGrayscale: images must be at least rank 2, but got rank ${t.rank}.`), v(r === 3, () => `Error in RGBToGrayscale: last dimension of an RGB image should be size 3, but got size ${r}.`);
	let i = t.dtype, a = R(t, "float32"), o = xy([
		.2989,
		.587,
		.114
	]), s;
	switch (t.rank) {
		case 2:
			s = hf("ij,j->i", a, o);
			break;
		case 3:
			s = hf("ijk,k->ij", a, o);
			break;
		case 4:
			s = hf("ijkl,l->ijk", a, o);
			break;
		case 5:
			s = hf("ijklm,m->ijkl", a, o);
			break;
		case 6:
			s = hf("ijklmn,n->ijklm", a, o);
			break;
		default: throw Error("Not a valid tensor rank.");
	}
	return s = up(s, -1), R(s, i);
}
var Fx, Ix = e((() => {
	P(), D(), _c(), gf(), dp(), I(), Sy(), Fx = /* @__PURE__ */ F({ rgbToGrayscale_: Px });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/image/rotate_with_offset.js
function Lx(e, t, n = 0, r = .5) {
	let i = N(e, "image", "rotateWithOffset", "float32");
	v(i.rank === 4, () => `Error in rotateWithOffset: image must be rank 4,but got rank ${i.rank}.`);
	let a = { image: i }, o = {
		radians: t,
		fillValue: n,
		center: r
	};
	return j.runKernel(li, a, o);
}
var Rx, zx = e((() => {
	M(), T(), P(), D(), I(), Rx = /* @__PURE__ */ F({ rotateWithOffset_: Lx });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/nonmax_util.js
function Bx(e, t, n, r, i, a) {
	r ??= .5, i ??= -Infinity, a ??= 0;
	let o = e.shape[0];
	return n = Math.min(n, o), v(0 <= r && r <= 1, () => `iouThreshold must be in [0, 1], but was '${r}'`), v(e.rank === 2, () => `boxes must be a 2D tensor, but was of rank '${e.rank}'`), v(e.shape[1] === 4, () => `boxes must have 4 columns, but 2nd dimension was ${e.shape[1]}`), v(t.rank === 1, () => "scores must be a 1D tensor"), v(t.shape[0] === o, () => `scores has incompatible shape with boxes. Expected ${o}, but was ${t.shape[0]}`), v(0 <= a && a <= 1, () => `softNmsSigma must be in [0, 1], but was '${a}'`), {
		maxOutputSize: n,
		iouThreshold: r,
		scoreThreshold: i,
		softNmsSigma: a
	};
}
var Vx = e((() => {
	D();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/image/non_max_suppression.js
function Hx(e, t, n, r = .5, i = -Infinity) {
	let a = N(e, "boxes", "nonMaxSuppression", "float32"), o = N(t, "scores", "nonMaxSuppression", "float32"), s = Bx(a, o, n, r, i);
	n = s.maxOutputSize, r = s.iouThreshold, i = s.scoreThreshold;
	let c = {
		maxOutputSize: n,
		iouThreshold: r,
		scoreThreshold: i
	};
	return j.runKernel(Jn, {
		boxes: a,
		scores: o
	}, c);
}
var Ux, Wx = e((() => {
	M(), T(), P(), Vx(), I(), Ux = /* @__PURE__ */ F({ nonMaxSuppression_: Hx });
}));
// node_modules/@tensorflow/tfjs-core/dist/backends/non_max_suppression_util.js
function Gx(e, t, n) {
	let r = Kx(e, t, n), i = r < 0 ? -(r + 1) : r;
	e.splice(i, 0, t);
}
function Kx(e, t, n) {
	return Jx(e, t, n || qx);
}
function qx(e, t) {
	return e > t ? 1 : e < t ? -1 : 0;
}
function Jx(e, t, n) {
	let r = 0, i = e.length, a = 0, o = !1;
	for (; r < i;) {
		a = r + (i - r >>> 1);
		let s = n(t, e[a]);
		s > 0 ? r = a + 1 : (i = a, o = !s);
	}
	return o ? r : -r - 1;
}
var Yx = e((() => {}));
// node_modules/@tensorflow/tfjs-core/dist/backends/non_max_suppression_impl.js
function Xx(e, t, n, r, i) {
	return $x(e, t, n, r, i, 0);
}
function Zx(e, t, n, r, i, a) {
	return $x(e, t, n, r, i, 0, !1, a, !0);
}
function Qx(e, t, n, r, i, a) {
	return $x(e, t, n, r, i, a, !0);
}
function $x(e, t, n, r, i, a, o = !1, s = !1, c = !1) {
	let l = [];
	for (let e = 0; e < t.length; e++) t[e] > i && l.push({
		score: t[e],
		boxIndex: e,
		suppressBeginIndex: 0
	});
	l.sort(nS);
	let u = a > 0 ? -.5 / a : 0, d = [], f = [];
	for (; d.length < n && l.length > 0;) {
		let t = l.pop(), { score: n, boxIndex: a, suppressBeginIndex: o } = t;
		if (n < i) break;
		let s = !1;
		for (let n = d.length - 1; n >= o; --n) {
			let o = eS(e, a, d[n]);
			if (o >= r) {
				s = !0;
				break;
			}
			if (t.score *= tS(r, u, o), t.score <= i) break;
		}
		t.suppressBeginIndex = d.length, s || (t.score === n ? (d.push(a), f.push(t.score)) : t.score > i && Gx(l, t, nS));
	}
	let p = d.length, m = n - p;
	s && m > 0 && (d.push(...Array(m).fill(0)), f.push(...Array(m).fill(0)));
	let h = { selectedIndices: d };
	return o && (h.selectedScores = f), c && (h.validOutputs = p), h;
}
function eS(e, t, n) {
	let r = e.subarray(t * 4, t * 4 + 4), i = e.subarray(n * 4, n * 4 + 4), a = Math.min(r[0], r[2]), o = Math.min(r[1], r[3]), s = Math.max(r[0], r[2]), c = Math.max(r[1], r[3]), l = Math.min(i[0], i[2]), u = Math.min(i[1], i[3]), d = Math.max(i[0], i[2]), f = Math.max(i[1], i[3]), p = (s - a) * (c - o), m = (d - l) * (f - u);
	if (p <= 0 || m <= 0) return 0;
	let h = Math.max(a, l), g = Math.max(o, u), _ = Math.min(s, d), v = Math.min(c, f), y = Math.max(_ - h, 0) * Math.max(v - g, 0);
	return y / (p + m - y);
}
function tS(e, t, n) {
	let r = Math.exp(t * n * n);
	return n <= e ? r : 0;
}
function nS(e, t) {
	return e.score - t.score || e.score === t.score && t.boxIndex - e.boxIndex;
}
var rS = e((() => {
	Yx();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/image/non_max_suppression_async.js
async function iS(e, t, n, r = .5, i = -Infinity) {
	let a = N(e, "boxes", "nonMaxSuppressionAsync"), o = N(t, "scores", "nonMaxSuppressionAsync"), s = Bx(a, o, n, r, i);
	n = s.maxOutputSize, r = s.iouThreshold, i = s.scoreThreshold;
	let c = await Promise.all([a.data(), o.data()]), l = c[0], u = c[1], { selectedIndices: d } = Xx(l, u, n, r, i);
	return a !== e && a.dispose(), o !== t && o.dispose(), xy(d, "int32");
}
var aS, oS = e((() => {
	rS(), P(), Vx(), Sy(), aS = iS;
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/image/non_max_suppression_with_score.js
function sS(e, t, n, r = .5, i = -Infinity, a = 0) {
	let o = N(e, "boxes", "nonMaxSuppression"), s = N(t, "scores", "nonMaxSuppression"), c = Bx(o, s, n, r, i, a);
	n = c.maxOutputSize, r = c.iouThreshold, i = c.scoreThreshold, a = c.softNmsSigma;
	let l = {
		boxes: o,
		scores: s
	}, u = {
		maxOutputSize: n,
		iouThreshold: r,
		scoreThreshold: i,
		softNmsSigma: a
	}, d = j.runKernel(Xn, l, u);
	return {
		selectedIndices: d[0],
		selectedScores: d[1]
	};
}
var cS, lS = e((() => {
	M(), T(), P(), Vx(), I(), cS = /* @__PURE__ */ F({ nonMaxSuppressionWithScore_: sS });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/image/non_max_suppression_with_score_async.js
async function uS(e, t, n, r = .5, i = -Infinity, a = 0) {
	let o = N(e, "boxes", "nonMaxSuppressionAsync"), s = N(t, "scores", "nonMaxSuppressionAsync"), c = Bx(o, s, n, r, i, a);
	n = c.maxOutputSize, r = c.iouThreshold, i = c.scoreThreshold, a = c.softNmsSigma;
	let l = await Promise.all([o.data(), s.data()]), u = l[0], d = l[1], { selectedIndices: f, selectedScores: p } = Qx(u, d, n, r, i, a);
	return o !== e && o.dispose(), s !== t && s.dispose(), {
		selectedIndices: xy(f, "int32"),
		selectedScores: xy(p)
	};
}
var dS, fS = e((() => {
	rS(), P(), Vx(), Sy(), dS = uS;
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/image/non_max_suppression_padded.js
function pS(e, t, n, r = .5, i = -Infinity, a = !1) {
	let o = N(e, "boxes", "nonMaxSuppression"), s = N(t, "scores", "nonMaxSuppression"), c = Bx(o, s, n, r, i, null), l = c.maxOutputSize, u = c.iouThreshold, d = c.scoreThreshold, f = {
		boxes: o,
		scores: s
	}, p = {
		maxOutputSize: l,
		iouThreshold: u,
		scoreThreshold: d,
		padToMaxOutputSize: a
	}, m = j.runKernel(Yn, f, p);
	return {
		selectedIndices: m[0],
		validOutputs: m[1]
	};
}
var mS, hS = e((() => {
	M(), T(), P(), Vx(), I(), mS = /* @__PURE__ */ F({ nonMaxSuppressionPadded_: pS });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/image/non_max_suppression_padded_async.js
async function gS(e, t, n, r = .5, i = -Infinity, a = !1) {
	let o = N(e, "boxes", "nonMaxSuppressionAsync"), s = N(t, "scores", "nonMaxSuppressionAsync"), c = Bx(o, s, n, r, i, null), l = c.maxOutputSize, u = c.iouThreshold, d = c.scoreThreshold, [f, p] = await Promise.all([o.data(), s.data()]), { selectedIndices: m, validOutputs: h } = Zx(f, p, l, u, d, a);
	return o !== e && o.dispose(), s !== t && s.dispose(), {
		selectedIndices: xy(m, "int32"),
		validOutputs: Y(h, "int32")
	};
}
var _S, vS = e((() => {
	rS(), P(), Vx(), Wf(), Sy(), _S = gS;
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/image/resize_bilinear.js
function yS(e, t, n = !1, r = !1) {
	let i = N(e, "images", "resizeBilinear");
	v(i.rank === 3 || i.rank === 4, () => `Error in resizeBilinear: x must be rank 3 or 4, but got rank ${i.rank}.`), v(t.length === 2, () => `Error in resizeBilinear: new shape must 2D, but got shape ${t}.`), v(r === !1 || n === !1, () => "Error in resizeBilinear: If halfPixelCenters is true, alignCorners must be false.");
	let a = i, o = !1;
	i.rank === 3 && (o = !0, a = W(i, [
		1,
		i.shape[0],
		i.shape[1],
		i.shape[2]
	]));
	let [] = t, s = { images: a }, c = {
		alignCorners: n,
		halfPixelCenters: r,
		size: t
	}, l = j.runKernel(hr, s, c);
	return o ? W(l, [
		l.shape[1],
		l.shape[2],
		l.shape[3]
	]) : l;
}
var bS, xS = e((() => {
	M(), T(), P(), D(), I(), G(), bS = /* @__PURE__ */ F({ resizeBilinear_: yS });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/image/resize_nearest_neighbor.js
function SS(e, t, n = !1, r = !1) {
	let i = N(e, "images", "resizeNearestNeighbor");
	v(i.rank === 3 || i.rank === 4, () => `Error in resizeNearestNeighbor: x must be rank 3 or 4, but got rank ${i.rank}.`), v(t.length === 2, () => `Error in resizeNearestNeighbor: new shape must 2D, but got shape ${t}.`), v(i.dtype === "float32" || i.dtype === "int32", () => "`images` must have `int32` or `float32` as dtype"), v(r === !1 || n === !1, () => "Error in resizeNearestNeighbor: If halfPixelCenters is true, alignCorners must be false.");
	let a = i, o = !1;
	i.rank === 3 && (o = !0, a = W(i, [
		1,
		i.shape[0],
		i.shape[1],
		i.shape[2]
	]));
	let [] = t, s = { images: a }, c = {
		alignCorners: n,
		halfPixelCenters: r,
		size: t
	}, l = j.runKernel(pr, s, c);
	return o ? W(l, [
		l.shape[1],
		l.shape[2],
		l.shape[3]
	]) : l;
}
var CS, wS = e((() => {
	M(), T(), P(), D(), I(), G(), CS = /* @__PURE__ */ F({ resizeNearestNeighbor_: SS });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/image/threshold.js
function TS(e, t = "binary", n = !1, r = .5) {
	let i = N(e, "image", "threshold"), a = i.shape[0] * i.shape[1], o = H(xy([r]), 255), s, c, l, u;
	if (v(i.rank === 3, () => `Error in threshold: image must be rank 3,but got rank ${i.rank}.`), v(i.shape[2] === 3 || i.shape[2] === 1, () => `Error in threshold: image color channel must be equal to 3 or 1but got ${i.shape[2]}.`), v(i.dtype === "int32" || i.dtype === "float32", () => `Error in dtype: image dtype must be int32 or float32,but got dtype ${i.dtype}.`), v(t === "otsu" || t === "binary", () => `Method must be binary or otsu, but was ${t}`), i.shape[2] === 3) {
		[s, c, l] = Qv(i, [
			1,
			1,
			1
		], -1);
		let e = H(s, .2989), t = H(c, .587), n = H(l, .114);
		u = z(z(e, t), n);
	} else u = e;
	t === "otsu" && (o = ES(Cu(R(iv(u), "int32"), yo([]), 256), a));
	let d = n ? Qp(u, o) : Op(u, o);
	return R(H(d, 255), "int32");
}
function ES(e, t) {
	let n = xy([-1]), r = xy([0]), i = xy([0]), a, o, s, c, l, u;
	for (let d = 0; d < e.size - 1; d++) {
		a = q(e, 0, d + 1), o = q(e, d + 1), l = V(X(a), t), u = V(X(o), t);
		let f = X(H(a, O_(0, a.size)));
		s = V(f, X(a));
		let p = Lu(o.shape, a.size), m = z(O_(0, o.size), p), h = H(o, m);
		c = V(X(h), X(o));
		let g = Z(s, c), _ = Z(s, c), v = H(l, u);
		i = H(H(v, g), _);
		let y = Op(i, r);
		r = nf(y, i, r), n = nf(y, xy([d]), n);
	}
	return n;
}
var DS, OS = e((() => {
	Sy(), I(), _c(), $v(), wu(), $p(), kp(), Qf(), B(), U(), kc(), km(), av(), rf(), Ru(), Ql(), k_(), bo(), D(), P(), DS = /* @__PURE__ */ F({ threshold_: TS });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/image/transform.js
function kS(e, t, n = "nearest", r = "constant", i = 0, a) {
	let o = N(e, "image", "transform", "float32"), s = N(t, "transforms", "transform", "float32");
	v(o.rank === 4, () => `Error in transform: image must be rank 4,but got rank ${o.rank}.`), v(s.rank === 2 && (s.shape[0] === o.shape[0] || s.shape[0] === 1) && s.shape[1] === 8, () => "Error in transform: Input transform should be batch x 8 or 1 x 8"), v(a == null || a.length === 2, () => `Error in transform: outputShape must be [height, width] or null, but got ${a}.`);
	let c = {
		image: o,
		transforms: s
	}, l = {
		interpolation: n,
		fillMode: r,
		fillValue: i,
		outputShape: a
	};
	return j.runKernel(ei, c, l);
}
var AS, jS = e((() => {
	M(), T(), P(), D(), I(), AS = /* @__PURE__ */ F({ transform_: kS });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/linalg/band_part.js
function MS(e, t, n) {
	let r = N(e, "a", "bandPart");
	v(r.rank >= 2, () => `bandPart(): Rank must be at least 2, got ${r.rank}.`);
	let i = r.shape, [a, o] = r.shape.slice(-2), s, c;
	typeof t == "number" ? (v(t % 1 == 0, () => `bandPart(): numLower must be an integer, got ${t}.`), v(t <= a, () => `bandPart(): numLower (${t}) must not be greater than the number of rows (${a}).`), s = N(t < 0 ? a : t, "numLower", "bandPart")) : (v(t.dtype === "int32", () => "bandPart(): numLower's dtype must be an int32."), s = nf(Yp(t, 0), a, Sh(t, a))), typeof n == "number" ? (v(n % 1 == 0, () => `bandPart(): numUpper must be an integer, got ${n}.`), v(n <= o, () => `bandPart(): numUpper (${n}) must not be greater than the number of columns (${o}).`), c = N(n < 0 ? o : n, "numUpper", "bandPart")) : (v(n.dtype === "int32", () => "bandPart(): numUpper's dtype must be an int32."), c = nf(Yp(n, 0), o, Sh(n, o)));
	let l = W(O_(0, a, 1, "int32"), [-1, 1]), u = O_(0, o, 1, "int32"), d = Z(l, u), f = Lm(Qp(d, s), jp(d, bm(c))), p = hh([a, o], r.dtype);
	return W(uy(eb(W(r, [
		-1,
		a,
		o
	])).map((e) => nf(f, e, p))), i);
}
var NS, PS = e((() => {
	P(), D(), Mp(), Xp(), $p(), Rm(), Ch(), xm(), I(), k_(), G(), dy(), km(), tb(), rf(), gh(), NS = /* @__PURE__ */ F({ bandPart_: MS });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/linalg/gram_schmidt.js
function FS(e) {
	let t;
	if (Array.isArray(e)) {
		t = !1, v(e != null && e.length > 0, () => "Gram-Schmidt process: input must not be null, undefined, or empty");
		let n = e[0].shape[0];
		for (let t = 1; t < e.length; ++t) v(e[t].shape[0] === n, () => `Gram-Schmidt: Non-unique lengths found in the input vectors: (${e[t].shape[0]} vs. ${n})`);
	} else t = !0, e = Qv(e, e.shape[0], 0).map((e) => sy(e, [0]));
	v(e.length <= e[0].shape[0], () => `Gram-Schmidt: Number of vectors (${e.length}) exceeds number of dimensions (${e[0].shape[0]}).`);
	let n = [], r = e;
	for (let t = 0; t < e.length; ++t) n.push(j.tidy(() => {
		let e = r[t];
		if (t > 0) for (let r = 0; r < t; ++r) {
			let t = H(X(H(n[r], e)), n[r]);
			e = Z(e, t);
		}
		return V(e, tp(e, "euclidean"));
	}));
	return t ? uy(n, 0) : n;
}
var IS, LS = e((() => {
	M(), D(), kc(), U(), np(), I(), $v(), cy(), dy(), km(), Qf(), IS = /* @__PURE__ */ F({ gramSchmidt_: FS });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/linalg/qr.js
function RS(e, t = !1) {
	if (v(e.rank >= 2, () => `qr() requires input tensor to have a rank >= 2, but got rank ${e.rank}`), e.rank === 2) return zS(e, t);
	{
		let n = e.shape.slice(0, e.shape.length - 2).reduce((e, t) => e * t), r = eb(W(e, [
			n,
			e.shape[e.shape.length - 2],
			e.shape[e.shape.length - 1]
		]), 0), i = [], a = [];
		return r.forEach((e) => {
			let [n, r] = zS(e, t);
			i.push(n), a.push(r);
		}), [W(uy(i, 0), e.shape), W(uy(a, 0), e.shape)];
	}
}
function zS(e, t = !1) {
	return j.tidy(() => {
		v(e.shape.length === 2, () => `qr2d() requires a 2D Tensor, but got a ${e.shape.length}D Tensor.`);
		let n = e.shape[0], r = e.shape[1], i = yp(n), a = yc(e), o = Cy([[1]], [1, 1]), s = yc(o), c = n >= r ? r : n;
		for (let e = 0; e < c; ++e) {
			let t = a, c = s, l = i;
			[s, a, i] = j.tidy(() => {
				let t = q(a, [e, e], [n - e, 1]), c = tp(t), l = q(a, [e, e], [1, 1]), u = nf(Op(l, 0), Cy([[-1]]), Cy([[1]])), d = Z(l, H(u, c)), f = V(t, d);
				s = f.shape[0] === 1 ? yc(o) : Wl([o, q(f, [1, 0], [f.shape[0] - 1, f.shape[1]])], 0);
				let p = bm(V(K(u, d), c)), m = q(a, [e, 0], [n - e, r]), h = H(p, s), g = hb(s);
				if (e === 0) a = Z(m, K(h, K(g, m)));
				else {
					let t = Z(m, K(h, K(g, m)));
					a = Wl([q(a, [0, 0], [e, r]), t], 0);
				}
				let _ = hb(h), v = q(i, [0, e], [n, i.shape[1] - e]);
				if (e === 0) i = Z(v, K(K(v, s), _));
				else {
					let t = Z(v, K(K(v, s), _));
					i = Wl([q(i, [0, 0], [n, e]), t], 1);
				}
				return [
					s,
					a,
					i
				];
			}), Po([
				t,
				c,
				l
			]);
		}
		return !t && n > r && (i = q(i, [0, 0], [n, r]), a = q(a, [0, 0], [r, r])), [i, a];
	});
}
var BS, VS = e((() => {
	M(), Ko(), D(), bc(), Gl(), kc(), bp(), kp(), ql(), U(), xm(), np(), I(), G(), Ql(), dy(), km(), wy(), gb(), tb(), rf(), BS = /* @__PURE__ */ F({ qr_: RS });
})), HS, US = e((() => {
	(function(e) {
		e[e.NONE = 0] = "NONE", e[e.MEAN = 1] = "MEAN", e[e.SUM = 2] = "SUM", e[e.SUM_BY_NONZERO_WEIGHTS = 3] = "SUM_BY_NONZERO_WEIGHTS";
	})(HS ||= {});
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/losses/compute_weighted_loss.js
function WS(e, t, n = HS.SUM_BY_NONZERO_WEIGHTS) {
	let r = N(e, "losses", "computeWeightedLoss"), i = null;
	t != null && (i = N(t, "weights", "computeWeightedLoss"));
	let a = i == null ? r : H(r, i);
	if (n === HS.NONE) return a;
	if (n === HS.SUM) return X(a);
	if (n === HS.MEAN) {
		if (i == null) return ph(a);
		{
			let e = r.size / i.size, t = V(X(a), X(i));
			return e > 1 ? V(t, Y(e)) : t;
		}
	}
	if (n === HS.SUM_BY_NONZERO_WEIGHTS) {
		if (i == null) return V(X(a), Y(r.size));
		{
			let e = H(i, _h(r.shape)), t = R(X(Bh(e, Y(0))), "float32");
			return V(X(a), t);
		}
	}
	throw Error(`Unknown reduction: ${n}`);
}
var GS, KS = e((() => {
	P(), _c(), kc(), US(), mh(), U(), Vh(), vh(), I(), Wf(), Qf(), GS = /* @__PURE__ */ F({ computeWeightedLoss_: WS });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/losses/absolute_difference.js
function qS(e, t, n, r = HS.SUM_BY_NONZERO_WEIGHTS) {
	let i = N(e, "labels", "absoluteDifference"), a = N(t, "predictions", "absoluteDifference"), o = null;
	n != null && (o = N(n, "weights", "absoluteDifference")), y(i.shape, a.shape, "Error in absoluteDifference: ");
	let s = Mc(Z(i, a));
	return GS(s, o, r);
}
var JS, YS = e((() => {
	P(), D(), Nc(), US(), I(), km(), KS(), JS = /* @__PURE__ */ F({ absoluteDifference_: qS });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/losses/cosine_distance.js
function XS(e, t, n, r, i = HS.SUM_BY_NONZERO_WEIGHTS) {
	let a = N(e, "labels", "cosineDistance"), o = N(t, "predictions", "cosineDistance"), s = null;
	r != null && (s = N(r, "weights", "cosineDistance")), y(a.shape, o.shape, "Error in cosineDistance: ");
	let c = Y(1), l = Z(c, X(H(a, o), n, !0));
	return GS(l, s, i);
}
var ZS, QS = e((() => {
	P(), D(), US(), U(), I(), Wf(), km(), Qf(), KS(), ZS = /* @__PURE__ */ F({ cosineDistance_: XS });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/losses/hinge_loss.js
function $S(e, t, n, r = HS.SUM_BY_NONZERO_WEIGHTS) {
	let i = N(e, "labels", "hingeLoss"), a = N(t, "predictions", "hingeLoss"), o = null;
	n != null && (o = N(n, "weights", "hingeLoss")), y(i.shape, a.shape, "Error in hingeLoss: ");
	let s = Y(1);
	i = Z(H(Y(2), i), s);
	let c = L_(Z(s, H(i, a)));
	return GS(c, o, r);
}
var eC, tC = e((() => {
	P(), D(), US(), U(), I(), R_(), Wf(), km(), KS(), eC = /* @__PURE__ */ F({ hingeLoss_: $S });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/losses/huber_loss.js
function nC(e, t, n, r = 1, i = HS.SUM_BY_NONZERO_WEIGHTS) {
	let a = N(e, "labels", "huberLoss"), o = N(t, "predictions", "huberLoss"), s = null;
	n != null && (s = N(n, "weights", "huberLoss")), y(a.shape, o.shape, "Error in huberLoss: ");
	let c = Y(r), l = Mc(Z(o, a)), u = Sh(l, c), d = Z(l, u), f = z(H(Y(.5), Yf(u)), H(c, d));
	return GS(f, s, i);
}
var rC, iC = e((() => {
	P(), D(), Nc(), B(), US(), Ch(), U(), I(), Wf(), Xf(), km(), KS(), rC = /* @__PURE__ */ F({ huberLoss_: nC });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/losses/log_loss.js
function aC(e, t, n, r = 1e-7, i = HS.SUM_BY_NONZERO_WEIGHTS) {
	let a = N(e, "labels", "logLoss"), o = N(t, "predictions", "logLoss"), s = null;
	n != null && (s = N(n, "weights", "logLoss")), y(a.shape, o.shape, "Error in logLoss: ");
	let c = Y(1), l = Y(r), u = bm(H(a, om(z(o, l)))), d = H(Z(c, a), om(z(Z(c, o), l))), f = Z(u, d);
	return GS(f, s, i);
}
var oC, sC = e((() => {
	P(), D(), B(), sm(), US(), U(), xm(), I(), Wf(), km(), KS(), oC = /* @__PURE__ */ F({ logLoss_: aC });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/losses/mean_squared_error.js
function cC(e, t, n, r = HS.SUM_BY_NONZERO_WEIGHTS) {
	let i = N(e, "labels", "meanSquaredError"), a = N(t, "predictions", "meanSquaredError"), o = null;
	n != null && (o = N(n, "weights", "meanSquaredError")), y(i.shape, a.shape, "Error in meanSquaredError: ");
	let s = iy(i, a);
	return GS(s, o, r);
}
var lC, uC = e((() => {
	P(), D(), US(), I(), ay(), KS(), lC = /* @__PURE__ */ F({ meanSquaredError_: cC });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/losses/sigmoid_cross_entropy.js
function dC(e, t) {
	let n = N(e, "labels", "sigmoidCrossEntropyWithLogits"), r = N(t, "logits", "sigmoidCrossEntropyWithLogits");
	y(n.shape, r.shape, "Error in sigmoidCrossEntropyWithLogits: ");
	let i = L_(r), a = H(r, n), o = lm(sp(bm(Mc(r))));
	return z(Z(i, a), o);
}
function fC(e, t, n, r = 0, i = HS.SUM_BY_NONZERO_WEIGHTS) {
	let a = N(e, "multiClassLabels", "sigmoidCrossEntropy"), o = N(t, "logits", "sigmoidCrossEntropy"), s = null;
	if (n != null && (s = N(n, "weights", "sigmoidCrossEntropy")), y(a.shape, o.shape, "Error in sigmoidCrossEntropy: "), r > 0) {
		let e = Y(r), t = Y(1), n = Y(.5);
		a = z(H(a, Z(t, e)), H(n, e));
	}
	let c = dC(a, o);
	return GS(c, s, i);
}
var pC, mC = e((() => {
	P(), D(), Nc(), B(), cp(), um(), US(), U(), xm(), I(), R_(), Wf(), km(), KS(), pC = /* @__PURE__ */ F({ sigmoidCrossEntropy_: fC });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/losses/softmax_cross_entropy.js
function hC(e, t, n = -1) {
	if (n === -1 && (n = t.rank - 1), n !== t.rank - 1) throw Error(`Softmax cross entropy along a non-last dimension is not yet supported. Labels / logits was rank ${t.rank} and dim was ${n}`);
	return gm((e, t, r) => {
		let i = Pm(t, [n], !0), a = Z(R(t, "float32"), i);
		r([e, a]);
		let o = bm(H(a, e));
		return {
			value: X(o, [n]),
			gradFunc: (e, t) => {
				let [r, i] = t, a = kf(e.shape, [n]);
				return [H(W(e, a), Z(R(r, "float32"), sp(i))), H(W(e, a), Z(sp(i), R(r, "float32")))];
			}
		};
	})(e, t);
}
function gC(e, t, n, r = 0, i = HS.SUM_BY_NONZERO_WEIGHTS) {
	let a = N(e, "onehotLabels", "softmaxCrossEntropy"), o = N(t, "logits", "softmaxCrossEntropy"), s = null;
	if (n != null && (s = N(n, "weights", "softmaxCrossEntropy")), y(a.shape, o.shape, "Error in softmaxCrossEntropy: "), r > 0) {
		let e = Y(r), t = Y(1), n = Y(a.shape[1]);
		a = z(H(a, Z(t, e)), V(e, n));
	}
	let c = hC(a, o);
	return GS(c, s, i);
}
var _C, vC = e((() => {
	vm(), P(), D(), B(), Pf(), _c(), kc(), cp(), Fm(), US(), U(), xm(), I(), G(), Wf(), km(), Qf(), KS(), _C = /* @__PURE__ */ F({ softmaxCrossEntropy_: gC });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/sparse/sparse_fill_empty_rows.js
function yC(e, t, n, r) {
	let i = N(e, "indices", "sparseFillEmptyRows", "int32"), a = N(t, "values", "sparseFillEmptyRows"), o = N(n, "denseShape", "sparseFillEmptyRows", "int32"), s = N(r, "defaultValue", "sparseFillEmptyRows", a.dtype);
	if (i.rank !== 2) throw Error(`Indices should be Tensor2D but received shape
        ${i.shape}`);
	if (a.rank !== 1) throw Error(`Values should be Tensor1D but received shape ${a.shape}`);
	if (o.rank !== 1) throw Error(`Dense shape should be Tensor1D but received shape ${o.shape}`);
	if (s.rank !== 0) throw Error(`Default value should be a scalar but received shape ${s.shape}`);
	let c = {
		indices: i,
		values: a,
		denseShape: o,
		defaultValue: s
	}, l = j.runKernel(Lr, c);
	return {
		outputIndices: l[0],
		outputValues: l[1],
		emptyRowIndicator: l[2],
		reverseIndexMap: l[3]
	};
}
var bC, xC = e((() => {
	M(), T(), P(), I(), bC = /* @__PURE__ */ F({ sparseFillEmptyRows_: yC });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/sparse/sparse_reshape.js
function SC(e, t, n) {
	let r = N(e, "inputIndices", "sparseReshape", "int32"), i = N(t, "inputShape", "sparseReshape", "int32"), a = N(n, "newShape", "sparseReshape", "int32");
	if (r.rank !== 2) throw Error(`Input indices should be Tensor2D but received shape
        ${r.shape}`);
	if (i.rank !== 1) throw Error(`Input shape should be Tensor1D but received shape ${i.shape}`);
	if (a.rank !== 1) throw Error(`New shape should be Tensor1D but received shape ${a.shape}`);
	let o = {
		inputIndices: r,
		inputShape: i,
		newShape: a
	}, s = j.runKernel(Rr, o);
	return {
		outputIndices: s[0],
		outputShape: s[1]
	};
}
var CC, wC = e((() => {
	M(), T(), P(), I(), CC = /* @__PURE__ */ F({ sparseReshape_: SC });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/sparse/sparse_segment_mean.js
function TC(e, t, n) {
	let r = N(e, "data", "sparseSegmentMean"), i = N(t, "indices", "sparseSegmentMean", "int32"), a = N(n, "segmentIds", "sparseSegmentMean", "int32");
	if (r.rank < 1) throw Error("Data should be at least 1 dimensional but received scalar");
	if (i.rank !== 1) throw Error(`Indices should be Tensor1D but received shape
          ${i.shape}`);
	if (a.rank !== 1) throw Error(`Segment ids should be Tensor1D but received shape
          ${a.shape}`);
	let o = {
		data: r,
		indices: i,
		segmentIds: a
	};
	return j.runKernel(zr, o);
}
var EC, DC = e((() => {
	M(), T(), P(), I(), EC = /* @__PURE__ */ F({ sparseSegmentMean_: TC });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/sparse/sparse_segment_sum.js
function OC(e, t, n) {
	let r = N(e, "data", "sparseSegmentSum"), i = N(t, "indices", "sparseSegmentSum", "int32"), a = N(n, "segmentIds", "sparseSegmentSum", "int32");
	if (r.rank < 1) throw Error("Data should be at least 1 dimensional but received scalar");
	if (i.rank !== 1) throw Error(`Indices should be Tensor1D but received shape
         ${i.shape}`);
	if (a.rank !== 1) throw Error(`Segment ids should be Tensor1D but received shape
         ${a.shape}`);
	let o = {
		data: r,
		indices: i,
		segmentIds: a
	};
	return j.runKernel(Br, o);
}
var kC, AC = e((() => {
	M(), T(), P(), I(), kC = /* @__PURE__ */ F({ sparseSegmentSum_: OC });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/string/string_n_grams.js
function jC(e, t, n, r, i, a, o, s) {
	let c = N(e, "data", "stringNGrams", "string");
	if (c.dtype !== "string") throw Error("Data must be of datatype string");
	if (c.shape.length !== 1) throw Error(`Data must be a vector, saw: ${c.shape}`);
	let l = N(t, "dataSplits", "stringNGrams");
	if (l.dtype !== "int32") throw Error("Data splits must be of datatype int32");
	let u = {
		separator: n,
		nGramWidths: r,
		leftPad: i,
		rightPad: a,
		padWidth: o,
		preserveShortSequences: s
	}, d = {
		data: c,
		dataSplits: l
	}, f = j.runKernel(Kr, d, u);
	return {
		nGrams: f[0],
		nGramsSplits: f[1]
	};
}
var MC, NC = e((() => {
	M(), T(), P(), I(), MC = /* @__PURE__ */ F({ stringNGrams_: jC });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/string/string_split.js
function PC(e, t, n = !0) {
	let r = N(e, "input", "stringSplit", "string"), i = N(t, "delimiter", "stringSplit", "string");
	if (r.rank !== 1) throw Error(`Input should be Tensor1D but received shape ${r.shape}`);
	if (i.rank !== 0) throw Error(`Delimiter should be a scalar but received shape ${i.shape}`);
	let a = { skipEmpty: n }, o = {
		input: r,
		delimiter: i
	}, s = j.runKernel(qr, o, a);
	return {
		indices: s[0],
		values: s[1],
		shape: s[2]
	};
}
var FC, IC = e((() => {
	M(), T(), P(), I(), FC = /* @__PURE__ */ F({ stringSplit_: PC });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/string/string_to_hash_bucket_fast.js
function LC(e, t) {
	let n = N(e, "input", "stringToHashBucketFast", "string"), r = { numBuckets: t };
	if (t <= 0) throw Error("Number of buckets must be at least 1");
	let i = { input: n };
	return j.runKernel(Jr, i, r);
}
var RC, zC = e((() => {
	M(), T(), P(), I(), RC = /* @__PURE__ */ F({ stringToHashBucketFast_: LC });
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/string/static_regex_replace.js
function BC(e, t, n, r = !0) {
	let i = N(e, "input", "staticRegexReplace", "string"), a = {
		pattern: t,
		rewrite: n,
		replaceGlobal: r
	};
	return j.runKernel(Wr, { x: i }, a);
}
var VC, HC = e((() => {
	M(), T(), P(), I(), VC = /* @__PURE__ */ F({ staticRegexReplace_: BC });
})), UC, WC, GC, KC, qC, JC, YC, XC = e((() => {
	Nc(), Ic(), zc(), B(), Hc(), Gc(), Jc(), Zc(), el(), rl(), ol(), ll(), fl(), hl(), zl(), Hl(), iu(), su(), fu(), hu(), vu(), xu(), wu(), Du(), Au(), Nu(), hc(), _c(), Iu(), Vu(), bc(), go(), Gl(), Wu(), qu(), Xu(), $u(), ad(), nd(), dd(), md(), bd(), Cd(), Ed(), kd(), Md(), Fd(), Rd(), Vd(), Wd(), qd(), kc(), uf(), pf(), gf(), yf(), Sf(), ef(), Tf(), ap(), cp(), dp(), mp(), bp(), Ru(), Cp(), Dc(), Ep(), kp(), Mp(), Fp(), Rp(), Vp(), Wp(), qp(), Xp(), $p(), tm(), im(), sm(), um(), Dm(), Mm(), Fm(), Rm(), Vm(), Wm(), qm(), $m(), ql(), Lf(), nh(), ah(), ch(), dh(), mh(), bh(), Bf(), Ch(), Eh(), kh(), Mh(), U(), Fh(), Rh(), xm(), Vh(), Wh(), vh(), qh(), Xh(), $h(), ng(), ag(), cg(), dg(), yg(), Uf(), Sg(), Sc(), Tg(), Og(), jg(), Pg(), Lg(), h_(), v_(), x_(), w_(), D_(), k_(), M_(), F_(), R_(), V_(), G(), W_(), q_(), X_(), $_(), nv(), av(), cv(), Wf(), dv(), mv(), _v(), Xl(), bv(), Cv(), Ev(), Ql(), kv(), Mv(), Fv(), Rv(), Vv(), wm(), mg(), Wv(), qv(), Xv(), ny(), $v(), qf(), Xf(), ay(), cy(), dy(), my(), _y(), km(), Qf(), by(), tu(), bo(), Sy(), wy(), Ey(), Oy(), Ay(), My(), By(), _p(), Uy(), Ky(), Yy(), Qy(), tb(), rb(), ab(), rf(), ub(), gh(), sf(), pb(), gb(), np(), yb(), Sb(), Zm(), Db(), Ab(), Fb(), Rb(), Vb(), I(), fx(), hx(), vx(), xx(), wx(), Dx(), Ax(), Nx(), Ix(), zx(), Wx(), oS(), lS(), fS(), hS(), vS(), xS(), wS(), OS(), jS(), PS(), LS(), VS(), YS(), KS(), QS(), tC(), iC(), sC(), uC(), mC(), vC(), xC(), wC(), DC(), AC(), NC(), IC(), zC(), HC(), UC = {
		fft: Uv,
		ifft: Kv,
		rfft: ty,
		irfft: Yv
	}, WC = {
		hammingWindow: mx,
		hannWindow: _x,
		frame: bx,
		stft: Cx
	}, GC = {
		flipLeftRight: kx,
		grayscaleToRGB: Mx,
		resizeNearestNeighbor: CS,
		resizeBilinear: bS,
		rgbToGrayscale: Fx,
		rotateWithOffset: Rx,
		cropAndResize: Ex,
		nonMaxSuppression: Ux,
		nonMaxSuppressionAsync: aS,
		nonMaxSuppressionWithScore: cS,
		nonMaxSuppressionWithScoreAsync: dS,
		nonMaxSuppressionPadded: mS,
		nonMaxSuppressionPaddedAsync: _S,
		threshold: DS,
		transform: AS
	}, KC = {
		bandPart: NS,
		gramSchmidt: IS,
		qr: BS
	}, qC = {
		absoluteDifference: JS,
		computeWeightedLoss: GS,
		cosineDistance: ZS,
		hingeLoss: eC,
		huberLoss: rC,
		logLoss: oC,
		meanSquaredError: lC,
		sigmoidCrossEntropy: pC,
		softmaxCrossEntropy: _C
	}, JC = {
		sparseFillEmptyRows: bC,
		sparseReshape: CC,
		sparseSegmentMean: EC,
		sparseSegmentSum: kC
	}, YC = {
		stringNGrams: MC,
		stringSplit: FC,
		stringToHashBucketFast: RC,
		staticRegexReplace: VC
	};
})), ZC = /* @__PURE__ */ n({
	Serializable: () => nw,
	SerializationMap: () => rw,
	getRegisteredName: () => $C,
	registerClass: () => QC
});
function QC(e, t, n) {
	v(e.className != null, () => "Class being registered does not have the static className property defined."), v(typeof e.className == "string", () => "className is required to be a string, but got type " + typeof e.className), v(e.className.length > 0, () => "Class being registered has an empty-string as its className, which is disallowed."), t === void 0 && (t = "Custom"), n === void 0 && (n = e.className);
	let r = n, i = t + ">" + r;
	return rw.register(e), ew.set(i, e), tw.set(e, i), e;
}
function $C(e) {
	return tw.has(e) ? tw.get(e) : e.className;
}
var ew, tw, nw, rw, iw = e((() => {
	D(), ew = /* @__PURE__ */ new Map(), tw = /* @__PURE__ */ new Map(), nw = class {
		getClassName() {
			return this.constructor.className;
		}
		static fromConfig(e, t) {
			return new e(t);
		}
	}, rw = class e {
		constructor() {
			this.classNameMap = {};
		}
		static getMap() {
			return e.instance ??= new e(), e.instance;
		}
		static register(t) {
			e.getMap().classNameMap[t.className] = [t, t.fromConfig];
		}
	};
})), aw, ow = e((() => {
	Ko(), vm(), XC(), iw(), aw = class extends nw {
		minimize(e, t = !1, n) {
			let { value: r, grads: i } = this.computeGradients(e, n);
			if (n != null) {
				let e = n.map((e) => ({
					name: e.name,
					tensor: i[e.name]
				}));
				this.applyGradients(e);
			} else this.applyGradients(i);
			return Po(i), t ? r : (r.dispose(), null);
		}
		get iterations() {
			return this.iterations_ ??= 0, this.iterations_;
		}
		incrementIterations() {
			this.iterations_ = this.iterations + 1;
		}
		computeGradients(e, t) {
			return hm(e, t);
		}
		dispose() {
			this.iterations_ != null && Po(this.iterations_);
		}
		async saveIterations() {
			return this.iterations_ ??= 0, {
				name: "iter",
				tensor: Y(this.iterations_, "int32")
			};
		}
		async getWeights() {
			throw Error("getWeights() is not implemented for this optimizer yet.");
		}
		async setWeights(e) {
			throw Error(`setWeights() is not implemented for this optimizer class ${this.getClassName()}`);
		}
		async extractIterations(e) {
			return this.iterations_ = (await e[0].tensor.data())[0], e.slice(1);
		}
	}, Object.defineProperty(aw, Symbol.hasInstance, { value: (e) => e.minimize != null && e.computeGradients != null && e.applyGradients != null });
})), sw, cw = e((() => {
	M(), Ko(), B(), kc(), U(), XC(), Xf(), sf(), ow(), sw = class extends aw {
		static get className() {
			return "Adadelta";
		}
		constructor(e, t, n = null) {
			super(), this.learningRate = e, this.rho = t, this.epsilon = n, this.accumulatedGrads = [], this.accumulatedUpdates = [], n ?? (this.epsilon = j.backend.epsilon());
		}
		applyGradients(e) {
			(Array.isArray(e) ? e.map((e) => e.name) : Object.keys(e)).forEach((t, n) => {
				let r = j.registeredVariables[t];
				this.accumulatedGrads[n] ?? (this.accumulatedGrads[n] = {
					originalName: `${t}/accum_grad`,
					variable: L(() => of(r).variable(!1))
				}), this.accumulatedUpdates[n] ?? (this.accumulatedUpdates[n] = {
					originalName: `${t}/accum_var`,
					variable: L(() => of(r).variable(!1))
				});
				let i = Array.isArray(e) ? e[n].tensor : e[t];
				if (i == null) return;
				let a = this.accumulatedGrads[n].variable, o = this.accumulatedUpdates[n].variable;
				L(() => {
					let e = z(H(a, this.rho), H(Yf(i), 1 - this.rho)), t = H(V(Kf(z(o, this.epsilon)), Kf(z(a, this.epsilon))), i), n = z(H(o, this.rho), H(Yf(t), 1 - this.rho));
					a.assign(e), o.assign(n);
					let s = z(H(t, -this.learningRate), r);
					r.assign(s);
				});
			}), this.incrementIterations();
		}
		dispose() {
			this.accumulatedUpdates != null && (Po(this.accumulatedGrads.map((e) => e.variable)), Po(this.accumulatedUpdates.map((e) => e.variable)));
		}
		async getWeights() {
			let e = [...this.accumulatedGrads, ...this.accumulatedUpdates];
			return [await this.saveIterations()].concat(e.map((e) => ({
				name: e.originalName,
				tensor: e.variable
			})));
		}
		async setWeights(e) {
			e = await this.extractIterations(e);
			let t = e.length / 2;
			this.accumulatedGrads = e.slice(0, t).map((e) => ({
				originalName: e.name,
				variable: e.tensor.variable(!1)
			})), this.accumulatedUpdates = e.slice(t, t * 2).map((e) => ({
				originalName: e.name,
				variable: e.tensor.variable(!1)
			}));
		}
		getConfig() {
			return {
				learningRate: this.learningRate,
				rho: this.rho,
				epsilon: this.epsilon
			};
		}
		static fromConfig(e, t) {
			return new e(t.learningRate, t.rho, t.epsilon);
		}
	};
})), lw, uw = e((() => {
	M(), Ko(), B(), kc(), Ru(), U(), qf(), Xf(), ow(), lw = class extends aw {
		static get className() {
			return "Adagrad";
		}
		constructor(e, t = .1) {
			super(), this.learningRate = e, this.initialAccumulatorValue = t, this.accumulatedGrads = [];
		}
		applyGradients(e) {
			(Array.isArray(e) ? e.map((e) => e.name) : Object.keys(e)).forEach((t, n) => {
				let r = j.registeredVariables[t];
				this.accumulatedGrads[n] ?? (this.accumulatedGrads[n] = {
					originalName: `${t}/accumulator`,
					variable: L(() => Lu(r.shape, this.initialAccumulatorValue).variable(!1))
				});
				let i = Array.isArray(e) ? e[n].tensor : e[t];
				if (i == null) return;
				let a = this.accumulatedGrads[n].variable;
				L(() => {
					let e = z(a, Yf(i));
					a.assign(e);
					let t = z(H(V(i, Kf(z(e, j.backend.epsilon()))), -this.learningRate), r);
					r.assign(t);
				});
			}), this.incrementIterations();
		}
		dispose() {
			this.accumulatedGrads != null && Po(this.accumulatedGrads.map((e) => e.variable));
		}
		async getWeights() {
			return [await this.saveIterations()].concat(this.accumulatedGrads.map((e) => ({
				name: e.originalName,
				tensor: e.variable
			})));
		}
		async setWeights(e) {
			e = await this.extractIterations(e), this.accumulatedGrads = e.map((e) => ({
				originalName: e.name,
				variable: e.tensor.variable(!1)
			}));
		}
		getConfig() {
			return {
				learningRate: this.learningRate,
				initialAccumulatorValue: this.initialAccumulatorValue
			};
		}
		static fromConfig(e, t) {
			return new e(t.learningRate, t.initialAccumulatorValue);
		}
	};
})), dw, fw = e((() => {
	M(), Ko(), B(), kc(), U(), Uf(), Wf(), qf(), Xf(), km(), sf(), ow(), dw = class extends aw {
		static get className() {
			return "Adam";
		}
		constructor(e, t, n, r = null) {
			super(), this.learningRate = e, this.beta1 = t, this.beta2 = n, this.epsilon = r, this.accumulatedFirstMoment = [], this.accumulatedSecondMoment = [], L(() => {
				this.accBeta1 = Y(t).variable(), this.accBeta2 = Y(n).variable();
			}), r ?? (this.epsilon = j.backend.epsilon());
		}
		applyGradients(e) {
			let t = Array.isArray(e) ? e.map((e) => e.name) : Object.keys(e);
			L(() => {
				let n = Z(1, this.accBeta1), r = Z(1, this.accBeta2);
				t.forEach((t, i) => {
					let a = j.registeredVariables[t];
					this.accumulatedFirstMoment[i] ?? (this.accumulatedFirstMoment[i] = {
						originalName: `${t}/m`,
						variable: L(() => of(a).variable(!1))
					}), this.accumulatedSecondMoment[i] ?? (this.accumulatedSecondMoment[i] = {
						originalName: `${t}/v`,
						variable: L(() => of(a).variable(!1))
					});
					let o = Array.isArray(e) ? e[i].tensor : e[t];
					if (o == null) return;
					let s = this.accumulatedFirstMoment[i].variable, c = this.accumulatedSecondMoment[i].variable, l = z(H(s, this.beta1), H(o, 1 - this.beta1)), u = z(H(c, this.beta2), H(Yf(o), 1 - this.beta2)), d = V(l, n), f = V(u, r);
					s.assign(l), c.assign(u);
					let p = z(H(V(d, z(Kf(f), this.epsilon)), -this.learningRate), a);
					a.assign(p);
				}), this.accBeta1.assign(H(this.accBeta1, this.beta1)), this.accBeta2.assign(H(this.accBeta2, this.beta2));
			}), this.incrementIterations();
		}
		dispose() {
			this.accBeta1.dispose(), this.accBeta2.dispose(), this.accumulatedFirstMoment != null && Po(this.accumulatedFirstMoment.map((e) => e.variable)), this.accumulatedSecondMoment != null && Po(this.accumulatedSecondMoment.map((e) => e.variable));
		}
		async getWeights() {
			let e = [...this.accumulatedFirstMoment, ...this.accumulatedSecondMoment];
			return [await this.saveIterations()].concat(e.map((e) => ({
				name: e.originalName,
				tensor: e.variable
			})));
		}
		async setWeights(e) {
			e = await this.extractIterations(e), L(() => {
				this.accBeta1.assign(Hf(this.beta1, this.iterations_ + 1)), this.accBeta2.assign(Hf(this.beta2, this.iterations_ + 1));
			});
			let t = e.length / 2;
			this.accumulatedFirstMoment = e.slice(0, t).map((e) => ({
				originalName: e.name,
				variable: e.tensor.variable(!1)
			})), this.accumulatedSecondMoment = e.slice(t, t * 2).map((e) => ({
				originalName: e.name,
				variable: e.tensor.variable(!1)
			}));
		}
		getConfig() {
			return {
				learningRate: this.learningRate,
				beta1: this.beta1,
				beta2: this.beta2,
				epsilon: this.epsilon
			};
		}
		static fromConfig(e, t) {
			return new e(t.learningRate, t.beta1, t.beta2, t.epsilon);
		}
	};
})), pw, mw = e((() => {
	M(), Ko(), Nc(), B(), kc(), dh(), U(), Wf(), km(), sf(), ow(), pw = class extends aw {
		static get className() {
			return "Adamax";
		}
		constructor(e, t, n, r = null, i = 0) {
			super(), this.learningRate = e, this.beta1 = t, this.beta2 = n, this.epsilon = r, this.decay = i, this.accumulatedFirstMoment = [], this.accumulatedWeightedInfNorm = [], L(() => {
				this.iteration = Y(0).variable(), this.accBeta1 = Y(t).variable();
			}), r ?? (this.epsilon = j.backend.epsilon());
		}
		applyGradients(e) {
			let t = Array.isArray(e) ? e.map((e) => e.name) : Object.keys(e);
			L(() => {
				let n = Z(1, this.accBeta1), r = V(-this.learningRate, z(H(this.iteration, this.decay), 1));
				t.forEach((t, i) => {
					let a = j.registeredVariables[t];
					this.accumulatedFirstMoment[i] ?? (this.accumulatedFirstMoment[i] = {
						originalName: `${t}/m`,
						variable: of(a).variable(!1)
					}), this.accumulatedWeightedInfNorm[i] ?? (this.accumulatedWeightedInfNorm[i] = {
						originalName: `${t}/v`,
						variable: of(a).variable(!1)
					});
					let o = Array.isArray(e) ? e[i].tensor : e[t];
					if (o == null) return;
					let s = this.accumulatedFirstMoment[i].variable, c = this.accumulatedWeightedInfNorm[i].variable, l = z(H(s, this.beta1), H(o, 1 - this.beta1)), u = H(c, this.beta2), d = Mc(o), f = uh(u, d);
					s.assign(l), c.assign(f);
					let p = z(H(V(r, n), V(l, z(f, this.epsilon))), a);
					a.assign(p);
				}), this.iteration.assign(z(this.iteration, 1)), this.accBeta1.assign(H(this.accBeta1, this.beta1));
			}), this.incrementIterations();
		}
		dispose() {
			this.accBeta1.dispose(), this.iteration.dispose(), this.accumulatedFirstMoment != null && Po(this.accumulatedFirstMoment.map((e) => e.variable)), this.accumulatedWeightedInfNorm != null && Po(this.accumulatedWeightedInfNorm.map((e) => e.variable));
		}
		async getWeights() {
			throw Error("getWeights() is not implemented for Adamax yet.");
		}
		async setWeights(e) {
			throw Error("setWeights() is not implemented for Adamax yet.");
		}
		getConfig() {
			return {
				learningRate: this.learningRate,
				beta1: this.beta1,
				beta2: this.beta2,
				epsilon: this.epsilon,
				decay: this.decay
			};
		}
		static fromConfig(e, t) {
			return new e(t.learningRate, t.beta1, t.beta2, t.epsilon, t.decay);
		}
	};
})), hw, gw = e((() => {
	M(), Ko(), B(), U(), Wf(), ow(), hw = class extends aw {
		static get className() {
			return "SGD";
		}
		constructor(e) {
			super(), this.learningRate = e, this.setLearningRate(e);
		}
		applyGradients(e) {
			(Array.isArray(e) ? e.map((e) => e.name) : Object.keys(e)).forEach((t, n) => {
				let r = Array.isArray(e) ? e[n].tensor : e[t];
				if (r == null) return;
				let i = j.registeredVariables[t];
				L(() => {
					let e = z(H(this.c, r), i);
					i.assign(e);
				});
			}), this.incrementIterations();
		}
		setLearningRate(e) {
			this.learningRate = e, this.c != null && this.c.dispose(), this.c = Fo(Y(-e));
		}
		dispose() {
			this.c.dispose();
		}
		async getWeights() {
			return [await this.saveIterations()];
		}
		async setWeights(e) {
			if (e = await this.extractIterations(e), e.length !== 0) throw Error("SGD optimizer does not have settable weights.");
		}
		getConfig() {
			return { learningRate: this.learningRate };
		}
		static fromConfig(e, t) {
			return new e(t.learningRate);
		}
	};
})), _w, vw = e((() => {
	M(), Ko(), B(), U(), Wf(), sf(), gw(), _w = class extends hw {
		static get className() {
			return "Momentum";
		}
		constructor(e, t, n = !1) {
			super(e), this.learningRate = e, this.momentum = t, this.useNesterov = n, this.accumulations = [], this.m = Y(this.momentum);
		}
		applyGradients(e) {
			(Array.isArray(e) ? e.map((e) => e.name) : Object.keys(e)).forEach((t, n) => {
				let r = j.registeredVariables[t];
				this.accumulations[n] ?? (this.accumulations[n] = {
					originalName: `${t}/momentum`,
					variable: L(() => of(r).variable(!1))
				});
				let i = this.accumulations[n].variable, a = Array.isArray(e) ? e[n].tensor : e[t];
				a != null && L(() => {
					let e, t = z(H(this.m, i), a);
					e = this.useNesterov ? z(H(this.c, z(a, H(t, this.m))), r) : z(H(this.c, t), r), i.assign(t), r.assign(e);
				});
			}), this.incrementIterations();
		}
		dispose() {
			this.m.dispose(), this.accumulations != null && Po(this.accumulations.map((e) => e.variable));
		}
		setMomentum(e) {
			this.momentum = e;
		}
		async getWeights() {
			return [await this.saveIterations()].concat(this.accumulations.map((e) => ({
				name: e.originalName,
				tensor: e.variable
			})));
		}
		async setWeights(e) {
			e = await this.extractIterations(e), this.accumulations = e.map((e) => ({
				originalName: e.name,
				variable: e.tensor.variable(!1)
			}));
		}
		getConfig() {
			return {
				learningRate: this.learningRate,
				momentum: this.momentum,
				useNesterov: this.useNesterov
			};
		}
		static fromConfig(e, t) {
			return new e(t.learningRate, t.momentum, t.useNesterov);
		}
	};
})), yw, bw = e((() => {
	M(), Ko(), B(), kc(), U(), qf(), Xf(), km(), sf(), ow(), yw = class extends aw {
		static get className() {
			return "RMSProp";
		}
		constructor(e, t = .9, n = 0, r = null, i = !1) {
			if (super(), this.learningRate = e, this.decay = t, this.momentum = n, this.epsilon = r, this.accumulatedMeanSquares = [], this.accumulatedMoments = [], this.accumulatedMeanGrads = [], this.centered = i, r ?? (this.epsilon = j.backend.epsilon()), e == null) throw Error("learningRate for RMSPropOptimizer must be defined.");
		}
		applyGradients(e) {
			(Array.isArray(e) ? e.map((e) => e.name) : Object.keys(e)).forEach((t, n) => {
				let r = j.registeredVariables[t];
				this.accumulatedMeanSquares[n] ?? (this.accumulatedMeanSquares[n] = {
					originalName: `${t}/rms`,
					variable: L(() => of(r).variable(!1))
				}), this.accumulatedMoments[n] ?? (this.accumulatedMoments[n] = {
					originalName: `${t}/momentum`,
					variable: L(() => of(r).variable(!1))
				}), this.accumulatedMeanGrads[n] == null && this.centered && (this.accumulatedMeanGrads[n] = {
					originalName: `${t}/mg`,
					variable: L(() => of(r).variable(!1))
				});
				let i = Array.isArray(e) ? e[n].tensor : e[t];
				if (i == null) return;
				let a = this.accumulatedMeanSquares[n].variable, o = this.accumulatedMoments[n].variable;
				L(() => {
					let e = z(H(a, this.decay), H(Yf(i), 1 - this.decay));
					if (this.centered) {
						let t = this.accumulatedMeanGrads[n].variable, s = z(H(t, this.decay), H(i, 1 - this.decay)), c = V(H(i, this.learningRate), Kf(Z(e, z(Yf(s), this.epsilon)))), l = z(H(o, this.momentum), c);
						a.assign(e), t.assign(s), o.assign(l);
						let u = Z(r, l);
						r.assign(u);
					} else {
						let e = z(H(a, this.decay), H(Yf(i), 1 - this.decay)), t = z(H(o, this.momentum), V(H(i, this.learningRate), Kf(z(e, this.epsilon))));
						a.assign(e), o.assign(t);
						let n = Z(r, t);
						r.assign(n);
					}
				});
			}), this.incrementIterations();
		}
		dispose() {
			this.accumulatedMeanSquares != null && Po(this.accumulatedMeanSquares.map((e) => e.variable)), this.accumulatedMeanGrads != null && this.centered && Po(this.accumulatedMeanGrads.map((e) => e.variable)), this.accumulatedMoments != null && Po(this.accumulatedMoments.map((e) => e.variable));
		}
		async getWeights() {
			let e = [...this.accumulatedMeanSquares, ...this.accumulatedMoments];
			return this.centered && e.push(...this.accumulatedMeanGrads), [await this.saveIterations()].concat(e.map((e) => ({
				name: e.originalName,
				tensor: e.variable
			})));
		}
		async setWeights(e) {
			e = await this.extractIterations(e);
			let t = this.centered ? e.length / 3 : e.length / 2;
			this.accumulatedMeanSquares = e.slice(0, t).map((e) => ({
				originalName: e.name,
				variable: e.tensor.variable(!1)
			})), this.accumulatedMoments = e.slice(t, t * 2).map((e) => ({
				originalName: e.name,
				variable: e.tensor.variable(!1)
			})), this.centered && (this.accumulatedMeanGrads = e.slice(t * 2, t * 3).map((e) => ({
				originalName: e.name,
				variable: e.tensor.variable(!1)
			})));
		}
		getConfig() {
			return {
				learningRate: this.learningRate,
				decay: this.decay,
				momentum: this.momentum,
				epsilon: this.epsilon,
				centered: this.centered
			};
		}
		static fromConfig(e, t) {
			return new e(t.learningRate, t.decay, t.momentum, t.epsilon, t.centered);
		}
	};
}));
// node_modules/@tensorflow/tfjs-core/dist/optimizers/register_optimizers.js
function xw() {
	for (let e of Sw) QC(e);
}
var Sw, Cw = e((() => {
	cw(), uw(), fw(), mw(), vw(), bw(), gw(), iw(), Sw = [
		sw,
		lw,
		dw,
		pw,
		_w,
		yw,
		hw
	];
}));
// node_modules/@tensorflow/tfjs-core/dist/io/browser_files.js
function ww(e) {
	return new Promise((e) => setTimeout(e)).then(e);
}
function Tw(e = "model") {
	return new Aw(e);
}
function Ew(e) {
	return new jw(e);
}
var Dw, Ow, kw, Aw, jw, Mw, Nw = e((() => {
	so(), He(), _s(), Cs(), To(), Dw = "model", Ow = ".json", kw = ".weights.bin", Aw = class e {
		constructor(t) {
			if (!w().getBool("IS_BROWSER")) throw Error("browserDownloads() cannot proceed because the current environment is not a browser.");
			t.startsWith(e.URL_SCHEME) && (t = t.slice(e.URL_SCHEME.length)), (t == null || t.length === 0) && (t = Dw), this.modelJsonFileName = t + Ow, this.weightDataFileName = t + kw;
		}
		async save(e) {
			if (typeof document > "u") throw Error("Browser downloads are not supported in this environment since `document` is not present");
			let t = wo.join(e.weightData), n = window.URL.createObjectURL(new Blob([t], { type: "application/octet-stream" }));
			if (e.modelTopology instanceof ArrayBuffer) throw Error("BrowserDownloads.save() does not support saving model topology in binary formats yet.");
			{
				let t = os(e, [{
					paths: ["./" + this.weightDataFileName],
					weights: e.weightSpecs
				}]), r = window.URL.createObjectURL(new Blob([JSON.stringify(t)], { type: "application/json" })), i = this.modelJsonAnchor == null ? document.createElement("a") : this.modelJsonAnchor;
				if (i.download = this.modelJsonFileName, i.href = r, await ww(() => i.dispatchEvent(new MouseEvent("click"))), e.weightData != null) {
					let e = this.weightDataAnchor == null ? document.createElement("a") : this.weightDataAnchor;
					e.download = this.weightDataFileName, e.href = n, await ww(() => e.dispatchEvent(new MouseEvent("click")));
				}
				return { modelArtifactsInfo: ls(e) };
			}
		}
	}, Aw.URL_SCHEME = "downloads://", jw = class {
		constructor(e) {
			if (e == null || e.length < 1) throw Error(`When calling browserFiles, at least 1 file is required, but received ${e}`);
			this.jsonFile = e[0], this.weightsFiles = e.slice(1);
		}
		async load() {
			return new Promise((e, t) => {
				let n = new FileReader();
				n.onload = (n) => {
					let r = JSON.parse(n.target.result), i = r.modelTopology;
					i == null ? t(/* @__PURE__ */ Error(`modelTopology field is missing from file ${this.jsonFile.name}`)) : r.weightsManifest == null ? t(/* @__PURE__ */ Error(`weightManifest field is missing from file ${this.jsonFile.name}`)) : this.weightsFiles.length === 0 ? e({ modelTopology: i }) : e(cs(r, (e) => this.loadWeights(e)));
				}, n.onerror = (e) => t(`Failed to read model topology and weights manifest JSON from file '${this.jsonFile.name}'. BrowserFiles supports loading Keras-style tf.Model artifacts only.`), n.readAsText(this.jsonFile);
			});
		}
		loadWeights(e) {
			let t = [], n = [];
			for (let r of e) t.push(...r.weights), n.push(...r.paths);
			let r = this.checkManifestAndWeightFiles(e), i = n.map((e) => this.loadWeightsFile(e, r[e]));
			return Promise.all(i).then((e) => [t, e]);
		}
		loadWeightsFile(e, t) {
			return new Promise((n, r) => {
				let i = new FileReader();
				i.onload = (e) => {
					let t = e.target.result;
					n(t);
				}, i.onerror = (t) => r(`Failed to weights data from file of path '${e}'.`), i.readAsArrayBuffer(t);
			});
		}
		checkManifestAndWeightFiles(e) {
			let t = [], n = this.weightsFiles.map((e) => as(e.name)), r = {};
			for (let i of e) i.paths.forEach((e) => {
				let i = as(e);
				if (t.indexOf(i) !== -1) throw Error(`Duplicate file basename found in weights manifest: '${i}'`);
				if (t.push(i), n.indexOf(i) === -1) throw Error(`Weight file with basename '${i}' is not provided.`);
				r[e] = this.weightsFiles[n.indexOf(i)];
			});
			if (t.length !== this.weightsFiles.length) throw Error(`Mismatch in the number of files in weights manifest (${t.length}) and the number of weight files provided (${this.weightsFiles.length}).`);
			return r;
		}
	}, Mw = (e) => w().getBool("IS_BROWSER") && !Array.isArray(e) && e.startsWith(Aw.URL_SCHEME) ? Tw(e.slice(Aw.URL_SCHEME.length)) : null, vs.registerSaveRouter(Mw);
}));
// node_modules/@tensorflow/tfjs-core/dist/io/progress.js
function Pw(e, t, n, r) {
	o(e), n ??= 0, r ??= 1, s(n, r);
	let i = 0, a = (a) => (a.then((a) => (t(n + ++i / e.length * (r - n)), a)), a);
	function o(e) {
		v(e != null && Array.isArray(e) && e.length > 0, () => "promises must be a none empty array");
	}
	function s(e, t) {
		v(e >= 0 && e <= 1, () => `Progress fraction must be in range [0, 1], but got startFraction ${e}`), v(t >= 0 && t <= 1, () => `Progress fraction must be in range [0, 1], but got endFraction ${t}`), v(t >= e, () => `startFraction must be no more than endFraction, but got startFraction ${e} and endFraction ${t}`);
	}
	return Promise.all(e.map(a));
}
var Fw = e((() => {
	D();
}));
// node_modules/@tensorflow/tfjs-core/dist/io/weights_loader.js
async function Iw(e, t) {
	t ??= {};
	let n = t.fetchFunc == null ? w().platform.fetch : t.fetchFunc, r = e.map((e) => n(e, t.requestInit, { isBinary: !0 })), i = (t.onProgress == null ? await Promise.all(r) : await Pw(r, t.onProgress, 0, .5)).map((e) => e.arrayBuffer());
	return t.onProgress == null ? await Promise.all(i) : await Pw(i, t.onProgress, .5, 1);
}
function Lw(e, t) {
	var n;
	let r = t.fetchFunc == null ? w().platform.fetch : t.fetchFunc, i = 0, a;
	return (n = t.onProgress) == null || n.call(t, 0), new ReadableStream({ pull: async (n) => {
		for (var o; i < e.length;) {
			a ||= (await r(e[i], t.requestInit, { isBinary: !0 })).body.getReader();
			let { done: s, value: c } = await a.read();
			if (s) i++, a = void 0, (o = t.onProgress) == null || o.call(t, i / e.length);
			else {
				n.enqueue(c);
				return;
			}
		}
		n.close();
	} });
}
async function Rw(e, t = "", n, r) {
	return zw((e) => Iw(e, { requestInit: r }))(e, t, n);
}
function zw(e) {
	return async (t, n = "", r) => {
		let i = t.map(() => !1), a = {}, o = r == null ? [] : r.map(() => !1), s = [];
		if (t.forEach((e, t) => {
			let n = 0;
			e.weights.forEach((e) => {
				let c = "quantization" in e ? e.quantization.dtype : e.dtype, l = xo[c] * x(e.shape), u = () => {
					i[t] = !0, a[t] ?? (a[t] = []), a[t].push({
						manifestEntry: e,
						groupOffset: n,
						sizeBytes: l
					});
				};
				r == null ? u() : r.forEach((t, n) => {
					t === e.name && (u(), o[n] = !0);
				}), s.push(e.name), n += l;
			});
		}), !o.every((e) => e)) {
			let e = r.filter((e, t) => !o[t]);
			throw Error(`Could not find weights in manifest with names: ${e.join(", ")}. \nManifest JSON has weights with names: ${s.join(", ")}.`);
		}
		let c = i.reduce((e, t, n) => (t && e.push(n), e), []), l = [];
		c.forEach((e) => {
			t[e].paths.forEach((e) => {
				let t = n + (n.endsWith("/") ? "" : "/") + e;
				l.push(t);
			});
		});
		let u = await e(l), d = {}, f = 0;
		return c.forEach((e) => {
			let n = t[e].paths.length, r = new wo(u.slice(f, f + n));
			a[e].forEach((e) => {
				let t = Jo(r.slice(e.groupOffset, e.groupOffset + e.sizeBytes), [e.manifestEntry]);
				for (let e in t) d[e] = t[e];
			}), f += n;
		}), d;
	};
}
var Bw = e((() => {
	He(), D(), To(), _s(), Fw(), So();
}));
// node_modules/@tensorflow/tfjs-core/dist/io/http.js
function Vw(e) {
	let t = e.lastIndexOf("/"), n = e.lastIndexOf("?"), r = e.substring(0, t), i = n > t ? e.substring(n) : "";
	return [r + "/", i];
}
function Hw(e) {
	return e.match(qw.URL_SCHEME_REGEX) != null;
}
function Uw(e, t) {
	return new qw(e, t);
}
function Ww(e, t) {
	return Uw(e, t);
}
var Gw, Kw, qw, Jw, Yw = e((() => {
	He(), D(), _s(), To(), Cs(), Bw(), Gw = "application/octet-stream", Kw = "application/json", qw = class {
		constructor(e, t) {
			if (this.DEFAULT_METHOD = "POST", t ??= {}, this.weightPathPrefix = t.weightPathPrefix, this.weightUrlConverter = t.weightUrlConverter, t.fetchFunc == null ? this.fetch = w().platform.fetch : (v(typeof t.fetchFunc == "function", () => "Must pass a function that matches the signature of `fetch` (see https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API)"), this.fetch = t.fetchFunc), v(e != null && e.length > 0, () => "URL path for http must not be null, undefined or empty."), Array.isArray(e) && v(e.length === 2, () => `URL paths for http must have a length of 2, (actual length is ${e.length}).`), this.path = e, t.requestInit != null && t.requestInit.body != null) throw Error("requestInit is expected to have no pre-existing body, but has one.");
			this.requestInit = t.requestInit || {}, this.loadOptions = t;
		}
		async save(e) {
			if (e.modelTopology instanceof ArrayBuffer) throw Error("BrowserHTTPRequest.save() does not support saving model topology in binary formats yet.");
			let t = Object.assign({ method: this.DEFAULT_METHOD }, this.requestInit);
			t.body = new FormData();
			let n = os(e, [{
				paths: ["./model.weights.bin"],
				weights: e.weightSpecs
			}]);
			if (t.body.append("model.json", new Blob([JSON.stringify(n)], { type: Kw }), "model.json"), e.weightData != null) {
				let n = wo.join(e.weightData);
				t.body.append("model.weights.bin", new Blob([n], { type: Gw }), "model.weights.bin");
			}
			let r = await this.fetch(this.path, t);
			if (r.ok) return {
				modelArtifactsInfo: ls(e),
				responses: [r]
			};
			throw Error(`BrowserHTTPRequest.save() failed due to HTTP response status ${r.status}.`);
		}
		async loadModelJSON() {
			let e = await this.fetch(this.path, this.requestInit);
			if (!e.ok) throw Error(`Request to ${this.path} failed with status code ${e.status}. Please verify this URL points to the model JSON of the model to load.`);
			let t;
			try {
				t = await e.json();
			} catch {
				let e = `Failed to parse model JSON of response from ${this.path}.`;
				throw this.path.endsWith(".pb") ? e += " Your path contains a .pb file extension. Support for .pb models have been removed in TensorFlow.js 1.0 in favor of .json models. You can re-convert your Python TensorFlow model using the TensorFlow.js 1.0 conversion scripts or you can convert your.pb models with the 'pb2json'NPM script in the tensorflow/tfjs-converter repository." : e += " Please make sure the server is serving valid JSON for this request.", Error(e);
			}
			let n = t.modelTopology, r = t.weightsManifest;
			if (n == null && r == null) throw Error(`The JSON from HTTP path ${this.path} contains neither model topology or manifest for weights.`);
			return t;
		}
		async load() {
			return this.loadOptions.streamWeights ? this.loadStream() : cs(await this.loadModelJSON(), (e) => this.loadWeights(e));
		}
		async loadStream() {
			let e = await this.loadModelJSON(), t = await this.getWeightUrls(e.weightsManifest), n = us(e.weightsManifest);
			return Object.assign(Object.assign({}, e), {
				weightSpecs: n,
				getWeightStream: () => Lw(t, this.loadOptions)
			});
		}
		async getWeightUrls(e) {
			let [t, n] = Vw(Array.isArray(this.path) ? this.path[1] : this.path), r = this.weightPathPrefix || t, i = [], a = [];
			for (let t of e) for (let e of t.paths) this.weightUrlConverter == null ? i.push(r + e + n) : a.push(this.weightUrlConverter(e));
			return this.weightUrlConverter && i.push(...await Promise.all(a)), i;
		}
		async loadWeights(e) {
			let t = await this.getWeightUrls(e);
			return [us(e), await Iw(t, this.loadOptions)];
		}
	}, qw.URL_SCHEME_REGEX = /^https?:\/\//, Jw = (e, t) => {
		if (typeof fetch > "u" && (t == null || t.fetchFunc == null)) return null;
		{
			let n = !0;
			if (n = Array.isArray(e) ? e.every((e) => Hw(e)) : Hw(e), n) return Uw(e, t);
		}
		return null;
	}, vs.registerSaveRouter(Jw), vs.registerLoadRouter(Jw);
}));
// node_modules/@tensorflow/tfjs-core/dist/io/passthrough.js
function Xw(e, t, n, r) {
	let i = arguments;
	return new nT(Zw(...i));
}
function Zw(e, t, n, r) {
	return arguments.length === 1 ? e.modelTopology != null || e.weightSpecs != null ? new eT(e) : (console.warn("Please call tf.io.fromMemory() with only one argument. The argument should be of type ModelArtifacts. The multi-argument signature of tf.io.fromMemory() has been deprecated and will be removed in a future release."), new eT({ modelTopology: e })) : (console.warn("Please call tf.io.fromMemory() with only one argument. The argument should be of type ModelArtifacts. The multi-argument signature of tf.io.fromMemory() has been deprecated and will be removed in a future release."), new eT({
		modelTopology: e,
		weightSpecs: t,
		weightData: n,
		trainingConfig: r
	}));
}
function Qw(e) {
	return new tT(e);
}
function $w(e) {
	return new tT(e);
}
var eT, tT, nT, rT = e((() => {
	eT = class {
		constructor(e) {
			this.modelArtifacts = e;
		}
		load() {
			return this.modelArtifacts;
		}
	}, tT = class {
		constructor(e) {
			this.saveHandler = e;
		}
		save(e) {
			return this.saveHandler(e);
		}
	}, nT = class {
		constructor(e) {
			e.load && (this.load = () => Promise.resolve(e.load())), e.save && (this.save = (t) => Promise.resolve(e.save(t)));
		}
	};
})), iT = /* @__PURE__ */ n({
	CompositeArrayBuffer: () => wo,
	browserFiles: () => Ew,
	browserHTTPRequest: () => Ww,
	concatenateArrayBuffers: () => is,
	copyModel: () => nc,
	decodeWeights: () => Jo,
	decodeWeightsStream: () => $o,
	encodeWeights: () => qo,
	fromMemory: () => Xw,
	fromMemorySync: () => Zw,
	getLoadHandlers: () => Ss,
	getModelArtifactsForJSON: () => cs,
	getModelArtifactsForJSONSync: () => ss,
	getModelArtifactsInfoForJSON: () => ls,
	getSaveHandlers: () => xs,
	getWeightSpecs: () => us,
	http: () => Uw,
	isHTTPScheme: () => Hw,
	listModels: () => ec,
	loadWeights: () => Rw,
	moveModel: () => rc,
	registerLoadRouter: () => bs,
	registerSaveRouter: () => ys,
	removeModel: () => tc,
	weightsLoaderFactory: () => zw,
	withSaveHandler: () => Qw,
	withSaveHandlerSync: () => $w
}), aT = e((() => {
	Fs(), Zs(), Nw(), Yw(), _s(), rT(), Cs(), Bw(), To(), oc();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/confusion_matrix.js
function oT(e, t, n) {
	let r = N(e, "labels", "confusionMatrix"), i = N(t, "predictions", "confusionMatrix");
	v(n == null || n > 0 && Number.isInteger(n), () => `If provided, numClasses must be a positive integer, but got ${n}`), v(r.rank === 1, () => `Expected the rank of labels to be 1, but got ${r.rank}`), v(i.rank === 1, () => `Expected the rank of predictions to be 1, but got ${i.rank}`), v(r.shape[0] === i.shape[0], () => `Mismatch in the number of examples: ${r.shape[0]} vs. ${i.shape[0]}. Labels and predictions should have the same number of elements.`), v(n > 0 && Number.isInteger(n), () => `numClasses is required to be a positive integer, but got ${n}`);
	let a = Uh(R(r, "int32"), n), o = Uh(R(i, "int32"), n), s = hb(a), c = K(s, o);
	return R(c, "int32");
}
var sT, cT = e((() => {
	P(), D(), _c(), ql(), Wh(), I(), gb(), sT = /* @__PURE__ */ F({ confusionMatrix_: oT });
})), lT = /* @__PURE__ */ n({ confusionMatrix: () => sT }), uT = e((() => {
	cT();
})), dT = /* @__PURE__ */ n({
	draw: () => xT,
	fromPixels: () => wT,
	fromPixelsAsync: () => _T,
	toPixels: () => bT
});
function fT(e, t = 3) {
	if (t > 4) throw Error("Cannot construct Tensor with more than 4 channels from pixels.");
	if (e == null) throw Error("pixels passed to tf.browser.fromPixels() can not be null");
	let n = !1, r = !1, i = !1, a = !1, o = !1, s = !1;
	if (e.data instanceof Uint8Array) n = !0;
	else if (typeof ImageData < "u" && e instanceof ImageData) r = !0;
	else if (typeof HTMLVideoElement < "u" && e instanceof HTMLVideoElement) i = !0;
	else if (typeof HTMLImageElement < "u" && e instanceof HTMLImageElement) a = !0;
	else if (e.getContext != null) o = !0;
	else if (typeof ImageBitmap < "u" && e instanceof ImageBitmap) s = !0;
	else throw Error(`pixels passed to tf.browser.fromPixels() must be either an HTMLVideoElement, HTMLImageElement, HTMLCanvasElement, ImageData in browser, or OffscreenCanvas, ImageData in webworker or {data: Uint32Array, width: number, height: number}, but was ${e.constructor.name}`);
	if (gi("FromPixels", j.backendName) != null) {
		let n = { pixels: e }, r = { numChannels: t };
		return j.runKernel(ci, n, r);
	}
	let [c, l] = i ? [e.videoWidth, e.videoHeight] : [e.width, e.height], u;
	if (o) u = e.getContext("2d").getImageData(0, 0, c, l).data;
	else if (r || n) u = e.data;
	else if (a || i || s) {
		if (ST == null) {
			if (typeof document > "u") {
				if (typeof OffscreenCanvas < "u" && typeof OffscreenCanvasRenderingContext2D < "u") ST = new OffscreenCanvas(1, 1).getContext("2d");
				else throw Error("Cannot parse input in current context. Reason: OffscreenCanvas Context2D rendering is not supported.");
			} else ST = document.createElement("canvas").getContext("2d", { willReadFrequently: !0 });
		}
		ST.canvas.width = c, ST.canvas.height = l, ST.drawImage(e, 0, 0, c, l), u = ST.getImageData(0, 0, c, l).data;
	}
	let d;
	if (t === 4) d = new Int32Array(u);
	else {
		let e = c * l;
		d = new Int32Array(e * t);
		for (let n = 0; n < e; n++) for (let e = 0; e < t; ++e) d[n * t + e] = u[n * 4 + e];
	}
	return Ty(d, [
		l,
		c,
		t
	], "int32");
}
function pT(e) {
	return e != null && e.data instanceof Uint8Array;
}
function mT() {
	return typeof window < "u" && typeof ImageBitmap < "u" && window.hasOwnProperty("createImageBitmap");
}
function hT(e) {
	return e != null && e.width !== 0 && e.height !== 0;
}
function gT(e) {
	return mT() && !(e instanceof ImageBitmap) && hT(e) && !pT(e);
}
async function _T(e, t = 3) {
	let n = null;
	if (w().getBool("WRAP_TO_IMAGEBITMAP") && gT(e)) {
		let t;
		try {
			t = await createImageBitmap(e, { premultiplyAlpha: "none" });
		} catch {
			t = null;
		}
		n = t != null && t.width === e.width && t.height === e.height ? t : e;
	} else n = e;
	return fT(n, t);
}
function vT(e) {
	if (e.rank !== 2 && e.rank !== 3) throw Error(`toPixels only supports rank 2 or 3 tensors, got rank ${e.rank}.`);
	let t = e.rank === 2 ? 1 : e.shape[2];
	if (t > 4 || t === 2) throw Error(`toPixels only supports depth of size 1, 3 or 4 but got ${t}`);
	if (e.dtype !== "float32" && e.dtype !== "int32") throw Error(`Unsupported type for toPixels: ${e.dtype}. Please use float32 or int32 tensors.`);
}
function yT(e) {
	let t = e?.alpha || 1;
	if (t > 1 || t < 0) throw Error(`Alpha value ${t} is suppoed to be in range [0 - 1].`);
}
async function bT(e, t) {
	let n = N(e, "img", "toPixels");
	if (!(e instanceof O)) {
		let e = n;
		n = R(e, "int32"), e.dispose();
	}
	vT(n);
	let [r, i] = n.shape.slice(0, 2), a = n.rank === 2 ? 1 : n.shape[2], o = await n.data(), s = n.dtype === "float32" ? 255 : 1, c = new Uint8ClampedArray(i * r * 4);
	for (let e = 0; e < r * i; ++e) {
		let t = [
			0,
			0,
			0,
			255
		];
		for (let r = 0; r < a; r++) {
			let i = o[e * a + r];
			if (n.dtype === "float32") {
				if (i < 0 || i > 1) throw Error(`Tensor values for a float32 Tensor must be in the range [0 - 1] but encountered ${i}.`);
			} else if (n.dtype === "int32" && (i < 0 || i > 255)) throw Error(`Tensor values for a int32 Tensor must be in the range [0 - 255] but encountered ${i}.`);
			a === 1 ? (t[0] = i * s, t[1] = i * s, t[2] = i * s) : t[r] = i * s;
		}
		let r = e * 4;
		c[r + 0] = Math.round(t[0]), c[r + 1] = Math.round(t[1]), c[r + 2] = Math.round(t[2]), c[r + 3] = Math.round(t[3]);
	}
	if (t != null) {
		CT || gi("Draw", j.backendName) != null && (console.warn("tf.browser.toPixels is not efficient to draw tensor on canvas. Please try tf.browser.draw instead."), CT = !0), t.width = i, t.height = r;
		let e = t.getContext("2d"), n = new ImageData(c, i, r);
		e.putImageData(n, 0, 0);
	}
	return n !== e && n.dispose(), c;
}
function xT(e, t, n) {
	let r = N(e, "img", "draw");
	if (!(e instanceof O)) {
		let e = r;
		r = R(e, "int32"), e.dispose();
	}
	vT(r), yT(n?.imageOptions);
	let i = { image: r }, a = {
		canvas: t,
		options: n
	};
	j.runKernel(Wt, i, a);
}
var ST, CT, wT, TT = e((() => {
	M(), He(), T(), Di(), ka(), P(), _c(), I(), Ey(), CT = !1, wT = /* @__PURE__ */ F({ fromPixels_: fT });
})), ET = /* @__PURE__ */ n({ prepareAndValidate: () => DT });
function DT(e, t) {
	let n = e.shape.length, r = t.shape.length;
	if (n < 1) throw Error(`tf.gatherND() expects the input to be rank 1 or higher, but the rank was ${n}.`);
	if (r < 1) throw Error(`tf.gatherND() expects the indices to be rank 1 or higher, but the rank was ${r}.`);
	if (t.dtype !== "int32") throw Error(`tf.gatherND() expects the indices to be int32 type, but the dtype was ${t.dtype}.`);
	if (t.shape[r - 1] > n) throw Error(`index innermost dimension length must be <= tensor rank; saw: ${t.shape[r - 1]} vs. ${n}`);
	if (x(e.shape) === 0) throw Error(`Requested more than 0 entries, but input is empty. Input shape: ${e.shape}.`);
	let i = t.shape, a = i[i.length - 1], o = 1;
	for (let e = 0; e < i.length - 1; ++e) o *= i[e];
	let s = e.shape, c = i.slice();
	c.pop();
	let l = 1;
	for (let e = a; e < n; ++e) l *= s[e], c.push(s[e]);
	let u = [...Ce(e.shape).map((e) => e / l), 1].slice(0, a);
	return [
		c,
		o,
		l,
		u
	];
}
var OT = e((() => {
	D();
})), kT = /* @__PURE__ */ n({
	assertParamsValid: () => AT,
	computeFlatOffset: () => UT,
	computeOutShape: () => MT,
	getNormalizedAxes: () => IT,
	isSliceContinous: () => HT,
	maskToAxes: () => jT,
	parseSliceParams: () => WT,
	sliceInfo: () => GT,
	startForAxis: () => BT,
	startIndicesWithElidedDims: () => LT,
	stopForAxis: () => VT,
	stopIndicesWithElidedDims: () => RT,
	stridesForAxis: () => zT,
	stridesWithElidedDims: () => NT
});
function AT(e, t, n) {
	let r = e.shape.length;
	v(r === t.length, () => `Error in slice${r}D: Length of begin ${t} must match the rank of the array (${r}).`), v(r === n.length, () => `Error in slice${r}D: Length of size ${n} must match the rank of the array (${r}).`);
	for (let i = 0; i < r; ++i) v(t[i] + n[i] <= e.shape[i], () => `Error in slice${r}D: begin[${i}] + size[${i}] (${t[i] + n[i]}) would overflow input.shape[${i}] (${e.shape[i]})`);
}
function jT(e) {
	let t = [], n = 0;
	for (; e > 0;) e & 1 && t.push(n), e /= 2, n++;
	return t;
}
function MT(e, t, n) {
	let r = [];
	for (let i = 0; i < e.length; i++) r[i] = Math.ceil((t[i] - e[i]) / n[i]);
	return r;
}
function NT(e, t, n, r) {
	let i = [...e];
	for (let e = i.length; e < r.length; e++) i.push(1);
	for (let e = 0; e < n; e++) e === 0 ? i[t] = 1 : (i.splice(t, 0, 1), i.pop());
	return i;
}
function PT(e, t, n) {
	return n <= e ? n : n - (t - 1);
}
function FT(e, t) {
	let n = [];
	for (let r = 0; r < e; r++) n.push(t + r);
	return n;
}
function IT(e, t, n, r, i, a, o, s, c) {
	let l = e.length, u = Array(l), d = Array(l), f = Array(l);
	if (t.length && n > 0) {
		let c = t[0], l = n + 1;
		u = LT(o, c, l, r, e), d = RT(s, c, l, i, e), f = NT(a, c, l, e);
	} else for (let t = 0; t < l; t++) u[t] = BT(o, r, a, e, t, c), d[t] = VT(s, i, a, e, t, c), f[t] = zT(a, t, c);
	return {
		begin: u,
		end: d,
		strides: f
	};
}
function LT(e, t, n, r, i) {
	let a = [...i], o = FT(n, t);
	for (let i = 0; i < a.length; i++) if (o.indexOf(i) > -1) a[i] = 0;
	else {
		let o = PT(t, n, i), s = r[o];
		e & 1 << o && (s = 0), a[i] = s;
	}
	return a;
}
function RT(e, t, n, r, i) {
	let a = [...i], o = FT(n, t);
	for (let i = 0; i < a.length; i++) if (o.indexOf(i) > -1) a[i] = 2 ** 53 - 1;
	else {
		let o = PT(t, n, i), s = r[o];
		e & 1 << o && (s = 2 ** 53 - 1), a[i] = s;
	}
	for (let e = 0; e < a.length; e++) {
		let t = i[e];
		a[e] < 0 && (a[e] += t), a[e] = f(0, a[e], i[e]);
	}
	return a;
}
function zT(e, t, n) {
	let r = e[t];
	return (n & 1 << t || r == null) && (r = 1), r;
}
function BT(e, t, n, r, i, a) {
	let o = t[i], s = n[i] || 1;
	(e & 1 << i || a & 1 << i || o == null) && (o = s > 0 ? -(2 ** 53 - 1) : 2 ** 53 - 1);
	let c = r[i];
	return o < 0 && (o += c), o = f(0, o, c - 1), o;
}
function VT(e, t, n, r, i, a) {
	let o = t[i], s = n[i] || 1;
	(e & 1 << i || a & 1 << i || o == null) && (o = s > 0 ? 2 ** 53 - 1 : -(2 ** 53 - 1));
	let c = r[i];
	return o < 0 && (o += c), o = s > 0 ? f(0, o, c) : f(-1, o, c - 1), o;
}
function HT(e, t, n) {
	let r = n.length;
	for (let e = 0; e < n.length; e++) if (n[e] > 1) {
		r = e;
		break;
	}
	for (let i = r + 1; i < n.length; i++) if (t[i] > 0 || n[i] !== e[i]) return !1;
	return !0;
}
function UT(e, t) {
	let n = e.length > 0 ? e[e.length - 1] : 1;
	for (let r = 0; r < e.length - 1; r++) n += e[r] * t[r];
	return n;
}
function WT(e, t, n) {
	let r, i = e.shape.length;
	r = typeof t == "number" ? [t, ...Array(i - 1).fill(0)] : t.length < i ? t.concat(Array(i - t.length).fill(0)) : t.slice(), r.forEach((e) => {
		v(e !== -1, () => "slice() does not support negative begin indexing.");
	});
	let a;
	return a = n == null ? Array(i).fill(-1) : typeof n == "number" ? [n, ...Array(i - 1).fill(-1)] : n.length < i ? n.concat(Array(i - n.length).fill(-1)) : n, a = a.map((t, n) => t >= 0 ? t : (v(t === -1, () => `Negative size values should be exactly -1 but got ${t} for the slice() size at index ${n}.`), e.shape[n] - r[n])), [r, a];
}
function GT(e, t, n, r, i, a, o, s, c) {
	let l;
	if (r == null ? (l = Array(t.length), l.fill(1)) : l = r, o != null && o & o - 1) throw Error("Multiple ellipses in slice is not allowed.");
	let u = !1, d = {
		dims: l.length,
		numAddAxisAfterEllipsis: 0,
		begin: t.slice(),
		end: n.slice(),
		strides: l.slice(),
		beginMask: i,
		endMask: a,
		ellipsisMask: o,
		newAxisMask: s,
		shrinkAxisMask: c
	};
	for (let e = 0; e < d.dims; e++) u && 1 << e & s && d.numAddAxisAfterEllipsis++, 1 << e & o && (u = !0);
	u || (d.ellipsisMask |= 1 << d.dims, d.dims++);
	let f = {
		dims: e.length,
		beginMask: 0,
		endMask: 0,
		beginValid: !1,
		endValid: !1
	};
	KT(d, f);
	let p = !0, m = !0, h = !0, g = [], _ = [];
	for (let t = 0; t < e.length; ++t) {
		if (f.strides[t] === 0) throw Error(`strides[${t}] must be non-zero`);
		let n = !!(f.shrinkAxisMask & 1 << t), r = e[t];
		if (r === -1) {
			g.push(n ? 1 : -1);
			continue;
		}
		let i = [f.beginMask & 1 << t, f.endMask & 1 << t], a = [f.strides[t] > 0 ? 0 : -1, f.strides[t] > 0 ? r : r - 1];
		if (n && f.strides[t] <= 0) throw Error("only stride 1 allowed on non-range indexing.");
		h &&= f.strides[t] === 1;
		let o = !!(f.beginMask & 1 << t && f.endMask & 1 << t);
		if (f.beginValid && f.endValid) {
			if (n) {
				let e = f.begin[t] < 0 ? r + f.begin[t] : f.begin[t];
				if (f.begin[t] = e, f.end[t] = f.begin[t] + 1, e < 0 || e >= r) throw Error(`slice index ${f.begin[t]} of dimension ${t} out of bounds.`);
			} else f.begin[t] = qT(f.begin[t], 0, f.strides[t], r, i, a), f.end[t] = qT(f.end[t], 1, f.strides[t], r, i, a);
			let e = f.strides[t] === 1 && f.begin[t] === 0 && f.end[t] === r;
			p &&= e, m &&= t === 0 && f.strides[t] === 1 || e;
		} else p = p && f.strides[t] === 1 && o, m &&= t === 0 && f.strides[t] === 1 || o;
		let s, c = !1;
		if (f.beginValid && f.endValid ? (s = f.end[t] - f.begin[t], c = !0) : n ? (s = 1, c = !0) : o && r >= 0 && (s = f.strides[t] < 0 ? -r : r, c = !0), c) {
			let e;
			e = s === 0 || s < 0 != f.strides[t] < 0 ? 0 : Math.trunc(s / f.strides[t]) + (s % f.strides[t] === 0 ? 0 : 1), g.push(e);
		} else g.push(-1);
	}
	for (let e = 0; e < f.finalShapeGatherIndices.length; ++e) {
		let t = f.finalShapeGatherIndices[e];
		t >= 0 ? _.push(g[t]) : t === JT && _.push(1);
	}
	return {
		finalShapeSparse: _.filter((e, t) => f.finalShapeGatherIndices[t] !== JT),
		finalShape: _,
		isIdentity: p,
		sliceDim0: m,
		isSimpleSlice: h,
		begin: f.begin,
		end: f.end,
		strides: f.strides
	};
}
function KT(e, t) {
	t.beginMask = 0, t.endMask = 0, t.shrinkAxisMask = 0;
	let n = 0;
	t.beginValid = e.begin != null, t.endValid = e.end != null, t.begin = Array(t.dims), t.end = Array(t.dims), t.strides = Array(t.dims), t.finalShapeGatherIndices = [], t.finalShapeGatherIndicesSparse = [], t.inputShapeGatherIndicesSparse = Array(t.dims);
	for (let r = 0; r < e.dims; r++) if (1 << r & e.ellipsisMask) {
		let i = Math.min(t.dims - (e.dims - r) + 1 + e.numAddAxisAfterEllipsis, t.dims);
		for (; n < i; n++) t.begin[n] = 0, t.end[n] = 0, t.strides[n] = 1, t.beginMask |= 1 << n, t.endMask |= 1 << n, t.finalShapeGatherIndices.push(n), t.finalShapeGatherIndicesSparse.push(-1), t.inputShapeGatherIndicesSparse[n] = r;
	} else if (1 << r & e.newAxisMask) t.finalShapeGatherIndices.push(JT), t.finalShapeGatherIndicesSparse.push(-1);
	else {
		if (n === t.begin.length) throw Error(`Index out of range using input dim ${n}; input has only ${t.dims} dims, ${t.begin.length}.`);
		e.begin != null && (t.begin[n] = e.begin[r]), e.end != null && (t.end[n] = e.end[r]), t.strides[n] = e.strides[r], e.beginMask & 1 << r && (t.beginMask |= 1 << n), e.endMask & 1 << r && (t.endMask |= 1 << n), e.shrinkAxisMask & 1 << r ? (t.finalShapeGatherIndices.push(YT), t.finalShapeGatherIndicesSparse.push(-1), t.shrinkAxisMask |= 1 << n) : (t.finalShapeGatherIndices.push(n), t.finalShapeGatherIndicesSparse.push(r)), t.inputShapeGatherIndicesSparse[n] = r, n++;
	}
}
function qT(e, t, n, r, i, a) {
	if (i[t]) return n > 0 ? a[t] : a[t + 1 & 1];
	{
		let t = e < 0 ? r + e : e;
		return t < a[0] ? a[0] : t > a[1] ? a[1] : t;
	}
}
var JT, YT, XT = e((() => {
	D(), JT = -2, YT = -1;
})), ZT, QT = e((() => {
	ZT = "4.22.0";
})), $T, eE = e((() => {
	cw(), uw(), fw(), mw(), vw(), bw(), gw(), $T = class {
		static sgd(e) {
			return new hw(e);
		}
		static momentum(e, t, n = !1) {
			return new _w(e, t, n);
		}
		static rmsprop(e, t = .9, n = 0, r = null, i = !1) {
			return new yw(e, t, n, r, i);
		}
		static adam(e = .001, t = .9, n = .999, r = null) {
			return new dw(e, t, n, r);
		}
		static adadelta(e = .001, t = .95, n = null) {
			return new sw(e, t, n);
		}
		static adamax(e = .002, t = .9, n = .999, r = null, i = 0) {
			return new pw(e, t, n, r, i);
		}
		static adagrad(e, t = .1) {
			return new lw(e, t);
		}
	};
})), tE, nE = e((() => {
	eE(), tE = $T;
}));
// node_modules/@tensorflow/tfjs-core/dist/browser_util.js
function rE() {
	return new Promise((e) => iE(() => e()));
}
var iE, aE = e((() => {
	iE = typeof requestAnimationFrame < "u" ? requestAnimationFrame : typeof setImmediate < "u" ? setImmediate : (e) => e();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/concat_util.js
function oE(e, t) {
	let n = e[0].length;
	e.forEach((e, t) => {
		v(e.length === n, () => `Error in concat${n}D: rank of tensors[${t}] must be the same as the rank of the rest (${n})`);
	}), v(t >= 0 && t < n, () => `Error in concat${n}D: axis must be between 0 and ${n - 1}.`);
	let r = e[0];
	e.forEach((e, i) => {
		for (let a = 0; a < n; a++) v(a === t || e[a] === r[a], () => `Error in concat${n}D: Shape of tensors[${i}] (${e}) does not match the shape of the rest (${r}) along the non-concatenated axis ${i}.`);
	});
}
function sE(e, t) {
	let n = e[0].slice();
	for (let r = 1; r < e.length; r++) n[t] += e[r][t];
	return n;
}
var cE = e((() => {
	D();
})), lE = e((() => {}));
// node_modules/@tensorflow/tfjs-core/dist/ops/ragged_to_dense_util.js
function uE(e, t, n) {
	let r = [];
	if (n == null && t == null) return r;
	if (t == null) for (; r.length < e + n.length;) r.push(-1);
	else r = t.slice();
	if (n == null) return r;
	if (e + n.length !== r.length) throw Error(`rt input.shape and shape=${t} are incompatible: rt input.rank = ${e + n.length}, but shape.rank = ${r.length}`);
	for (let i = 1; i < n.length; ++i) {
		let a = n[i], o = r[r.length - n.length + i], s = r[o];
		if (a >= 0) {
			if (s >= 0) {
				if (s !== a) throw Error(`rt input.shape and shape=${t} are incompatible: rt input.shape[${i + e}] = ${a} but shape[${i + e}] = ${s}`);
			} else r[o] = a;
		}
	}
	return r;
}
function dE(e) {
	let t = {
		FIRST_DIM_SIZE: mE.FIRST_DIM_SIZE,
		VALUE_ROWIDS: mE.VALUE_ROWIDS,
		ROW_LENGTHS: mE.ROW_LENGTHS,
		ROW_SPLITS: mE.ROW_SPLITS,
		ROW_LIMITS: mE.ROW_LIMITS,
		ROW_STARTS: mE.ROW_STARTS
	}, n = [];
	for (let r of e) if (r in t) n.push(t[r]);
	else break;
	return n;
}
function fE(e) {
	return e.length === 0 ? 0 : e[0] === mE.FIRST_DIM_SIZE ? e.length - 1 : e.length;
}
function pE(e, t) {
	if (e == null || t == null) return;
	let n = e.length, r = t.length;
	if (n >= r) throw Error(`defaultValue.shape=${e} and ragged tensor flatValues.shape=${t}, are incompatible: defaultValue.rank = ${n} must be less than ragged tensor input flatValues.rank = ${r})`);
	for (let i = 0; i < Math.min(n, r - 1); ++i) {
		let n = e[i], r = t[i + 1];
		if (n >= 0 && r >= 0 && n !== 1 && n !== r) throw Error(`defaultValue.shape=${e}, and ragged tensor input flatValues.shape=${t} are incompatible: defaultValue.shape[${i - e.length}] = ${n} but ragged tensor input.flatValues.shape[${i - e.length}] = ${r}`);
	}
}
var mE, hE = e((() => {
	(function(e) {
		e[e.FIRST_DIM_SIZE = 0] = "FIRST_DIM_SIZE", e[e.VALUE_ROWIDS = 1] = "VALUE_ROWIDS", e[e.ROW_LENGTHS = 2] = "ROW_LENGTHS", e[e.ROW_SPLITS = 3] = "ROW_SPLITS", e[e.ROW_LIMITS = 4] = "ROW_LIMITS", e[e.ROW_STARTS = 5] = "ROW_STARTS";
	})(mE ||= {});
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/reduce_util.js
function gE(e) {
	return e <= 30 ? e : Se(e, Math.floor(Math.sqrt(e)));
}
var _E = e((() => {
	D();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/rotate_util.js
function vE(e, t, n) {
	return [n * (typeof e == "number" ? e : e[0]), t * (typeof e == "number" ? e : e[1])];
}
var yE = e((() => {}));
// node_modules/@tensorflow/tfjs-core/dist/ops/array_ops_util.js
function bE(e, t, n, r = !0) {
	let i = [];
	if (r) i = i.concat(t.slice(0)), i.push(e[0] / n), i = i.concat(e.slice(1));
	else {
		i = i.concat(e[0]);
		let n = t.length;
		for (let r = 0; r < n; ++r) i = i.concat([e[r + 1] / t[r], t[r]]);
		i = i.concat(e.slice(n + 1));
	}
	return i;
}
function xE(e, t, n = !0) {
	let r = [];
	if (n) {
		r.push(t);
		for (let n = t + 1; n < e; ++n) n <= 2 * t ? (r.push(n), r.push(n - (t + 1))) : r.push(n);
	} else {
		let n = [], i = [];
		for (let r = 1; r < e; ++r) r >= t * 2 + 1 || r % 2 == 1 ? i.push(r) : n.push(r);
		r.push(...n), r.push(0), r.push(...i);
	}
	return r;
}
function SE(e, t, n, r = !0) {
	let i = [];
	r ? i.push(e[0] / n) : i.push(e[0] * n);
	for (let n = 1; n < e.length; ++n) n <= t.length ? r ? i.push(t[n - 1] * e[n]) : i.push(e[n] / t[n - 1]) : i.push(e[n]);
	return i;
}
function CE(e, t) {
	let n = [0];
	for (let r = 0; r < t; ++r) n.push(e[r][0]);
	return n;
}
function wE(e, t, n) {
	let r = e.slice(0, 1);
	for (let i = 0; i < n; ++i) r.push(e[i + 1] - t[i][0] - t[i][1]);
	return r;
}
var TE = e((() => {})), EE, DE, OE = e((() => {
	EE = 1.7580993408473768, DE = 1.0507009873554805;
})), kE, AE, jE, ME, NE, PE, FE = e((() => {
	kE = .3275911, AE = .254829592, jE = -.284496736, ME = 1.421413741, NE = -1.453152027, PE = 1.061405429;
}));
// node_modules/@tensorflow/tfjs-core/dist/backends/complex_util.js
function IE(e, t) {
	if (e.length !== t.length) throw Error(`Cannot merge real and imag arrays of different lengths. real:${e.length}, imag: ${t.length}.`);
	let n = new Float32Array(e.length * 2);
	for (let r = 0; r < n.length; r += 2) n[r] = e[r / 2], n[r + 1] = t[r / 2];
	return n;
}
function LE(e) {
	let t = new Float32Array(e.length / 2), n = new Float32Array(e.length / 2);
	for (let r = 0; r < e.length; r += 2) t[r / 2] = e[r], n[r / 2] = e[r + 1];
	return {
		real: t,
		imag: n
	};
}
function RE(e) {
	let t = Math.ceil(e.length / 4), n = new Float32Array(t), r = new Float32Array(t);
	for (let t = 0; t < e.length; t += 4) n[Math.floor(t / 4)] = e[t], r[Math.floor(t / 4)] = e[t + 1];
	return {
		real: n,
		imag: r
	};
}
function zE(e) {
	let t = Math.floor(e.length / 4), n = new Float32Array(t), r = new Float32Array(t);
	for (let t = 2; t < e.length; t += 4) n[Math.floor(t / 4)] = e[t], r[Math.floor(t / 4)] = e[t + 1];
	return {
		real: n,
		imag: r
	};
}
function BE(e, t) {
	return {
		real: e[t * 2],
		imag: e[t * 2 + 1]
	};
}
function VE(e, t, n, r) {
	e[r * 2] = t, e[r * 2 + 1] = n;
}
function HE(e, t) {
	let n = new Float32Array(e / 2), r = new Float32Array(e / 2);
	for (let i = 0; i < Math.ceil(e / 2); i++) {
		let a = (t ? 2 : -2) * Math.PI * (i / e);
		n[i] = Math.cos(a), r[i] = Math.sin(a);
	}
	return {
		real: n,
		imag: r
	};
}
function UE(e, t, n) {
	let r = (n ? 2 : -2) * Math.PI * (e / t);
	return {
		real: Math.cos(r),
		imag: Math.sin(r)
	};
}
var WE = e((() => {}));
// node_modules/@tensorflow/tfjs-core/dist/backends/einsum_util.js
function GE(e, t) {
	e = e.replace(/\s/g, "");
	let n = (e.length - e.replace(QE, "").length) / 2;
	if (n < 1) throw Error("Equations without an arrow are not supported.");
	if (n > 1) throw Error(`Equation must contain exactly one arrow ("${ZE}").`);
	let [r, i] = e.split(ZE);
	v(r.indexOf(eD) === -1, () => `The ellipsis notation ("${eD}") is not supported yet.`);
	let a = r.split($E), o = a.length;
	if (t !== o) throw Error(`Expected ${o} input tensors, received ${t}`);
	if (o > 2) throw Error("Support for more than 2 input tensors is not implemented yet.");
	let s = [];
	for (let e = 0; e < i.length; ++e) {
		let t = i[e];
		if (!a.some((e) => e.indexOf(t) !== -1)) throw Error(`Output subscripts contain the label ${t} not present in the input subscripts.`);
		s.indexOf(t) === -1 && s.push(t);
	}
	for (let e = 0; e < r.length; ++e) {
		let t = r[e];
		s.indexOf(t) === -1 && t !== $E && s.push(t);
	}
	let c = Array(a.length);
	for (let e = 0; e < o; ++e) {
		if (new Set(a[e].split("")).size !== a[e].length) throw Error(`Found duplicate axes in input component ${a[e]}. Support for duplicate axes in input is not implemented yet.`);
		c[e] = [];
		for (let t = 0; t < a[e].length; ++t) c[e].push(s.indexOf(a[e][t]));
	}
	let l = s.length, u = i.length, d = [];
	for (let e = u; e < l; ++e) d.push(e);
	return {
		allDims: s,
		summedDims: d,
		idDims: c
	};
}
function KE(e, t) {
	let n = Array(e);
	n.fill(-1);
	for (let e = 0; e < t.length; ++e) n[t[e]] = e;
	let r = [];
	for (let t = 0; t < e; ++t) n[t] === -1 && r.push(t);
	return n = n.filter((e) => e !== -1), {
		permutationIndices: n,
		expandDims: r
	};
}
function qE(e, t, n) {
	let r = Array(e);
	for (let e = 0; e < n.length; ++e) {
		let i = n[e].shape;
		for (let n = 0; n < t[e].length; ++n) r[t[e][n]] === void 0 ? r[t[e][n]] = i[n] : v(r[t[e][n]] === i[n], () => `Expected dimension ${r[t[e][n]]} at axis ${n} of input shaped ${JSON.stringify(i)}, but got dimension ${i[n]}`);
	}
}
function JE(e, t) {
	let n = e, r = [], i = 0;
	e.length === 0 && n.push(-1), i = e.length + 1;
	for (let e = 0; e < i; ++e) r.push([]);
	let a = [];
	for (let e = 0; e < n.length; ++e) {
		let i = n[e], o = XE(t, i);
		for (let t of o) a.indexOf(t) === -1 && (r[e].push(t), a.push(t));
	}
	return {
		path: n,
		steps: r
	};
}
function YE(e) {
	return e.every((e, t) => e === t);
}
function XE(e, t) {
	let n = [];
	for (let r = 0; r < e.length; ++r) (e[r].length === 0 || e[r].indexOf(t) !== -1 || t === -1) && n.push(r);
	return n;
}
var ZE, QE, $E, eD, tD = e((() => {
	Pe(), ZE = "->", QE = /->/g, $E = ",", eD = "...";
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/split_util.js
function nD(e, t, n = 0) {
	let r = [];
	if (typeof t == "number") v(e.shape[n] % t === 0, () => "Number of splits must evenly divide the axis."), r = Array(t).fill(e.shape[n] / t);
	else {
		v(t.reduce((e, t) => (t === -1 && (e += 1), e), 0) <= 1, () => "There should be only one negative value in split array.");
		let i = t.indexOf(-1);
		if (i !== -1) {
			let r = t.reduce((e, t) => t > 0 ? e + t : e);
			t[i] = e.shape[n] - r;
		}
		v(e.shape[n] === t.reduce((e, t) => e + t), () => "The sum of sizes must match the size of the axis dimension."), r = t;
	}
	return r;
}
var rD = e((() => {
	D();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/sparse/sparse_fill_empty_rows_util.js
function iD(e) {
	return `Received SparseTensor with denseShape[0] = 0 but
  indices.shape[0] = ${e}`;
}
function aD(e, t) {
	return `indices(${e}, 0) is invalid: ${t} < 0`;
}
function oD(e, t, n) {
	return `indices(${e}, 0) is invalid: ${t} >= ${n}`;
}
var sD = e((() => {}));
// node_modules/@tensorflow/tfjs-core/dist/ops/sparse/sparse_reshape_util.js
function cD(e, t) {
	return `only one output dimension may be -1, not both ${e} and ${t}`;
}
function lD(e, t) {
	return `size ${e} must be non-negative, not ${t}`;
}
function uD() {
	return "reshape cannot infer the missing input size for an empty tensor unless all specified input sizes are non-zero";
}
function dD(e, t) {
	return `Input to reshape is a SparseTensor with ${x(e)}
  dense values, but the requested shape requires a multiple of ${x(t)}. inputShape=${e} outputShape= ${t}`;
}
function fD(e, t) {
	return `Input to reshape is a tensor with ${x(e)} dense values, but the requested shape has ${x(t)}. inputShape=${e} outputShape=${t}`;
}
var pD = e((() => {
	D();
}));
// node_modules/@tensorflow/tfjs-core/dist/ops/sparse/sparse_segment_reduction_util.js
function mD() {
	return "segment ids must be >= 0";
}
function hD() {
	return "segment ids are not increasing";
}
function gD(e, t) {
	return `Segment id ${e} out of range [0, ${t}), possibly because segmentIds input is not sorted.`;
}
function _D(e, t, n) {
	return `Bad: indices[${e}] == ${t} out of range [0, ${n})`;
}
var vD = e((() => {})), yD = /* @__PURE__ */ n({
	collectGatherOpShapeInfo: () => SD,
	computeOutShape: () => xD,
	segOpComputeOptimalWindowSize: () => bD
});
function bD(e, t) {
	let n = !1, r;
	for (e <= 30 ? (r = e, n = !0) : r = Se(e, Math.floor(Math.sqrt(e))); !n;) r > t || r === e ? n = !0 : r = Se(e, r + 1);
	return r;
}
function xD(e, t, n) {
	let r = [], i = e.length;
	for (let a = 0; a < i; a++) a === t ? r.push(n) : r.push(e[a]);
	return r;
}
function SD(e, t, n, r) {
	let i = t.shape.length, a = e.shape.length;
	if (r !== 0 && (r < -i || r > i)) throw Error(`Expect batchDims in the range of [-${i}, ${i}], but got ${r}`);
	if (r < 0 && (r += i), r > a) throw Error(`batchDims (${r}) must be less than rank(x) (
    ${a}).`);
	if (n < r) throw Error(`batchDims (${r}) must be less than or equal to axis (${n}).`);
	for (let n = 0; n < r; ++n) if (e.shape[n] !== t.shape[n]) throw Error(`x.shape[${n}]: ${e.shape[n]} should be equal to indices.shape[${n}]: ${t.shape[n]}.`);
	let o = e.shape[n], s = [], c = 1, l = 1, u = 1;
	for (let t = 0; t < r; ++t) s.push(e.shape[t]), c *= e.shape[t];
	for (let t = r; t < n; t++) s.push(e.shape[t]), l *= e.shape[t];
	for (let e = r; e < i; e++) s.push(t.shape[e]);
	for (let t = n + 1; t < a; t++) s.push(e.shape[t]), u *= e.shape[t];
	return {
		batchSize: c,
		sliceSize: u,
		outerSize: l,
		dimSize: o,
		outputShape: s
	};
}
var CD = e((() => {
	D(), _E();
})), wD = /* @__PURE__ */ n({
	ERF_A1: () => AE,
	ERF_A2: () => jE,
	ERF_A3: () => ME,
	ERF_A4: () => NE,
	ERF_A5: () => PE,
	ERF_P: () => kE,
	PARALLELIZE_THRESHOLD: () => 30,
	RowPartitionType: () => mE,
	SELU_SCALE: () => DE,
	SELU_SCALEALPHA: () => EE,
	applyActivation: () => qb,
	assertAndGetBroadcastShape: () => J,
	assertAxesAreInnerMostDims: () => Af,
	assertParamsConsistent: () => oE,
	assignToTypedArray: () => VE,
	axesAreInnerMostDims: () => Ef,
	calculateShapes: () => Iy,
	checkEinsumDimSizes: () => qE,
	checkPadOnDimRoundingMode: () => Pl,
	combineLocations: () => Df,
	combineRaggedTensorToTensorShapes: () => uE,
	complexWithEvenIndex: () => RE,
	complexWithOddIndex: () => zE,
	computeConv2DInfo: () => yl,
	computeConv3DInfo: () => bl,
	computeDefaultPad: () => Cl,
	computeDilation2DInfo: () => gl,
	computeOptimalWindowSize: () => gE,
	computeOutAndReduceShapes: () => Of,
	computeOutShape: () => sE,
	computePool2DInfo: () => _l,
	computePool3DInfo: () => vl,
	convertConv2DDataFormat: () => Nl,
	decodeEinsumEquation: () => GE,
	eitherStridesOrDilationsAreOne: () => jl,
	expandShapeToKeepDim: () => kf,
	exponent: () => UE,
	exponents: () => HE,
	fromStringArrayToUint8: () => ED,
	fromUint8ToStringArray: () => TD,
	getAxesPermutation: () => jf,
	getBroadcastDims: () => Yd,
	getComplexWithIndex: () => BE,
	getEinsumComputePath: () => JE,
	getEinsumPermutation: () => KE,
	getFusedBiasGradient: () => Kb,
	getFusedDyActivation: () => Gb,
	getImageCenter: () => vE,
	getInnerMostAxes: () => Nf,
	getPermuted: () => xE,
	getRaggedRank: () => fE,
	getReductionAxes: () => Xd,
	getReshaped: () => bE,
	getReshapedPermuted: () => SE,
	getRowPartitionTypesHelper: () => dE,
	getSliceBeginCoords: () => CE,
	getSliceSize: () => wE,
	getSparseFillEmptyRowsIndicesDenseShapeMismatch: () => iD,
	getSparseFillEmptyRowsNegativeIndexErrorMessage: () => aD,
	getSparseFillEmptyRowsOutOfRangeIndexErrorMessage: () => oD,
	getSparseReshapeEmptyTensorZeroOutputDimErrorMessage: () => uD,
	getSparseReshapeInputOutputMismatchErrorMessage: () => fD,
	getSparseReshapeInputOutputMultipleErrorMessage: () => dD,
	getSparseReshapeMultipleNegativeOneOutputDimErrorMessage: () => cD,
	getSparseReshapeNegativeOutputDimErrorMessage: () => lD,
	getSparseSegmentReductionIndicesOutOfRangeErrorMessage: () => _D,
	getSparseSegmentReductionNegativeSegmentIdsErrorMessage: () => mD,
	getSparseSegmentReductionNonIncreasingSegmentIdsErrorMessage: () => hD,
	getSparseSegmentReductionSegmentIdOutOfRangeErrorMessage: () => gD,
	getUndoAxesPermutation: () => Mf,
	isIdentityPermutation: () => YE,
	log: () => mi,
	mergeRealAndImagArrays: () => IE,
	prepareAndValidate: () => DT,
	prepareSplitSize: () => nD,
	segment_util: () => yD,
	shouldFuse: () => Jb,
	slice_util: () => kT,
	splitRealAndImagArrays: () => LE,
	stridesOrDilationsArePositive: () => Ml,
	tupleValuesAreOne: () => Al,
	upcastType: () => Aa,
	validateDefaultValueShape: () => pE,
	validateInput: () => Fy,
	validateUpdateShape: () => Py,
	warn: () => pi
});
function TD(e) {
	try {
		return e.map((e) => na(e));
	} catch (e) {
		throw Error(`Failed to decode encoded string bytes into utf-8, error: ${e}`);
	}
}
function ED(e) {
	return e.map((e) => ta(e));
}
var DD = e((() => {
	D(), Pf(), Zd(), cE(), Fl(), Yb(), lE(), hE(), _E(), XT(), Ba(), yE(), TE(), OT(), Ly(), OE(), Yb(), FE(), hi(), WE(), tD(), rD(), sD(), pD(), vD(), CD();
})), OD = /* @__PURE__ */ n({
	nonMaxSuppressionV3Impl: () => Xx,
	nonMaxSuppressionV4Impl: () => Zx,
	nonMaxSuppressionV5Impl: () => Qx,
	whereImpl: () => ob
}), kD = e((() => {
	rS(), sb();
})), AD = e((() => {
	aT(), uT(), Zd(), TT(), OT(), Ly(), XT(), iw(), A(), s_(), D(), QT(), cw(), uw(), fw(), mw(), vw(), ow(), eE(), bw(), gw(), ka(), Ba(), XC(), US(), nE(), Ko(), Di(), vm(), He(), aE(), DD(), ao(), kD(), l(), T();
})), jD = /* @__PURE__ */ n({
	Abs: () => "Abs",
	Acos: () => Ye,
	Acosh: () => Xe,
	AdadeltaOptimizer: () => sw,
	AdagradOptimizer: () => lw,
	AdamOptimizer: () => dw,
	AdamaxOptimizer: () => pw,
	Add: () => "Add",
	AddN: () => Qe,
	All: () => "All",
	Any: () => "Any",
	ArgMax: () => tt,
	ArgMin: () => nt,
	Asin: () => rt,
	Asinh: () => it,
	Atan: () => at,
	Atan2: () => st,
	Atanh: () => ot,
	AvgPool: () => ct,
	AvgPool3D: () => ut,
	AvgPool3DGrad: () => dt,
	AvgPoolGrad: () => lt,
	BatchMatMul: () => ft,
	BatchToSpaceND: () => pt,
	Bincount: () => mt,
	BitwiseAnd: () => ht,
	BroadcastArgs: () => _t,
	BroadcastTo: () => gt,
	Cast: () => vt,
	Ceil: () => yt,
	ClipByValue: () => bt,
	Complex: () => xt,
	ComplexAbs: () => St,
	Concat: () => Ct,
	Conv2D: () => wt,
	Conv2DBackpropFilter: () => Tt,
	Conv2DBackpropInput: () => Et,
	Conv3D: () => Dt,
	Conv3DBackpropFilterV2: () => Ot,
	Conv3DBackpropInputV2: () => kt,
	Cos: () => "Cos",
	Cosh: () => jt,
	CropAndResize: () => Pt,
	Cumprod: () => Mt,
	Cumsum: () => Nt,
	DataStorage: () => s,
	DenseBincount: () => Ft,
	DepthToSpace: () => It,
	DepthwiseConv2dNative: () => Lt,
	DepthwiseConv2dNativeBackpropFilter: () => Rt,
	DepthwiseConv2dNativeBackpropInput: () => zt,
	Diag: () => Bt,
	Dilation2D: () => Vt,
	Dilation2DBackpropFilter: () => Ut,
	Dilation2DBackpropInput: () => Ht,
	Draw: () => Wt,
	ENV: () => Ve,
	Einsum: () => Kt,
	Elu: () => "Elu",
	EluGrad: () => Jt,
	Environment: () => Be,
	Equal: () => Xt,
	Erf: () => "Erf",
	Exp: () => "Exp",
	ExpandDims: () => Qt,
	Expm1: () => $t,
	FFT: () => "FFT",
	Fill: () => tn,
	FlipLeftRight: () => nn,
	Floor: () => rn,
	FloorDiv: () => an,
	FromPixels: () => ci,
	FusedBatchNorm: () => on,
	FusedConv2D: () => di,
	FusedDepthwiseConv2D: () => fi,
	GatherNd: () => cn,
	GatherV2: () => sn,
	Greater: () => ln,
	GreaterEqual: () => un,
	IFFT: () => fn,
	Identity: () => dn,
	Imag: () => pn,
	IsFinite: () => mn,
	IsInf: () => hn,
	IsNan: () => gn,
	KernelBackend: () => c,
	LRN: () => "LRN",
	LRNGrad: () => An,
	LeakyRelu: () => _n,
	Less: () => vn,
	LessEqual: () => yn,
	LinSpace: () => bn,
	Log: () => "Log",
	Log1p: () => Sn,
	LogSoftmax: () => Dn,
	LogicalAnd: () => Cn,
	LogicalNot: () => wn,
	LogicalOr: () => Tn,
	LogicalXor: () => En,
	LowerBound: () => On,
	MatrixBandPart: () => jn,
	Max: () => "Max",
	MaxPool: () => Pn,
	MaxPool3D: () => In,
	MaxPool3DGrad: () => Ln,
	MaxPoolGrad: () => Fn,
	MaxPoolWithArgmax: () => Rn,
	Maximum: () => Nn,
	Mean: () => zn,
	Min: () => "Min",
	Minimum: () => Vn,
	MirrorPad: () => Hn,
	Mod: () => "Mod",
	MomentumOptimizer: () => _w,
	Multinomial: () => Wn,
	Multiply: () => Gn,
	Neg: () => "Neg",
	NonMaxSuppressionV3: () => Jn,
	NonMaxSuppressionV4: () => Yn,
	NonMaxSuppressionV5: () => Xn,
	NotEqual: () => qn,
	OP_SCOPE_SUFFIX: () => po,
	OneHot: () => Qn,
	OnesLike: () => Zn,
	Optimizer: () => aw,
	OptimizerConstructors: () => $T,
	Pack: () => $n,
	PadV2: () => er,
	Pool: () => tr,
	Pow: () => "Pow",
	Prelu: () => rr,
	Prod: () => ir,
	RMSPropOptimizer: () => yw,
	RaggedGather: () => ar,
	RaggedRange: () => or,
	RaggedTensorToTensor: () => sr,
	Range: () => cr,
	Rank: () => Pa,
	Real: () => lr,
	RealDiv: () => Gt,
	Reciprocal: () => ur,
	Reduction: () => HS,
	Relu: () => dr,
	Relu6: () => _r,
	Reshape: () => fr,
	ResizeBilinear: () => hr,
	ResizeBilinearGrad: () => gr,
	ResizeNearestNeighbor: () => pr,
	ResizeNearestNeighborGrad: () => mr,
	Reverse: () => vr,
	RotateWithOffset: () => li,
	Round: () => yr,
	Rsqrt: () => br,
	SGDOptimizer: () => hw,
	ScatterNd: () => xr,
	SearchSorted: () => Cr,
	Select: () => wr,
	Selu: () => Tr,
	Sigmoid: () => Ar,
	Sign: () => kr,
	Sin: () => "Sin",
	Sinh: () => Or,
	Slice: () => Er,
	Softmax: () => Ir,
	Softplus: () => jr,
	SpaceToBatchND: () => Pr,
	SparseFillEmptyRows: () => Lr,
	SparseReshape: () => Rr,
	SparseSegmentMean: () => zr,
	SparseSegmentSum: () => Br,
	SparseToDense: () => Vr,
	SplitV: () => Fr,
	Sqrt: () => Mr,
	Square: () => Ur,
	SquaredDifference: () => Hr,
	StaticRegexReplace: () => Wr,
	Step: () => si,
	StridedSlice: () => Gr,
	StringNGrams: () => Kr,
	StringSplit: () => qr,
	StringToHashBucketFast: () => Jr,
	Sub: () => "Sub",
	Sum: () => "Sum",
	Tan: () => "Tan",
	Tanh: () => Zr,
	Tensor: () => O,
	TensorBuffer: () => Ta,
	TensorScatterUpdate: () => Sr,
	Tile: () => Qr,
	TopK: () => $r,
	Transform: () => ei,
	Transpose: () => ti,
	Unique: () => ni,
	Unpack: () => ri,
	UnsortedSegmentSum: () => ii,
	UpperBound: () => ai,
	Variable: () => Oa,
	ZerosLike: () => oi,
	_FusedMatMul: () => ui,
	abs: () => Mc,
	acos: () => Fc,
	acosh: () => Rc,
	add: () => z,
	addN: () => Vc,
	all: () => Wc,
	any: () => qc,
	argMax: () => Xc,
	argMin: () => $c,
	asin: () => nl,
	asinh: () => al,
	atan: () => cl,
	atan2: () => dl,
	atanh: () => ml,
	avgPool: () => Rl,
	avgPool3d: () => Vl,
	backend: () => Wo,
	backend_util: () => wD,
	basicLSTMCell: () => ru,
	batchNorm: () => du,
	batchNorm2d: () => mu,
	batchNorm3d: () => _u,
	batchNorm4d: () => bu,
	batchToSpaceND: () => ou,
	bincount: () => Cu,
	bitwiseAnd: () => Eu,
	booleanMaskAsync: () => fb,
	broadcastArgs: () => ku,
	broadcastTo: () => Mu,
	broadcast_util: () => Jd,
	browser: () => dT,
	buffer: () => mc,
	cast: () => R,
	ceil: () => Fu,
	clipByValue: () => Bu,
	clone: () => yc,
	complex: () => ho,
	concat: () => Wl,
	concat1d: () => Uu,
	concat2d: () => Ku,
	concat3d: () => Yu,
	concat4d: () => Qu,
	conv1d: () => id,
	conv2d: () => td,
	conv2dTranspose: () => ud,
	conv3d: () => pd,
	conv3dTranspose: () => yd,
	copyRegisteredKernels: () => Ci,
	cos: () => Sd,
	cosh: () => Td,
	cosineWindow: () => Lb,
	cumprod: () => Od,
	cumsum: () => jd,
	customGrad: () => gm,
	denseBincount: () => Pd,
	deprecationWarn: () => ko,
	depthToSpace: () => Ld,
	depthwiseConv2d: () => Bd,
	device_util: () => $a,
	diag: () => Ud,
	dilation2d: () => Kd,
	disableDeprecationWarnings: () => Oo,
	dispose: () => Po,
	disposeVariables: () => Ao,
	div: () => V,
	divNoNan: () => lf,
	dot: () => ff,
	dropout: () => Pb,
	einsum: () => hf,
	elu: () => vf,
	enableDebugMode: () => Do,
	enableProdMode: () => Eo,
	enclosingPowerOfTwo: () => Ib,
	engine: () => jo,
	ensureShape: () => xf,
	env: () => w,
	equal: () => $d,
	erf: () => wf,
	euclideanNorm: () => ip,
	exp: () => sp,
	expandDims: () => up,
	expm1: () => pp,
	eye: () => yp,
	fft: () => Uv,
	fill: () => Lu,
	findBackend: () => Vo,
	findBackendFactory: () => Ho,
	floor: () => Sp,
	floorDiv: () => Ec,
	fused: () => dx,
	gather: () => Tp,
	gatherND: () => kb,
	gather_util: () => ET,
	getBackend: () => zo,
	getGradient: () => _i,
	getKernel: () => gi,
	getKernelsForBackend: () => vi,
	grad: () => dm,
	grads: () => fm,
	greater: () => Op,
	greaterEqual: () => jp,
	ifft: () => Kv,
	imag: () => Pp,
	image: () => GC,
	inTopKAsync: () => Bb,
	io: () => iT,
	irfft: () => Yv,
	isFinite: () => Lp,
	isInf: () => Bp,
	isNaN: () => Up,
	keep: () => Fo,
	kernel_impls: () => OD,
	leakyRelu: () => Kp,
	less: () => Yp,
	lessEqual: () => Qp,
	linalg: () => KC,
	linspace: () => em,
	localResponseNormalization: () => rm,
	log: () => om,
	log1p: () => lm,
	logSigmoid: () => Em,
	logSoftmax: () => jm,
	logSumExp: () => Pm,
	logicalAnd: () => Lm,
	logicalNot: () => Bm,
	logicalOr: () => Um,
	logicalXor: () => Km,
	losses: () => qC,
	lowerBound: () => Qm,
	matMul: () => K,
	math: () => lT,
	max: () => If,
	maxPool: () => th,
	maxPool3d: () => ih,
	maxPoolWithArgmax: () => sh,
	maximum: () => uh,
	mean: () => ph,
	memory: () => Mo,
	meshgrid: () => yh,
	min: () => zf,
	minimum: () => Sh,
	mirrorPad: () => Th,
	mod: () => Oh,
	moments: () => jh,
	movingAverage: () => vb,
	mul: () => H,
	multiRNNCell: () => Ph,
	multinomial: () => Lh,
	neg: () => bm,
	nextFrame: () => rE,
	norm: () => tp,
	notEqual: () => Bh,
	oneHot: () => Uh,
	ones: () => _h,
	onesLike: () => Kh,
	op: () => F,
	outerProduct: () => Yh,
	pad: () => Qh,
	pad1d: () => tg,
	pad2d: () => ig,
	pad3d: () => sg,
	pad4d: () => ug,
	pool: () => vg,
	pow: () => Hf,
	prelu: () => xg,
	print: () => xc,
	prod: () => wg,
	profile: () => No,
	raggedGather: () => Dg,
	raggedRange: () => Ag,
	raggedTensorToTensor: () => Ng,
	rand: () => Ig,
	randomGamma: () => m_,
	randomNormal: () => __,
	randomStandardNormal: () => b_,
	randomUniform: () => C_,
	randomUniformInt: () => E_,
	range: () => O_,
	ready: () => Ro,
	real: () => j_,
	reciprocal: () => P_,
	registerBackend: () => Uo,
	registerGradient: () => bi,
	registerKernel: () => yi,
	relu: () => L_,
	relu6: () => B_,
	removeBackend: () => Bo,
	reshape: () => W,
	reverse: () => U_,
	reverse1d: () => K_,
	reverse2d: () => Y_,
	reverse3d: () => Q_,
	reverse4d: () => tv,
	rfft: () => ty,
	round: () => iv,
	rsqrt: () => sv,
	scalar: () => Y,
	scatterND: () => xb,
	scatter_util: () => Ny,
	searchSorted: () => Xm,
	selu: () => uv,
	separableConv2d: () => pv,
	serialization: () => ZC,
	setBackend: () => Lo,
	setPlatform: () => Go,
	setdiff1dAsync: () => gv,
	sigmoid: () => Yl,
	sign: () => yv,
	signal: () => WC,
	sin: () => Sv,
	sinh: () => Tv,
	slice: () => q,
	slice1d: () => Ov,
	slice2d: () => jv,
	slice3d: () => Pv,
	slice4d: () => Lv,
	slice_util: () => kT,
	softmax: () => Bv,
	softplus: () => Cm,
	spaceToBatchND: () => pg,
	sparse: () => JC,
	sparseToDense: () => Eb,
	spectral: () => UC,
	split: () => Qv,
	sqrt: () => Kf,
	square: () => Yf,
	squaredDifference: () => iy,
	squeeze: () => sy,
	stack: () => uy,
	step: () => py,
	stridedSlice: () => gy,
	string: () => YC,
	sub: () => Z,
	sum: () => X,
	sumOutType: () => ja,
	tan: () => yy,
	tanh: () => eu,
	tensor: () => yo,
	tensor1d: () => xy,
	tensor2d: () => Cy,
	tensor3d: () => Ty,
	tensor4d: () => Dy,
	tensor5d: () => ky,
	tensor6d: () => jy,
	tensorScatterUpdate: () => zy,
	tensor_util: () => Va,
	test_util: () => Kg,
	tidy: () => L,
	tile: () => gp,
	time: () => Io,
	topk: () => Hy,
	train: () => tE,
	transpose: () => hb,
	truncatedNormal: () => Gy,
	unique: () => Jy,
	unregisterGradient: () => Si,
	unregisterKernel: () => xi,
	unsortedSegmentSum: () => Zy,
	unstack: () => eb,
	upcastType: () => Aa,
	upperBound: () => nb,
	util: () => Yi,
	valueAndGrad: () => pm,
	valueAndGrads: () => mm,
	variable: () => ib,
	variableGrads: () => hm,
	version_core: () => ZT,
	where: () => nf,
	whereAsync: () => lb,
	zeros: () => hh,
	zerosLike: () => of
}), MD = e((() => {
	Cc(), Cw(), AD(), xw();
})), ND = e((() => {
	MD(), w().registerFlag("KEEP_INTERMEDIATE_TENSORS", () => !1, (e) => {
		e && console.warn("Keep intermediate tensors is ON. This will print the values of all intermediate tensors during model inference. Not all models support this mode. For details, check e2e/benchmarks/ model_config.js. This significantly impacts performance.");
	});
})), PD, FD, ID = e((() => {
	(function(e) {
		e[e.DT_INVALID = 0] = "DT_INVALID", e[e.DT_FLOAT = 1] = "DT_FLOAT", e[e.DT_DOUBLE = 2] = "DT_DOUBLE", e[e.DT_INT32 = 3] = "DT_INT32", e[e.DT_UINT8 = 4] = "DT_UINT8", e[e.DT_INT16 = 5] = "DT_INT16", e[e.DT_INT8 = 6] = "DT_INT8", e[e.DT_STRING = 7] = "DT_STRING", e[e.DT_COMPLEX64 = 8] = "DT_COMPLEX64", e[e.DT_INT64 = 9] = "DT_INT64", e[e.DT_BOOL = 10] = "DT_BOOL", e[e.DT_QINT8 = 11] = "DT_QINT8", e[e.DT_QUINT8 = 12] = "DT_QUINT8", e[e.DT_QINT32 = 13] = "DT_QINT32", e[e.DT_BFLOAT16 = 14] = "DT_BFLOAT16", e[e.DT_QINT16 = 15] = "DT_QINT16", e[e.DT_QUINT16 = 16] = "DT_QUINT16", e[e.DT_UINT16 = 17] = "DT_UINT16", e[e.DT_COMPLEX128 = 18] = "DT_COMPLEX128", e[e.DT_HALF = 19] = "DT_HALF", e[e.DT_RESOURCE = 20] = "DT_RESOURCE", e[e.DT_VARIANT = 21] = "DT_VARIANT", e[e.DT_UINT32 = 22] = "DT_UINT32", e[e.DT_UINT64 = 23] = "DT_UINT64", e[e.DT_FLOAT_REF = 101] = "DT_FLOAT_REF", e[e.DT_DOUBLE_REF = 102] = "DT_DOUBLE_REF", e[e.DT_INT32_REF = 103] = "DT_INT32_REF", e[e.DT_UINT8_REF = 104] = "DT_UINT8_REF", e[e.DT_INT16_REF = 105] = "DT_INT16_REF", e[e.DT_INT8_REF = 106] = "DT_INT8_REF", e[e.DT_STRING_REF = 107] = "DT_STRING_REF", e[e.DT_COMPLEX64_REF = 108] = "DT_COMPLEX64_REF", e[e.DT_INT64_REF = 109] = "DT_INT64_REF", e[e.DT_BOOL_REF = 110] = "DT_BOOL_REF", e[e.DT_QINT8_REF = 111] = "DT_QINT8_REF", e[e.DT_QUINT8_REF = 112] = "DT_QUINT8_REF", e[e.DT_QINT32_REF = 113] = "DT_QINT32_REF", e[e.DT_BFLOAT16_REF = 114] = "DT_BFLOAT16_REF", e[e.DT_QINT16_REF = 115] = "DT_QINT16_REF", e[e.DT_QUINT16_REF = 116] = "DT_QUINT16_REF", e[e.DT_UINT16_REF = 117] = "DT_UINT16_REF", e[e.DT_COMPLEX128_REF = 118] = "DT_COMPLEX128_REF", e[e.DT_HALF_REF = 119] = "DT_HALF_REF", e[e.DT_RESOURCE_REF = 120] = "DT_RESOURCE_REF", e[e.DT_VARIANT_REF = 121] = "DT_VARIANT_REF", e[e.DT_UINT32_REF = 122] = "DT_UINT32_REF", e[e.DT_UINT64_REF = 123] = "DT_UINT64_REF";
	})(PD ||= {}), (function(e) {
		(function(e) {
			e[e.LEGACY = 0] = "LEGACY", e[e.V1 = 1] = "V1", e[e.V2 = 2] = "V2";
		})(e.CheckpointFormatVersion ||= {});
	})(FD ||= {});
}));
// node_modules/@tensorflow/tfjs-converter/dist/operations/custom_op/register.js
function LD(e, t) {
	BD[e] = {
		tfOpName: e,
		category: "custom",
		inputs: [],
		attrs: [],
		customExecutor: t
	};
}
function RD(e) {
	return BD[e];
}
function zD(e) {
	delete BD[e];
}
var BD, VD = e((() => {
	BD = {};
}));
// node_modules/@tensorflow/tfjs-converter/dist/operations/executors/utils.js
function Q(e, t, n, r, i) {
	let a = t.inputParams[e];
	if (a && a.inputIndexStart !== void 0) {
		let e = a.inputIndexStart, o = a.inputIndexEnd === 0 ? void 0 : a.inputIndexEnd === void 0 ? e + 1 : a.inputIndexEnd, s = e < 0 ? t.inputNames.length + e : e;
		if (a.type === "tensor") return HD(t.inputNames[s], n, r, i);
		if (a.type === "tensors") {
			let a = t.inputs.slice(e, o);
			return t.inputNames.slice(e, o).filter((e, t) => a[t]?.op !== "NoOp").map((e) => HD(e, n, r, i));
		}
		let c = HD(t.inputNames[s], n, r, i), l = c.dataSync();
		return a.type === "number" ? l[0] : Te(c.shape, l);
	}
	let o = t.attrParams[e];
	return o && o.value;
}
function HD(e, t, n, r) {
	let [i, a] = KD(e, n);
	if (r != null) {
		let e = r.getHashTableHandleByName(i);
		if (e != null) return e;
	}
	let o = n.currentContextIds.find((e) => !!t[GD(i, e)]);
	return o === void 0 ? void 0 : t[GD(i, o)][a];
}
function UD(e, t, n) {
	return t[GD(e, n.currentContextId)];
}
function WD(e, t) {
	let [n, r, i] = KD(e, t);
	return [
		GD(n, t && t.currentContextId),
		r,
		i
	];
}
function GD(e, t) {
	return t ? `${e}-${t}` : e;
}
function KD(e, t) {
	if (e === "") return [
		"",
		0,
		void 0
	];
	let n = t != null && t.parseNodeNameCache != null;
	if (n) {
		let n = t.parseNodeNameCache.get(e);
		if (n != null) return n;
	}
	let r = e.split(":"), i;
	if (r.length === 1) i = [
		e,
		0,
		void 0
	];
	else {
		let e = r[0], t = r.length === 3 ? r[1] : void 0;
		i = [
			e,
			Number(r[r.length - 1]),
			t
		];
	}
	return n && t.parseNodeNameCache.set(e, i), i;
}
function qD(e, t, n) {
	let r = Q("pad", e, t, n);
	if (r === "explicit") {
		r = Q("explicitPaddings", e, t, n);
		let i = [
			[0, 0],
			[0, 0],
			[0, 0],
			[0, 0]
		];
		for (let e = 0; e < 4; e++) i[e][0] = r[e * 2], i[e][1] = r[e * 2 + 1];
		return i;
	}
	return r;
}
function JD(e) {
	return e.kept ? e : yc(e);
}
var $ = e((() => {
	MD();
})), YD = /* @__PURE__ */ n({ json: () => XD }), XD, ZD = e((() => {
	XD = [
		{
			tfOpName: "Add",
			category: "arithmetic",
			inputs: [{
				start: 0,
				name: "a",
				type: "tensor"
			}, {
				start: 1,
				name: "b",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "AddV2",
			category: "arithmetic",
			inputs: [{
				start: 0,
				name: "a",
				type: "tensor"
			}, {
				start: 1,
				name: "b",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "AddN",
			category: "arithmetic",
			inputs: [{
				start: 0,
				end: 0,
				name: "tensors",
				type: "tensors"
			}]
		},
		{
			tfOpName: "BiasAdd",
			category: "arithmetic",
			inputs: [{
				start: 0,
				name: "a",
				type: "tensor"
			}, {
				start: 1,
				name: "b",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}, {
				tfName: "data_format",
				name: "dataFormat",
				type: "string",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Sub",
			category: "arithmetic",
			inputs: [{
				start: 0,
				name: "a",
				type: "tensor"
			}, {
				start: 1,
				name: "b",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "RealDiv",
			category: "arithmetic",
			inputs: [{
				start: 0,
				name: "a",
				type: "tensor"
			}, {
				start: 1,
				name: "b",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Div",
			category: "arithmetic",
			inputs: [{
				start: 0,
				name: "a",
				type: "tensor"
			}, {
				start: 1,
				name: "b",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "DivNoNan",
			category: "arithmetic",
			inputs: [{
				start: 0,
				name: "a",
				type: "tensor"
			}, {
				start: 1,
				name: "b",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "FloorDiv",
			category: "arithmetic",
			inputs: [{
				start: 0,
				name: "a",
				type: "tensor"
			}, {
				start: 1,
				name: "b",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Mul",
			category: "arithmetic",
			inputs: [{
				start: 0,
				name: "a",
				type: "tensor"
			}, {
				start: 1,
				name: "b",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Maximum",
			category: "arithmetic",
			inputs: [{
				start: 0,
				name: "a",
				type: "tensor"
			}, {
				start: 1,
				name: "b",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Minimum",
			category: "arithmetic",
			inputs: [{
				start: 0,
				name: "a",
				type: "tensor"
			}, {
				start: 1,
				name: "b",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Pow",
			category: "arithmetic",
			inputs: [{
				start: 0,
				name: "a",
				type: "tensor"
			}, {
				start: 1,
				name: "b",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "SquaredDifference",
			category: "arithmetic",
			inputs: [{
				start: 0,
				name: "a",
				type: "tensor"
			}, {
				start: 1,
				name: "b",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Mod",
			category: "arithmetic",
			inputs: [{
				start: 0,
				name: "a",
				type: "tensor"
			}, {
				start: 1,
				name: "b",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "FloorMod",
			category: "arithmetic",
			inputs: [{
				start: 0,
				name: "a",
				type: "tensor"
			}, {
				start: 1,
				name: "b",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		}
	];
})), QD = /* @__PURE__ */ n({ json: () => $D }), $D, eO = e((() => {
	$D = [
		{
			tfOpName: "Abs",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Acos",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Asin",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Atan",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Atan2",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "y",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Ceil",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "ClipByValue",
			category: "basic_math",
			inputs: [
				{
					start: 0,
					name: "x",
					type: "tensor"
				},
				{
					start: 1,
					name: "clipValueMin",
					type: "number"
				},
				{
					start: 2,
					name: "clipValueMax",
					type: "number"
				}
			],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Complex",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "real",
				type: "tensor"
			}, {
				start: 1,
				name: "imag",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "ComplexAbs",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Cos",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Cosh",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Elu",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Exp",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Floor",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Log",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Imag",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}, {
				tfName: "Tout",
				name: "outputType",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Neg",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Real",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}, {
				tfName: "Tout",
				name: "outputType",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Prelu",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "alpha",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Relu",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Relu6",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Selu",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Sigmoid",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Sin",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Sinh",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Sqrt",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Rsqrt",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Square",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Tan",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Tanh",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Sign",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Round",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Expm1",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Log1p",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Reciprocal",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Softplus",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Asinh",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Acosh",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Atanh",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Erf",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "LeakyRelu",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "alpha",
				name: "alpha",
				type: "number",
				defaultValue: .2
			}, {
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "IsNan",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "IsFinite",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "IsInf",
			category: "basic_math",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		}
	];
})), tO = /* @__PURE__ */ n({ json: () => nO }), nO, rO = e((() => {
	nO = [
		{
			tfOpName: "EmptyTensorList",
			category: "control",
			inputs: [{
				start: 0,
				name: "elementShape",
				type: "shape"
			}, {
				start: 1,
				name: "maxNumElements",
				type: "number"
			}],
			attrs: [{
				tfName: "element_dtype",
				name: "elementDType",
				type: "dtype"
			}]
		},
		{
			tfOpName: "LoopCond",
			category: "control",
			inputs: [{
				start: 0,
				name: "pred",
				type: "tensor"
			}]
		},
		{
			tfOpName: "Switch",
			category: "control",
			inputs: [{
				start: 0,
				name: "data",
				type: "tensor"
			}, {
				start: 1,
				name: "pred",
				type: "tensor"
			}]
		},
		{
			tfOpName: "Merge",
			category: "control",
			inputs: [{
				start: 0,
				end: 0,
				name: "tensors",
				type: "tensors"
			}]
		},
		{
			tfOpName: "Enter",
			category: "control",
			inputs: [{
				start: 0,
				name: "tensor",
				type: "tensor"
			}],
			attrs: [
				{
					tfName: "T",
					name: "dtype",
					type: "dtype",
					notSupported: !0
				},
				{
					tfName: "frame_name",
					name: "frameName",
					type: "string"
				},
				{
					tfName: "is_constant",
					name: "isConstant",
					type: "bool"
				}
			]
		},
		{
			tfOpName: "Exit",
			category: "control",
			inputs: [{
				start: 0,
				name: "tensor",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "NextIteration",
			category: "control",
			inputs: [{
				start: 0,
				name: "tensor",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "TensorArrayV3",
			category: "control",
			inputs: [{
				start: 0,
				name: "size",
				type: "number"
			}],
			attrs: [
				{
					tfName: "dtype",
					name: "dtype",
					type: "dtype"
				},
				{
					tfName: "element_shape",
					name: "elementShape",
					type: "shape"
				},
				{
					tfName: "dynamic_size",
					name: "dynamicSize",
					type: "bool"
				},
				{
					tfName: "clear_after_read",
					name: "clearAfterRead",
					type: "bool"
				},
				{
					tfName: "identical_element_shapes",
					name: "identicalElementShapes",
					type: "bool"
				},
				{
					tfName: "tensor_array_name",
					name: "name",
					type: "string"
				}
			]
		},
		{
			tfOpName: "TensorArrayWriteV3",
			category: "control",
			inputs: [
				{
					start: 0,
					name: "tensorArrayId",
					type: "tensor"
				},
				{
					start: 1,
					name: "index",
					type: "number"
				},
				{
					start: 2,
					name: "tensor",
					type: "tensor"
				},
				{
					start: 3,
					name: "flowIn",
					type: "number"
				}
			],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "TensorArrayReadV3",
			category: "control",
			inputs: [
				{
					start: 0,
					name: "tensorArrayId",
					type: "tensor"
				},
				{
					start: 1,
					name: "index",
					type: "number"
				},
				{
					start: 2,
					name: "flowIn",
					type: "number"
				}
			],
			attrs: [{
				tfName: "dtype",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "TensorArrayGatherV3",
			category: "control",
			inputs: [
				{
					start: 0,
					name: "tensorArrayId",
					type: "tensor"
				},
				{
					start: 1,
					name: "indices",
					type: "number[]"
				},
				{
					start: 2,
					name: "flowIn",
					type: "number"
				}
			],
			attrs: [{
				tfName: "dtype",
				name: "dtype",
				type: "dtype"
			}, {
				tfName: "element_shape",
				name: "elementShape",
				type: "shape"
			}]
		},
		{
			tfOpName: "TensorArrayScatterV3",
			category: "control",
			inputs: [
				{
					start: 0,
					name: "tensorArrayId",
					type: "tensor"
				},
				{
					start: 1,
					name: "indices",
					type: "number[]"
				},
				{
					start: 2,
					name: "tensor",
					type: "tensor"
				},
				{
					start: 3,
					name: "flowIn",
					type: "number"
				}
			],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype"
			}]
		},
		{
			tfOpName: "TensorArrayConcatV3",
			category: "control",
			inputs: [{
				start: 0,
				name: "tensorArrayId",
				type: "tensor"
			}, {
				start: 1,
				name: "flowIn",
				type: "number"
			}],
			attrs: [{
				tfName: "dtype",
				name: "dtype",
				type: "dtype"
			}, {
				tfName: "element_shape_except0",
				name: "elementShapeExcept0",
				type: "shape",
				notSupported: !0
			}]
		},
		{
			tfOpName: "TensorArraySplitV3",
			category: "control",
			inputs: [
				{
					start: 0,
					name: "tensorArrayId",
					type: "tensor"
				},
				{
					start: 1,
					name: "tensor",
					type: "tensor"
				},
				{
					start: 2,
					name: "lengths",
					type: "number[]"
				},
				{
					start: 3,
					name: "flowIn",
					type: "number"
				}
			],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype"
			}]
		},
		{
			tfOpName: "TensorArraySizeV3",
			category: "control",
			inputs: [{
				start: 0,
				name: "tensorArrayId",
				type: "tensor"
			}, {
				start: 1,
				name: "flowIn",
				type: "number"
			}]
		},
		{
			tfOpName: "TensorArrayCloseV3",
			category: "control",
			inputs: [{
				start: 0,
				name: "tensorArrayId",
				type: "tensor"
			}]
		},
		{
			tfOpName: "StatelessIf",
			category: "control",
			inputs: [{
				start: 0,
				name: "cond",
				type: "tensor"
			}, {
				start: 1,
				end: 0,
				name: "args",
				type: "tensors"
			}],
			attrs: [{
				tfName: "then_branch",
				name: "thenBranch",
				type: "func"
			}, {
				tfName: "else_branch",
				name: "elseBranch",
				type: "func"
			}]
		},
		{
			tfOpName: "If",
			category: "control",
			inputs: [{
				start: 0,
				name: "cond",
				type: "tensor"
			}, {
				start: 1,
				end: 0,
				name: "args",
				type: "tensors"
			}],
			attrs: [{
				tfName: "then_branch",
				name: "thenBranch",
				type: "func"
			}, {
				tfName: "else_branch",
				name: "elseBranch",
				type: "func"
			}]
		},
		{
			tfOpName: "StatelessWhile",
			category: "control",
			inputs: [{
				start: 0,
				end: 0,
				name: "args",
				type: "tensors"
			}],
			attrs: [{
				tfName: "cond",
				name: "cond",
				type: "func"
			}, {
				tfName: "body",
				name: "body",
				type: "func"
			}]
		},
		{
			tfOpName: "While",
			category: "control",
			inputs: [{
				start: 0,
				end: 0,
				name: "args",
				type: "tensors"
			}],
			attrs: [{
				tfName: "cond",
				name: "cond",
				type: "func"
			}, {
				tfName: "body",
				name: "body",
				type: "func"
			}]
		},
		{
			tfOpName: "TensorListScatter",
			category: "control",
			inputs: [
				{
					start: 0,
					name: "tensor",
					type: "tensor"
				},
				{
					start: 1,
					name: "indices",
					type: "number[]"
				},
				{
					start: 2,
					name: "elementShape",
					type: "shape"
				}
			],
			attrs: [{
				tfName: "element_dtype",
				name: "elementDType",
				type: "dtype"
			}]
		},
		{
			tfOpName: "TensorListScatterV2",
			category: "control",
			inputs: [
				{
					start: 0,
					name: "tensor",
					type: "tensor"
				},
				{
					start: 1,
					name: "indices",
					type: "number[]"
				},
				{
					start: 2,
					name: "elementShape",
					type: "shape"
				},
				{
					start: 3,
					name: "numElements",
					type: "number"
				}
			],
			attrs: [{
				tfName: "element_dtype",
				name: "elementDType",
				type: "dtype"
			}]
		},
		{
			tfOpName: "TensorListGather",
			category: "control",
			inputs: [
				{
					start: 0,
					name: "tensorListId",
					type: "tensor"
				},
				{
					start: 1,
					name: "indices",
					type: "number[]"
				},
				{
					start: 2,
					name: "elementShape",
					type: "shape"
				}
			],
			attrs: [{
				tfName: "element_dtype",
				name: "elementDType",
				type: "dtype"
			}]
		},
		{
			tfOpName: "TensorListGetItem",
			category: "control",
			inputs: [
				{
					start: 0,
					name: "tensorListId",
					type: "tensor"
				},
				{
					start: 1,
					name: "index",
					type: "number"
				},
				{
					start: 2,
					name: "elementShape",
					type: "shape"
				}
			],
			attrs: [{
				tfName: "element_dtype",
				name: "elementDType",
				type: "dtype"
			}]
		},
		{
			tfOpName: "TensorListSetItem",
			category: "control",
			inputs: [
				{
					start: 0,
					name: "tensorListId",
					type: "tensor"
				},
				{
					start: 1,
					name: "index",
					type: "number"
				},
				{
					start: 2,
					name: "tensor",
					type: "tensor"
				}
			],
			attrs: [{
				tfName: "element_dtype",
				name: "elementDType",
				type: "dtype"
			}]
		},
		{
			tfOpName: "TensorListReserve",
			category: "control",
			inputs: [{
				start: 0,
				name: "elementShape",
				type: "shape"
			}, {
				start: 1,
				name: "numElements",
				type: "number"
			}],
			attrs: [{
				tfName: "element_dtype",
				name: "elementDType",
				type: "dtype"
			}]
		},
		{
			tfOpName: "TensorListFromTensor",
			category: "control",
			inputs: [{
				start: 0,
				name: "tensor",
				type: "tensor"
			}, {
				start: 1,
				name: "elementShape",
				type: "shape"
			}],
			attrs: [{
				tfName: "element_dtype",
				name: "elementDType",
				type: "dtype"
			}]
		},
		{
			tfOpName: "TensorListStack",
			category: "control",
			inputs: [{
				start: 0,
				name: "tensorListId",
				type: "tensor"
			}, {
				start: 1,
				name: "elementShape",
				type: "shape"
			}],
			attrs: [{
				tfName: "element_dtype",
				name: "elementDType",
				type: "dtype"
			}, {
				tfName: "num_elements",
				name: "numElements",
				type: "dtype"
			}]
		},
		{
			tfOpName: "TensorListSplit",
			category: "control",
			inputs: [
				{
					start: 0,
					name: "tensor",
					type: "tensor"
				},
				{
					start: 1,
					name: "elementShape",
					type: "shape"
				},
				{
					start: 2,
					name: "lengths",
					type: "number[]"
				}
			],
			attrs: [{
				tfName: "element_dtype",
				name: "elementDType",
				type: "dtype"
			}]
		},
		{
			tfOpName: "TensorListConcat",
			category: "control",
			inputs: [{
				start: 0,
				name: "tensorListId",
				type: "tensor"
			}],
			attrs: [{
				tfName: "element_shape",
				name: "elementShape",
				type: "shape"
			}, {
				tfName: "element_dtype",
				name: "elementDType",
				type: "dtype"
			}]
		},
		{
			tfOpName: "TensorListConcatV2",
			category: "control",
			inputs: [{
				start: 0,
				name: "tensorListId",
				type: "tensor"
			}],
			attrs: [{
				tfName: "element_shape",
				name: "elementShape",
				type: "shape"
			}, {
				tfName: "element_dtype",
				name: "elementDType",
				type: "dtype"
			}]
		},
		{
			tfOpName: "TensorListPopBack",
			category: "control",
			inputs: [{
				start: 0,
				name: "tensorListId",
				type: "tensor"
			}, {
				start: 1,
				name: "elementShape",
				type: "shape"
			}],
			attrs: [{
				tfName: "element_dtype",
				name: "elementDType",
				type: "dtype"
			}]
		},
		{
			tfOpName: "TensorListPushBack",
			category: "control",
			inputs: [{
				start: 0,
				name: "tensorListId",
				type: "tensor"
			}, {
				start: 1,
				name: "tensor",
				type: "tensor"
			}],
			attrs: [{
				tfName: "element_dtype",
				name: "elementDType",
				type: "dtype"
			}]
		},
		{
			tfOpName: "TensorListLength",
			category: "control",
			inputs: [{
				start: 0,
				name: "tensorListId",
				type: "tensor"
			}]
		},
		{
			tfOpName: "TensorListResize",
			category: "control",
			inputs: [{
				start: 0,
				name: "tensorListId",
				type: "tensor"
			}, {
				start: 1,
				name: "size",
				type: "number"
			}]
		}
	];
})), iO = /* @__PURE__ */ n({ json: () => aO }), aO, oO = e((() => {
	aO = [
		{
			tfOpName: "AvgPool",
			category: "convolution",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [
				{
					tfName: "strides",
					name: "strides",
					type: "number[]"
				},
				{
					tfName: "padding",
					name: "pad",
					type: "string"
				},
				{
					tfName: "data_format",
					name: "dataFormat",
					type: "string",
					notSupported: !0
				},
				{
					tfName: "ksize",
					name: "kernelSize",
					type: "number[]"
				},
				{
					tfName: "T",
					name: "dtype",
					type: "dtype",
					notSupported: !0
				}
			]
		},
		{
			tfOpName: "MaxPool",
			category: "convolution",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [
				{
					tfName: "strides",
					name: "strides",
					type: "number[]"
				},
				{
					tfName: "padding",
					name: "pad",
					type: "string"
				},
				{
					tfName: "data_format",
					name: "dataFormat",
					type: "string",
					notSupported: !0
				},
				{
					tfName: "ksize",
					name: "kernelSize",
					type: "number[]"
				},
				{
					tfName: "explicit_paddings",
					name: "explicitPaddings",
					type: "number[]",
					defaultValue: [],
					notSupported: !0
				},
				{
					tfName: "T",
					name: "dtype",
					type: "dtype",
					notSupported: !0
				}
			]
		},
		{
			tfOpName: "MaxPoolWithArgmax",
			category: "convolution",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [
				{
					tfName: "strides",
					name: "strides",
					type: "number[]"
				},
				{
					tfName: "padding",
					name: "pad",
					type: "string"
				},
				{
					tfName: "ksize",
					name: "kernelSize",
					type: "number[]"
				},
				{
					tfName: "include_batch_in_index",
					name: "includeBatchInIndex",
					type: "bool"
				},
				{
					tfName: "T",
					name: "dtype",
					type: "dtype",
					notSupported: !0
				}
			]
		},
		{
			tfOpName: "AvgPool3D",
			category: "convolution",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [
				{
					tfName: "strides",
					name: "strides",
					type: "number[]"
				},
				{
					tfName: "padding",
					name: "pad",
					type: "string"
				},
				{
					tfName: "data_format",
					name: "dataFormat",
					type: "string",
					notSupported: !0
				},
				{
					tfName: "ksize",
					name: "kernelSize",
					type: "number[]"
				},
				{
					tfName: "T",
					name: "dtype",
					type: "dtype",
					notSupported: !0
				}
			]
		},
		{
			tfOpName: "MaxPool3D",
			category: "convolution",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [
				{
					tfName: "strides",
					name: "strides",
					type: "number[]"
				},
				{
					tfName: "padding",
					name: "pad",
					type: "string"
				},
				{
					tfName: "data_format",
					name: "dataFormat",
					type: "string",
					notSupported: !0
				},
				{
					tfName: "ksize",
					name: "kernelSize",
					type: "number[]"
				},
				{
					tfName: "T",
					name: "dtype",
					type: "dtype",
					notSupported: !0
				}
			]
		},
		{
			tfOpName: "Conv1D",
			category: "convolution",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "filter",
				type: "tensor"
			}],
			attrs: [
				{
					tfName: "stride",
					name: "stride",
					type: "number"
				},
				{
					tfName: "padding",
					name: "pad",
					type: "string"
				},
				{
					tfName: "data_format",
					name: "dataFormat",
					type: "string",
					defaultValue: "NWC"
				},
				{
					tfName: "T",
					name: "dtype",
					type: "dtype",
					notSupported: !0
				},
				{
					tfName: "dilation",
					name: "dilation",
					type: "number",
					defaultValue: 1
				}
			]
		},
		{
			tfOpName: "Conv2D",
			category: "convolution",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "filter",
				type: "tensor"
			}],
			attrs: [
				{
					tfName: "T",
					name: "dtype",
					type: "dtype",
					notSupported: !0
				},
				{
					tfName: "strides",
					name: "strides",
					type: "number[]"
				},
				{
					tfName: "padding",
					name: "pad",
					type: "string"
				},
				{
					tfName: "useCudnnOnGpu",
					name: "useCudnnOnGpu",
					type: "bool"
				},
				{
					tfName: "data_format",
					name: "dataFormat",
					type: "string",
					defaultValue: "NHWC"
				},
				{
					tfName: "explicit_paddings",
					name: "explicitPaddings",
					type: "number[]",
					defaultValue: []
				},
				{
					tfName: "dilations",
					name: "dilations",
					type: "number[]"
				}
			]
		},
		{
			tfOpName: "_FusedConv2D",
			category: "convolution",
			inputs: [
				{
					start: 0,
					name: "x",
					type: "tensor"
				},
				{
					start: 1,
					name: "filter",
					type: "tensor"
				},
				{
					start: 2,
					end: 0,
					name: "args",
					type: "tensors"
				}
			],
			attrs: [
				{
					tfName: "num_args",
					name: "numArgs",
					type: "number"
				},
				{
					tfName: "T",
					name: "dtype",
					type: "dtype",
					notSupported: !0
				},
				{
					tfName: "strides",
					name: "strides",
					type: "number[]"
				},
				{
					tfName: "padding",
					name: "pad",
					type: "string"
				},
				{
					tfName: "explicit_paddings",
					name: "explicitPaddings",
					type: "number[]",
					defaultValue: []
				},
				{
					tfName: "use_cudnn_on_gpu",
					name: "useCudnnOnGpu",
					type: "bool",
					defaultValue: !0
				},
				{
					tfName: "data_format",
					name: "dataFormat",
					type: "string",
					defaultValue: "NHWC"
				},
				{
					tfName: "dilations",
					name: "dilations",
					type: "number[]",
					defaultValue: [
						1,
						1,
						1,
						1
					]
				},
				{
					tfName: "fused_ops",
					name: "fusedOps",
					type: "string[]",
					defaultValue: []
				},
				{
					tfName: "epsilon",
					name: "epsilon",
					type: "number",
					defaultValue: 1e-4
				},
				{
					tfName: "leakyrelu_alpha",
					name: "leakyreluAlpha",
					type: "number",
					defaultValue: .2
				}
			]
		},
		{
			tfOpName: "Conv2DBackpropInput",
			category: "convolution",
			inputs: [
				{
					start: 2,
					name: "x",
					type: "tensor"
				},
				{
					start: 1,
					name: "filter",
					type: "tensor"
				},
				{
					start: 0,
					name: "outputShape",
					type: "number[]"
				}
			],
			attrs: [
				{
					tfName: "strides",
					name: "strides",
					type: "number[]"
				},
				{
					tfName: "padding",
					name: "pad",
					type: "string"
				},
				{
					tfName: "data_format",
					name: "dataFormat",
					type: "string",
					notSupported: !0
				},
				{
					tfName: "explicit_paddings",
					name: "explicitPaddings",
					type: "number[]",
					defaultValue: []
				},
				{
					tfName: "dilations",
					name: "dilations",
					type: "number[]",
					notSupported: !0
				}
			]
		},
		{
			tfOpName: "DepthwiseConv2d",
			category: "convolution",
			inputs: [{
				start: 0,
				name: "input",
				type: "tensor"
			}, {
				start: 1,
				name: "filter",
				type: "tensor"
			}],
			attrs: [
				{
					tfName: "strides",
					name: "strides",
					type: "number[]"
				},
				{
					tfName: "padding",
					name: "pad",
					type: "string"
				},
				{
					tfName: "data_format",
					name: "dataFormat",
					type: "string",
					defaultValue: "NHWC"
				},
				{
					tfName: "explicit_paddings",
					name: "explicitPaddings",
					type: "number[]",
					defaultValue: []
				},
				{
					tfName: "dilations",
					name: "dilations",
					type: "number[]"
				}
			]
		},
		{
			tfOpName: "DepthwiseConv2dNative",
			category: "convolution",
			inputs: [{
				start: 0,
				name: "input",
				type: "tensor"
			}, {
				start: 1,
				name: "filter",
				type: "tensor"
			}],
			attrs: [
				{
					tfName: "strides",
					name: "strides",
					type: "number[]"
				},
				{
					tfName: "padding",
					name: "pad",
					type: "string"
				},
				{
					tfName: "data_format",
					name: "dataFormat",
					type: "string",
					defaultValue: "NHWC"
				},
				{
					tfName: "explicit_paddings",
					name: "explicitPaddings",
					type: "number[]",
					defaultValue: []
				},
				{
					tfName: "dilations",
					name: "dilations",
					type: "number[]"
				}
			]
		},
		{
			tfOpName: "FusedDepthwiseConv2dNative",
			category: "convolution",
			inputs: [
				{
					start: 0,
					name: "x",
					type: "tensor"
				},
				{
					start: 1,
					name: "filter",
					type: "tensor"
				},
				{
					start: 2,
					end: 0,
					name: "args",
					type: "tensors"
				}
			],
			attrs: [
				{
					tfName: "num_args",
					name: "numArgs",
					type: "number"
				},
				{
					tfName: "T",
					name: "dtype",
					type: "dtype",
					notSupported: !0
				},
				{
					tfName: "strides",
					name: "strides",
					type: "number[]"
				},
				{
					tfName: "padding",
					name: "pad",
					type: "string"
				},
				{
					tfName: "data_format",
					name: "dataFormat",
					type: "string",
					defaultValue: "NHWC"
				},
				{
					tfName: "dilations",
					name: "dilations",
					type: "number[]",
					defaultValue: [
						1,
						1,
						1,
						1
					]
				},
				{
					tfName: "fused_ops",
					name: "fusedOps",
					type: "string[]",
					defaultValue: []
				},
				{
					tfName: "explicit_paddings",
					name: "explicitPaddings",
					type: "number[]",
					defaultValue: []
				}
			]
		},
		{
			tfOpName: "Conv3D",
			category: "convolution",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "filter",
				type: "tensor"
			}],
			attrs: [
				{
					tfName: "strides",
					name: "strides",
					type: "number[]"
				},
				{
					tfName: "padding",
					name: "pad",
					type: "string"
				},
				{
					tfName: "data_format",
					name: "dataFormat",
					type: "string",
					defaultValue: "NHWC"
				},
				{
					tfName: "dilations",
					name: "dilations",
					type: "number[]"
				}
			]
		},
		{
			tfOpName: "Dilation2D",
			category: "convolution",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "filter",
				type: "tensor"
			}],
			attrs: [
				{
					tfName: "strides",
					name: "strides",
					type: "number[]"
				},
				{
					tfName: "rates",
					name: "dilations",
					type: "number[]"
				},
				{
					tfName: "padding",
					name: "pad",
					type: "string"
				}
			]
		}
	];
})), sO = /* @__PURE__ */ n({ json: () => cO }), cO, lO = e((() => {
	cO = [
		{
			tfOpName: "Fill",
			category: "creation",
			inputs: [{
				start: 0,
				name: "shape",
				type: "number[]"
			}, {
				start: 1,
				name: "value",
				type: "number"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype"
			}]
		},
		{
			tfOpName: "LinSpace",
			category: "creation",
			inputs: [
				{
					start: 0,
					name: "start",
					type: "number"
				},
				{
					start: 1,
					name: "stop",
					type: "number"
				},
				{
					start: 2,
					name: "num",
					type: "number"
				}
			],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "OneHot",
			category: "creation",
			inputs: [
				{
					start: 0,
					name: "indices",
					type: "tensor"
				},
				{
					start: 1,
					name: "depth",
					type: "number"
				},
				{
					start: 2,
					name: "onValue",
					type: "number",
					defaultValue: 1
				},
				{
					start: 3,
					name: "offValue",
					type: "number",
					defaultValue: 0
				}
			],
			attrs: [{
				tfName: "axis",
				name: "axis",
				type: "number",
				notSupported: !0
			}, {
				tfName: "T",
				name: "dtype",
				type: "dtype"
			}]
		},
		{
			tfOpName: "Ones",
			category: "creation",
			inputs: [{
				start: 0,
				name: "shape",
				type: "number[]"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype"
			}]
		},
		{
			tfOpName: "OnesLike",
			category: "creation",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "dtype",
				name: "dtype",
				type: "dtype"
			}]
		},
		{
			tfOpName: "RandomStandardNormal",
			category: "creation",
			inputs: [{
				start: 0,
				name: "shape",
				type: "number[]"
			}],
			attrs: [
				{
					tfName: "seed",
					name: "seed",
					type: "number",
					defaultValue: 0
				},
				{
					tfName: "seed2",
					name: "seed2",
					type: "number",
					defaultValue: 0,
					notSupported: !0
				},
				{
					tfName: "dtype",
					name: "dtype",
					type: "dtype"
				},
				{
					tfName: "T",
					name: "T",
					type: "number",
					notSupported: !0
				}
			]
		},
		{
			tfOpName: "RandomUniform",
			category: "creation",
			inputs: [{
				start: 0,
				name: "shape",
				type: "number[]"
			}],
			attrs: [
				{
					tfName: "minval",
					name: "minval",
					type: "number",
					defaultValue: 0
				},
				{
					tfName: "maxval",
					name: "maxval",
					type: "number",
					defaultValue: 1
				},
				{
					tfName: "dtype",
					name: "dtype",
					type: "dtype"
				},
				{
					tfName: "seed",
					name: "seed",
					type: "number",
					defaultValue: 0
				},
				{
					tfName: "seed2",
					name: "seed2",
					type: "number",
					defaultValue: 0,
					notSupported: !0
				},
				{
					tfName: "T",
					name: "T",
					type: "number",
					notSupported: !0
				}
			]
		},
		{
			tfOpName: "RandomUniformInt",
			category: "creation",
			inputs: [{
				start: 0,
				name: "shape",
				type: "number[]"
			}],
			attrs: [
				{
					tfName: "minval",
					name: "minval",
					type: "number"
				},
				{
					tfName: "maxval",
					name: "maxval",
					type: "number"
				},
				{
					tfName: "seed",
					name: "seed",
					type: "number",
					defaultValue: 0
				},
				{
					tfName: "seed2",
					name: "seed2",
					type: "number",
					defaultValue: 0,
					notSupported: !0
				}
			]
		},
		{
			tfOpName: "Range",
			category: "creation",
			inputs: [
				{
					start: 0,
					name: "start",
					type: "number"
				},
				{
					start: 1,
					name: "stop",
					type: "number"
				},
				{
					start: 2,
					name: "step",
					type: "number",
					defaultValue: 0
				}
			],
			attrs: [{
				tfName: "Tidx",
				name: "dtype",
				type: "dtype"
			}]
		},
		{
			tfOpName: "TruncatedNormal",
			category: "creation",
			inputs: [{
				start: 0,
				name: "shape",
				type: "number[]"
			}],
			attrs: [
				{
					tfName: "means",
					name: "mean",
					type: "number",
					defaultValue: 0
				},
				{
					tfName: "stddev",
					name: "stdDev",
					type: "number",
					defaultValue: 1
				},
				{
					tfName: "seed",
					name: "seed",
					type: "number"
				},
				{
					tfName: "seed2",
					name: "seed2",
					type: "number",
					defaultValue: 0,
					notSupported: !0
				},
				{
					tfName: "dtype",
					name: "dtype",
					type: "dtype"
				},
				{
					tfName: "T",
					name: "T",
					type: "number",
					notSupported: !0
				}
			]
		},
		{
			tfOpName: "Zeros",
			category: "creation",
			inputs: [{
				start: 0,
				name: "shape",
				type: "number[]"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype"
			}]
		},
		{
			tfOpName: "ZerosLike",
			category: "creation",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype"
			}]
		},
		{
			tfOpName: "Multinomial",
			category: "creation",
			inputs: [{
				start: 0,
				name: "logits",
				type: "tensor"
			}, {
				start: 1,
				name: "numSamples",
				type: "number"
			}],
			attrs: [
				{
					tfName: "seed",
					name: "seed",
					type: "number"
				},
				{
					tfName: "seed2",
					name: "seed2",
					type: "number"
				},
				{
					tfName: "T",
					name: "dtype",
					type: "dtype"
				},
				{
					tfName: "output_dtype",
					name: "output_dtype",
					type: "dtype"
				}
			]
		}
	];
})), uO = /* @__PURE__ */ n({ json: () => dO }), dO, fO = e((() => {
	dO = [
		{
			tfOpName: "NonMaxSuppressionV2",
			category: "dynamic",
			inputs: [
				{
					start: 0,
					name: "boxes",
					type: "tensor"
				},
				{
					start: 1,
					name: "scores",
					type: "tensor"
				},
				{
					start: 2,
					name: "maxOutputSize",
					type: "number"
				},
				{
					start: 3,
					name: "iouThreshold",
					type: "number"
				}
			]
		},
		{
			tfOpName: "NonMaxSuppressionV3",
			category: "dynamic",
			inputs: [
				{
					start: 0,
					name: "boxes",
					type: "tensor"
				},
				{
					start: 1,
					name: "scores",
					type: "tensor"
				},
				{
					start: 2,
					name: "maxOutputSize",
					type: "number"
				},
				{
					start: 3,
					name: "iouThreshold",
					type: "number"
				},
				{
					start: 4,
					name: "scoreThreshold",
					type: "number"
				}
			]
		},
		{
			tfOpName: "NonMaxSuppressionV4",
			category: "dynamic",
			inputs: [
				{
					start: 0,
					name: "boxes",
					type: "tensor"
				},
				{
					start: 1,
					name: "scores",
					type: "tensor"
				},
				{
					start: 2,
					name: "maxOutputSize",
					type: "number"
				},
				{
					start: 3,
					name: "iouThreshold",
					type: "number"
				},
				{
					start: 4,
					name: "scoreThreshold",
					type: "number"
				}
			],
			attrs: [
				{
					tfName: "T",
					name: "dtype",
					type: "dtype",
					notSupported: !0
				},
				{
					tfName: "T_threshold",
					name: "threshold",
					type: "dtype",
					notSupported: !0
				},
				{
					tfName: "pad_to_max_output_size",
					name: "padToMaxOutputSize",
					type: "bool"
				}
			]
		},
		{
			tfOpName: "NonMaxSuppressionV5",
			category: "dynamic",
			inputs: [
				{
					start: 0,
					name: "boxes",
					type: "tensor"
				},
				{
					start: 1,
					name: "scores",
					type: "tensor"
				},
				{
					start: 2,
					name: "maxOutputSize",
					type: "number"
				},
				{
					start: 3,
					name: "iouThreshold",
					type: "number"
				},
				{
					start: 4,
					name: "scoreThreshold",
					type: "number"
				},
				{
					start: 5,
					name: "softNmsSigma",
					type: "number"
				}
			]
		},
		{
			tfOpName: "Where",
			category: "dynamic",
			inputs: [{
				start: 0,
				name: "condition",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "ListDiff",
			category: "dynamic",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "y",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		}
	];
})), pO = /* @__PURE__ */ n({ json: () => mO }), mO, hO = e((() => {
	mO = [
		{
			tfOpName: "LowerBound",
			category: "evaluation",
			inputs: [{
				start: 0,
				name: "sortedSequence",
				type: "tensor"
			}, {
				start: 1,
				name: "values",
				type: "tensor"
			}]
		},
		{
			tfOpName: "TopKV2",
			category: "evaluation",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "k",
				type: "number"
			}],
			attrs: [{
				tfName: "sorted",
				name: "sorted",
				type: "bool"
			}]
		},
		{
			tfOpName: "UpperBound",
			category: "evaluation",
			inputs: [{
				start: 0,
				name: "sortedSequence",
				type: "tensor"
			}, {
				start: 1,
				name: "values",
				type: "tensor"
			}]
		},
		{
			tfOpName: "Unique",
			category: "evaluation",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}]
		},
		{
			tfOpName: "UniqueV2",
			category: "evaluation",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "axis",
				type: "number"
			}]
		}
	];
})), gO = /* @__PURE__ */ n({ json: () => _O }), _O, vO = e((() => {
	_O = [
		{
			tfOpName: "PlaceholderWithDefault",
			category: "graph",
			inputs: [{
				start: 0,
				name: "default",
				type: "tensor"
			}],
			attrs: [{
				tfName: "shape",
				name: "shape",
				type: "shape"
			}, {
				tfName: "dtype",
				name: "dtype",
				type: "dtype"
			}]
		},
		{
			tfOpName: "Placeholder",
			category: "graph",
			attrs: [{
				tfName: "shape",
				name: "shape",
				type: "shape"
			}, {
				tfName: "dtype",
				name: "dtype",
				type: "dtype"
			}]
		},
		{
			tfOpName: "Const",
			category: "graph"
		},
		{
			tfOpName: "Identity",
			category: "graph",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}]
		},
		{
			tfOpName: "IdentityN",
			category: "graph",
			inputs: [{
				start: 0,
				end: 0,
				name: "x",
				type: "tensors"
			}]
		},
		{
			tfOpName: "Snapshot",
			category: "graph",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}]
		},
		{
			tfOpName: "Rank",
			category: "graph",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}]
		},
		{
			tfOpName: "Size",
			category: "graph",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}]
		},
		{
			tfOpName: "Shape",
			category: "graph",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}]
		},
		{
			tfOpName: "ShapeN",
			category: "graph",
			inputs: [{
				start: 0,
				end: 0,
				name: "x",
				type: "tensors"
			}]
		},
		{
			tfOpName: "Print",
			category: "graph",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "data",
				type: "tensors"
			}],
			attrs: [
				{
					tfName: "message",
					name: "message",
					type: "string"
				},
				{
					tfName: "first_n",
					name: "firstN",
					type: "number",
					notSupported: !0
				},
				{
					tfName: "summarize",
					name: "summarize",
					type: "number",
					defaultValue: 3
				}
			]
		},
		{
			tfOpName: "NoOp",
			category: "graph",
			inputs: []
		},
		{
			tfOpName: "StopGradient",
			category: "graph",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}]
		},
		{
			tfOpName: "FakeQuantWithMinMaxVars",
			category: "graph",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "min",
				name: "min",
				type: "number"
			}, {
				tfName: "max",
				name: "max",
				type: "number"
			}]
		}
	];
})), yO = /* @__PURE__ */ n({ json: () => bO }), bO, xO = e((() => {
	bO = [
		{
			tfOpName: "HashTable",
			category: "hash_table",
			inputs: [],
			attrs: [
				{
					tfName: "shared_name",
					name: "sharedName",
					type: "string"
				},
				{
					tfName: "use_node_name_sharing",
					name: "useNodeNameSharing",
					type: "bool"
				},
				{
					tfName: "key_dtype",
					name: "keyDType",
					type: "dtype"
				},
				{
					tfName: "value_dtype",
					name: "valueDType",
					type: "dtype"
				}
			]
		},
		{
			tfOpName: "HashTableV2",
			category: "hash_table",
			inputs: [],
			attrs: [
				{
					tfName: "shared_name",
					name: "sharedName",
					type: "string"
				},
				{
					tfName: "use_node_name_sharing",
					name: "useNodeNameSharing",
					type: "bool"
				},
				{
					tfName: "key_dtype",
					name: "keyDType",
					type: "dtype"
				},
				{
					tfName: "value_dtype",
					name: "valueDType",
					type: "dtype"
				}
			]
		},
		{
			tfOpName: "LookupTableImport",
			category: "hash_table",
			inputs: [
				{
					start: 0,
					name: "tableHandle",
					type: "tensor"
				},
				{
					start: 1,
					name: "keys",
					type: "tensor"
				},
				{
					start: 2,
					name: "values",
					type: "tensor"
				}
			],
			attrs: [{
				tfName: "Tin",
				name: "tIn",
				type: "dtype",
				notSupported: !0
			}, {
				tfName: "Tout",
				name: "tOut",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "LookupTableImportV2",
			category: "hash_table",
			inputs: [
				{
					start: 0,
					name: "tableHandle",
					type: "tensor"
				},
				{
					start: 1,
					name: "keys",
					type: "tensor"
				},
				{
					start: 2,
					name: "values",
					type: "tensor"
				}
			],
			attrs: [{
				tfName: "Tin",
				name: "tIn",
				type: "dtype",
				notSupported: !0
			}, {
				tfName: "Tout",
				name: "tOut",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "LookupTableFind",
			category: "hash_table",
			inputs: [
				{
					start: 0,
					name: "tableHandle",
					type: "tensor"
				},
				{
					start: 1,
					name: "keys",
					type: "tensor"
				},
				{
					start: 2,
					name: "defaultValue",
					type: "tensor"
				}
			],
			attrs: [{
				tfName: "Tin",
				name: "tIn",
				type: "dtype",
				notSupported: !0
			}, {
				tfName: "Tout",
				name: "tOut",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "LookupTableFindV2",
			category: "hash_table",
			inputs: [
				{
					start: 0,
					name: "tableHandle",
					type: "tensor"
				},
				{
					start: 1,
					name: "keys",
					type: "tensor"
				},
				{
					start: 2,
					name: "defaultValue",
					type: "tensor"
				}
			],
			attrs: [{
				tfName: "Tin",
				name: "tIn",
				type: "dtype",
				notSupported: !0
			}, {
				tfName: "Tout",
				name: "tOut",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "LookupTableSize",
			category: "hash_table",
			inputs: [{
				start: 0,
				name: "tableHandle",
				type: "tensor"
			}]
		},
		{
			tfOpName: "LookupTableSizeV2",
			category: "hash_table",
			inputs: [{
				start: 0,
				name: "tableHandle",
				type: "tensor"
			}]
		},
		{
			tfOpName: "InitializeTable",
			category: "hash_table",
			inputs: [
				{
					start: 0,
					name: "tableHandle",
					type: "tensor"
				},
				{
					start: 1,
					name: "keys",
					type: "tensor"
				},
				{
					start: 2,
					name: "values",
					type: "tensor"
				}
			]
		},
		{
			tfOpName: "InitializeTableV2",
			category: "hash_table",
			inputs: [
				{
					start: 0,
					name: "tableHandle",
					type: "tensor"
				},
				{
					start: 1,
					name: "keys",
					type: "tensor"
				},
				{
					start: 2,
					name: "values",
					type: "tensor"
				}
			]
		}
	];
})), SO = /* @__PURE__ */ n({ json: () => CO }), CO, wO = e((() => {
	CO = [
		{
			tfOpName: "ResizeBilinear",
			category: "image",
			inputs: [{
				start: 0,
				name: "images",
				type: "tensor"
			}, {
				start: 1,
				name: "size",
				type: "number[]"
			}],
			attrs: [
				{
					tfName: "align_corners",
					name: "alignCorners",
					type: "bool"
				},
				{
					tfName: "half_pixel_centers",
					name: "halfPixelCenters",
					type: "bool"
				},
				{
					tfName: "T",
					name: "dtype",
					type: "dtype",
					notSupported: !0
				}
			]
		},
		{
			tfOpName: "ResizeNearestNeighbor",
			category: "image",
			inputs: [{
				start: 0,
				name: "images",
				type: "tensor"
			}, {
				start: 1,
				name: "size",
				type: "number[]"
			}],
			attrs: [
				{
					tfName: "align_corners",
					name: "alignCorners",
					type: "bool"
				},
				{
					tfName: "half_pixel_centers",
					name: "halfPixelCenters",
					type: "bool"
				},
				{
					tfName: "T",
					name: "dtype",
					type: "dtype",
					notSupported: !0
				}
			]
		},
		{
			tfOpName: "CropAndResize",
			category: "image",
			inputs: [
				{
					start: 0,
					name: "image",
					type: "tensor"
				},
				{
					start: 1,
					name: "boxes",
					type: "tensor"
				},
				{
					start: 2,
					name: "boxInd",
					type: "tensor"
				},
				{
					start: 3,
					name: "cropSize",
					type: "number[]"
				}
			],
			attrs: [{
				tfName: "method",
				name: "method",
				type: "string"
			}, {
				tfName: "extrapolation_value",
				name: "extrapolationValue",
				type: "number"
			}]
		},
		{
			tfOpName: "ImageProjectiveTransformV3",
			category: "image",
			inputs: [
				{
					start: 0,
					name: "images",
					type: "tensor"
				},
				{
					start: 1,
					name: "transforms",
					type: "tensor"
				},
				{
					start: 2,
					name: "outputShape",
					type: "number[]"
				},
				{
					start: 3,
					name: "fillValue",
					type: "number"
				}
			],
			attrs: [{
				tfName: "interpolation",
				name: "interpolation",
				type: "string"
			}, {
				tfName: "fill_mode",
				name: "fillMode",
				type: "string"
			}]
		}
	];
})), TO = /* @__PURE__ */ n({ json: () => EO }), EO, DO = e((() => {
	EO = [
		{
			tfOpName: "Equal",
			category: "logical",
			inputs: [{
				start: 0,
				name: "a",
				type: "tensor"
			}, {
				start: 1,
				name: "b",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "NotEqual",
			category: "logical",
			inputs: [{
				start: 0,
				name: "a",
				type: "tensor"
			}, {
				start: 1,
				name: "b",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Greater",
			category: "logical",
			inputs: [{
				start: 0,
				name: "a",
				type: "tensor"
			}, {
				start: 1,
				name: "b",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "GreaterEqual",
			category: "logical",
			inputs: [{
				start: 0,
				name: "a",
				type: "tensor"
			}, {
				start: 1,
				name: "b",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Less",
			category: "logical",
			inputs: [{
				start: 0,
				name: "a",
				type: "tensor"
			}, {
				start: 1,
				name: "b",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "LessEqual",
			category: "logical",
			inputs: [{
				start: 0,
				name: "a",
				type: "tensor"
			}, {
				start: 1,
				name: "b",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "LogicalAnd",
			category: "logical",
			inputs: [{
				start: 0,
				name: "a",
				type: "tensor"
			}, {
				start: 1,
				name: "b",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "LogicalNot",
			category: "logical",
			inputs: [{
				start: 0,
				name: "a",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "LogicalOr",
			category: "logical",
			inputs: [{
				start: 0,
				name: "a",
				type: "tensor"
			}, {
				start: 1,
				name: "b",
				type: "tensor"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Select",
			category: "logical",
			inputs: [
				{
					start: 0,
					name: "condition",
					type: "tensor"
				},
				{
					start: 1,
					name: "a",
					type: "tensor"
				},
				{
					start: 2,
					name: "b",
					type: "tensor"
				}
			],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "SelectV2",
			category: "logical",
			inputs: [
				{
					start: 0,
					name: "condition",
					type: "tensor"
				},
				{
					start: 1,
					name: "a",
					type: "tensor"
				},
				{
					start: 2,
					name: "b",
					type: "tensor"
				}
			],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "BitwiseAnd",
			category: "logical",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "y",
				type: "tensor"
			}]
		}
	];
})), OO = /* @__PURE__ */ n({ json: () => kO }), kO, AO = e((() => {
	kO = [
		{
			tfOpName: "_FusedMatMul",
			category: "matrices",
			inputs: [
				{
					start: 0,
					name: "a",
					type: "tensor"
				},
				{
					start: 1,
					name: "b",
					type: "tensor"
				},
				{
					start: 2,
					end: 0,
					name: "args",
					type: "tensors"
				}
			],
			attrs: [
				{
					tfName: "num_args",
					name: "numArgs",
					type: "number"
				},
				{
					tfName: "fused_ops",
					name: "fusedOps",
					type: "string[]",
					defaultValue: []
				},
				{
					tfName: "epsilon",
					name: "epsilon",
					type: "number",
					defaultValue: 1e-4
				},
				{
					tfName: "transpose_a",
					name: "transposeA",
					type: "bool",
					defaultValue: !1
				},
				{
					tfName: "transpose_b",
					name: "transposeB",
					type: "bool",
					defaultValue: !1
				},
				{
					tfName: "leakyrelu_alpha",
					name: "leakyreluAlpha",
					type: "number",
					defaultValue: .2
				},
				{
					tfName: "T",
					name: "dtype",
					type: "dtype",
					notSupported: !0
				}
			]
		},
		{
			tfOpName: "MatMul",
			category: "matrices",
			inputs: [{
				start: 0,
				name: "a",
				type: "tensor"
			}, {
				start: 1,
				name: "b",
				type: "tensor"
			}],
			attrs: [
				{
					tfName: "transpose_a",
					name: "transposeA",
					type: "bool",
					defaultValue: !1
				},
				{
					tfName: "transpose_b",
					name: "transposeB",
					type: "bool",
					defaultValue: !1
				},
				{
					tfName: "T",
					name: "dtype",
					type: "dtype",
					notSupported: !0
				}
			]
		},
		{
			tfOpName: "BatchMatMul",
			category: "matrices",
			inputs: [{
				start: 0,
				name: "a",
				type: "tensor"
			}, {
				start: 1,
				name: "b",
				type: "tensor"
			}],
			attrs: [
				{
					tfName: "adj_x",
					name: "transposeA",
					type: "bool",
					defaultValue: !1
				},
				{
					tfName: "adj_y",
					name: "transposeB",
					type: "bool",
					defaultValue: !1
				},
				{
					tfName: "T",
					name: "dtype",
					type: "dtype",
					notSupported: !0
				}
			]
		},
		{
			tfOpName: "BatchMatMulV2",
			category: "matrices",
			inputs: [{
				start: 0,
				name: "a",
				type: "tensor"
			}, {
				start: 1,
				name: "b",
				type: "tensor"
			}],
			attrs: [
				{
					tfName: "adj_x",
					name: "transposeA",
					type: "bool",
					defaultValue: !1
				},
				{
					tfName: "adj_y",
					name: "transposeB",
					type: "bool",
					defaultValue: !1
				},
				{
					tfName: "T",
					name: "dtype",
					type: "dtype",
					notSupported: !0
				}
			]
		},
		{
			tfOpName: "Transpose",
			category: "matrices",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "perm",
				type: "number[]"
			}],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Einsum",
			category: "matrices",
			inputs: [{
				start: 0,
				end: 0,
				name: "tensors",
				type: "tensors"
			}],
			attrs: [
				{
					tfName: "equation",
					name: "equation",
					type: "string"
				},
				{
					tfName: "N",
					name: "n",
					type: "number",
					defaultValue: 2
				},
				{
					tfName: "T",
					name: "dtype",
					type: "dtype"
				}
			]
		},
		{
			tfOpName: "MatrixBandPart",
			category: "matrices",
			inputs: [
				{
					start: 0,
					name: "a",
					type: "tensor"
				},
				{
					start: 1,
					name: "numLower",
					type: "tensor"
				},
				{
					start: 1,
					name: "numUpper",
					type: "tensor"
				}
			]
		}
	];
})), jO = /* @__PURE__ */ n({ json: () => MO }), MO, NO = e((() => {
	MO = [
		{
			tfOpName: "EuclideanNorm",
			category: "normalization",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "axis",
				type: "number[]"
			}],
			attrs: [{
				tfName: "keep_dims",
				name: "keepDims",
				type: "bool",
				defaultValue: !1
			}]
		},
		{
			tfOpName: "FusedBatchNorm",
			category: "normalization",
			inputs: [
				{
					start: 0,
					name: "x",
					type: "tensor"
				},
				{
					start: 1,
					name: "scale",
					type: "tensor"
				},
				{
					start: 2,
					name: "offset",
					type: "tensor"
				},
				{
					start: 3,
					name: "mean",
					type: "tensor"
				},
				{
					start: 4,
					name: "variance",
					type: "tensor"
				}
			],
			attrs: [{
				tfName: "epsilon",
				name: "epsilon",
				type: "number",
				defaultValue: .001
			}, {
				tfName: "data_format",
				name: "dataFormat",
				type: "string",
				notSupported: !0
			}]
		},
		{
			tfOpName: "FusedBatchNormV2",
			category: "normalization",
			inputs: [
				{
					start: 0,
					name: "x",
					type: "tensor"
				},
				{
					start: 1,
					name: "scale",
					type: "tensor"
				},
				{
					start: 2,
					name: "offset",
					type: "tensor"
				},
				{
					start: 3,
					name: "mean",
					type: "tensor"
				},
				{
					start: 4,
					name: "variance",
					type: "tensor"
				}
			],
			attrs: [{
				tfName: "epsilon",
				name: "epsilon",
				type: "number",
				defaultValue: .001
			}, {
				tfName: "data_format",
				name: "dataFormat",
				type: "string",
				notSupported: !0
			}]
		},
		{
			tfOpName: "FusedBatchNormV3",
			category: "normalization",
			inputs: [
				{
					start: 0,
					name: "x",
					type: "tensor"
				},
				{
					start: 1,
					name: "scale",
					type: "tensor"
				},
				{
					start: 2,
					name: "offset",
					type: "tensor"
				},
				{
					start: 3,
					name: "mean",
					type: "tensor"
				},
				{
					start: 4,
					name: "variance",
					type: "tensor"
				}
			],
			attrs: [{
				tfName: "epsilon",
				name: "epsilon",
				type: "number",
				defaultValue: .001
			}, {
				tfName: "data_format",
				name: "dataFormat",
				type: "string",
				notSupported: !0
			}]
		},
		{
			tfOpName: "LRN",
			category: "normalization",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [
				{
					tfName: "depth_radius",
					name: "radius",
					type: "number",
					defaultValue: 5
				},
				{
					tfName: "bias",
					name: "bias",
					type: "number",
					defaultValue: 1
				},
				{
					tfName: "alpha",
					name: "alpha",
					type: "number",
					defaultValue: 1
				},
				{
					tfName: "beta",
					name: "beta",
					type: "number",
					defaultValue: .5
				}
			]
		},
		{
			tfOpName: "Softmax",
			category: "normalization",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}]
		},
		{
			tfOpName: "LogSoftmax",
			category: "normalization",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}]
		}
	];
})), PO = /* @__PURE__ */ n({ json: () => FO }), FO, IO = e((() => {
	FO = [
		{
			tfOpName: "Bincount",
			category: "reduction",
			inputs: [
				{
					start: 0,
					name: "x",
					type: "tensor"
				},
				{
					start: 1,
					name: "size",
					type: "number"
				},
				{
					start: 2,
					name: "weights",
					type: "tensor"
				}
			]
		},
		{
			tfOpName: "DenseBincount",
			category: "reduction",
			inputs: [
				{
					start: 0,
					name: "x",
					type: "tensor"
				},
				{
					start: 1,
					name: "size",
					type: "number"
				},
				{
					start: 2,
					name: "weights",
					type: "tensor"
				}
			],
			attrs: [{
				tfName: "binary_output",
				name: "binaryOutput",
				type: "bool"
			}]
		},
		{
			tfOpName: "Max",
			category: "reduction",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "axis",
				type: "number[]"
			}],
			attrs: [{
				tfName: "keep_dims",
				name: "keepDims",
				type: "bool"
			}]
		},
		{
			tfOpName: "Mean",
			category: "reduction",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "axis",
				type: "number[]"
			}],
			attrs: [{
				tfName: "keep_dims",
				name: "keepDims",
				type: "bool"
			}]
		},
		{
			tfOpName: "Min",
			category: "reduction",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "axis",
				type: "number[]"
			}],
			attrs: [{
				tfName: "keep_dims",
				name: "keepDims",
				type: "bool"
			}]
		},
		{
			tfOpName: "Sum",
			category: "reduction",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "axis",
				type: "number[]"
			}],
			attrs: [{
				tfName: "keep_dims",
				name: "keepDims",
				type: "bool"
			}]
		},
		{
			tfOpName: "All",
			category: "reduction",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "axis",
				type: "number[]"
			}],
			attrs: [{
				tfName: "keep_dims",
				name: "keepDims",
				type: "bool"
			}]
		},
		{
			tfOpName: "Any",
			category: "reduction",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "axis",
				type: "number[]"
			}],
			attrs: [{
				tfName: "keep_dims",
				name: "keepDims",
				type: "bool"
			}]
		},
		{
			tfOpName: "ArgMax",
			category: "reduction",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "axis",
				type: "number"
			}]
		},
		{
			tfOpName: "ArgMin",
			category: "reduction",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "axis",
				type: "number"
			}]
		},
		{
			tfOpName: "Prod",
			category: "reduction",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "axis",
				type: "number[]"
			}],
			attrs: [{
				tfName: "keep_dims",
				name: "keepDims",
				type: "bool"
			}, {
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Cumprod",
			category: "reduction",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "axis",
				type: "number"
			}],
			attrs: [{
				tfName: "exclusive",
				name: "exclusive",
				type: "bool"
			}, {
				tfName: "reverse",
				name: "reverse",
				type: "bool"
			}]
		},
		{
			tfOpName: "Cumsum",
			category: "reduction",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "axis",
				type: "number"
			}],
			attrs: [{
				tfName: "exclusive",
				name: "exclusive",
				type: "bool"
			}, {
				tfName: "reverse",
				name: "reverse",
				type: "bool"
			}]
		}
	];
})), LO = /* @__PURE__ */ n({ json: () => RO }), RO, zO = e((() => {
	RO = [
		{
			tfOpName: "ConcatV2",
			category: "slice_join",
			inputs: [{
				start: 0,
				end: -1,
				name: "tensors",
				type: "tensors"
			}, {
				start: -1,
				name: "axis",
				type: "number"
			}],
			attrs: [{
				tfName: "N",
				name: "n",
				type: "number",
				defaultValue: 2
			}]
		},
		{
			tfOpName: "Concat",
			category: "slice_join",
			inputs: [{
				start: 1,
				end: 0,
				name: "tensors",
				type: "tensors"
			}, {
				start: 0,
				name: "axis",
				type: "number"
			}],
			attrs: [{
				tfName: "N",
				name: "n",
				type: "number",
				defaultValue: 2
			}]
		},
		{
			tfOpName: "GatherV2",
			category: "slice_join",
			inputs: [
				{
					start: 0,
					name: "x",
					type: "tensor"
				},
				{
					start: 1,
					name: "indices",
					type: "tensor"
				},
				{
					start: 2,
					name: "axis",
					type: "number",
					defaultValue: 0
				}
			],
			attrs: [{
				tfName: "batch_dims",
				name: "batchDims",
				type: "number",
				defaultValue: 0
			}]
		},
		{
			tfOpName: "Gather",
			category: "slice_join",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "indices",
				type: "tensor"
			}],
			attrs: [{
				tfName: "validate_indices",
				name: "validateIndices",
				type: "bool",
				notSupported: !0
			}]
		},
		{
			tfOpName: "Reverse",
			category: "slice_join",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "dims",
				type: "bool[]"
			}]
		},
		{
			tfOpName: "ReverseV2",
			category: "slice_join",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "axis",
				type: "number[]"
			}]
		},
		{
			tfOpName: "Slice",
			category: "slice_join",
			inputs: [
				{
					start: 0,
					name: "x",
					type: "tensor"
				},
				{
					start: 1,
					name: "begin",
					type: "number[]"
				},
				{
					start: 2,
					name: "size",
					type: "number[]"
				}
			]
		},
		{
			tfOpName: "StridedSlice",
			category: "slice_join",
			inputs: [
				{
					start: 0,
					name: "x",
					type: "tensor"
				},
				{
					start: 1,
					name: "begin",
					type: "number[]"
				},
				{
					start: 2,
					name: "end",
					type: "number[]"
				},
				{
					start: 3,
					name: "strides",
					type: "number[]"
				}
			],
			attrs: [
				{
					tfName: "begin_mask",
					name: "beginMask",
					type: "number",
					defaultValue: 0
				},
				{
					tfName: "end_mask",
					name: "endMask",
					type: "number",
					defaultValue: 0
				},
				{
					tfName: "new_axis_mask",
					name: "newAxisMask",
					type: "number",
					defaultValue: 0
				},
				{
					tfName: "ellipsis_mask",
					name: "ellipsisMask",
					type: "number",
					defaultValue: 0
				},
				{
					tfName: "shrink_axis_mask",
					name: "shrinkAxisMask",
					type: "number",
					defaultValue: 0
				}
			]
		},
		{
			tfOpName: "Pack",
			category: "slice_join",
			inputs: [{
				start: 0,
				end: 0,
				name: "tensors",
				type: "tensors"
			}],
			attrs: [{
				tfName: "axis",
				name: "axis",
				type: "number",
				defaultValue: 0
			}]
		},
		{
			tfOpName: "Unpack",
			category: "slice_join",
			inputs: [{
				start: 0,
				name: "tensor",
				type: "tensor"
			}],
			attrs: [{
				tfName: "axis",
				name: "axis",
				type: "number",
				defaultValue: 0
			}, {
				tfName: "num",
				name: "num",
				type: "number",
				defaultValue: 0,
				notSupported: !0
			}]
		},
		{
			tfOpName: "Tile",
			category: "slice_join",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "reps",
				type: "number[]"
			}]
		},
		{
			tfOpName: "Split",
			category: "slice_join",
			inputs: [{
				start: 0,
				name: "axis",
				type: "number",
				defaultValue: 0
			}, {
				start: 1,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "num_split",
				name: "numOrSizeSplits",
				type: "number",
				defaultValue: 1
			}]
		},
		{
			tfOpName: "SplitV",
			category: "slice_join",
			inputs: [
				{
					start: 0,
					name: "x",
					type: "tensor"
				},
				{
					start: 1,
					name: "numOrSizeSplits",
					type: "number[]"
				},
				{
					start: 2,
					name: "axis",
					type: "number",
					defaultValue: 0
				}
			]
		},
		{
			tfOpName: "ScatterNd",
			category: "slice_join",
			inputs: [
				{
					start: 0,
					name: "indices",
					type: "tensor"
				},
				{
					start: 1,
					name: "values",
					type: "tensor"
				},
				{
					start: 2,
					name: "shape",
					type: "number[]"
				}
			]
		},
		{
			tfOpName: "GatherNd",
			category: "slice_join",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "indices",
				type: "tensor"
			}]
		},
		{
			tfOpName: "SparseToDense",
			category: "slice_join",
			inputs: [
				{
					start: 0,
					name: "sparseIndices",
					type: "tensor"
				},
				{
					start: 1,
					name: "outputShape",
					type: "number[]"
				},
				{
					start: 2,
					name: "sparseValues",
					type: "tensor"
				},
				{
					start: 3,
					name: "defaultValue",
					type: "tensor"
				}
			],
			attrs: [{
				tfName: "validate_indices",
				name: "validateIndices",
				type: "bool",
				defaultValue: !1,
				notSupported: !0
			}]
		},
		{
			tfOpName: "TensorScatterUpdate",
			category: "slice_join",
			inputs: [
				{
					start: 0,
					name: "tensor",
					type: "tensor"
				},
				{
					start: 1,
					name: "indices",
					type: "tensor"
				},
				{
					start: 2,
					name: "values",
					type: "tensor"
				}
			]
		}
	];
})), BO = /* @__PURE__ */ n({ json: () => VO }), VO, HO = e((() => {
	VO = [
		{
			tfOpName: "SparseFillEmptyRows",
			category: "sparse",
			inputs: [
				{
					start: 0,
					name: "indices",
					type: "tensor"
				},
				{
					start: 1,
					name: "values",
					type: "tensor"
				},
				{
					start: 2,
					name: "denseShape",
					type: "tensor"
				},
				{
					start: 3,
					name: "defaultValue",
					type: "tensor"
				}
			]
		},
		{
			tfOpName: "SparseReshape",
			category: "sparse",
			inputs: [
				{
					start: 0,
					name: "inputIndices",
					type: "tensor"
				},
				{
					start: 1,
					name: "inputShape",
					type: "tensor"
				},
				{
					start: 2,
					name: "newShape",
					type: "tensor"
				}
			],
			attrs: [{
				tfName: "T",
				name: "dtype",
				type: "dtype",
				notSupported: !0
			}]
		},
		{
			tfOpName: "SparseSegmentMean",
			category: "sparse",
			inputs: [
				{
					start: 0,
					name: "data",
					type: "tensor"
				},
				{
					start: 1,
					name: "indices",
					type: "tensor"
				},
				{
					start: 2,
					name: "segmentIds",
					type: "tensor"
				}
			]
		},
		{
			tfOpName: "SparseSegmentSum",
			category: "sparse",
			inputs: [
				{
					start: 0,
					name: "data",
					type: "tensor"
				},
				{
					start: 1,
					name: "indices",
					type: "tensor"
				},
				{
					start: 2,
					name: "segmentIds",
					type: "tensor"
				}
			]
		}
	];
})), UO = /* @__PURE__ */ n({ json: () => WO }), WO, GO = e((() => {
	WO = [
		{
			tfOpName: "FFT",
			category: "spectral",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}]
		},
		{
			tfOpName: "IFFT",
			category: "spectral",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}]
		},
		{
			tfOpName: "RFFT",
			category: "spectral",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "fft_length",
				type: "number",
				notSupported: !0
			}]
		},
		{
			tfOpName: "IRFFT",
			category: "spectral",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "fft_length",
				type: "number",
				notSupported: !0
			}]
		}
	];
})), KO = /* @__PURE__ */ n({ json: () => qO }), qO, JO = e((() => {
	qO = [
		{
			tfOpName: "StaticRegexReplace",
			category: "string",
			inputs: [{
				start: 0,
				name: "input",
				type: "tensor"
			}],
			attrs: [
				{
					tfName: "pattern",
					name: "pattern",
					type: "string"
				},
				{
					tfName: "rewrite",
					name: "rewrite",
					type: "string"
				},
				{
					tfName: "replace_global",
					name: "replaceGlobal",
					type: "bool"
				}
			]
		},
		{
			tfOpName: "StringNGrams",
			category: "string",
			inputs: [{
				start: 0,
				name: "data",
				type: "tensor"
			}, {
				start: 1,
				name: "dataSplits",
				type: "tensor"
			}],
			attrs: [
				{
					tfName: "separator",
					name: "separator",
					type: "string"
				},
				{
					tfName: "ngram_widths",
					name: "nGramWidths",
					type: "number[]"
				},
				{
					tfName: "left_pad",
					name: "leftPad",
					type: "string"
				},
				{
					tfName: "right_pad",
					name: "rightPad",
					type: "string"
				},
				{
					tfName: "pad_width",
					name: "padWidth",
					type: "number"
				},
				{
					tfName: "preserve_short_sequences",
					name: "preserveShortSequences",
					type: "bool"
				}
			],
			outputs: ["ngrams", "ngrams_splits"]
		},
		{
			tfOpName: "StringSplit",
			category: "string",
			inputs: [{
				start: 0,
				name: "input",
				type: "tensor"
			}, {
				start: 1,
				name: "delimiter",
				type: "tensor"
			}],
			attrs: [{
				tfName: "skip_empty",
				name: "skipEmpty",
				type: "bool"
			}],
			outputs: [
				"indices",
				"values",
				"shape"
			]
		},
		{
			tfOpName: "StringToHashBucketFast",
			category: "string",
			inputs: [{
				start: 0,
				name: "input",
				type: "tensor"
			}],
			attrs: [{
				tfName: "num_buckets",
				name: "numBuckets",
				type: "number"
			}]
		}
	];
})), YO = /* @__PURE__ */ n({ json: () => XO }), XO, ZO = e((() => {
	XO = [
		{
			tfOpName: "Cast",
			category: "transformation",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "SrcT",
				name: "sdtype",
				type: "dtype",
				notSupported: !0
			}, {
				tfName: "DstT",
				name: "dtype",
				type: "dtype"
			}]
		},
		{
			tfOpName: "ExpandDims",
			category: "transformation",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "axis",
				type: "number"
			}]
		},
		{
			tfOpName: "MirrorPad",
			category: "transformation",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "padding",
				type: "number[]"
			}],
			attrs: [{
				tfName: "mode",
				name: "mode",
				type: "string"
			}]
		},
		{
			tfOpName: "Pad",
			category: "transformation",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "padding",
				type: "number[]"
			}],
			attrs: [{
				tfName: "constant_value",
				name: "constantValue",
				type: "number",
				defaultValue: 0
			}]
		},
		{
			tfOpName: "PadV2",
			category: "transformation",
			inputs: [
				{
					start: 0,
					name: "x",
					type: "tensor"
				},
				{
					start: 1,
					name: "padding",
					type: "number[]"
				},
				{
					start: 2,
					name: "constantValue",
					type: "number",
					defaultValue: 0
				}
			]
		},
		{
			tfOpName: "Reshape",
			category: "transformation",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "shape",
				type: "number[]"
			}]
		},
		{
			tfOpName: "EnsureShape",
			category: "transformation",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "shape",
				type: "number[]"
			}]
		},
		{
			tfOpName: "Squeeze",
			category: "transformation",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "axis",
				tfDeprecatedName: "squeeze_dims",
				name: "axis",
				type: "number[]"
			}]
		},
		{
			tfOpName: "SpaceToBatchND",
			category: "transformation",
			inputs: [
				{
					start: 0,
					name: "x",
					type: "tensor"
				},
				{
					start: 1,
					name: "blockShape",
					type: "number[]"
				},
				{
					start: 2,
					name: "paddings",
					type: "number[]"
				}
			]
		},
		{
			tfOpName: "BatchToSpaceND",
			category: "transformation",
			inputs: [
				{
					start: 0,
					name: "x",
					type: "tensor"
				},
				{
					start: 1,
					name: "blockShape",
					type: "number[]"
				},
				{
					start: 2,
					name: "crops",
					type: "number[]"
				}
			]
		},
		{
			tfOpName: "DepthToSpace",
			category: "transformation",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}],
			attrs: [{
				tfName: "block_size",
				name: "blockSize",
				type: "number"
			}, {
				tfName: "data_format",
				name: "dataFormat",
				type: "string"
			}]
		},
		{
			tfOpName: "BroadcastTo",
			category: "transformation",
			inputs: [{
				start: 0,
				name: "x",
				type: "tensor"
			}, {
				start: 1,
				name: "shape",
				type: "number[]"
			}],
			attrs: []
		},
		{
			tfOpName: "BroadcastArgs",
			category: "transformation",
			inputs: [{
				start: 0,
				name: "s0",
				type: "tensor"
			}, {
				start: 1,
				name: "s1",
				type: "tensor"
			}],
			attrs: []
		}
	];
}));
// node_modules/@tensorflow/tfjs-converter/dist/operations/operation_mapper.js
function QO(e) {
	let t = w().global;
	if (t.atob !== void 0) return t.atob(e);
	if (typeof Buffer < "u") return new Buffer(e, "base64").toString();
	throw Error("Unable to decode base64 in this environment. Missing built-in atob() or Buffer()");
}
function $O(e, t) {
	let n = Array.isArray(e) ? String.fromCharCode.apply(null, e) : QO(e);
	return t ? n : n.toLowerCase();
}
function ek(e, t, n, r = !1) {
	let i = e[t];
	return i == null ? n : $O(i.s, r);
}
function tk(e, t, n) {
	let r = e[t];
	return r ? r.b : n;
}
function nk(e, t, n) {
	let r = e[t] || {}, i = r.i == null ? r.f == null ? n : r.f : r.i;
	return typeof i == "number" ? i : parseInt(i, 10);
}
function rk(e) {
	switch (typeof e == "string" && (e = PD[e]), e) {
		case PD.DT_FLOAT:
		case PD.DT_HALF: return "float32";
		case PD.DT_INT32:
		case PD.DT_INT64:
		case PD.DT_INT8:
		case PD.DT_UINT8: return "int32";
		case PD.DT_BOOL: return "bool";
		case PD.DT_DOUBLE: return "float32";
		case PD.DT_STRING: return "string";
		case PD.DT_COMPLEX64:
		case PD.DT_COMPLEX128: return "complex64";
		default: return null;
	}
}
function ik(e, t, n) {
	let r = e[t];
	return r && r.func ? r.func.name : n;
}
function ak(e, t, n) {
	let r = e[t];
	return r && r.type ? rk(r.type) : n;
}
function ok(e, t, n) {
	let r = e[t];
	return r && r.list && r.list.type ? r.list.type.map((e) => rk(e)) : n;
}
function sk(e) {
	if (!e.unknownRank) return e.dim == null ? [] : e.dim.map((e) => typeof e.size == "number" ? e.size : parseInt(e.size, 10));
}
function ck(e, t, n) {
	let r = e[t];
	return r && r.shape ? sk(r.shape) : n;
}
function lk(e, t, n) {
	let r = e[t];
	return r ? ((r.list.f && r.list.f.length ? r.list.f : r.list.i) || []).map((e) => typeof e == "number" ? e : parseInt(e, 10)) : n;
}
function uk(e, t, n, r = !1) {
	let i = e[t];
	return i && i.list && i.list.s ? i.list.s.map((e) => $O(e, r)) : n;
}
function dk(e, t, n) {
	let r = e[t];
	return r && r.list && r.list.shape ? r.list.shape.map((e) => sk(e)) : n;
}
function fk(e, t, n) {
	let r = e[t];
	return r && r.list && r.list.b ? r.list.b : n;
}
var pk, mk = e((() => {
	MD(), ID(), VD(), $(), ZD(), eO(), rO(), oO(), lO(), fO(), hO(), vO(), xO(), wO(), DO(), AO(), NO(), IO(), zO(), HO(), GO(), JO(), ZO(), pk = class {
		static get Instance() {
			return this._instance ||= new this();
		}
		constructor() {
			let e = [
				YD,
				QD,
				tO,
				iO,
				sO,
				uO,
				pO,
				gO,
				yO,
				SO,
				TO,
				OO,
				jO,
				PO,
				LO,
				BO,
				UO,
				KO,
				YO
			], t = [].concat(...e.map((e) => e.json));
			this.opMappers = t.reduce((e, t) => (e[t.tfOpName] = t, e), {});
		}
		transformGraph(e, t = {}) {
			let n = e.node, r = [], i = [], a = [], o = n.reduce((e, t) => (e[t.name] = this.mapNode(t), t.op.startsWith("Placeholder") ? r.push(e[t.name]) : t.op === "Const" ? i.push(e[t.name]) : (t.input == null || t.input.length === 0) && a.push(e[t.name]), e), {}), s = [], c = [], l = {}, u = {};
			t != null && (l = this.mapSignatureEntries(t.inputs), u = this.mapSignatureEntries(t.outputs));
			let d = Object.keys(o);
			d.forEach((e) => {
				let t = o[e];
				t.inputNames.forEach((e, n) => {
					let [r, , i] = WD(e), a = o[r];
					if (a.outputs != null) {
						let e = a.outputs.indexOf(i);
						if (e !== -1) {
							let i = `${r}:${e}`;
							t.inputNames[n] = i;
						}
					}
					t.inputs.push(a), a.children.push(t);
				});
			}), Object.keys(u).length === 0 ? d.forEach((e) => {
				let t = o[e];
				t.children.length === 0 && c.push(t);
			}) : Object.keys(u).forEach((e) => {
				let [t] = WD(e), n = o[t];
				n != null && (n.signatureKey = u[e], c.push(n));
			}), Object.keys(l).length > 0 ? Object.keys(l).forEach((e) => {
				let [t] = WD(e), n = o[t];
				n && (n.signatureKey = l[e], s.push(n));
			}) : s = r;
			let f = {};
			e.library != null && e.library.function != null && (f = e.library.function.reduce((e, t) => (e[t.signature.name] = this.mapFunction(t), e), {}));
			let p = {
				nodes: o,
				inputs: s,
				outputs: c,
				weights: i,
				placeholders: r,
				signature: t,
				functions: f
			};
			return a.length > 0 && (p.initNodes = a), p;
		}
		mapSignatureEntries(e) {
			return Object.keys(e || {}).reduce((t, n) => (t[e[n].name] = n, t), {});
		}
		mapNode(e) {
			let t = RD(e.op) || this.opMappers[e.op] || {};
			e.attr ??= {};
			let n = {
				name: e.name,
				op: e.op,
				category: t.category,
				inputNames: (e.input || []).map((e) => e.startsWith("^") ? e.slice(1) : e),
				inputs: [],
				children: [],
				inputParams: {},
				attrParams: {},
				rawAttrs: e.attr,
				outputs: t.outputs
			};
			return t.inputs != null && (n.inputParams = t.inputs.reduce((e, t) => (e[t.name] = {
				type: t.type,
				inputIndexStart: t.start,
				inputIndexEnd: t.end
			}, e), {})), t.attrs != null && (n.attrParams = t.attrs.reduce((t, n) => {
				let r = n.type, i;
				switch (n.type) {
					case "string":
						i = ek(e.attr, n.tfName, n.defaultValue), i === void 0 && n.tfDeprecatedName && (i = ek(e.attr, n.tfDeprecatedName, n.defaultValue));
						break;
					case "string[]":
						i = uk(e.attr, n.tfName, n.defaultValue), i === void 0 && n.tfDeprecatedName && (i = uk(e.attr, n.tfDeprecatedName, n.defaultValue));
						break;
					case "number":
						i = nk(e.attr, n.tfName, n.defaultValue || 0), i === void 0 && n.tfDeprecatedName && (i = nk(e.attr, n.tfDeprecatedName, n.defaultValue));
						break;
					case "number[]":
						i = lk(e.attr, n.tfName, n.defaultValue), i === void 0 && n.tfDeprecatedName && (i = lk(e.attr, n.tfDeprecatedName, n.defaultValue));
						break;
					case "bool":
						i = tk(e.attr, n.tfName, n.defaultValue), i === void 0 && n.tfDeprecatedName && (i = tk(e.attr, n.tfDeprecatedName, n.defaultValue));
						break;
					case "bool[]":
						i = fk(e.attr, n.tfName, n.defaultValue), i === void 0 && n.tfDeprecatedName && (i = fk(e.attr, n.tfDeprecatedName, n.defaultValue));
						break;
					case "shape":
						i = ck(e.attr, n.tfName, n.defaultValue), i === void 0 && n.tfDeprecatedName && (i = ck(e.attr, n.tfDeprecatedName, n.defaultValue));
						break;
					case "shape[]":
						i = dk(e.attr, n.tfName, n.defaultValue), i === void 0 && n.tfDeprecatedName && (i = dk(e.attr, n.tfDeprecatedName, n.defaultValue));
						break;
					case "dtype":
						i = ak(e.attr, n.tfName, n.defaultValue), i === void 0 && n.tfDeprecatedName && (i = ak(e.attr, n.tfDeprecatedName, n.defaultValue));
						break;
					case "dtype[]":
						i = ok(e.attr, n.tfName, n.defaultValue), i === void 0 && n.tfDeprecatedName && (i = ok(e.attr, n.tfDeprecatedName, n.defaultValue));
						break;
					case "func":
						i = ik(e.attr, n.tfName, n.defaultValue), i === void 0 && n.tfDeprecatedName && (i = ik(e.attr, n.tfDeprecatedName, n.defaultValue));
						break;
					case "tensor":
					case "tensors": break;
					default: throw Error(`Unsupported param type: ${n.type} for op: ${e.op}`);
				}
				return t[n.name] = {
					value: i,
					type: r
				}, t;
			}, {})), n;
		}
		mapFunction(e) {
			let t = e.nodeDef, n = [], r = [], i = {};
			t != null && (i = t.reduce((e, t) => (e[t.name] = this.mapNode(t), t.op === "Const" && r.push(e[t.name]), e), {}));
			let a = [], o = [];
			e.signature.inputArg.forEach((e) => {
				let [t] = WD(e.name), n = {
					name: t,
					op: "Placeholder",
					inputs: [],
					inputNames: [],
					category: "graph",
					inputParams: {},
					attrParams: { dtype: {
						value: rk(e.type),
						type: "dtype"
					} },
					children: []
				};
				n.signatureKey = e.name, a.push(n), i[t] = n;
			}), Object.keys(i).forEach((e) => {
				let t = i[e];
				t.inputNames.forEach((e, n) => {
					let [r, , a] = WD(e), o = i[r];
					if (o.outputs != null) {
						let e = o.outputs.indexOf(a);
						if (e !== -1) {
							let i = `${r}:${e}`;
							t.inputNames[n] = i;
						}
					}
					t.inputs.push(o), o.children.push(t);
				});
			});
			let s = e.ret;
			e.signature.outputArg.forEach((e) => {
				let [t, n] = WD(s[e.name]), r = i[t];
				r != null && (r.defaultOutput = n, o.push(r));
			});
			let c = this.mapArgsToSignature(e);
			return {
				nodes: i,
				inputs: a,
				outputs: o,
				weights: r,
				placeholders: n,
				signature: c
			};
		}
		mapArgsToSignature(e) {
			return {
				methodName: e.signature.name,
				inputs: e.signature.inputArg.reduce((e, t) => (e[t.name] = this.mapArgToTensorInfo(t), e), {}),
				outputs: e.signature.outputArg.reduce((t, n) => (t[n.name] = this.mapArgToTensorInfo(n, e.ret), t), {})
			};
		}
		mapArgToTensorInfo(e, t) {
			let n = e.name;
			return t != null && (n = t[n]), {
				name: n,
				dtype: e.type
			};
		}
	};
})), hk, gk = e((() => {
	$(), mk(), hk = class {
		constructor(e, t, n) {
			this.node = e, this.tensorMap = t, this.context = n, this.inputs = [], this.attrs = {}, this.inputs = e.inputNames.map((e) => this.getInput(e)), e.rawAttrs != null && (this.attrs = Object.keys(e.rawAttrs).reduce((e, t) => (e[t] = this.getAttr(t), e), {}));
		}
		getInput(e) {
			return HD(e, this.tensorMap, this.context);
		}
		getAttr(e, t) {
			let n = this.node.rawAttrs[e];
			if (n.tensor != null) return HD(e, this.tensorMap, this.context);
			if (n.i != null || n.f != null) return nk(this.node.rawAttrs, e, t);
			if (n.s != null) return ek(this.node.rawAttrs, e, t);
			if (n.b != null) return tk(this.node.rawAttrs, e, t);
			if (n.shape != null) return ck(this.node.rawAttrs, e, t);
			if (n.type != null) return ak(this.node.rawAttrs, e, t);
			if (n.list != null) {
				if (n.list.i != null || n.list.f != null) return lk(this.node.rawAttrs, e, t);
				if (n.list.s != null) return uk(this.node.rawAttrs, e, t);
				if (n.list.shape != null) return dk(this.node.rawAttrs, e, t);
				if (n.list.b != null) return fk(this.node.rawAttrs, e, t);
				if (n.list.type != null) return ok(this.node.rawAttrs, e, t);
			}
			return t;
		}
	};
})), _k = /* @__PURE__ */ n({
	OP_SCOPE_SUFFIX: () => po,
	abs: () => Mc,
	acos: () => Fc,
	acosh: () => Rc,
	add: () => z,
	addN: () => Vc,
	all: () => Wc,
	any: () => qc,
	argMax: () => Xc,
	argMin: () => $c,
	asin: () => nl,
	asinh: () => al,
	atan: () => cl,
	atan2: () => dl,
	atanh: () => ml,
	avgPool: () => Rl,
	avgPool3d: () => Vl,
	basicLSTMCell: () => ru,
	batchNorm: () => du,
	batchNorm2d: () => mu,
	batchNorm3d: () => _u,
	batchNorm4d: () => bu,
	batchToSpaceND: () => ou,
	bincount: () => Cu,
	bitwiseAnd: () => Eu,
	booleanMaskAsync: () => fb,
	broadcastArgs: () => ku,
	broadcastTo: () => Mu,
	buffer: () => mc,
	cast: () => R,
	ceil: () => Fu,
	clipByValue: () => Bu,
	clone: () => yc,
	complex: () => ho,
	concat: () => Wl,
	concat1d: () => Uu,
	concat2d: () => Ku,
	concat3d: () => Yu,
	concat4d: () => Qu,
	conv1d: () => id,
	conv2d: () => td,
	conv2dTranspose: () => ud,
	conv3d: () => pd,
	conv3dTranspose: () => yd,
	cos: () => Sd,
	cosh: () => Td,
	cosineWindow: () => Lb,
	cumprod: () => Od,
	cumsum: () => jd,
	denseBincount: () => Pd,
	depthToSpace: () => Ld,
	depthwiseConv2d: () => Bd,
	diag: () => Ud,
	dilation2d: () => Kd,
	div: () => V,
	divNoNan: () => lf,
	dot: () => ff,
	dropout: () => Pb,
	einsum: () => hf,
	elu: () => vf,
	enclosingPowerOfTwo: () => Ib,
	ensureShape: () => xf,
	equal: () => $d,
	erf: () => wf,
	euclideanNorm: () => ip,
	exp: () => sp,
	expandDims: () => up,
	expm1: () => pp,
	eye: () => yp,
	fft: () => Uv,
	fill: () => Lu,
	floor: () => Sp,
	floorDiv: () => Ec,
	fused: () => dx,
	gather: () => Tp,
	gatherND: () => kb,
	greater: () => Op,
	greaterEqual: () => jp,
	ifft: () => Kv,
	imag: () => Pp,
	image: () => GC,
	inTopKAsync: () => Bb,
	irfft: () => Yv,
	isFinite: () => Lp,
	isInf: () => Bp,
	isNaN: () => Up,
	leakyRelu: () => Kp,
	less: () => Yp,
	lessEqual: () => Qp,
	linalg: () => KC,
	linspace: () => em,
	localResponseNormalization: () => rm,
	log: () => om,
	log1p: () => lm,
	logSigmoid: () => Em,
	logSoftmax: () => jm,
	logSumExp: () => Pm,
	logicalAnd: () => Lm,
	logicalNot: () => Bm,
	logicalOr: () => Um,
	logicalXor: () => Km,
	losses: () => qC,
	lowerBound: () => Qm,
	matMul: () => K,
	max: () => If,
	maxPool: () => th,
	maxPool3d: () => ih,
	maxPoolWithArgmax: () => sh,
	maximum: () => uh,
	mean: () => ph,
	meshgrid: () => yh,
	min: () => zf,
	minimum: () => Sh,
	mirrorPad: () => Th,
	mod: () => Oh,
	moments: () => jh,
	movingAverage: () => vb,
	mul: () => H,
	multiRNNCell: () => Ph,
	multinomial: () => Lh,
	neg: () => bm,
	norm: () => tp,
	notEqual: () => Bh,
	oneHot: () => Uh,
	ones: () => _h,
	onesLike: () => Kh,
	op: () => F,
	outerProduct: () => Yh,
	pad: () => Qh,
	pad1d: () => tg,
	pad2d: () => ig,
	pad3d: () => sg,
	pad4d: () => ug,
	pool: () => vg,
	pow: () => Hf,
	prelu: () => xg,
	print: () => xc,
	prod: () => wg,
	raggedGather: () => Dg,
	raggedRange: () => Ag,
	raggedTensorToTensor: () => Ng,
	rand: () => Ig,
	randomGamma: () => m_,
	randomNormal: () => __,
	randomStandardNormal: () => b_,
	randomUniform: () => C_,
	randomUniformInt: () => E_,
	range: () => O_,
	real: () => j_,
	reciprocal: () => P_,
	relu: () => L_,
	relu6: () => B_,
	reshape: () => W,
	reverse: () => U_,
	reverse1d: () => K_,
	reverse2d: () => Y_,
	reverse3d: () => Q_,
	reverse4d: () => tv,
	rfft: () => ty,
	round: () => iv,
	rsqrt: () => sv,
	scalar: () => Y,
	scatterND: () => xb,
	searchSorted: () => Xm,
	selu: () => uv,
	separableConv2d: () => pv,
	setdiff1dAsync: () => gv,
	sigmoid: () => Yl,
	sign: () => yv,
	signal: () => WC,
	sin: () => Sv,
	sinh: () => Tv,
	slice: () => q,
	slice1d: () => Ov,
	slice2d: () => jv,
	slice3d: () => Pv,
	slice4d: () => Lv,
	softmax: () => Bv,
	softplus: () => Cm,
	spaceToBatchND: () => pg,
	sparse: () => JC,
	sparseToDense: () => Eb,
	spectral: () => UC,
	split: () => Qv,
	sqrt: () => Kf,
	square: () => Yf,
	squaredDifference: () => iy,
	squeeze: () => sy,
	stack: () => uy,
	step: () => py,
	stridedSlice: () => gy,
	string: () => YC,
	sub: () => Z,
	sum: () => X,
	tan: () => yy,
	tanh: () => eu,
	tensor: () => yo,
	tensor1d: () => xy,
	tensor2d: () => Cy,
	tensor3d: () => Ty,
	tensor4d: () => Dy,
	tensor5d: () => ky,
	tensor6d: () => jy,
	tensorScatterUpdate: () => zy,
	tile: () => gp,
	topk: () => Hy,
	transpose: () => hb,
	truncatedNormal: () => Gy,
	unique: () => Jy,
	unsortedSegmentSum: () => Zy,
	unstack: () => eb,
	upperBound: () => nb,
	variable: () => ib,
	where: () => nf,
	whereAsync: () => lb,
	zeros: () => hh,
	zerosLike: () => of
}), vk = e((() => {
	XC();
})), yk, bk = e((() => {
	vk(), $(), yk = (e, t, n, r = _k) => {
		switch (e.op) {
			case "BiasAdd":
			case "AddV2":
			case "Add": return [r.add(Q("a", e, t, n), Q("b", e, t, n))];
			case "AddN": return [r.addN(Q("tensors", e, t, n))];
			case "FloorMod":
			case "Mod": return [r.mod(Q("a", e, t, n), Q("b", e, t, n))];
			case "Mul": return [r.mul(Q("a", e, t, n), Q("b", e, t, n))];
			case "RealDiv":
			case "Div": return [r.div(Q("a", e, t, n), Q("b", e, t, n))];
			case "DivNoNan": return [r.divNoNan(Q("a", e, t, n), Q("b", e, t, n))];
			case "FloorDiv": return [r.floorDiv(Q("a", e, t, n), Q("b", e, t, n))];
			case "Sub": return [r.sub(Q("a", e, t, n), Q("b", e, t, n))];
			case "Minimum": return [r.minimum(Q("a", e, t, n), Q("b", e, t, n))];
			case "Maximum": return [r.maximum(Q("a", e, t, n), Q("b", e, t, n))];
			case "Pow": return [r.pow(Q("a", e, t, n), Q("b", e, t, n))];
			case "SquaredDifference": return [r.squaredDifference(Q("a", e, t, n), Q("b", e, t, n))];
			default: throw TypeError(`Node type ${e.op} is not implemented`);
		}
	};
})), xk, Sk = e((() => {
	vk(), $(), xk = (e, t, n, r = _k) => {
		switch (e.op) {
			case "Abs":
			case "ComplexAbs": return [r.abs(Q("x", e, t, n))];
			case "Acos": return [r.acos(Q("x", e, t, n))];
			case "Acosh": return [r.acosh(Q("x", e, t, n))];
			case "Asin": return [r.asin(Q("x", e, t, n))];
			case "Asinh": return [r.asinh(Q("x", e, t, n))];
			case "Atan": return [r.atan(Q("x", e, t, n))];
			case "Atan2": return [r.atan2(Q("x", e, t, n), Q("y", e, t, n))];
			case "Atanh": return [r.atanh(Q("x", e, t, n))];
			case "Ceil": return [r.ceil(Q("x", e, t, n))];
			case "Complex": return [r.complex(Q("real", e, t, n), Q("imag", e, t, n))];
			case "Cos": return [r.cos(Q("x", e, t, n))];
			case "Cosh": return [r.cosh(Q("x", e, t, n))];
			case "Elu": return [r.elu(Q("x", e, t, n))];
			case "Erf": return [r.erf(Q("x", e, t, n))];
			case "Exp": return [r.exp(Q("x", e, t, n))];
			case "Expm1": return [r.expm1(Q("x", e, t, n))];
			case "Floor": return [r.floor(Q("x", e, t, n))];
			case "Log": return [r.log(Q("x", e, t, n))];
			case "Log1p": return [r.log1p(Q("x", e, t, n))];
			case "Imag": return [r.imag(Q("x", e, t, n))];
			case "Neg": return [r.neg(Q("x", e, t, n))];
			case "Reciprocal": return [r.reciprocal(Q("x", e, t, n))];
			case "Real": return [r.real(Q("x", e, t, n))];
			case "Relu": return [r.relu(Q("x", e, t, n))];
			case "Round": return [r.round(Q("x", e, t, n))];
			case "Selu": return [r.selu(Q("x", e, t, n))];
			case "Sigmoid": return [r.sigmoid(Q("x", e, t, n))];
			case "Sin": return [r.sin(Q("x", e, t, n))];
			case "Sign": return [r.sign(Q("x", e, t, n))];
			case "Sinh": return [r.sinh(Q("x", e, t, n))];
			case "Softplus": return [r.softplus(Q("x", e, t, n))];
			case "Sqrt": return [r.sqrt(Q("x", e, t, n))];
			case "Square": return [r.square(Q("x", e, t, n))];
			case "Tanh": return [r.tanh(Q("x", e, t, n))];
			case "Tan": return [r.tan(Q("x", e, t, n))];
			case "ClipByValue": return [r.clipByValue(Q("x", e, t, n), Q("clipValueMin", e, t, n), Q("clipValueMax", e, t, n))];
			case "Relu6": return [r.relu6(Q("x", e, t, n))];
			case "Rsqrt": return [r.rsqrt(HD(e.inputNames[0], t, n))];
			case "LeakyRelu": return [r.leakyRelu(Q("x", e, t, n), Q("alpha", e, t, n))];
			case "Prelu": return [r.prelu(Q("x", e, t, n), Q("alpha", e, t, n))];
			case "IsNan": return [r.isNaN(HD(e.inputNames[0], t, n))];
			case "IsInf": return [r.isInf(HD(e.inputNames[0], t, n))];
			case "IsFinite": return [r.isFinite(HD(e.inputNames[0], t, n))];
			default: throw TypeError(`Node type ${e.op} is not implemented`);
		}
	};
}));
// node_modules/@tensorflow/tfjs-converter/dist/executor/tensor_utils.js
function Ck(e, t, n = "") {
	if (typeof e != "number" && typeof t != "number") {
		v(e.length === t.length, () => n + ` Shapes ${e} and ${t} must match`);
		for (let r = 0; r < e.length; r++) {
			let i = e[r], a = t[r];
			v(i < 0 || a < 0 || i === a, () => n + ` Shapes ${e} and ${t} must match`);
		}
	}
}
function wk(e) {
	return !(typeof e == "number" || e.some((e) => e < 0));
}
function Tk(e, t, n) {
	let r = Ek(e, n), i = !wk(r);
	if (i && t.length === 0) throw Error(`Tried to calculate elements of an empty list with non-fully-defined elementShape: ${r}`);
	if (i && t.forEach((e) => {
		r = Ek(e.shape, r);
	}), !wk(r)) throw Error(`Non-fully-defined elementShape: ${r}`);
	return r;
}
function Ek(e, t) {
	if (typeof e == "number") return t;
	if (typeof t == "number") return e;
	if (e.length !== t.length) throw Error(`Incompatible ranks during merge: ${e} vs. ${t}`);
	let n = [];
	for (let r = 0; r < e.length; ++r) {
		let i = e[r], a = t[r];
		if (i >= 0 && a >= 0 && i !== a) throw Error(`Incompatible shape during merge: ${e} vs. ${t}`);
		n[r] = i >= 0 ? i : a;
	}
	return n;
}
var Dk = e((() => {
	MD();
})), Ok, kk = e((() => {
	MD(), Dk(), Ok = class {
		constructor(e, t, n, r, i, a, o) {
			this.name = e, this.dtype = t, this.maxSize = n, this.elementShape = r, this.identicalElementShapes = i, this.dynamicSize = a, this.clearAfterRead = o, this.tensors = [], this.closed_ = !1, this.idTensor = Y(0), Fo(this.idTensor);
		}
		get id() {
			return this.idTensor.id;
		}
		get closed() {
			return this.closed_;
		}
		clearAndClose(e) {
			this.tensors.forEach((t) => {
				e != null && e.has(t.tensor.id) || t.tensor.dispose();
			}), this.tensors = [], this.closed_ = !0, this.idTensor.dispose();
		}
		size() {
			return this.tensors.length;
		}
		read(e) {
			if (this.closed_) throw Error(`TensorArray ${this.name} has already been closed.`);
			if (e < 0 || e >= this.size()) throw Error(`Tried to read from index ${e}, but array size is: ${this.size()}`);
			let t = this.tensors[e];
			if (t.cleared) throw Error(`TensorArray ${this.name}: Could not read index ${e} twice because it was cleared after a previous read (perhaps try setting clear_after_read = false?).`);
			return this.clearAfterRead && (t.cleared = !0), t.read = !0, t.tensor;
		}
		readMany(e) {
			return e.map((e) => this.read(e));
		}
		write(e, t) {
			if (this.closed_) throw Error(`TensorArray ${this.name} has already been closed.`);
			if (e < 0 || !this.dynamicSize && e >= this.maxSize) throw Error(`Tried to write to index ${e}, but array is not resizeable and size is: ${this.maxSize}`);
			let n = this.tensors[e] || {};
			if (t.dtype !== this.dtype) throw Error(`TensorArray ${this.name}: Could not write to TensorArray index ${e},
          because the value dtype is ${t.dtype}, but TensorArray dtype is ${this.dtype}.`);
			if (this.size() === 0 && (this.elementShape == null || this.elementShape.length === 0) && (this.elementShape = t.shape), Ck(this.elementShape, t.shape, `TensorArray ${this.name}: Could not write to TensorArray index ${e}.`), n.read) throw Error(`TensorArray ${this.name}: Could not write to TensorArray index ${e}, because it has already been read.`);
			if (n.written) throw Error(`TensorArray ${this.name}: Could not write to TensorArray index ${e}, because it has already been written.`);
			n.tensor = t, Fo(t), n.written = !0, this.tensors[e] = n;
		}
		writeMany(e, t) {
			if (e.length !== t.length) throw Error(`TensorArray ${this.name}: could not write multiple tensors,because the index size: ${e.length} is not the same as tensors size: ${t.length}.`);
			e.forEach((e, n) => this.write(e, t[n]));
		}
		gather(e, t) {
			if (t && t !== this.dtype) throw Error(`TensorArray dtype is ${this.dtype} but gather requested dtype ${t}`);
			if (e) e = e.slice(0, this.size());
			else {
				e = [];
				for (let t = 0; t < this.size(); t++) e.push(t);
			}
			if (e.length === 0) return yo([], [0].concat(this.elementShape));
			let n = this.readMany(e);
			return Ck(this.elementShape, n[0].shape, "TensorArray shape mismatch: "), uy(n, 0);
		}
		concat(e) {
			if (e && e !== this.dtype) throw Error(`TensorArray dtype is ${this.dtype} but concat requested dtype ${e}`);
			if (this.size() === 0) return yo([], [0].concat(this.elementShape));
			let t = [];
			for (let e = 0; e < this.size(); e++) t.push(e);
			let n = this.readMany(t);
			return Ck(this.elementShape, n[0].shape, `TensorArray shape mismatch: tensor array shape (${this.elementShape}) vs first tensor shape (${n[0].shape})`), Wl(n, 0);
		}
		scatter(e, t) {
			if (t.dtype !== this.dtype) throw Error(`TensorArray dtype is ${this.dtype} but tensor has dtype ${t.dtype}`);
			if (e.length !== t.shape[0]) throw Error(`Expected len(indices) == tensor.shape[0], but saw: ${e.length} vs. ${t.shape[0]}`);
			let n = Math.max(...e);
			if (!this.dynamicSize && n >= this.maxSize) throw Error(`Max index must be < array size (${n}  vs. ${this.maxSize})`);
			this.writeMany(e, eb(t, 0));
		}
		split(e, t) {
			if (t.dtype !== this.dtype) throw Error(`TensorArray dtype is ${this.dtype} but tensor has dtype ${t.dtype}`);
			let n = 0, r = e.map((e) => (n += e, n));
			if (n !== t.shape[0]) throw Error(`Expected sum of lengths to be equal to
          tensor.shape[0], but sum of lengths is
        ${n}, and tensor's shape is: ${t.shape}`);
			if (!this.dynamicSize && e.length !== this.maxSize) throw Error(`TensorArray's size is not equal to the size of lengths (${this.maxSize} vs. ${e.length}), and the TensorArray is not marked as dynamically resizeable`);
			let i = n === 0 ? 0 : t.size / n, a = [];
			L(() => {
				t = W(t, [
					1,
					n,
					i
				]);
				for (let n = 0; n < e.length; ++n) {
					let o = [
						0,
						n === 0 ? 0 : r[n - 1],
						0
					], s = [
						1,
						e[n],
						i
					];
					a[n] = W(q(t, o, s), this.elementShape);
				}
				return a;
			});
			let o = [];
			for (let t = 0; t < e.length; t++) o[t] = t;
			this.writeMany(o, a);
		}
	};
}));
// node_modules/@tensorflow/tfjs-converter/dist/executor/tensor_list.js
function Ak(e, t, n) {
	let r = e.dtype;
	if (e.shape.length < 1) throw Error(`Tensor must be at least a vector, but saw shape: ${e.shape}`);
	if (e.dtype !== n) throw Error(`Invalid data types; op elements ${e.dtype}, but list elements ${n}`);
	Ck(e.shape.slice(1), t, "TensorList shape mismatch: ");
	let i = eb(e);
	return new Pk(i, t, r);
}
function jk(e, t, n, r) {
	return new Pk([], e, t, r);
}
function Mk(e, t, n, r) {
	if (t.length !== e.shape[0]) throw Error(`Expected len(indices) == tensor.shape[0], but saw: ${t.length} vs. ${e.shape[0]}`);
	let i = Math.max(...t);
	if (r != null && r !== -1 && i >= r) throw Error(`Max index must be < array size (${i}  vs. ${r})`);
	let a = new Pk([], n, e.dtype, r), o = eb(e, 0);
	return t.forEach((e, t) => {
		a.setItem(e, o[t]);
	}), a;
}
function Nk(e, t, n) {
	let r = 0, i = t.map((e) => (r += e, r));
	if (r !== e.shape[0]) throw Error(`Expected sum of lengths to be equal to
          tensor.shape[0], but sum of lengths is
        ${r}, and tensor's shape is: ${e.shape}`);
	let a = Ek(e.shape.slice(1), n), o = r === 0 ? 0 : e.size / r, s = L(() => {
		let n = [];
		e = W(e, [
			1,
			r,
			o
		]);
		for (let r = 0; r < t.length; ++r) {
			let s = [
				0,
				r === 0 ? 0 : i[r - 1],
				0
			], c = [
				1,
				t[r],
				o
			];
			n[r] = W(q(e, s, c), a);
		}
		return e.dispose(), n;
	}), c = new Pk([], n, e.dtype, t.length);
	for (let e = 0; e < s.length; e++) c.setItem(e, s[e]);
	return c;
}
var Pk, Fk = e((() => {
	MD(), Dk(), Pk = class e {
		get id() {
			return this.idTensor.id;
		}
		constructor(e, t, n, r = -1) {
			this.tensors = e, this.elementShape = t, this.elementDtype = n, e?.forEach((e) => {
				if (n !== e.dtype) throw Error(`Invalid data types; op elements ${n}, but list elements ${e.dtype}`);
				Ck(t, e.shape, "TensorList shape mismatch: "), Fo(e);
			}), this.idTensor = Y(0), this.maxNumElements = r, Fo(this.idTensor);
		}
		copy() {
			return new e([...this.tensors], this.elementShape, this.elementDtype);
		}
		clearAndClose(e) {
			this.tensors.forEach((t) => {
				e != null && e.has(t.id) || t.dispose();
			}), this.tensors.length = 0, this.idTensor.dispose();
		}
		size() {
			return this.tensors.length;
		}
		stack(e, t, n = -1) {
			if (t !== this.elementDtype) throw Error(`Invalid data types; op elements ${t}, but list elements ${this.elementDtype}`);
			if (n !== -1 && this.tensors.length !== n) throw Error(`Operation expected a list with ${n} elements but got a list with ${this.tensors.length} elements.`);
			Ck(e, this.elementShape, "TensorList shape mismatch: ");
			let r = Tk(this.elementShape, this.tensors, e);
			return L(() => {
				let e = this.tensors.map((e) => W(e, r));
				return uy(e, 0);
			});
		}
		popBack(e, t) {
			if (t !== this.elementDtype) throw Error(`Invalid data types; op elements ${t}, but list elements ${this.elementDtype}`);
			if (this.size() === 0) throw Error("Trying to pop from an empty list.");
			let n = Tk(this.elementShape, this.tensors, e), r = this.tensors.pop();
			return r.kept = !1, Ck(r.shape, e, "TensorList shape mismatch: "), W(r, n);
		}
		pushBack(e) {
			if (e.dtype !== this.elementDtype) throw Error(`Invalid data types; op elements ${e.dtype}, but list elements ${this.elementDtype}`);
			if (Ck(e.shape, this.elementShape, "TensorList shape mismatch: "), this.maxNumElements === this.size()) throw Error("Trying to push element into a full list.");
			Fo(e), this.tensors.push(e);
		}
		resize(t) {
			if (t < 0) throw Error(`TensorListResize expects size to be non-negative. Got: ${t}`);
			if (this.maxNumElements !== -1 && t > this.maxNumElements) throw Error(`TensorListResize input size ${t} is greater maxNumElement ${this.maxNumElements}.`);
			let n = new e([], this.elementShape, this.elementDtype, this.maxNumElements);
			n.tensors.length = t;
			for (let e = 0; e < Math.min(this.tensors.length, t); ++e) n.tensors[e] = this.tensors[e];
			return n;
		}
		getItem(e, t, n) {
			if (n !== this.elementDtype) throw Error(`Invalid data types; op elements ${n}, but list elements ${this.elementDtype}`);
			if (e < 0 || e > this.tensors.length) throw Error(`Trying to access element ${e} in a list with ${this.tensors.length} elements.`);
			if (this.tensors[e] == null) throw Error(`element at index ${e} is null.`);
			Ck(this.tensors[e].shape, t, "TensorList shape mismatch: ");
			let r = Tk(this.elementShape, this.tensors, t);
			return W(this.tensors[e], r);
		}
		setItem(e, t) {
			if (t.dtype !== this.elementDtype) throw Error(`Invalid data types; op elements ${t.dtype}, but list elements ${this.elementDtype}`);
			if (e < 0 || this.maxNumElements !== -1 && e >= this.maxNumElements) throw Error(`Trying to set element ${e} in a list with max ${this.maxNumElements} elements.`);
			Ck(this.elementShape, t.shape, "TensorList shape mismatch: "), Fo(t), this.tensors[e] != null && (this.tensors[e].kept = !1), this.tensors[e] = t;
		}
		gather(e, t, n) {
			if (t !== this.elementDtype) throw Error(`Invalid data types; op elements ${t}, but list elements ${this.elementDtype}`);
			Ck(this.elementShape, n, "TensorList shape mismatch: "), e = e.slice(0, this.size());
			let r = Tk(this.elementShape, this.tensors, n);
			return e.length === 0 ? yo([], [0].concat(r)) : L(() => {
				let t = e.map((e) => W(this.tensors[e], r));
				return uy(t, 0);
			});
		}
		concat(e, t) {
			if (e && e !== this.elementDtype) throw Error(`TensorList dtype is ${this.elementDtype} but concat requested dtype ${e}`);
			Ck(this.elementShape, t, "TensorList shape mismatch: ");
			let n = Tk(this.elementShape, this.tensors, t);
			return this.size() === 0 ? yo([], [0].concat(n)) : L(() => {
				let e = this.tensors.map((e) => W(e, n));
				return Wl(e, 0);
			});
		}
	};
})), Ik, Lk = e((() => {
	MD(), kk(), Fk(), $(), Ik = async (e, t, n) => {
		switch (e.op) {
			case "If":
			case "StatelessIf": {
				let r = Q("thenBranch", e, t, n), i = Q("elseBranch", e, t, n), a = Q("cond", e, t, n), o = Q("args", e, t, n);
				return (await a.data())[0] ? n.functionMap[r].executeFunctionAsync(o, n.tensorArrayMap, n.tensorListMap) : n.functionMap[i].executeFunctionAsync(o, n.tensorArrayMap, n.tensorListMap);
			}
			case "While":
			case "StatelessWhile": {
				let r = Q("body", e, t, n), i = Q("cond", e, t, n), a = Q("args", e, t, n), o = await n.functionMap[i].executeFunctionAsync(a, n.tensorArrayMap, n.tensorListMap), s = a.map((e) => e.id), c = await o[0].data();
				o.forEach((e) => {
					!e.kept && s.indexOf(e.id) === -1 && e.dispose();
				});
				let l = a;
				for (; c[0];) {
					let e = l;
					l = await n.functionMap[r].executeFunctionAsync(l, n.tensorArrayMap, n.tensorListMap);
					let t = l.map((e) => e.id);
					e.forEach((e) => {
						!e.kept && s.indexOf(e.id) === -1 && t.indexOf(e.id) === -1 && e.dispose();
					});
					let a = await n.functionMap[i].executeFunctionAsync(l, n.tensorArrayMap, n.tensorListMap);
					c = await a[0].data(), a.forEach((e) => {
						!e.kept && s.indexOf(e.id) === -1 && t.indexOf(e.id) === -1 && e.dispose();
					});
				}
				return l;
			}
			case "LoopCond": return [JD(Q("pred", e, t, n))];
			case "Switch": {
				let r = Q("pred", e, t, n), i = Q("data", e, t, n);
				return i.kept || (i = JD(i)), (await r.data())[0] ? [void 0, i] : [i, void 0];
			}
			case "Merge": {
				let r = e.inputNames.find((e) => HD(e, t, n) !== void 0);
				return r ? [JD(HD(r, t, n))] : void 0;
			}
			case "Enter": {
				let r = Q("frameName", e, t, n), i = Q("tensor", e, t, n);
				return n.enterFrame(r), [JD(i)];
			}
			case "Exit": {
				let r = Q("tensor", e, t, n);
				return n.exitFrame(), [JD(r)];
			}
			case "NextIteration": {
				let r = Q("tensor", e, t, n);
				return n.nextIteration(), [JD(r)];
			}
			case "TensorArrayV3": {
				let r = Q("size", e, t, n), i = Q("dtype", e, t, n), a = Q("elementShape", e, t, n), o = Q("dynamicSize", e, t, n), s = Q("clearAfterRead", e, t, n), c = Q("identicalElementShapes", e, t, n), l = Q("name", e, t, n), u = new Ok(l, i, r, a, c, o, s);
				return n.addTensorArray(u), [u.idTensor, Y(1)];
			}
			case "TensorArrayWriteV3": {
				let r = Q("tensorArrayId", e, t, n), i = Q("index", e, t, n), a = Q("tensor", e, t, n), o = n.getTensorArray(r.id);
				return o.write(i, a), [o.idTensor];
			}
			case "TensorArrayReadV3": {
				let r = Q("tensorArrayId", e, t, n), i = Q("index", e, t, n);
				return [n.getTensorArray(r.id).read(i)];
			}
			case "TensorArrayGatherV3": {
				let r = Q("tensorArrayId", e, t, n), i = Q("indices", e, t, n), a = Q("dtype", e, t, n);
				return [n.getTensorArray(r.id).gather(i, a)];
			}
			case "TensorArrayScatterV3": {
				let r = Q("tensorArrayId", e, t, n), i = Q("indices", e, t, n), a = Q("tensor", e, t, n), o = n.getTensorArray(r.id);
				return o.scatter(i, a), [o.idTensor];
			}
			case "TensorArrayConcatV3": {
				let r = Q("tensorArrayId", e, t, n), i = n.getTensorArray(r.id), a = Q("dtype", e, t, n);
				return [i.concat(a)];
			}
			case "TensorArraySplitV3": {
				let r = Q("tensorArrayId", e, t, n), i = Q("tensor", e, t, n), a = Q("lengths", e, t, n), o = n.getTensorArray(r.id);
				return o.split(a, i), [o.idTensor];
			}
			case "TensorArraySizeV3": {
				let r = Q("tensorArrayId", e, t, n);
				return [Y(n.getTensorArray(r.id).size(), "int32")];
			}
			case "TensorArrayCloseV3": {
				let r = Q("tensorArrayId", e, t, n), i = n.getTensorArray(r.id);
				return i.clearAndClose(), [i.idTensor];
			}
			case "TensorListSetItem": {
				let r = Q("tensorListId", e, t, n), i = Q("index", e, t, n), a = Q("tensor", e, t, n), o = n.getTensorList(r.id);
				return o.setItem(i, a), [o.idTensor];
			}
			case "TensorListGetItem": {
				let r = Q("tensorListId", e, t, n), i = Q("index", e, t, n), a = Q("elementShape", e, t, n), o = Q("elementDType", e, t, n);
				return [n.getTensorList(r.id).getItem(i, a, o)];
			}
			case "TensorListScatterV2":
			case "TensorListScatter": {
				let r = Q("indices", e, t, n), i = Mk(Q("tensor", e, t, n), r, Q("elementShape", e, t, n), Q("numElements", e, t, n));
				return n.addTensorList(i), [i.idTensor];
			}
			case "TensorListReserve":
			case "EmptyTensorList": {
				let r = Q("elementShape", e, t, n), i = Q("elementDType", e, t, n), a;
				a = e.op === "TensorListReserve" ? "numElements" : "maxNumElements";
				let o = Q(a, e, t, n), s = jk(r, i, o, e.op === "TensorListReserve" ? -1 : o);
				return n.addTensorList(s), [s.idTensor];
			}
			case "TensorListGather": {
				let r = Q("tensorListId", e, t, n), i = Q("indices", e, t, n), a = Q("elementShape", e, t, n), o = Q("elementDType", e, t, n);
				return [n.getTensorList(r.id).gather(i, o, a)];
			}
			case "TensorListStack": {
				let r = Q("tensorListId", e, t, n), i = Q("elementShape", e, t, n), a = Q("elementDType", e, t, n), o = Q("numElements", e, t, n);
				return [n.getTensorList(r.id).stack(i, a, o)];
			}
			case "TensorListFromTensor": {
				let r = Ak(Q("tensor", e, t, n), Q("elementShape", e, t, n), Q("elementDType", e, t, n));
				return n.addTensorList(r), [r.idTensor];
			}
			case "TensorListConcat":
			case "TensorListConcatV2": {
				let r = Q("tensorListId", e, t, n), i = n.getTensorList(r.id), a = Q("dtype", e, t, n), o = Q("elementShape", e, t, n);
				return [i.concat(a, o)];
			}
			case "TensorListPushBack": {
				let r = Q("tensorListId", e, t, n), i = Q("tensor", e, t, n), a = n.getTensorList(r.id);
				return a.pushBack(i), [a.idTensor];
			}
			case "TensorListPopBack": {
				let r = Q("tensorListId", e, t, n), i = Q("elementShape", e, t, n), a = Q("elementDType", e, t, n);
				return [n.getTensorList(r.id).popBack(i, a)];
			}
			case "TensorListSplit": {
				let r = Q("tensor", e, t, n), i = Q("elementShape", e, t, n), a = Nk(r, Q("lengths", e, t, n), i);
				return n.addTensorList(a), [a.idTensor];
			}
			case "TensorListLength": {
				let r = Q("tensorListId", e, t, n);
				return [Y(n.getTensorList(r.id).size(), "int32")];
			}
			case "TensorListResize": {
				let r = Q("tensorListId", e, t, n), i = Q("size", e, t, n), a = n.getTensorList(r.id).resize(i);
				return n.addTensorList(a), [a.idTensor];
			}
			default: throw TypeError(`Node type ${e.op} is not implemented`);
		}
	};
}));
// node_modules/@tensorflow/tfjs-converter/dist/operations/executors/convolution_executor.js
function Rk(e, t, n) {
	let [r, i] = Q("fusedOps", e, t, n), a = r === "biasadd", o = !a, s = i === "prelu", c = r === "fusedbatchnorm", l = Q("numArgs", e, t, n);
	if (a) {
		if (s && l !== 2) throw Error("FusedConv2d and DepthwiseConv2d with BiasAdd and Prelu must have two extra arguments: bias and alpha.");
		if (!s && a && l !== 1) throw Error("FusedConv2d and DepthwiseConv2d with BiasAdd must have one extra argument: bias.");
	}
	if (c) throw Error("FusedConv2d and DepthwiseConv2d with FusedBatchNorm is not supported");
	let u = Q("strides", e, t, n), d = qD(e, t, n), f = Q("dataFormat", e, t, n).toUpperCase(), p = Q("dilations", e, t, n), [m, h] = Q("args", e, t, n);
	o && (h = m, m = void 0);
	let g = Q("leakyreluAlpha", e, t, n);
	return {
		stride: u,
		pad: d,
		dataFormat: f,
		dilations: p,
		biasArg: m,
		preluArg: h,
		activationFunc: i,
		leakyreluAlpha: g
	};
}
var zk, Bk = e((() => {
	vk(), $(), zk = (e, t, n, r = _k) => {
		switch (e.op) {
			case "Conv1D": {
				let i = Q("stride", e, t, n), a = Q("pad", e, t, n), o = Q("dataFormat", e, t, n).toUpperCase(), s = Q("dilation", e, t, n);
				return [r.conv1d(Q("x", e, t, n), Q("filter", e, t, n), i, a, o, s)];
			}
			case "Conv2D": {
				let i = Q("strides", e, t, n), a = qD(e, t, n), o = Q("dataFormat", e, t, n).toUpperCase(), s = Q("dilations", e, t, n);
				return [r.conv2d(Q("x", e, t, n), Q("filter", e, t, n), [i[1], i[2]], a, o, [s[1], s[2]])];
			}
			case "_FusedConv2D": {
				let { stride: i, pad: a, dataFormat: o, dilations: s, biasArg: c, preluArg: l, activationFunc: u, leakyreluAlpha: d } = Rk(e, t, n);
				return [r.fused.conv2d({
					x: Q("x", e, t, n),
					filter: Q("filter", e, t, n),
					strides: [i[1], i[2]],
					pad: a,
					dataFormat: o,
					dilations: [s[1], s[2]],
					bias: c,
					activation: u,
					preluActivationWeights: l,
					leakyreluAlpha: d
				})];
			}
			case "FusedDepthwiseConv2dNative": {
				let { stride: i, pad: a, dataFormat: o, dilations: s, biasArg: c, preluArg: l, activationFunc: u, leakyreluAlpha: d } = Rk(e, t, n);
				return [r.fused.depthwiseConv2d({
					x: Q("x", e, t, n),
					filter: Q("filter", e, t, n),
					strides: [i[1], i[2]],
					pad: a,
					dataFormat: o,
					dilations: [s[1], s[2]],
					bias: c,
					activation: u,
					preluActivationWeights: l,
					leakyreluAlpha: d
				})];
			}
			case "Conv2DBackpropInput":
			case "Conv2dTranspose": {
				let i = Q("outputShape", e, t, n), a = Q("strides", e, t, n), o = qD(e, t, n);
				return [r.conv2dTranspose(Q("x", e, t, n), Q("filter", e, t, n), i, [a[1], a[2]], o)];
			}
			case "DepthwiseConv2dNative":
			case "DepthwiseConv2d": {
				let i = Q("strides", e, t, n), a = qD(e, t, n), o = Q("dilations", e, t, n), s = Q("dataFormat", e, t, n).toUpperCase();
				return [r.depthwiseConv2d(Q("input", e, t, n), Q("filter", e, t, n), [i[1], i[2]], a, s, [o[1], o[2]])];
			}
			case "Conv3D": {
				let i = Q("strides", e, t, n), a = Q("pad", e, t, n), o = Q("dataFormat", e, t, n).toUpperCase(), s = Q("dilations", e, t, n);
				return [r.conv3d(Q("x", e, t, n), Q("filter", e, t, n), [
					i[1],
					i[2],
					i[3]
				], a, o, [
					s[1],
					s[2],
					s[3]
				])];
			}
			case "AvgPool": {
				let i = Q("strides", e, t, n), a = Q("pad", e, t, n), o = Q("kernelSize", e, t, n);
				return [r.avgPool(Q("x", e, t, n), [o[1], o[2]], [i[1], i[2]], a)];
			}
			case "MaxPool": {
				let i = Q("strides", e, t, n), a = Q("pad", e, t, n), o = Q("kernelSize", e, t, n);
				return [r.maxPool(Q("x", e, t, n), [o[1], o[2]], [i[1], i[2]], a)];
			}
			case "MaxPoolWithArgmax": {
				let i = Q("strides", e, t, n), a = Q("pad", e, t, n), o = Q("kernelSize", e, t, n), s = Q("includeBatchInIndex", e, t, n), { result: c, indexes: l } = r.maxPoolWithArgmax(Q("x", e, t, n), [o[1], o[2]], [i[1], i[2]], a, s);
				return [c, l];
			}
			case "AvgPool3D": {
				let i = Q("strides", e, t, n), a = Q("pad", e, t, n), o = Q("kernelSize", e, t, n);
				return [r.avgPool3d(Q("x", e, t, n), [
					o[1],
					o[2],
					o[3]
				], [
					i[1],
					i[2],
					i[3]
				], a)];
			}
			case "MaxPool3D": {
				let i = Q("strides", e, t, n), a = Q("pad", e, t, n), o = Q("kernelSize", e, t, n);
				return [r.maxPool3d(Q("x", e, t, n), [
					o[1],
					o[2],
					o[3]
				], [
					i[1],
					i[2],
					i[3]
				], a)];
			}
			case "Dilation2D": {
				let i = Q("strides", e, t, n), a = Q("pad", e, t, n), o = Q("dilations", e, t, n), s = i[1], c = i[2], l = o[1], u = o[2];
				return [r.dilation2d(Q("x", e, t, n), Q("filter", e, t, n), [s, c], a, [l, u], "NHWC")];
			}
			default: throw TypeError(`Node type ${e.op} is not implemented`);
		}
	};
})), Vk, Hk = e((() => {
	vk(), $(), Vk = (e, t, n, r = _k) => {
		switch (e.op) {
			case "Fill": {
				let i = Q("shape", e, t, n), a = Q("dtype", e, t, n), o = Q("value", e, t, n);
				return [r.fill(i, o, a)];
			}
			case "LinSpace": {
				let i = Q("start", e, t, n), a = Q("stop", e, t, n), o = Q("num", e, t, n);
				return [r.linspace(i, a, o)];
			}
			case "Multinomial": {
				let i = Q("logits", e, t, n), a = Q("numSamples", e, t, n), o = Q("seed", e, t, n);
				return [r.multinomial(i, a, o)];
			}
			case "OneHot": {
				let i = Q("indices", e, t, n), a = Q("depth", e, t, n), o = Q("onValue", e, t, n), s = Q("offValue", e, t, n), c = Q("dtype", e, t, n);
				return [r.oneHot(i, a, o, s, c)];
			}
			case "Ones": return [r.ones(Q("shape", e, t, n), Q("dtype", e, t, n))];
			case "OnesLike": return [r.onesLike(Q("x", e, t, n))];
			case "RandomStandardNormal": return [r.randomStandardNormal(Q("shape", e, t, n), Q("dtype", e, t, n), Q("seed", e, t, n))];
			case "RandomUniform": return [r.randomUniform(Q("shape", e, t, n), Q("minval", e, t, n), Q("maxval", e, t, n), Q("dtype", e, t, n))];
			case "RandomUniformInt": return [r.randomUniformInt(Q("shape", e, t, n), Q("minval", e, t, n), Q("maxval", e, t, n), Q("seed", e, t, n))];
			case "Range": {
				let i = Q("start", e, t, n), a = Q("stop", e, t, n), o = Q("step", e, t, n);
				return [r.range(i, a, o, Q("dtype", e, t, n))];
			}
			case "TruncatedNormal": {
				let i = Q("shape", e, t, n), a = Q("mean", e, t, n), o = Q("stdDev", e, t, n), s = Q("seed", e, t, n);
				return [r.truncatedNormal(i, a, o, Q("dtype", e, t, n), s)];
			}
			case "Zeros": return [r.zeros(Q("shape", e, t, n), Q("dtype", e, t, n))];
			case "ZerosLike": return [r.zerosLike(Q("x", e, t, n))];
			default: throw TypeError(`Node type ${e.op} is not implemented`);
		}
	};
}));
// node_modules/@tensorflow/tfjs-converter/dist/operations/executors/dynamic_executor.js
function Uk(e, t, n) {
	return {
		boxes: Q("boxes", e, t, n),
		scores: Q("scores", e, t, n),
		maxOutputSize: Q("maxOutputSize", e, t, n),
		iouThreshold: Q("iouThreshold", e, t, n),
		scoreThreshold: Q("scoreThreshold", e, t, n),
		softNmsSigma: Q("softNmsSigma", e, t, n)
	};
}
var Wk, Gk = e((() => {
	vk(), $(), Wk = async (e, t, n, r, i = _k) => {
		switch (e.op) {
			case "NonMaxSuppressionV5": {
				let { boxes: r, scores: a, maxOutputSize: o, iouThreshold: s, scoreThreshold: c, softNmsSigma: l } = Uk(e, t, n), u = await i.image.nonMaxSuppressionWithScoreAsync(r, a, o, s, c, l);
				return [u.selectedIndices, u.selectedScores];
			}
			case "NonMaxSuppressionV4": {
				let { boxes: r, scores: a, maxOutputSize: o, iouThreshold: s, scoreThreshold: c } = Uk(e, t, n), l = Q("padToMaxOutputSize", e, t, n), u = await i.image.nonMaxSuppressionPaddedAsync(r, a, o, s, c, l);
				return [u.selectedIndices, u.validOutputs];
			}
			case "NonMaxSuppressionV3":
			case "NonMaxSuppressionV2": {
				let { boxes: r, scores: a, maxOutputSize: o, iouThreshold: s, scoreThreshold: c } = Uk(e, t, n);
				return [await i.image.nonMaxSuppressionAsync(r, a, o, s, c)];
			}
			case "Where": {
				let r = i.cast(Q("condition", e, t, n), "bool"), a = [await i.whereAsync(r)];
				return r.dispose(), a;
			}
			case "ListDiff": return i.setdiff1dAsync(Q("x", e, t, n), Q("y", e, t, n));
			default: throw TypeError(`Node type ${e.op} is not implemented`);
		}
	};
})), Kk, qk = e((() => {
	vk(), $(), Kk = (e, t, n, r = _k) => {
		switch (e.op) {
			case "LowerBound": {
				let i = Q("sortedSequence", e, t, n), a = Q("values", e, t, n);
				return [r.lowerBound(i, a)];
			}
			case "TopKV2": {
				let i = Q("x", e, t, n), a = Q("k", e, t, n), o = Q("sorted", e, t, n), s = r.topk(i, a, o);
				return [s.values, s.indices];
			}
			case "UpperBound": {
				let i = Q("sortedSequence", e, t, n), a = Q("values", e, t, n);
				return [r.upperBound(i, a)];
			}
			case "Unique": {
				let i = Q("x", e, t, n), a = r.unique(i);
				return [a.values, a.indices];
			}
			case "UniqueV2": {
				let i = Q("x", e, t, n), a = Q("axis", e, t, n), o = r.unique(i, a);
				return [o.values, o.indices];
			}
			default: throw TypeError(`Node type ${e.op} is not implemented`);
		}
	};
})), Jk, Yk = e((() => {
	vk(), $(), Jk = (e, t, n, r = _k) => {
		switch (e.op) {
			case "Const": return t[e.name];
			case "PlaceholderWithDefault":
				let i = Q("default", e, t, n);
				return [HD(e.name, t, n) || i];
			case "Placeholder": return [HD(e.name, t, n)];
			case "Identity":
			case "StopGradient":
			case "FakeQuantWithMinMaxVars": return [JD(Q("x", e, t, n))];
			case "IdentityN": return Q("x", e, t, n).map((e) => JD(e));
			case "Snapshot": return [JD(Q("x", e, t, n))];
			case "Shape": return [r.tensor1d(Q("x", e, t, n).shape, "int32")];
			case "ShapeN": return Q("x", e, t, n).map((e) => r.tensor1d(e.shape));
			case "Size": return [r.scalar(Q("x", e, t, n).size, "int32")];
			case "Rank": return [r.scalar(Q("x", e, t, n).rank, "int32")];
			case "NoOp": return [r.scalar(1)];
			case "Print":
				let a = Q("x", e, t, n), o = Q("data", e, t, n), s = Q("message", e, t, n), c = Q("summarize", e, t, n);
				console.warn("The graph has a tf.print() operation,usually used for debugging, which slows down performance."), console.log(s);
				for (let e = 0; e < o.length; e++) console.log(Array.prototype.slice.call(o[e].dataSync()).slice(0, c));
				return [a];
			default: throw TypeError(`Node type ${e.op} is not implemented`);
		}
	};
})), Xk, Zk = e((() => {
	MD(), vk(), Xk = class {
		get id() {
			return this.handle.id;
		}
		constructor(e, t) {
			this.keyDType = e, this.valueDType = t, this.handle = Y(0), this.tensorMap = /* @__PURE__ */ new Map(), Fo(this.handle);
		}
		clearAndClose() {
			this.tensorMap.forEach((e) => e.dispose()), this.tensorMap.clear(), this.handle.dispose();
		}
		size() {
			return this.tensorMap.size;
		}
		tensorSize() {
			return Y(this.size(), "int32");
		}
		async import(e, t) {
			this.checkKeyAndValueTensor(e, t);
			let n = await e.data();
			return this.tensorMap.forEach((e) => e.dispose()), this.tensorMap.clear(), L(() => {
				let e = eb(t), r = n.length, i = e.length;
				v(r === i, () => `The number of elements doesn't match, keys has ${r} elements, the values has ${i} elements.`);
				for (let t = 0; t < r; t++) {
					let r = n[t], i = e[t];
					Fo(i), this.tensorMap.set(r, i);
				}
				return this.handle;
			});
		}
		async find(e, t) {
			this.checkKeyAndValueTensor(e, t);
			let n = await e.data();
			return L(() => {
				let e = [];
				for (let r = 0; r < n.length; r++) {
					let i = n[r], a = this.findWithDefault(i, t);
					e.push(a);
				}
				return uy(e);
			});
		}
		findWithDefault(e, t) {
			return this.tensorMap.get(e) ?? t;
		}
		checkKeyAndValueTensor(e, t) {
			if (e.dtype !== this.keyDType) throw Error(`Expect key dtype ${this.keyDType}, but got ${e.dtype}`);
			if (t.dtype !== this.valueDType) throw Error(`Expect value dtype ${this.valueDType}, but got ${t.dtype}`);
		}
	};
})), Qk, $k = e((() => {
	Zk(), $(), Qk = async (e, t, n, r) => {
		switch (e.op) {
			case "HashTable":
			case "HashTableV2": {
				let i = r.getHashTableHandleByName(e.name);
				if (i != null) return [i];
				{
					let i = Q("keyDType", e, t, n), a = Q("valueDType", e, t, n), o = new Xk(i, a);
					return r.addHashTable(e.name, o), [o.handle];
				}
			}
			case "InitializeTable":
			case "InitializeTableV2":
			case "LookupTableImport":
			case "LookupTableImportV2": {
				let i = Q("tableHandle", e, t, n, r), a = Q("keys", e, t, n), o = Q("values", e, t, n);
				return [await r.getHashTableById(i.id).import(a, o)];
			}
			case "LookupTableFind":
			case "LookupTableFindV2": {
				let i = Q("tableHandle", e, t, n, r), a = Q("keys", e, t, n), o = Q("defaultValue", e, t, n);
				return [await r.getHashTableById(i.id).find(a, o)];
			}
			case "LookupTableSize":
			case "LookupTableSizeV2": {
				let i = Q("tableHandle", e, t, n, r);
				return [r.getHashTableById(i.id).tensorSize()];
			}
			default: throw TypeError(`Node type ${e.op} is not implemented`);
		}
	};
})), eA, tA = e((() => {
	vk(), $(), eA = (e, t, n, r = _k) => {
		switch (e.op) {
			case "ResizeBilinear": {
				let i = Q("images", e, t, n), a = Q("size", e, t, n), o = Q("alignCorners", e, t, n), s = Q("halfPixelCenters", e, t, n);
				return [r.image.resizeBilinear(i, [a[0], a[1]], o, s)];
			}
			case "ResizeNearestNeighbor": {
				let i = Q("images", e, t, n), a = Q("size", e, t, n), o = Q("alignCorners", e, t, n), s = Q("halfPixelCenters", e, t, n);
				return [r.image.resizeNearestNeighbor(i, [a[0], a[1]], o, s)];
			}
			case "CropAndResize": {
				let i = Q("image", e, t, n), a = Q("boxes", e, t, n), o = Q("boxInd", e, t, n), s = Q("cropSize", e, t, n), c = Q("method", e, t, n), l = Q("extrapolationValue", e, t, n);
				return [r.image.cropAndResize(i, a, o, s, c, l)];
			}
			case "ImageProjectiveTransformV3": {
				let i = Q("images", e, t, n), a = Q("transforms", e, t, n), o = Q("outputShape", e, t, n), s = Q("fillValue", e, t, n), c = Q("interpolation", e, t, n), l = Q("fillMode", e, t, n);
				return [r.image.transform(i, a, c.toLowerCase(), l.toLowerCase(), s, o)];
			}
			default: throw TypeError(`Node type ${e.op} is not implemented`);
		}
	};
})), nA, rA = e((() => {
	vk(), $(), nA = (e, t, n, r = _k) => {
		switch (e.op) {
			case "Equal": return [r.equal(Q("a", e, t, n), Q("b", e, t, n))];
			case "NotEqual": return [r.notEqual(Q("a", e, t, n), Q("b", e, t, n))];
			case "Greater": return [r.greater(Q("a", e, t, n), Q("b", e, t, n))];
			case "GreaterEqual": return [r.greaterEqual(Q("a", e, t, n), Q("b", e, t, n))];
			case "Less": return [r.less(Q("a", e, t, n), Q("b", e, t, n))];
			case "LessEqual": return [r.lessEqual(Q("a", e, t, n), Q("b", e, t, n))];
			case "LogicalAnd": return [r.logicalAnd(Q("a", e, t, n), Q("b", e, t, n))];
			case "LogicalNot": return [r.logicalNot(Q("a", e, t, n))];
			case "LogicalOr": return [r.logicalOr(Q("a", e, t, n), Q("b", e, t, n))];
			case "Select":
			case "SelectV2": return [r.where(Q("condition", e, t, n), Q("a", e, t, n), Q("b", e, t, n))];
			case "BitwiseAnd": return [r.bitwiseAnd(Q("a", e, t, n), Q("b", e, t, n))];
			default: throw TypeError(`Node type ${e.op} is not implemented`);
		}
	};
})), iA, aA = e((() => {
	vk(), $(), iA = (e, t, n, r = _k) => {
		switch (e.op) {
			case "BatchMatMul":
			case "BatchMatMulV2":
			case "MatMul": return [r.matMul(Q("a", e, t, n), Q("b", e, t, n), Q("transposeA", e, t, n), Q("transposeB", e, t, n))];
			case "Einsum": return [r.einsum(Q("equation", e, t, n), ...Q("tensors", e, t, n))];
			case "Transpose": return [r.transpose(Q("x", e, t, n), Q("perm", e, t, n))];
			case "_FusedMatMul":
				let [i, a] = Q("fusedOps", e, t, n), o = i === "biasadd", s = a === "prelu", c = Q("numArgs", e, t, n), l = Q("leakyreluAlpha", e, t, n);
				if (o) {
					if (s && c !== 2) throw Error("Fused MatMul with BiasAdd and Prelu must have two extra arguments: bias and alpha.");
					if (!s && c !== 1) throw Error("Fused MatMul with BiasAdd must have one extra argument: bias.");
				}
				let [u, d] = Q("args", e, t, n);
				return [r.fused.matMul({
					a: Q("a", e, t, n),
					b: Q("b", e, t, n),
					transposeA: Q("transposeA", e, t, n),
					transposeB: Q("transposeB", e, t, n),
					bias: u,
					activation: a,
					preluActivationWeights: d,
					leakyreluAlpha: l
				})];
			case "MatrixBandPart": return [r.linalg.bandPart(Q("a", e, t, n), Q("numLower", e, t, n), Q("numUpper", e, t, n))];
			default: throw TypeError(`Node type ${e.op} is not implemented`);
		}
	};
})), oA, sA = e((() => {
	vk(), $(), oA = (e, t, n, r = _k) => {
		switch (e.op) {
			case "EuclideanNorm": return [r.euclideanNorm(Q("x", e, t, n), Q("axis", e, t, n), Q("keepDims", e, t, n))];
			case "FusedBatchNorm":
			case "FusedBatchNormV2": return [r.batchNorm(Q("x", e, t, n), Q("mean", e, t, n), Q("variance", e, t, n), Q("offset", e, t, n), Q("scale", e, t, n), Q("epsilon", e, t, n))];
			case "FusedBatchNormV3": return [r.batchNorm(Q("x", e, t, n), Q("mean", e, t, n), Q("variance", e, t, n), Q("offset", e, t, n), Q("scale", e, t, n), Q("epsilon", e, t, n))];
			case "LRN": return [r.localResponseNormalization(Q("x", e, t, n), Q("radius", e, t, n), Q("bias", e, t, n), Q("alpha", e, t, n), Q("beta", e, t, n))];
			case "Softmax": return [r.softmax(Q("x", e, t, n))];
			case "LogSoftmax": return [r.logSoftmax(Q("x", e, t, n))];
			default: throw TypeError(`Node type ${e.op} is not implemented`);
		}
	};
})), cA, lA = e((() => {
	vk(), $(), cA = (e, t, n, r = _k) => {
		switch (e.op) {
			case "RaggedGather": {
				let { outputNestedSplits: i, outputDenseValues: a } = r.raggedGather(Q("paramsNestedSplits", e, t, n), Q("paramsDenseValues", e, t, n), Q("indices", e, t, n), Q("outputRaggedRank", e, t, n));
				return i.concat(a);
			}
			case "RaggedRange": {
				let { rtNestedSplits: i, rtDenseValues: a } = r.raggedRange(Q("starts", e, t, n), Q("limits", e, t, n), Q("splits", e, t, n));
				return [i, a];
			}
			case "RaggedTensorToTensor": return [r.raggedTensorToTensor(Q("shape", e, t, n), Q("values", e, t, n), Q("defaultValue", e, t, n), Q("rowPartitionTensors", e, t, n), Q("rowPartitionTypes", e, t, n))];
			default: throw TypeError(`Node type ${e.op} is not implemented`);
		}
	};
})), uA, dA = e((() => {
	vk(), $(), uA = (e, t, n, r = _k) => {
		switch (e.op) {
			case "Max": {
				let i = Q("axis", e, t, n), a = Q("keepDims", e, t, n);
				return [r.max(Q("x", e, t, n), i, a)];
			}
			case "Mean": {
				let i = Q("axis", e, t, n), a = Q("keepDims", e, t, n);
				return [r.mean(Q("x", e, t, n), i, a)];
			}
			case "Min": {
				let i = Q("axis", e, t, n), a = Q("keepDims", e, t, n);
				return [r.min(Q("x", e, t, n), i, a)];
			}
			case "Sum": {
				let i = Q("axis", e, t, n), a = Q("keepDims", e, t, n);
				return [r.sum(Q("x", e, t, n), i, a)];
			}
			case "All": {
				let i = Q("axis", e, t, n), a = Q("keepDims", e, t, n);
				return [r.all(Q("x", e, t, n), i, a)];
			}
			case "Any": {
				let i = Q("axis", e, t, n), a = Q("keepDims", e, t, n);
				return [r.any(Q("x", e, t, n), i, a)];
			}
			case "ArgMax": {
				let i = Q("axis", e, t, n);
				return [r.argMax(Q("x", e, t, n), i)];
			}
			case "ArgMin": {
				let i = Q("axis", e, t, n);
				return [r.argMin(Q("x", e, t, n), i)];
			}
			case "Prod": {
				let i = Q("axis", e, t, n), a = Q("keepDims", e, t, n);
				return [r.prod(Q("x", e, t, n), i, a)];
			}
			case "Cumprod": {
				let i = Q("axis", e, t, n), a = Q("exclusive", e, t, n), o = Q("reverse", e, t, n);
				return [r.cumprod(Q("x", e, t, n), i, a, o)];
			}
			case "Cumsum": {
				let i = Q("axis", e, t, n), a = Q("exclusive", e, t, n), o = Q("reverse", e, t, n);
				return [r.cumsum(Q("x", e, t, n), i, a, o)];
			}
			case "Bincount":
				let i = Q("x", e, t, n), a = Q("weights", e, t, n), o = Q("size", e, t, n);
				return [r.bincount(i, a, o)];
			case "DenseBincount": {
				let i = Q("x", e, t, n), a = Q("weights", e, t, n), o = Q("size", e, t, n), s = Q("binaryOutput", e, t, n);
				return [r.denseBincount(i, a, o, s)];
			}
			default: throw TypeError(`Node type ${e.op} is not implemented`);
		}
	};
})), fA, pA = e((() => {
	MD(), vk(), $(), fA = (e, t, n, r = _k) => {
		switch (e.op) {
			case "ConcatV2":
			case "Concat": {
				let i = Q("n", e, t, n), a = Q("axis", e, t, n), o = Q("tensors", e, t, n);
				return o = o.slice(0, i), [r.concat(o, a)];
			}
			case "Gather": {
				let i = Q("x", e, t, n), a = Q("indices", e, t, n);
				return [r.gather(i, r.cast(a, "int32"), 0)];
			}
			case "GatherV2": {
				let i = Q("axis", e, t, n), a = Q("batchDims", e, t, n), o = Q("x", e, t, n), s = Q("indices", e, t, n);
				return [r.gather(o, r.cast(s, "int32"), i, a)];
			}
			case "Reverse": {
				let i = Q("dims", e, t, n), a = [];
				for (let e = 0; e < i.length; e++) i[e] && a.push(e);
				let o = Q("x", e, t, n);
				return [r.reverse(o, a)];
			}
			case "ReverseV2": {
				let i = Q("axis", e, t, n), a = Q("x", e, t, n);
				return [r.reverse(a, i)];
			}
			case "Slice": {
				let i = Q("begin", e, t, n), a = Q("size", e, t, n);
				return [r.slice(Q("x", e, t, n), i, a)];
			}
			case "StridedSlice": {
				let i = Q("begin", e, t, n), a = Q("end", e, t, n), o = Q("strides", e, t, n), s = Q("beginMask", e, t, n), c = Q("endMask", e, t, n), l = Q("ellipsisMask", e, t, n), u = Q("newAxisMask", e, t, n), d = Q("shrinkAxisMask", e, t, n), f = Q("x", e, t, n);
				return [r.stridedSlice(f, i, a, o, s, c, l, u, d)];
			}
			case "Pack": return L(() => {
				let i = Q("axis", e, t, n), a = Q("tensors", e, t, n), o = a[0].shape, s = r.squeeze(a[0]).shape, c = a.map((e) => {
					let t = S(e.shape, o);
					if (!t && !S(r.squeeze(e).shape, s)) throw Error("the input tensors shape does not match");
					return t ? e : r.reshape(e, o);
				});
				return [r.stack(c, i)];
			});
			case "Unpack": {
				let i = Q("axis", e, t, n), a = Q("tensor", e, t, n);
				return r.unstack(a, i);
			}
			case "Tile": {
				let i = Q("reps", e, t, n);
				return [r.tile(Q("x", e, t, n), i)];
			}
			case "Split":
			case "SplitV": {
				let i = Q("axis", e, t, n), a = Q("numOrSizeSplits", e, t, n), o = Q("x", e, t, n);
				return r.split(o, a, i);
			}
			case "ScatterNd": {
				let i = Q("indices", e, t, n), a = Q("values", e, t, n), o = Q("shape", e, t, n);
				return [r.scatterND(i, a, o)];
			}
			case "GatherNd": {
				let i = Q("x", e, t, n), a = Q("indices", e, t, n);
				return [r.gatherND(i, a)];
			}
			case "SparseToDense": {
				let i = Q("sparseIndices", e, t, n), a = Q("outputShape", e, t, n), o = Q("sparseValues", e, t, n), s = Q("defaultValue", e, t, n);
				return [r.sparseToDense(i, o, a, o.dtype === s.dtype ? s : r.cast(s, o.dtype))];
			}
			case "TensorScatterUpdate": {
				let i = Q("indices", e, t, n), a = Q("values", e, t, n), o = Q("tensor", e, t, n);
				return [r.tensorScatterUpdate(o, i, a)];
			}
			default: throw TypeError(`Node type ${e.op} is not implemented`);
		}
	};
})), mA, hA = e((() => {
	vk(), $(), mA = (e, t, n, r = _k) => {
		switch (e.op) {
			case "SparseFillEmptyRows": {
				let { outputIndices: i, outputValues: a, emptyRowIndicator: o, reverseIndexMap: s } = r.sparse.sparseFillEmptyRows(Q("indices", e, t, n), Q("values", e, t, n), Q("denseShape", e, t, n), Q("defaultValue", e, t, n));
				return [
					i,
					a,
					o,
					s
				];
			}
			case "SparseReshape": {
				let { outputIndices: i, outputShape: a } = r.sparse.sparseReshape(Q("inputIndices", e, t, n), Q("inputShape", e, t, n), Q("newShape", e, t, n));
				return [i, a];
			}
			case "SparseSegmentMean": return [r.sparse.sparseSegmentMean(Q("data", e, t, n), Q("indices", e, t, n), Q("segmentIds", e, t, n))];
			case "SparseSegmentSum": return [r.sparse.sparseSegmentSum(Q("data", e, t, n), Q("indices", e, t, n), Q("segmentIds", e, t, n))];
			default: throw TypeError(`Node type ${e.op} is not implemented`);
		}
	};
})), gA, _A = e((() => {
	vk(), $(), gA = (e, t, n, r = _k) => {
		switch (e.op) {
			case "FFT": return [r.fft(Q("x", e, t, n))];
			case "IFFT": return [r.ifft(Q("x", e, t, n))];
			case "RFFT": return [r.rfft(Q("x", e, t, n))];
			case "IRFFT": return [r.irfft(Q("x", e, t, n))];
			default: throw TypeError(`Node type ${e.op} is not implemented`);
		}
	};
})), vA, yA = e((() => {
	vk(), $(), vA = (e, t, n, r = _k) => {
		switch (e.op) {
			case "StaticRegexReplace": return [r.string.staticRegexReplace(Q("input", e, t, n), Q("pattern", e, t, n), Q("rewrite", e, t, n), Q("replaceGlobal", e, t, n))];
			case "StringNGrams": {
				let { nGrams: i, nGramsSplits: a } = r.string.stringNGrams(Q("data", e, t, n), Q("dataSplits", e, t, n), Q("separator", e, t, n), Q("nGramWidths", e, t, n), Q("leftPad", e, t, n), Q("rightPad", e, t, n), Q("padWidth", e, t, n), Q("preserveShortSequences", e, t, n));
				return [i, a];
			}
			case "StringSplit": {
				let { indices: i, values: a, shape: o } = r.string.stringSplit(Q("input", e, t, n), Q("delimiter", e, t, n), Q("skipEmpty", e, t, n));
				return [
					i,
					a,
					o
				];
			}
			case "StringToHashBucketFast": return [r.string.stringToHashBucketFast(Q("input", e, t, n), Q("numBuckets", e, t, n))];
			default: throw TypeError(`Node type ${e.op} is not implemented`);
		}
	};
})), bA, xA = e((() => {
	vk(), $(), bA = (e, t, n, r = _k) => {
		switch (e.op) {
			case "Cast": return [r.cast(Q("x", e, t, n), Q("dtype", e, t, n))];
			case "ExpandDims": {
				let i = Q("axis", e, t, n);
				return [r.expandDims(Q("x", e, t, n), i)];
			}
			case "Squeeze": {
				let i = Q("axis", e, t, n);
				return [r.squeeze(Q("x", e, t, n), i)];
			}
			case "Reshape": return [r.reshape(Q("x", e, t, n), Q("shape", e, t, n))];
			case "EnsureShape": return [r.ensureShape(Q("x", e, t, n), Q("shape", e, t, n))];
			case "MirrorPad": return [r.mirrorPad(Q("x", e, t, n), Q("padding", e, t, n), Q("mode", e, t, n))];
			case "PadV2":
			case "Pad": return [r.pad(Q("x", e, t, n), Q("padding", e, t, n), Q("constantValue", e, t, n))];
			case "SpaceToBatchND": {
				let i = Q("blockShape", e, t, n), a = Q("paddings", e, t, n);
				return [r.spaceToBatchND(Q("x", e, t, n), i, a)];
			}
			case "BatchToSpaceND": {
				let i = Q("blockShape", e, t, n), a = Q("crops", e, t, n);
				return [r.batchToSpaceND(Q("x", e, t, n), i, a)];
			}
			case "DepthToSpace": {
				let i = Q("blockSize", e, t, n), a = Q("dataFormat", e, t, n).toUpperCase();
				return [r.depthToSpace(Q("x", e, t, n), i, a)];
			}
			case "BroadcastTo": return [r.broadcastTo(Q("x", e, t, n), Q("shape", e, t, n))];
			case "BroadcastArgs": return [r.broadcastArgs(Q("s0", e, t, n), Q("s1", e, t, n))];
			default: throw TypeError(`Node type ${e.op} is not implemented`);
		}
	};
}));
// node_modules/@tensorflow/tfjs-converter/dist/operations/operation_executor.js
function SA(e, t, n, r, i = L) {
	let a = ((e, t, n) => {
		switch (e.category) {
			case "arithmetic": return i(() => yk(e, t, n));
			case "basic_math": return i(() => xk(e, t, n));
			case "control": return Ik(e, t, n);
			case "convolution": return i(() => zk(e, t, n));
			case "creation": return i(() => Vk(e, t, n));
			case "dynamic": return Wk(e, t, n);
			case "evaluation": return i(() => Kk(e, t, n));
			case "image": return i(() => eA(e, t, n));
			case "graph": return i(() => Jk(e, t, n));
			case "logical": return i(() => nA(e, t, n));
			case "matrices": return i(() => iA(e, t, n));
			case "normalization": return i(() => oA(e, t, n));
			case "ragged": return i(() => cA(e, t, n));
			case "reduction": return i(() => uA(e, t, n));
			case "slice_join": return i(() => fA(e, t, n));
			case "sparse": return i(() => mA(e, t, n));
			case "spectral": return i(() => gA(e, t, n));
			case "string": return i(() => vA(e, t, n));
			case "transformation": return i(() => bA(e, t, n));
			case "hash_table": return Qk(e, t, n, r);
			case "custom":
				let a = RD(e.op);
				if (a && a.customExecutor) return a.customExecutor(new hk(e, t, n));
				throw TypeError(`Custom op ${e.op} is not registered.`);
			default: throw TypeError(`Unknown op '${e.op}'. File an issue at https://github.com/tensorflow/tfjs/issues so we can add it, or register a custom execution with tf.registerOp()`);
		}
	})(e, t, n);
	return Ne(a) ? a.then((e) => [].concat(e)) : [].concat(a);
}
var CA = e((() => {
	MD(), gk(), VD(), bk(), Sk(), Lk(), Bk(), Hk(), Gk(), qk(), Yk(), $k(), tA(), rA(), aA(), sA(), lA(), dA(), pA(), hA(), _A(), yA(), xA();
})), wA, TA = e((() => {
	wA = class {
		constructor(e = {}, t = {}, n = {}, r = {}, i) {
			this.weightMap = e, this.tensorArrayMap = t, this.tensorListMap = n, this.functionMap = r, this.parseNodeNameCache = i, this.rootContext = {
				id: 0,
				frameName: "",
				iterationId: 0
			}, this.contexts = [this.rootContext], this.lastId = 0, this.generateCurrentContextIds();
		}
		newFrame(e, t) {
			return {
				id: e,
				frameName: t,
				iterationId: 0
			};
		}
		set currentContext(e) {
			this.contexts !== e && (this.contexts = e, this.generateCurrentContextIds());
		}
		get currentContext() {
			return this.contexts;
		}
		get currentContextId() {
			return this._currentContextIds[0];
		}
		get currentContextIds() {
			return this._currentContextIds;
		}
		generateCurrentContextIds() {
			let e = [];
			for (let t = 0; t < this.contexts.length - 1; t++) {
				let n = this.contexts.slice(0, this.contexts.length - t);
				e.push(this.contextIdforContexts(n));
			}
			e.push(""), this._currentContextIds = e;
		}
		contextIdforContexts(e) {
			return e ? e.map((e) => e.id === 0 && e.iterationId === 0 ? "" : `${e.frameName}-${e.iterationId}`).join("/") : "";
		}
		enterFrame(e) {
			this.contexts && (this.lastId++, this.contexts = this.contexts.slice(), this.contexts.push(this.newFrame(this.lastId, e)), this._currentContextIds.unshift(this.contextIdforContexts(this.contexts)));
		}
		exitFrame() {
			if (this.contexts && this.contexts.length > 1) this.contexts = this.contexts.slice(), this.contexts.splice(-1), this.currentContextIds.shift();
			else throw Error("Cannot exit frame, the context is empty");
		}
		nextIteration() {
			if (this.contexts && this.contexts.length > 0) {
				this.contexts = this.contexts.slice(), this.lastId++;
				let e = Object.assign({}, this.contexts[this.contexts.length - 1]);
				e.iterationId += 1, e.id = this.lastId, this.contexts.splice(-1, 1, e), this._currentContextIds.splice(0, 1, this.contextIdforContexts(this.contexts));
			} else throw Error("Cannot increase frame iteration, the context is empty");
		}
		getWeight(e) {
			return this.weightMap[e];
		}
		addTensorArray(e) {
			this.tensorArrayMap[e.id] = e;
		}
		getTensorArray(e) {
			return this.tensorArrayMap[e];
		}
		addTensorList(e) {
			this.tensorListMap[e.id] = e;
		}
		getTensorList(e) {
			return this.tensorListMap[e];
		}
		dispose(e) {
			for (let t in this.tensorArrayMap) this.tensorArrayMap[t].clearAndClose(e);
			for (let t in this.tensorListMap) this.tensorListMap[t].clearAndClose(e);
		}
	};
}));
// node_modules/@tensorflow/tfjs-converter/dist/executor/model_analysis.js
function EA(e, t, n, r) {
	let i = /* @__PURE__ */ new Set(), a = [], o = null, s = null, c = /* @__PURE__ */ new Set(), l = new Set(Object.keys(e).map((e) => KD(e)[0]));
	r ||= [];
	let u = new Set(r.map((e) => KD(e.name)[0])), d = [...t];
	for (; d.length > 0;) {
		let e = d.pop();
		(jA(e) || MA(e) || NA(e)) && (o ?? (o = e, s = o.children.map((e) => e.name).filter((e) => i.has(e)))), i.add(e.name), n[e.name] ?? (l.has(e.name) || u.has(e.name) || (e.inputs.length === 0 ? a.push(e.name) : e.inputs.forEach((e) => {
			c.has(e.name) || (c.add(e.name), d.push(e));
		})));
	}
	return {
		inputs: e,
		outputs: t,
		usedNodes: i,
		missingInputs: a,
		dynamicNode: o,
		syncInputs: s
	};
}
function DA(e, t) {
	let { usedNodes: n, inputs: r } = t, i = Object.keys(r).map((e) => KD(e)[0]).map((t) => e.nodes[t]), a = e.initNodes || [], o = (e) => n.has(typeof e == "string" ? e : e.name);
	function s(e) {
		return [...new Map(e.map((e) => [e.name, e])).values()];
	}
	let c = s([
		...i,
		...e.weights,
		...a
	]).filter(o), l = s([...c, ...Object.values(e.nodes)]).filter(o), u = new Map(l.map((e) => [e.name, e])), d = {};
	for (let e of l) {
		d[e.name] = d[e.name] || 0;
		for (let t of e.children) o(t) || (d[t.name] = Infinity), d[t.name] = (d[t.name] || 0) + 1;
	}
	let f = Object.entries(d).filter(([, e]) => e === 0).map(([e]) => e), p = [...f];
	for (; f.length > 0;) {
		let e = f.pop(), t = u.get(e);
		for (let e of t.children.filter(o)) --d[e.name] === 0 && (p.push(e.name), f.push(e.name));
	}
	let m = OA(p.map((e) => u.get(e)), c);
	return kA(m, c), m;
}
function OA(e, t) {
	let n = new Map(e.map((e) => [e.name, e])), r = t.map((e) => e.name), i = new Set(r);
	for (; r.length > 0;) {
		let e = r.pop(), t = n.get(e);
		for (let e of t.children) n.has(e.name) && !i.has(e.name) && (i.add(e.name), r.push(e.name));
	}
	return e.filter((e) => i.has(e.name));
}
function kA(e, t) {
	let n = new Map(e.map((e, t) => [e.name, t])), r = new Set(t.map((e) => e.name)), i = (e) => r.has(typeof e == "string" ? e : e.name), a = new Set(e.map((e) => e.name)), o = (e) => a.has(typeof e == "string" ? e : e.name);
	for (let t of e) {
		for (let e of t.children.filter(o)) {
			if (!n.has(e.name)) throw new PA(`Child ${e.name} of node ${t.name} is unreachable.`);
			if (n.get(t.name) > n.get(e.name)) throw new PA(`Node ${t.name} is scheduled to run after its child ${e.name}.`);
		}
		if (!i(t)) for (let e of t.inputs) {
			if (!n.has(e.name)) throw new PA(`Input ${e.name} of node ${t.name} is unreachable.`);
			if (n.get(e.name) > n.get(t.name)) throw new PA(`Node ${t.name} is scheduled to run before its input ${e.name}.`);
		}
	}
}
function AA(e) {
	let t = new Map(e.map((e, t) => [e.name, t])), n = 2 ** 53 - 1, r = e.map((e, t) => jA(e) ? n : t), i = (e) => r[t.get(e.name)] ?? -1, a = e.map((e, t) => e.children.map(i).reduce((e, t) => Math.max(e, t), r[t])), o = /* @__PURE__ */ new Map();
	for (let t = 0; t < e.length; ++t) {
		let r = a[t];
		if (r === n) continue;
		let i = e[t], s = e[r];
		o.has(s.name) || o.set(s.name, []), o.get(s.name).push(i);
	}
	return o;
}
function jA(e) {
	return FA.has(e.op);
}
function MA(e) {
	return IA.has(e.op);
}
function NA(e) {
	return LA.has(e.op);
}
var PA, FA, IA, LA, RA = e((() => {
	$(), PA = class extends Error {
		constructor(e) {
			super(`NodesExecutionOrderError: ${e}`);
		}
	}, FA = /* @__PURE__ */ new Set([
		"Switch",
		"Merge",
		"Enter",
		"Exit",
		"NextIteration",
		"StatelessIf",
		"StatelessWhile",
		"if",
		"While"
	]), IA = /* @__PURE__ */ new Set([
		"NonMaxSuppressionV2",
		"NonMaxSuppressionV3",
		"NonMaxSuppressionV5",
		"Where"
	]), LA = /* @__PURE__ */ new Set([
		"HashTable",
		"HashTableV2",
		"LookupTableImport",
		"LookupTableImportV2",
		"LookupTableFind",
		"LookupTableFindV2",
		"LookupTableSize",
		"LookupTableSizeV2"
	]);
})), zA, BA = e((() => {
	MD(), $(), CA(), TA(), RA(), zA = class e {
		get weightIds() {
			return this.parent ? this.parent.weightIds : this._weightIds;
		}
		get functionExecutorMap() {
			return this.parent ? this.parent.functionExecutorMap : this._functionExecutorMap;
		}
		get weightMap() {
			return this.parent ? this.parent.weightMap : this._weightMap;
		}
		set weightMap(e) {
			let t = Object.keys(e).map((t) => e[t].map((e) => e.id));
			this._weightIds = [].concat(...t), this._weightMap = e;
		}
		set resourceManager(e) {
			this._resourceManager = e;
		}
		get inputs() {
			return this._inputs.map((e) => ({
				name: e.name,
				shape: e.attrParams.shape ? e.attrParams.shape.value : void 0,
				dtype: e.attrParams.dtype ? e.attrParams.dtype.value : void 0
			}));
		}
		get outputs() {
			return this._outputs.map((e) => ({
				name: e.name,
				shape: e.attrParams.shape ? e.attrParams.shape.value : void 0,
				dtype: e.attrParams.dtype ? e.attrParams.dtype.value : void 0
			}));
		}
		get inputNodes() {
			return this._inputs.map((e) => e.signatureKey || e.name);
		}
		get outputNodes() {
			return this._outputs.map((e) => {
				let t = e.signatureKey || e.name;
				return e.defaultOutput ? `${t}:${e.defaultOutput}` : t;
			});
		}
		get functions() {
			return Object.keys(this._functions).reduce((e, t) => (e[t] = this._functions[t].signature, e), {});
		}
		constructor(t, n) {
			this.graph = t, this.parent = n, this.compiledMap = /* @__PURE__ */ new Map(), this.parseNodeNameCache = /* @__PURE__ */ new Map(), this._weightMap = {}, this.SEPARATOR = ",", this._functions = {}, this._functionExecutorMap = {}, this.keepIntermediateTensors = !1, this._outputs = t.outputs, this._inputs = t.inputs, this._initNodes = t.initNodes, this._signature = t.signature, this._functions = t.functions, t.functions != null && Object.keys(t.functions).forEach((n) => {
				this._functionExecutorMap[n] = new e(t.functions[n], this);
			});
		}
		getCompilationKey(e, t) {
			let n = e.map((e) => e.name).sort(), r = t.map((e) => e.name).sort();
			return n.join(this.SEPARATOR) + "--" + r.join(this.SEPARATOR);
		}
		compile(e, t) {
			let n = EA(e, t, this.weightMap, this._initNodes), { missingInputs: r, dynamicNode: i, syncInputs: a } = n;
			if (i != null) throw Error(`This execution contains the node '${i.name}', which has the dynamic op '${i.op}'. Please use model.executeAsync() instead. Alternatively, to avoid the dynamic ops, specify the inputs [${a}]`);
			if (r.length > 0) {
				let n = t.map((e) => e.name), i = Object.keys(e);
				throw Error(`Cannot compute the outputs [${n}] from the provided inputs [${i}]. Missing the following inputs: [${r}]`);
			}
			let o = DA(this.graph, n);
			return {
				orderedNodes: o,
				nodeLiveUntilMap: AA(o)
			};
		}
		cloneAndKeepTensor(e) {
			if (e == null) return null;
			let t = e.clone();
			return Fo(t), t;
		}
		cloneTensorList(e) {
			return e ? e.map((e) => this.cloneAndKeepTensor(e)) : null;
		}
		cloneTensorMap(e) {
			return Object.fromEntries(Object.entries(e).map(([e, t]) => [e, this.cloneTensorList(t)]));
		}
		execute(e, t) {
			this.disposeIntermediateTensors(), e = this.mapInputs(e);
			let n = Object.keys(e).sort();
			this.checkInputs(e), this.checkInputShapeAndType(e), t = this.mapOutputs(t), this.checkOutputs(t);
			let r = n.map((e) => this.graph.nodes[KD(e)[0]]), i = t.map((e) => KD(e)[0]), a = new Set(i), o = i.map((e) => this.graph.nodes[e]);
			o.length === 0 && (o = this._outputs);
			let s = this.getCompilationKey(r, o), c = this.compiledMap.get(s);
			c ?? (c = this.compile(e, o), this.compiledMap.set(s, c));
			try {
				this.keepIntermediateTensors = w().getBool("KEEP_INTERMEDIATE_TENSORS");
			} catch (e) {
				this.keepIntermediateTensors = !1, console.warn(e.message);
			}
			let l = {}, u = {};
			return L(() => {
				let n = new wA(this.weightMap, l, u, this.functionExecutorMap, this.parseNodeNameCache), r = Object.assign({}, this.weightMap);
				this.keepIntermediateTensors && (this.clonedTensorsMap = this.cloneTensorMap(this.weightMap)), Object.keys(e).forEach((t) => {
					let [i, a] = KD(t, n), o = [];
					o[a] = e[t], r[i] = o, this.keepIntermediateTensors && (this.clonedTensorsMap[i] = this.cloneTensorList(o));
				});
				let i = this.getFrozenTensorIds(r), { orderedNodes: o, nodeLiveUntilMap: s } = c;
				for (let e of o) {
					if (r[e.name]) continue;
					let t = SA(e, r, n, this._resourceManager);
					if (Ne(t)) throw Error(`The execution of the op '${e.op}' returned a promise. Please use model.executeAsync() instead.`);
					r[e.name] = t, this.keepIntermediateTensors && (this.clonedTensorsMap[e.name] = this.cloneTensorList(t)), this.checkTensorForDisposalWithNodeLiveUntilInfo(e, r, n, i, a, s.get(e.name));
				}
				return this.parent ?? n.dispose(i), t.map((e) => HD(e, r, n));
			});
		}
		getFrozenTensorIds(e) {
			let t = [].concat.apply([], Object.keys(e).map((t) => e[t]).map((e) => e.map((e) => e.id)));
			return new Set(t);
		}
		checkTensorForDisposal(e, t, n, r, i, a, o) {
			if (!(jA(t) || a.has(e))) {
				for (let r of n[e]) r != null && (o[r.id] = (o[r.id] || 0) + t.children.length);
				for (let e of t.inputs) {
					if (jA(e)) continue;
					let t = UD(e.name, n, r);
					if (t != null) for (let e of t) {
						if (!e || e.kept || i.has(e.id)) continue;
						let t = o[e.id];
						t === 1 ? (e.dispose(), delete o[e.id]) : t != null && o[e.id]--;
					}
				}
			}
		}
		checkTensorForDisposalWithNodeLiveUntilInfo(e, t, n, r, i, a) {
			function o(e) {
				return jA(e) || i.has(e.name);
			}
			if (!(jA(e) || a == null)) for (let e of a) {
				if (o(e)) continue;
				let i = UD(e.name, t, n);
				for (let e of i) !e || e.kept || r.has(e.id) || e.dispose();
			}
		}
		async executeAsync(e, t) {
			return this._executeAsync(e, t);
		}
		disposeIntermediateTensors() {
			this.clonedTensorsMap &&= (Object.values(this.clonedTensorsMap).forEach((e) => {
				for (let t of e) t && !t.isDisposed && t.dispose();
			}), null);
		}
		getIntermediateTensors() {
			return this.clonedTensorsMap;
		}
		async _executeAsync(e, t, n = !1, r = {}, i = {}) {
			this.disposeIntermediateTensors(), n || (e = this.mapInputs(e), this.checkInputs(e), this.checkInputShapeAndType(e), t = this.mapOutputs(t), this.checkOutputs(t));
			try {
				this.keepIntermediateTensors = w().getBool("KEEP_INTERMEDIATE_TENSORS");
			} catch (e) {
				this.keepIntermediateTensors = !1, console.warn(e.message);
			}
			let a = new wA(this.weightMap, r, i, this.functionExecutorMap, this.parseNodeNameCache);
			this.keepIntermediateTensors && (this.clonedTensorsMap = this.cloneTensorMap(this.weightMap));
			let o = await this.executeWithControlFlow(e, a, t, n), s = t.map((e) => HD(e, o, a)), c = s.map((e) => e.id), l = Object.keys(e).map((t) => e[t].id), u = /* @__PURE__ */ new Set([
				...c,
				...l,
				...this.weightIds
			]);
			return Object.values(o).forEach((e) => {
				e.forEach((e) => {
					e && !e.isDisposed && !u.has(e.id) && e.dispose();
				});
			}), this.parent ?? a.dispose(u), s;
		}
		async executeFunctionAsync(e, t, n) {
			let r = e.reduce((e, t, n) => (e[this.inputs[n].name] = t, e), {});
			return this._executeAsync(r, this.outputNodes, !0, t, n);
		}
		async executeWithControlFlow(e, t, n, r) {
			let i = Object.keys(e), a = i.map((e) => this.graph.nodes[KD(e)[0]]), o = n.map((e) => KD(e)[0]), s = new Set(o), c = o.map((e) => this.graph.nodes[e]);
			c.length === 0 && (c = this._outputs);
			let { usedNodes: l, missingInputs: u, dynamicNode: d, syncInputs: f } = EA(e, c, this.weightMap, this._initNodes), p = [
				...a,
				...this.graph.weights,
				...this._initNodes || []
			].map((e) => ({
				node: e,
				contexts: t.currentContext
			})), m = Object.assign({}, this.weightMap);
			Object.keys(e).forEach((t) => {
				let [n, r] = KD(t), i = [];
				i[r] = e[t], m[n] = i;
			});
			let h = {}, g = this.getFrozenTensorIds(m), _ = {};
			for (; p.length > 0;) {
				let e = this.processStack(a, p, t, m, _, g, s, h, l);
				await Promise.all(e);
			}
			d == null && !r && console.warn("This model execution did not contain any nodes with control flow or dynamic output shapes. You can use model.execute() instead.");
			let v = c.filter((e) => !jA(e) && !HD(e.name, m, t)).map((e) => e.name);
			if (v.length > 0) {
				let e = "";
				throw d != null && (e = `Alternatively, to avoid the dynamic ops, use model.execute() and specify the inputs [${f}]`), Error(`Cannot compute the outputs [${v}] from the provided inputs [${i}]. Consider providing the following inputs: [${u}]. ${e}`);
			}
			return m;
		}
		processStack(e, t, n, r, i, a, o, s, c) {
			let l = [];
			for (; t.length > 0;) {
				let e = t.pop();
				n.currentContext = e.contexts;
				let u = "";
				if (e.node.op === "Enter" && Q("isConstant", e.node, r, n) && ([u] = WD(e.node.name, n)), r[e.node.name] == null) {
					let d = SA(e.node, r, n, this._resourceManager);
					u || ([u] = WD(e.node.name, n));
					let f = n.currentContext;
					Ne(d) ? l.push(d.then((l) => (r[u] = l, this.keepIntermediateTensors && (this.clonedTensorsMap[u] = this.cloneTensorList(l)), n.currentContext = f, this.checkTensorForDisposal(u, e.node, r, n, a, o, s), this.processChildNodes(e.node, t, n, r, i, c), l))) : (r[u] = d, this.keepIntermediateTensors && (this.clonedTensorsMap[u] = this.cloneTensorList(d)), this.checkTensorForDisposal(u, e.node, r, n, a, o, s), this.processChildNodes(e.node, t, n, r, i, c));
				} else this.processChildNodes(e.node, t, n, r, i, c);
			}
			return l;
		}
		processChildNodes(e, t, n, r, i, a) {
			e.children.forEach((e) => {
				let [o] = WD(e.name, n);
				!i[o] && a.has(e.name) && (e.op === "Merge" ? e.inputNames.some((e) => !!HD(e, r, n)) && (i[o] = !0, t.push({
					contexts: n.currentContext,
					node: e
				})) : e.inputNames.every((e) => !!HD(e, r, n)) && (i[o] = !0, t.push({
					contexts: n.currentContext,
					node: e
				})));
			});
		}
		dispose() {
			Object.keys(this.weightMap).forEach((e) => this.weightMap[e].forEach((e) => e.dispose()));
		}
		checkInputShapeAndType(e) {
			Object.keys(e).forEach((t) => {
				let n = e[t], [r] = KD(t), i = this.graph.nodes[r];
				if (i.attrParams.shape && i.attrParams.shape.value) {
					let e = i.attrParams.shape.value;
					v(e.length === n.shape.length && n.shape.every((t, n) => e[n] === -1 || e[n] === t), () => `The shape of dict['${i.name}'] provided in model.execute(dict) must be [${e}], but was [${n.shape}]`);
				}
				i.attrParams.dtype && i.attrParams.dtype.value && v(n.dtype === i.attrParams.dtype.value, () => `The dtype of dict['${i.name}'] provided in model.execute(dict) must be ${i.attrParams.dtype.value}, but was ${n.dtype}`);
			});
		}
		mapInputs(e) {
			let t = {};
			for (let n in e) {
				let r = this._signature?.inputs?.[n];
				r == null ? t[n] = e[n] : t[r.name] = e[n];
			}
			return t;
		}
		checkInputs(e) {
			let t = Object.keys(e).filter((e) => {
				let [t] = KD(e);
				return this.graph.nodes[t] == null;
			});
			if (t.length > 0) throw Error(`The dict provided in model.execute(dict) has keys: [${t}] that are not part of graph`);
		}
		mapOutputs(e) {
			return e.map((e) => {
				let t = this._signature?.outputs?.[e];
				return t == null ? e : t.name;
			}, {});
		}
		checkOutputs(e) {
			e.forEach((e) => {
				let [t] = KD(e);
				if (!this.graph.nodes[t]) throw Error(`The output '${e}' is not found in the graph`);
			});
		}
	};
})), VA, HA = e((() => {
	VA = class {
		constructor(e = {}, t = {}) {
			this.hashTableNameToHandle = e, this.hashTableMap = t;
		}
		addHashTable(e, t) {
			this.hashTableNameToHandle[e] = t.handle, this.hashTableMap[t.id] = t;
		}
		getHashTableHandleByName(e) {
			return this.hashTableNameToHandle[e];
		}
		getHashTableById(e) {
			return this.hashTableMap[e];
		}
		dispose() {
			for (let e in this.hashTableMap) this.hashTableMap[e].clearAndClose(), delete this.hashTableMap[e];
			for (let e in this.hashTableNameToHandle) this.hashTableNameToHandle[e].dispose(), delete this.hashTableNameToHandle[e];
		}
	};
}));
// node_modules/@tensorflow/tfjs-converter/dist/executor/graph_model.js
async function UA(e, t = {}, n = iT) {
	if (e == null) throw Error("modelUrl in loadGraphModel() cannot be null. Please provide a url or an IOHandler that loads the model");
	t ??= {}, t.fromTFHub && typeof e == "string" && (e = GA(e));
	let r = new JA(e, t, n);
	return await r.load(), r;
}
function WA(e) {
	if (e == null) throw Error("modelUrl in loadGraphModelSync() cannot be null. Please provide model artifacts or an IOHandler that loads the model");
	let t;
	if (e instanceof Array) {
		let [n, r] = e;
		if (!n) throw Error("modelJSON must be the first element of the array");
		if (!r || !(r instanceof ArrayBuffer)) throw Error("An ArrayBuffer of weights must be the second element of the array");
		if (!("modelTopology" in n)) throw Error("Model JSON is missing 'modelTopology'");
		if (!("weightsManifest" in n)) throw Error("Model JSON is missing 'weightsManifest'");
		t = Zw(ss(n, us(n.weightsManifest), r));
	} else if ("load" in e) t = e;
	else if ("modelTopology" in e && "weightSpecs" in e && "weightData" in e) t = Zw(e);
	else throw Error("Unknown model format");
	let n = new JA(t);
	return n.load(), n;
}
function GA(e) {
	return e.endsWith("/") || (e += "/"), `${e}${qA}${KA}`;
}
var KA, qA, JA, YA = e((() => {
	MD(), mk(), BA(), HA(), _s(), KA = "?tfjs-format=file", qA = "model.json", JA = class {
		get modelVersion() {
			return this.version;
		}
		get inputNodes() {
			return this.executor.inputNodes;
		}
		get outputNodes() {
			return this.executor.outputNodes;
		}
		get inputs() {
			return this.executor.inputs;
		}
		get outputs() {
			return this.executor.outputs;
		}
		get weights() {
			return this.executor.weightMap;
		}
		get metadata() {
			return this.artifacts.userDefinedMetadata;
		}
		get modelSignature() {
			return this.signature;
		}
		get modelStructuredOutputKeys() {
			return this.structuredOutputKeys;
		}
		constructor(e, t = {}, n = iT) {
			this.modelUrl = e, this.loadOptions = t, this.version = "n/a", this.io = n, t ?? (this.loadOptions = {}), this.resourceManager = new VA();
		}
		findIOHandler() {
			let e = this.modelUrl;
			if (e.load != null) this.handler = e;
			else if (this.loadOptions.requestInit != null) this.handler = this.io.browserHTTPRequest(e, this.loadOptions);
			else {
				let t = this.io.getLoadHandlers(e, this.loadOptions);
				if (t.length === 0) t.push(this.io.browserHTTPRequest(e, this.loadOptions));
				else if (t.length > 1) throw Error(`Found more than one (${t.length}) load handlers for URL '${[e]}'`);
				this.handler = t[0];
			}
		}
		load() {
			if (this.findIOHandler(), this.handler.load == null) throw Error("Cannot proceed with model loading because the IOHandler provided does not have the `load` method implemented.");
			let e = this.handler.load();
			return Ne(e) ? e.then((e) => e.getWeightStream == null ? this.loadSync(e) : this.loadStreaming(e)) : this.loadSync(e);
		}
		loadSync(e) {
			let t = this.io.decodeWeights(e.weightData, e.weightSpecs);
			return this.loadWithWeightMap(e, t);
		}
		async loadStreaming(e) {
			if (e.getWeightStream == null) throw Error("Model artifacts missing streamWeights function");
			let t = await $o(e.getWeightStream(), e.weightSpecs);
			return this.loadWithWeightMap(e, t);
		}
		loadWithWeightMap(e, t) {
			this.artifacts = e;
			let n = this.artifacts.modelTopology, r = this.artifacts.signature;
			if (this.artifacts.userDefinedMetadata != null) {
				let e = this.artifacts.userDefinedMetadata;
				e.signature != null && (r = e.signature), e.structuredOutputKeys != null && (this.structuredOutputKeys = e.structuredOutputKeys);
			}
			if (this.signature = r, this.version = `${n.versions.producer}.${n.versions.minConsumer}`, this.executor = new zA(pk.Instance.transformGraph(n, this.signature)), this.executor.weightMap = this.convertTensorMapToTensorsMap(t), this.executor.resourceManager = this.resourceManager, e.modelInitializer != null && e.modelInitializer.node != null) {
				let t = pk.Instance.transformGraph(e.modelInitializer);
				this.initializer = new zA(t), this.initializer.weightMap = this.executor.weightMap, this.initializer.resourceManager = this.resourceManager, this.initializerSignature = e.initializerSignature;
			}
			return !0;
		}
		async save(e, t) {
			if (typeof e == "string") {
				let t = this.io.getSaveHandlers(e);
				if (t.length === 0) throw Error(`Cannot find any save handlers for URL '${e}'`);
				if (t.length > 1) throw Error(`Found more than one (${t.length}) save handlers for URL '${e}'`);
				e = t[0];
			}
			if (e.save == null) throw Error("GraphModel.save() cannot proceed because the IOHandler provided does not have the `save` attribute defined.");
			return e.save(this.artifacts);
		}
		addStructuredOutputNames(e) {
			if (this.structuredOutputKeys) {
				let t = e instanceof O ? [e] : e, n = {};
				return t.forEach((e, t) => n[this.structuredOutputKeys[t]] = e), n;
			}
			return e;
		}
		predict(e, t) {
			let n = this.execute(e, this.outputNodes);
			return this.addStructuredOutputNames(n);
		}
		async predictAsync(e, t) {
			let n = await this.executeAsync(e, this.outputNodes);
			return this.addStructuredOutputNames(n);
		}
		normalizeInputs(e) {
			if (!(e instanceof O) && !Array.isArray(e)) {
				let t = this.signature?.inputs;
				if (t != null) for (let n in t) {
					let r = t[n];
					r.resourceId != null && (e[n] = this.resourceIdToCapturedInput[r.resourceId]);
				}
				return e;
			}
			e = Array.isArray(e) ? e : [e];
			let t = Object.keys(this.resourceIdToCapturedInput).length;
			if (e.length + t !== this.inputNodes.length) throw Error(`Input tensor count mismatch, the graph model has ${this.inputNodes.length - t} non-resource placeholders, while there are ${e.length} input tensors provided.`);
			let n = 0;
			return this.inputNodes.reduce((t, r) => {
				let i = this.signature?.inputs?.[r]?.resourceId;
				return t[r] = i == null ? e[n++] : this.resourceIdToCapturedInput[i], t;
			}, {});
		}
		normalizeOutputs(e) {
			return e ||= this.outputNodes, Array.isArray(e) ? e : [e];
		}
		executeInitializerGraph() {
			return this.initializer == null ? [] : this.initializerSignature == null ? this.initializer.execute({}, []) : this.initializer.execute({}, Object.keys(this.initializerSignature.outputs));
		}
		async executeInitializerGraphAsync() {
			return this.initializer == null ? [] : this.initializerSignature == null ? this.initializer.executeAsync({}, []) : this.initializer.executeAsync({}, Object.keys(this.initializerSignature.outputs));
		}
		setResourceIdToCapturedInput(e) {
			if (this.resourceIdToCapturedInput = {}, this.initializerSignature) {
				let t = this.initializerSignature.outputs, n = Object.keys(t);
				for (let r = 0; r < n.length; r++) {
					let i = t[n[r]];
					this.resourceIdToCapturedInput[i.resourceId] = e[r];
				}
			}
		}
		execute(e, t) {
			this.resourceIdToCapturedInput ?? this.setResourceIdToCapturedInput(this.executeInitializerGraph()), e = this.normalizeInputs(e), t = this.normalizeOutputs(t);
			let n = this.executor.execute(e, t);
			return n.length > 1 ? n : n[0];
		}
		async executeAsync(e, t) {
			this.resourceIdToCapturedInput ?? this.setResourceIdToCapturedInput(await this.executeInitializerGraphAsync()), e = this.normalizeInputs(e), t = this.normalizeOutputs(t);
			let n = await this.executor.executeAsync(e, t);
			return n.length > 1 ? n : n[0];
		}
		getIntermediateTensors() {
			return this.executor.getIntermediateTensors();
		}
		disposeIntermediateTensors() {
			this.executor.disposeIntermediateTensors();
		}
		convertTensorMapToTensorsMap(e) {
			return Object.keys(e).reduce((t, n) => (t[n] = [e[n]], t), {});
		}
		dispose() {
			this.executor.dispose(), this.initializer && (this.initializer.dispose(), this.resourceIdToCapturedInput && Po(this.resourceIdToCapturedInput)), this.resourceManager.dispose();
		}
	};
})), XA, ZA = e((() => {
	XA = "4.22.0";
})), QA = /* @__PURE__ */ n({
	GraphModel: () => JA,
	deregisterOp: () => zD,
	loadGraphModel: () => UA,
	loadGraphModelSync: () => WA,
	registerOp: () => LD,
	version_converter: () => XA
}), $A = e((() => {
	ND(), YA(), VD(), ZA();
}));
export { BE as $, ig as $a, Ud as $c, bo as $d, Ze as $f, c as $g, Yr as $h, nv as $i, _u as $l, qn as $m, ex as $n, Pm as $o, Qt as $p, Ey as $r, up as $s, TT as $t, Vc as $u, uD as A, Kg as Aa, xf as Ac, _s as Ad, ea as Af, be as Ag, Ar as Ah, Lv as Ai, $u as Al, wn as Am, XC as An, mh as Ao, Ot as Ap, rb as Ar, Kp as As, sE as At, vl as Au, rD as B, Tg as Ba, sf as Bc, Ho as Bd, _i as Bf, Oe as Bg, zr as Bh, Sv as Bi, Ru as Bl, Rn as Bm, CS as Bn, $m as Bo, Rt as Bp, Uy as Br, Mp as Bs, AT as Bt, ll as Bu, CD as C, x_ as Ca, kf as Cc, lc as Cd, Ta as Cf, f as Cg, li as Ch, Kv as Ci, sd as Cl, vn as Cm, ow as Cn, Sh as Co, xt as Cp, pb as Cr, tm as Cs, mE as Ct, G as Cu, hD as D, h_ as Da, Pf as Dc, is as Dd, Xi as Df, ue as Dg, Cr as Dh, Vv as Di, td as Dl, Sn as Dm, QC as Dn, _h as Do, Tt as Dp, ob as Dr, Xp as Ds, hE as Dt, bl as Du, mD as E, __ as Ea, Mf as Ec, Cs as Ed, ka as Ef, de as Eg, xr as Eh, Wv as Ei, ad as El, xn as Em, iw as En, vh as Eo, wt as Ep, sb as Er, Qp as Es, dE as Et, yl as Eu, pD as F, Ng as Fa, gf as Fc, Ao as Fd, Qi as Ff, Ne as Fg, Ir as Fh, kv as Fi, Uu as Fl, Mn as Fm, UC as Fn, sh as Fo, Mt as Fp, Zy as Fr, Rp as Fs, tE as Ft, ml as Fu, KE as G, vg as Ga, ef as Gc, No as Gd, yi as Gf, u as Gg, Ur as Gh, mv as Gi, ku as Gl, Hn as Gm, Zx as Gn, Km as Go, Ht as Gp, Ly as Gr, Sp as Gs, WT as Gt, $c as Gu, qE as H, Sg as Ha, rf as Hc, Ko as Hd, vi as Hf, ce as Hg, Vr as Hh, yv as Hi, Iu as Hl, zn as Hm, bS as Hn, Zm as Ho, Bt as Hp, By as Hr, kp as Hs, MT as Ht, ol as Hu, iD as I, jg as Ia, ff as Ic, Do as Id, Yi as If, _e as Ig, jr as Ih, Ov as Ii, Wu as Il, Pn as Im, YC as In, ah as Io, Nt as Ip, Yy as Ir, Lp as Is, $T as It, hl as Iu, VE as J, dg as Ja, Yd as Jc, Bo as Jd, hi as Jf, le as Jg, si as Jh, uv as Ji, Du as Jl, Gn as Jm, fx as Jn, Vm as Jo, qt as Jp, jy as Jr, bp as Js, ET as Jt, Zc as Ju, tD as K, mg as Ka, J as Kc, Ro as Kd, Si as Kf, x as Kg, Hr as Kh, pv as Ki, Au as Kl, Un as Km, Qx as Kn, Wm as Ko, Wt as Kp, Ny as Kr, Cp as Ks, GT as Kt, el as Ku, aD as L, Ag as La, pf as Lc, Eo as Ld, Hi as Lf, je as Lg, Pr as Lh, Ev as Li, Bu as Ll, In as Lm, HS as Ln, ih as Lo, Ft as Lp, Jy as Lr, Pp as Ls, eE as Lt, dl as Lu, dD as M, Lg as Ma, vf as Mc, ko as Md, D as Mf, Pe as Mg, Dr as Mh, Pv as Mi, Xu as Ml, En as Mm, qC as Mn, dh as Mo, At as Mp, tb as Mr, Up as Ms, aE as Mt, jl as Mu, cD as N, Ig as Na, yf as Nc, Oo as Nd, ra as Nf, ne as Ng, Or as Nh, Mv as Ni, Ku as Nl, On as Nm, WC as Nn, uh as No, jt as Np, eb as Nr, Vp as Ns, rE as Nt, Fl as Nu, gD as O, m_ as Oa, wf as Oc, Jo as Od, na as Of, me as Og, wr as Oh, Bv as Oi, nd as Ol, Dn as Om, ZC as On, gh as Oo, Et as Op, ab as Or, Yp as Os, pE as Ot, gl as Ou, lD as P, Pg as Pa, hf as Pc, Po as Pd, $i as Pf, ye as Pg, Er as Ph, jv as Pi, qu as Pl, jn as Pm, JC as Pn, ch as Po, Pt as Pp, Qy as Pr, Bp as Ps, nE as Pt, Al as Pu, HE as Q, ag as Qa, qd as Qc, Io as Qd, Xe as Qf, s as Qg, Jr as Qh, iv as Qi, xu as Ql, Xn as Qm, ix as Qn, Fm as Qo, Zt as Qp, Dy as Qr, mp as Qs, wT as Qt, Gc as Qu, oD as R, Og as Ra, lf as Rc, jo as Rd, Ji as Rf, De as Rg, Lr as Rh, Tv as Ri, Vu as Rl, Ln as Rm, US as Rn, nh as Ro, It as Rp, Ky as Rr, Fp as Rs, QT as Rt, fl as Ru, xD as S, C_ as Sa, Of as Sc, hc as Sd, O as Sf, he as Sg, vr as Sh, Yv as Si, dd as Sl, _n as Sm, aw as Sn, Ch as So, bt as Sp, fb as Sr, rm as Ss, _E as St, zl as Su, _D as T, v_ as Ta, Nf as Tc, xs as Td, wa as Tf, Ee as Tg, br as Th, Uv as Ti, id as Tl, bn as Tm, rw as Tn, yh as To, Ct as Tp, lb as Tr, $p as Ts, fE as Tt, Pl as Tu, GE as U, xg as Ua, nf as Uc, Fo as Ud, Di as Uf, oe as Ug, Fr as Uh, _v as Ui, Mu as Ul, Bn as Um, rS as Un, Xm as Uo, Vt as Up, zy as Ur, Tp as Us, XT as Ut, nl as Uu, nD as V, wg as Va, of as Vc, zo as Vd, gi as Vf, p as Vg, Br as Vh, bv as Vi, Fu as Vl, Nn as Vm, xS as Vn, Qm as Vo, zt as Vp, Hy as Vr, Op as Vs, UT as Vt, al as Vu, JE as W, yg as Wa, $d as Wc, Mo as Wd, bi as Wf, ae as Wg, Mr as Wh, gv as Wi, Nu as Wl, Vn as Wm, Xx as Wn, qm as Wo, Ut as Wp, Iy as Wr, Ep as Ws, HT as Wt, rl as Wu, zE as X, cg as Xa, Zd as Xc, Go as Xd, Je as Xf, m as Xg, Kr as Xh, sv as Xi, wu as Xl, Jn as Xm, lx as Xn, Rm as Xo, Xt as Xp, ky as Xr, gp as Xs, DT as Xt, Jc as Xu, RE as Y, ug as Ya, Xd as Yc, Lo as Yd, pi as Yf, h as Yg, Gr as Yh, cv as Yi, Cu as Yl, Kn as Ym, ux as Yn, Bm as Yo, Jt as Yp, Ay as Yr, _p as Ys, OT as Yt, qc as Yu, UE as Z, sg as Za, Kd as Zc, L as Zd, Ye as Zf, Te as Zg, qr as Zh, av as Zi, bu as Zl, Yn as Zm, rx as Zn, Lm as Zo, Yt as Zp, Oy as Zr, pp as Zs, dT as Zt, Wc as Zu, wD as _, k_ as _a, Bf as _c, yc as _d, Va as _f, w as _g, fr as _h, ny as _i, gd as _l, mn as _m, fw as _n, jh as _o, ht as _p, xb as _r, um as _s, wE as _t, Wl as _u, JA as a, q_ as aa, np as ac, Mc as ad, F as af, $r as ag, nr as ah, by as ai, Pd as al, an as am, Yw as an, Yh as ao, rt as ap, Bb as ar, Em as as, ME as at, ou as au, DD as b, E_ as ba, If as bc, _c as bd, ja as bf, v as bg, pr as bh, Qv as bi, md as bl, kn as bm, sw as bn, Eh as bo, vt as bp, gb as br, om as bs, yE as bt, Hl as bu, WA as c, U_ as ca, X as cc, H as cd, $a as cf, ni as cg, ar as ch, gy as ci, Md as cl, di as cm, yw as cn, Wh as co, st as cp, Ib as cr, xm as cs, kE as ct, iu as cu, LD as d, R_ as da, qf as dc, Ec as dd, no as df, ai as dg, cr as dh, dy as di, Td as dl, sn as dm, vw as dn, Bh as do, ut as dp, Fb as dr, dm as ds, EE as dt, Ql as du, l as e_, tv as ea, dp as ec, Hc as ed, yo as ef, Nr as eg, Qn as eh, Ty as ei, Wd as el, $t as em, uT as en, ng as eo, Qe as ep, tx as er, Mm as es, WE as et, vu as eu, jD as f, L_ as fa, Kf as fc, Dc as fd, j as ff, oi as fg, lr as fh, uy as fi, Ed as fl, ln as fm, hw as fn, Rh as fo, dt as fp, kb as fr, fm as fs, OE as ft, q as fu, OD as g, j_ as ga, Hf as gc, xc as gd, Ua as gf, Be as gg, _r as gh, iy as gi, bd as gl, pn as gm, dw as gn, Mh as go, mt as gp, Sb as gr, hm as gs, CE as gt, K as gu, kD as h, M_ as ha, Uf as hc, Sc as hd, A as hf, Ve as hg, dr as hh, ay as hi, yd as hl, dn as hm, mw as hn, Ph as ho, pt as hp, Eb as hr, mm as hs, SE as ht, ql as hu, XA as i, Y_ as ia, ap as ic, Ic as id, I as if, Qr as ig, tr as ih, xy as ii, Rd as il, rn as im, Ww as in, Xh as io, nt as ip, Wb as ir, Dm as is, jE as it, fu as iu, fD as j, Gg as ja, Sf as jc, Wo as jd, ia as jf, se as jg, kr as jh, Fv as ji, Yu as jl, Tn as jm, KC as jn, ph as jo, kt as jp, nb as jr, Wp as js, cE as jt, Nl as ju, vD as k, s_ as ka, Tf as kc, qo as kd, ta as kf, Me as kg, Tr as kh, Rv as ki, Qu as kl, Cn as km, GC as kn, hh as ko, Dt as kp, ib as kr, qp as ks, oE as kt, _l as ku, zD as l, V_ as la, Xf as lc, V as ld, ao as lf, ri as lg, or as lh, my as li, Od as ll, fi as lm, bw as ln, Uh as lo, ot as lp, Rb as lr, bm as ls, FE as lt, tu as lu, AD as m, P_ as ma, Y as mc, B as md, Wa as mf, T as mg, ur as mh, sy as mi, Cd as ml, fn as mm, pw as mn, Fh as mo, ft as mp, Db as mr, pm as ms, bE as mt, Yl as mu, $A as n, Q_ as na, cp as nc, zc as nd, go as nf, Zr as ng, $n as nh, Cy as ni, Vd as nl, tn as nm, aT as nn, $h as no, et as np, Qb as nr, km as ns, LE as nt, hu as nu, YA as o, K_ as oa, tp as oc, Nc as od, N as of, ei as og, rr as oh, yy as oi, Fd as ol, ci as om, Bw as on, qh as oo, it as op, Vb as or, wm as os, NE as ot, su as ou, MD as p, F_ as pa, Wf as pc, z as pd, M as pf, ui as pg, Gt as ph, cy as pi, Sd as pl, un as pm, gw as pn, Lh as po, lt as pp, Ab as pr, vm as ps, xE as pt, Xl as pu, YE as q, pg as qa, Jd as qc, Uo as qd, xi as qf, C as qg, Wr as qh, dv as qi, Eu as ql, Wn as qm, dx as qn, Um as qo, Kt as qp, My as qr, yp as qs, kT as qt, Xc as qu, ZA as r, X_ as ra, ip as rc, Fc as rd, po as rf, Sr as rg, er as rh, Sy as ri, Ld as rl, nn as rm, iT as rn, Qh as ro, tt as rp, Ub as rr, Z as rs, AE as rt, du as ru, UA as s, W_ as sa, Qf as sc, U as sd, P as sf, ti as sg, ir as sh, _y as si, jd as sl, on as sm, Rw as sn, Kh as so, at as sp, Lb as sr, Cm as ss, PE as st, ru as su, QA as t, $_ as ta, sp as tc, Rc as td, ho as tf, Xr as tg, Zn as th, wy as ti, Bd as tl, en as tm, lT as tn, tg as to, $e as tp, Zb as tr, jm as ts, IE as tt, mu as tu, VD as u, B_ as ua, Yf as uc, kc as ud, ro as uf, ii as ug, sr as uh, py as ui, kd as ul, cn as um, _w as un, Vh as uo, ct as up, Pb as ur, gm as us, DE as ut, eu as uu, ED as v, O_ as va, zf as vc, bc as vd, Pa as vf, He as vg, hr as vh, ty as vi, _d as vl, hn as vm, lw as vn, kh as vo, _t as vp, yb as vr, lm as vs, TE as vt, Gl as vu, bD as w, b_ as wa, jf as wc, Ss as wd, Oa as wf, Ce as wg, yr as wh, qv as wi, cd as wl, yn as wm, nw as wn, bh as wo, St as wp, ub as wr, em as ws, uE as wt, W as wu, SD as x, w_ as xa, Af as xc, mc as xd, Aa as xf, y as xg, mr as xh, Xv as xi, ud as xl, An as xm, cw as xn, Th as xo, yt as xp, hb as xr, im as xs, gE as xt, Rl as xu, TD as y, D_ as ya, Lf as yc, R as yd, Ba as yf, S as yg, gr as yh, $v as yi, pd as yl, gn as ym, uw as yn, Oh as yo, gt as yp, vb as yr, sm as ys, vE as yt, Vl as yu, sD as z, Dg as za, uf as zc, Vo as zd, Ci as zf, ke as zg, Rr as zh, Cv as zi, Lu as zl, Fn as zm, wS as zn, th as zo, Lt as zp, Gy as zr, jp as zs, ZT as zt, cl as zu };
